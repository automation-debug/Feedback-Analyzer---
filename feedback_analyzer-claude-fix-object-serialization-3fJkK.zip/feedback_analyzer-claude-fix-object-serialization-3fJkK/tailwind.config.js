/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        score: {
          excellent: '#53815F',
          good: '#AECF76',
          average: '#EBCB6B',
          below: '#D68A77',
          critical: '#AA392D'
        }
      }
    },
  },
  plugins: [],
}
