import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  Mail,
  Upload,
  FileSpreadsheet,
  Send,
  Eye,
  EyeOff,
  Paperclip,
  Link2,
  X,
  Check,
  AlertCircle,
  Loader2,
  ArrowLeft,
  Users,
  Plus,
  Trash2,
  Settings,
  Bold,
  Italic,
  Underline,
  AlignRight,
  AlignCenter,
  AlignLeft,
  Type,
  Smile,
  ChevronDown,
  ExternalLink,
  FolderOpen,
  FileText,
  CheckCircle2,
  XCircle,
  Clock
} from 'lucide-react';
import * as XLSX from 'xlsx';

// Gmail-compatible fonts
const GMAIL_FONTS = [
  { name: 'Arial', value: 'Arial, sans-serif' },
  { name: 'Comic Sans MS', value: '"Comic Sans MS", cursive' },
  { name: 'Courier New', value: '"Courier New", monospace' },
  { name: 'Georgia', value: 'Georgia, serif' },
  { name: 'Impact', value: 'Impact, sans-serif' },
  { name: 'Tahoma', value: 'Tahoma, sans-serif' },
  { name: 'Times New Roman', value: '"Times New Roman", serif' },
  { name: 'Trebuchet MS', value: '"Trebuchet MS", sans-serif' },
  { name: 'Verdana', value: 'Verdana, sans-serif' },
];

const FONT_SIZES = [
  { name: 'صغير', value: '10px' },
  { name: 'عادي', value: '14px' },
  { name: 'متوسط', value: '18px' },
  { name: 'كبير', value: '22px' },
  { name: 'ضخم', value: '28px' },
];

// Common emojis for emails
const EMOJI_CATEGORIES = {
  'وجوه': ['😊', '😃', '😄', '🙂', '😉', '🤝', '👍', '👏', '🙏', '💪', '✨', '🌟', '⭐', '🎉', '🎊'],
  'أعمال': ['📧', '📩', '📨', '💼', '📁', '📂', '📊', '📈', '📋', '✅', '❌', '⏰', '📅', '🔔', '💡'],
  'رموز': ['❤️', '💙', '💚', '💛', '🔵', '🟢', '🟡', '🔴', '⚪', '⚫', '▶️', '◀️', '🔗', '📌', '🏆'],
};

/**
 * EmailAutomation Component
 * Handles bulk email sending through webhooks
 */
const EmailAutomation = ({ onBack }) => {
  // Recipients data
  const [recipients, setRecipients] = useState([]);
  const [recipientsFile, setRecipientsFile] = useState(null);

  // Email content
  const [subject, setSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');
  const [bodyHtml, setBodyHtml] = useState('');

  // Formatting state
  const [currentFont, setCurrentFont] = useState(GMAIL_FONTS[0]);
  const [currentSize, setCurrentSize] = useState(FONT_SIZES[1]);
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isUnderline, setIsUnderline] = useState(false);
  const [alignment, setAlignment] = useState('right');
  const [textColor, setTextColor] = useState('#000000');

  // Dropdowns
  const [showFontDropdown, setShowFontDropdown] = useState(false);
  const [showSizeDropdown, setShowSizeDropdown] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);

  // Attachments
  const [attachmentType, setAttachmentType] = useState('files'); // 'files' or 'gdrive'
  const [attachmentFiles, setAttachmentFiles] = useState([]);
  const [gdriveLink, setGdriveLink] = useState('');

  // Webhook - load from localStorage
  const [webhookUrl, setWebhookUrl] = useState(() => {
    try {
      return localStorage.getItem('emailWebhookUrl') || '';
    } catch {
      return '';
    }
  });
  const [showWebhookSettings, setShowWebhookSettings] = useState(false);

  // Column mapping info
  const [detectedColumns, setDetectedColumns] = useState({ email: null, cc: null, name: null });

  // Preview
  const [showPreview, setShowPreview] = useState(false);
  const [selectedRecipient, setSelectedRecipient] = useState(null);

  // Sending state
  const [isSending, setIsSending] = useState(false);
  const [sendProgress, setSendProgress] = useState({ sent: 0, failed: 0, total: 0 });
  const [sendResults, setSendResults] = useState([]);
  const [sendComplete, setSendComplete] = useState(false);

  // Refs
  const editorRef = useRef(null);
  const fileInputRef = useRef(null);
  const attachmentInputRef = useRef(null);

  // Save webhook URL to localStorage when it changes
  useEffect(() => {
    try {
      if (webhookUrl) {
        localStorage.setItem('emailWebhookUrl', webhookUrl);
      }
    } catch (e) {
      console.warn('Could not save webhook URL to localStorage:', e);
    }
  }, [webhookUrl]);

  // Parse recipients Excel file
  const handleRecipientsUpload = useCallback((e) => {
    const file = e.target.files[0];
    if (!file) return;

    setRecipientsFile(file);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        // Get all column headers from first row
        const allColumns = Object.keys(jsonData[0] || {});

        // Try to find email column
        const emailKey = allColumns.find(k =>
          k.toLowerCase().includes('email') ||
          k.toLowerCase().includes('بريد') ||
          k.toLowerCase().includes('الإيميل') ||
          k.toLowerCase().includes('mail')
        );

        // Try to find CC column
        const ccKey = allColumns.find(k =>
          k.toLowerCase().includes('cc') ||
          k.toLowerCase().includes('manager') ||
          k.toLowerCase().includes('مدير') ||
          k.toLowerCase().includes('نسخة')
        );

        // Try to find name column
        const nameKey = allColumns.find(k =>
          k.toLowerCase().includes('name') ||
          k.toLowerCase().includes('اسم') ||
          k.toLowerCase().includes('الموظف') ||
          k.toLowerCase().includes('الاسم')
        );

        // Save detected columns for display
        setDetectedColumns({
          email: emailKey || null,
          cc: ccKey || null,
          name: nameKey || null,
          allColumns: allColumns
        });

        // Map columns - looking for email, cc, name columns
        const mappedRecipients = jsonData.map((row, index) => {
          return {
            id: index + 1,
            email: row[emailKey] || '',
            cc: row[ccKey] || '',
            name: row[nameKey] || `مستلم ${index + 1}`,
            status: 'pending' // pending, sending, sent, failed
          };
        }).filter(r => r.email); // Only keep rows with email

        setRecipients(mappedRecipients);

        if (!emailKey) {
          alert('تحذير: لم يتم العثور على عمود البريد الإلكتروني. تأكد من وجود عمود يحتوي على "email" أو "بريد"');
        }
      } catch (error) {
        console.error('Error parsing file:', error);
        alert('حدث خطأ في قراءة الملف. تأكد من صيغة الملف.');
      }
    };

    reader.readAsArrayBuffer(file);
  }, []);

  // Handle attachment files upload
  const handleAttachmentsUpload = useCallback((e) => {
    const files = Array.from(e.target.files);
    const pdfFiles = files.filter(f => f.type === 'application/pdf');

    // Convert files to base64 for sending
    Promise.all(pdfFiles.map(file => {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          resolve({
            name: file.name,
            size: file.size,
            data: e.target.result.split(',')[1], // Base64 data
            type: 'application/pdf'
          });
        };
        reader.readAsDataURL(file);
      });
    })).then(processedFiles => {
      setAttachmentFiles(prev => [...prev, ...processedFiles]);
    });
  }, []);

  // Remove attachment
  const removeAttachment = (index) => {
    setAttachmentFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Apply formatting to editor
  const applyFormat = (command, value = null) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    updateBodyHtml();
  };

  // Update HTML from editor
  const updateBodyHtml = () => {
    if (editorRef.current) {
      setBodyHtml(editorRef.current.innerHTML);
      setEmailBody(editorRef.current.innerText);
    }
  };

  // Insert emoji
  const insertEmoji = (emoji) => {
    if (editorRef.current) {
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      const textNode = document.createTextNode(emoji);
      range.insertNode(textNode);
      range.setStartAfter(textNode);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
      updateBodyHtml();
    }
    setShowEmojiPicker(false);
  };

  // Send emails via webhook
  const sendEmails = async () => {
    if (!webhookUrl) {
      alert('يرجى إدخال رابط Webhook في الإعدادات');
      setShowWebhookSettings(true);
      return;
    }

    if (recipients.length === 0) {
      alert('يرجى رفع ملف المستلمين أولاً');
      return;
    }

    if (!subject.trim()) {
      alert('يرجى إدخال عنوان البريد');
      return;
    }

    setIsSending(true);
    setSendComplete(false);
    setSendProgress({ sent: 0, failed: 0, total: recipients.length });
    setSendResults([]);

    const results = [];

    for (let i = 0; i < recipients.length; i++) {
      const recipient = recipients[i];

      // Update status to sending
      setRecipients(prev => prev.map(r =>
        r.id === recipient.id ? { ...r, status: 'sending' } : r
      ));

      try {
        const payload = {
          to: recipient.email,
          cc: recipient.cc || undefined,
          subject: subject,
          body: bodyHtml || emailBody,
          recipientName: recipient.name,
          attachments: attachmentType === 'files'
            ? attachmentFiles.map(f => ({ name: f.name, data: f.data, type: f.type }))
            : undefined,
          gdriveLink: attachmentType === 'gdrive' ? gdriveLink : undefined
        };

        const response = await fetch(webhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          // Update status to sent
          setRecipients(prev => prev.map(r =>
            r.id === recipient.id ? { ...r, status: 'sent' } : r
          ));
          setSendProgress(prev => ({ ...prev, sent: prev.sent + 1 }));
          results.push({ ...recipient, status: 'sent', error: null });
        } else {
          throw new Error(`HTTP ${response.status}`);
        }
      } catch (error) {
        // Update status to failed
        setRecipients(prev => prev.map(r =>
          r.id === recipient.id ? { ...r, status: 'failed', error: error.message } : r
        ));
        setSendProgress(prev => ({ ...prev, failed: prev.failed + 1 }));
        results.push({ ...recipient, status: 'failed', error: error.message });
      }

      // Small delay between sends
      if (i < recipients.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    setSendResults(results);
    setIsSending(false);
    setSendComplete(true);
  };

  // Reset all
  const handleReset = () => {
    setRecipients([]);
    setRecipientsFile(null);
    setSubject('');
    setEmailBody('');
    setBodyHtml('');
    setAttachmentFiles([]);
    setGdriveLink('');
    setSendComplete(false);
    setSendResults([]);
    setSendProgress({ sent: 0, failed: 0, total: 0 });
    if (editorRef.current) {
      editorRef.current.innerHTML = '';
    }
  };

  // Colors for color picker
  const COLORS = [
    '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#efefef', '#f3f3f3', '#ffffff',
    '#980000', '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#4a86e8', '#0000ff', '#9900ff', '#ff00ff',
    '#e6b8af', '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#c9daf8', '#cfe2f3', '#d9d2e9', '#ead1dc',
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-l from-emerald-600 to-teal-700 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-xl">
                <Mail className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">أتمتة إرسال البريد الإلكتروني</h1>
                <p className="text-emerald-100 text-sm mt-1">
                  إرسال رسائل بريدية جماعية عبر Webhook
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {/* Webhook Status Badge */}
              <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm ${webhookUrl ? 'bg-emerald-500/30 text-emerald-100' : 'bg-red-500/30 text-red-100'}`}>
                <div className={`w-2 h-2 rounded-full ${webhookUrl ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}></div>
                {webhookUrl ? 'Webhook متصل' : 'غير متصل'}
              </div>
              <button
                onClick={() => setShowWebhookSettings(true)}
                className="flex items-center gap-2 bg-white/20 hover:bg-white/30 px-4 py-2 rounded-xl transition-colors"
              >
                <Settings className="w-4 h-4" />
                الإعدادات
              </button>
              <button
                onClick={onBack}
                className="flex items-center gap-2 bg-white/20 hover:bg-white/30 px-4 py-2 rounded-xl transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                رجوع
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6">
          {/* Send Complete Results */}
          {sendComplete && (
            <div className="mb-6 p-6 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  تم الانتهاء من الإرسال
                </h3>
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 rounded-lg text-sm font-medium transition-colors"
                >
                  إرسال جديد
                </button>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200 text-center">
                  <div className="text-3xl font-bold text-slate-800">{sendProgress.total}</div>
                  <div className="text-sm text-slate-500">إجمالي</div>
                </div>
                <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-200 text-center">
                  <div className="text-3xl font-bold text-emerald-600">{sendProgress.sent}</div>
                  <div className="text-sm text-emerald-600">تم إرساله</div>
                </div>
                <div className="bg-red-50 p-4 rounded-xl border border-red-200 text-center">
                  <div className="text-3xl font-bold text-red-600">{sendProgress.failed}</div>
                  <div className="text-sm text-red-600">فشل</div>
                </div>
              </div>
              {sendResults.filter(r => r.status === 'failed').length > 0 && (
                <div className="bg-red-50 p-4 rounded-xl border border-red-200">
                  <h4 className="font-medium text-red-800 mb-2">الرسائل الفاشلة:</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {sendResults.filter(r => r.status === 'failed').map((r, i) => (
                      <div key={i} className="text-sm text-red-700 flex items-center gap-2">
                        <XCircle className="w-4 h-4 flex-shrink-0" />
                        <span>{r.email}: {r.error}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Enhanced Progress Bar */}
          {isSending && (
            <div className="mb-6 p-6 bg-gradient-to-l from-indigo-50 to-purple-50 rounded-2xl border border-indigo-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-indigo-800 font-bold text-lg flex items-center gap-3">
                  <div className="relative">
                    <Loader2 className="w-6 h-6 animate-spin text-indigo-600" />
                    <div className="absolute inset-0 w-6 h-6 bg-indigo-400 rounded-full animate-ping opacity-20"></div>
                  </div>
                  جارٍ إرسال البريد الإلكتروني...
                </span>
                <span className="text-indigo-700 font-bold text-xl">
                  {Math.round(((sendProgress.sent + sendProgress.failed) / sendProgress.total) * 100)}%
                </span>
              </div>

              {/* Current recipient being processed */}
              {recipients.find(r => r.status === 'sending') && (
                <div className="bg-white/70 rounded-lg p-3 mb-4 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-indigo-500 animate-pulse" />
                  <span className="text-sm text-slate-600">جارٍ الإرسال إلى:</span>
                  <span className="text-sm font-medium text-indigo-700">{recipients.find(r => r.status === 'sending')?.email}</span>
                </div>
              )}

              <div className="w-full bg-indigo-200/50 rounded-full h-4 overflow-hidden">
                <div
                  className="bg-gradient-to-l from-indigo-600 to-purple-600 h-4 rounded-full transition-all duration-500 ease-out relative"
                  style={{ width: `${((sendProgress.sent + sendProgress.failed) / sendProgress.total) * 100}%` }}
                >
                  <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-4">
                <div className="bg-white/70 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-slate-700">{sendProgress.total}</div>
                  <div className="text-xs text-slate-500">إجمالي</div>
                </div>
                <div className="bg-emerald-100/70 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-emerald-600">{sendProgress.sent}</div>
                  <div className="text-xs text-emerald-600">تم الإرسال ✓</div>
                </div>
                <div className="bg-red-100/70 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-red-600">{sendProgress.failed}</div>
                  <div className="text-xs text-red-600">فشل ✗</div>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column - Recipients & Attachments */}
            <div className="space-y-6">
              {/* Recipients Upload */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  المستلمون
                </h3>

                {recipients.length === 0 ? (
                  <div>
                    {/* Excel Format Explanation */}
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4">
                      <h4 className="font-medium text-amber-800 mb-2 flex items-center gap-2">
                        <FileSpreadsheet className="w-4 h-4" />
                        صيغة ملف Excel المطلوبة
                      </h4>
                      <div className="text-sm text-amber-700 space-y-1">
                        <p><strong>الأعمدة المطلوبة:</strong></p>
                        <ul className="list-disc list-inside mr-2 space-y-1">
                          <li><span className="text-red-600">*</span> <strong>البريد الإلكتروني:</strong> email, بريد, الإيميل, mail</li>
                          <li><strong>الاسم (اختياري):</strong> name, اسم, الموظف, الاسم</li>
                          <li><strong>CC (اختياري):</strong> cc, manager, مدير, نسخة</li>
                        </ul>
                      </div>
                      <div className="mt-3 bg-white rounded-lg border border-amber-200 overflow-hidden">
                        <table className="w-full text-xs">
                          <thead className="bg-amber-100">
                            <tr>
                              <th className="px-2 py-1 text-right">الاسم</th>
                              <th className="px-2 py-1 text-right">email</th>
                              <th className="px-2 py-1 text-right">cc</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-t border-amber-100">
                              <td className="px-2 py-1 text-slate-600">أحمد محمد</td>
                              <td className="px-2 py-1 text-slate-600" dir="ltr">ahmed@email.com</td>
                              <td className="px-2 py-1 text-slate-600" dir="ltr">manager@email.com</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center cursor-pointer hover:border-indigo-500 hover:bg-indigo-50/50 transition-all"
                    >
                      <Upload className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                      <p className="text-slate-600 font-medium mb-2">اسحب ملف Excel هنا أو انقر للرفع</p>
                      <p className="text-slate-400 text-sm">
                        يدعم: .xlsx, .xls, .csv
                      </p>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm text-slate-600 flex items-center gap-2">
                        <FileSpreadsheet className="w-4 h-4" />
                        {recipientsFile?.name}
                      </span>
                      <button
                        onClick={() => { setRecipients([]); setRecipientsFile(null); setDetectedColumns({ email: null, cc: null, name: null }); }}
                        className="text-red-500 hover:text-red-700 text-sm flex items-center gap-1"
                      >
                        <Trash2 className="w-4 h-4" />
                        إزالة
                      </button>
                    </div>

                    {/* Column Detection Preview */}
                    <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-3 mb-3">
                      <h4 className="text-sm font-medium text-indigo-800 mb-2">الأعمدة المكتشفة:</h4>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div className={`p-2 rounded-lg ${detectedColumns.email ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                          <span className="font-medium">البريد:</span>
                          <span className="block truncate">{detectedColumns.email || 'غير موجود ❌'}</span>
                        </div>
                        <div className={`p-2 rounded-lg ${detectedColumns.name ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                          <span className="font-medium">الاسم:</span>
                          <span className="block truncate">{detectedColumns.name || 'افتراضي'}</span>
                        </div>
                        <div className={`p-2 rounded-lg ${detectedColumns.cc ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                          <span className="font-medium">CC:</span>
                          <span className="block truncate">{detectedColumns.cc || 'لا يوجد'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white rounded-xl border border-slate-200 max-h-60 overflow-y-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-slate-100 sticky top-0">
                          <tr>
                            <th className="px-3 py-2 text-right font-medium text-slate-600">الاسم</th>
                            <th className="px-3 py-2 text-right font-medium text-slate-600">البريد</th>
                            <th className="px-3 py-2 text-right font-medium text-slate-600">CC</th>
                            <th className="px-3 py-2 text-center font-medium text-slate-600">الحالة</th>
                          </tr>
                        </thead>
                        <tbody>
                          {recipients.map((r) => (
                            <tr key={r.id} className="border-t border-slate-100">
                              <td className="px-3 py-2 text-slate-800">{r.name}</td>
                              <td className="px-3 py-2 text-slate-600 text-xs">{r.email}</td>
                              <td className="px-3 py-2 text-slate-500 text-xs">{r.cc || '-'}</td>
                              <td className="px-3 py-2 text-center">
                                {r.status === 'pending' && <Clock className="w-4 h-4 text-slate-400 mx-auto" />}
                                {r.status === 'sending' && <Loader2 className="w-4 h-4 text-indigo-500 animate-spin mx-auto" />}
                                {r.status === 'sent' && <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto" />}
                                {r.status === 'failed' && <XCircle className="w-4 h-4 text-red-500 mx-auto" />}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      إجمالي {recipients.length} مستلم
                    </p>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleRecipientsUpload}
                  className="hidden"
                />
              </div>

              {/* Attachments */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <Paperclip className="w-5 h-5 text-indigo-600" />
                  المرفقات
                </h3>

                {/* Attachment Type Tabs */}
                <div className="flex gap-2 mb-4">
                  <button
                    onClick={() => setAttachmentType('files')}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                      attachmentType === 'files'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <FileText className="w-4 h-4" />
                    ملفات PDF
                  </button>
                  <button
                    onClick={() => setAttachmentType('gdrive')}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                      attachmentType === 'gdrive'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <FolderOpen className="w-4 h-4" />
                    رابط Google Drive
                  </button>
                </div>

                {attachmentType === 'files' ? (
                  <div>
                    <div
                      onClick={() => attachmentInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center cursor-pointer hover:border-indigo-500 hover:bg-indigo-50/50 transition-all"
                    >
                      <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-slate-600 text-sm">انقر لرفع ملفات PDF</p>
                    </div>
                    <input
                      ref={attachmentInputRef}
                      type="file"
                      accept=".pdf"
                      multiple
                      onChange={handleAttachmentsUpload}
                      className="hidden"
                    />
                    {attachmentFiles.length > 0 && (
                      <div className="mt-3 space-y-2">
                        {attachmentFiles.map((file, i) => (
                          <div key={i} className="flex items-center justify-between bg-white p-3 rounded-lg border border-slate-200">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-red-500" />
                              <span className="text-sm text-slate-700">{file.name}</span>
                              <span className="text-xs text-slate-400">
                                ({(file.size / 1024).toFixed(1)} KB)
                              </span>
                            </div>
                            <button
                              onClick={() => removeAttachment(i)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 relative">
                        <Link2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input
                          type="url"
                          value={gdriveLink}
                          onChange={(e) => setGdriveLink(e.target.value)}
                          placeholder="https://drive.google.com/..."
                          className="w-full pr-10 pl-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          dir="ltr"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      أدخل رابط مجلد Google Drive المشترك الذي يحتوي على المرفقات
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column - Email Composer */}
            <div className="space-y-6">
              {/* Subject */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  عنوان البريد
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="أدخل عنوان البريد الإلكتروني"
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              {/* Rich Text Editor */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-slate-700">
                    محتوى البريد
                  </label>
                  <button
                    onClick={() => setShowPreview(!showPreview)}
                    className="text-sm text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                  >
                    {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {showPreview ? 'إخفاء المعاينة' : 'معاينة Gmail'}
                  </button>
                </div>

                {/* Formatting Toolbar */}
                <div className="flex flex-wrap items-center gap-1 p-2 bg-slate-100 rounded-t-xl border border-slate-200 border-b-0">
                  {/* Font Family */}
                  <div className="relative">
                    <button
                      onClick={() => { setShowFontDropdown(!showFontDropdown); setShowSizeDropdown(false); setShowEmojiPicker(false); }}
                      className="flex items-center gap-1 px-2 py-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-sm"
                    >
                      <Type className="w-4 h-4" />
                      <span className="max-w-20 truncate">{currentFont.name}</span>
                      <ChevronDown className="w-3 h-3" />
                    </button>
                    {showFontDropdown && (
                      <div className="absolute top-full right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-20 w-48 max-h-60 overflow-y-auto">
                        {GMAIL_FONTS.map((font) => (
                          <button
                            key={font.name}
                            onClick={() => {
                              setCurrentFont(font);
                              applyFormat('fontName', font.value);
                              setShowFontDropdown(false);
                            }}
                            className="w-full px-3 py-2 text-right hover:bg-slate-100 text-sm"
                            style={{ fontFamily: font.value }}
                          >
                            {font.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Font Size */}
                  <div className="relative">
                    <button
                      onClick={() => { setShowSizeDropdown(!showSizeDropdown); setShowFontDropdown(false); setShowEmojiPicker(false); }}
                      className="flex items-center gap-1 px-2 py-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-sm"
                    >
                      <span>{currentSize.name}</span>
                      <ChevronDown className="w-3 h-3" />
                    </button>
                    {showSizeDropdown && (
                      <div className="absolute top-full right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-20 w-32">
                        {FONT_SIZES.map((size) => (
                          <button
                            key={size.name}
                            onClick={() => {
                              setCurrentSize(size);
                              applyFormat('fontSize', FONT_SIZES.indexOf(size) + 1);
                              setShowSizeDropdown(false);
                            }}
                            className="w-full px-3 py-2 text-right hover:bg-slate-100 text-sm"
                          >
                            {size.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="w-px h-6 bg-slate-300 mx-1" />

                  {/* Bold */}
                  <button
                    onClick={() => { setIsBold(!isBold); applyFormat('bold'); }}
                    className={`p-1.5 rounded-lg transition-colors ${isBold ? 'bg-indigo-100 text-indigo-700' : 'hover:bg-slate-200'}`}
                  >
                    <Bold className="w-4 h-4" />
                  </button>

                  {/* Italic */}
                  <button
                    onClick={() => { setIsItalic(!isItalic); applyFormat('italic'); }}
                    className={`p-1.5 rounded-lg transition-colors ${isItalic ? 'bg-indigo-100 text-indigo-700' : 'hover:bg-slate-200'}`}
                  >
                    <Italic className="w-4 h-4" />
                  </button>

                  {/* Underline */}
                  <button
                    onClick={() => { setIsUnderline(!isUnderline); applyFormat('underline'); }}
                    className={`p-1.5 rounded-lg transition-colors ${isUnderline ? 'bg-indigo-100 text-indigo-700' : 'hover:bg-slate-200'}`}
                  >
                    <Underline className="w-4 h-4" />
                  </button>

                  <div className="w-px h-6 bg-slate-300 mx-1" />

                  {/* Text Color */}
                  <div className="relative">
                    <button
                      onClick={() => { setShowColorPicker(!showColorPicker); setShowEmojiPicker(false); }}
                      className="p-1.5 rounded-lg hover:bg-slate-200 flex items-center gap-1"
                    >
                      <div className="w-4 h-4 rounded border border-slate-300" style={{ backgroundColor: textColor }} />
                      <ChevronDown className="w-3 h-3" />
                    </button>
                    {showColorPicker && (
                      <div className="absolute top-full right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-20 p-2 w-52">
                        <div className="grid grid-cols-10 gap-1">
                          {COLORS.map((color) => (
                            <button
                              key={color}
                              onClick={() => {
                                setTextColor(color);
                                applyFormat('foreColor', color);
                                setShowColorPicker(false);
                              }}
                              className="w-4 h-4 rounded border border-slate-200 hover:scale-125 transition-transform"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="w-px h-6 bg-slate-300 mx-1" />

                  {/* Alignment */}
                  <button
                    onClick={() => { setAlignment('right'); applyFormat('justifyRight'); }}
                    className={`p-1.5 rounded-lg transition-colors ${alignment === 'right' ? 'bg-indigo-100 text-indigo-700' : 'hover:bg-slate-200'}`}
                  >
                    <AlignRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { setAlignment('center'); applyFormat('justifyCenter'); }}
                    className={`p-1.5 rounded-lg transition-colors ${alignment === 'center' ? 'bg-indigo-100 text-indigo-700' : 'hover:bg-slate-200'}`}
                  >
                    <AlignCenter className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { setAlignment('left'); applyFormat('justifyLeft'); }}
                    className={`p-1.5 rounded-lg transition-colors ${alignment === 'left' ? 'bg-indigo-100 text-indigo-700' : 'hover:bg-slate-200'}`}
                  >
                    <AlignLeft className="w-4 h-4" />
                  </button>

                  <div className="w-px h-6 bg-slate-300 mx-1" />

                  {/* Emoji Picker */}
                  <div className="relative">
                    <button
                      onClick={() => { setShowEmojiPicker(!showEmojiPicker); setShowFontDropdown(false); setShowSizeDropdown(false); setShowColorPicker(false); }}
                      className="p-1.5 rounded-lg hover:bg-slate-200"
                    >
                      <Smile className="w-4 h-4" />
                    </button>
                    {showEmojiPicker && (
                      <div className="absolute top-full right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-20 p-3 w-72">
                        {Object.entries(EMOJI_CATEGORIES).map(([category, emojis]) => (
                          <div key={category} className="mb-3">
                            <div className="text-xs text-slate-500 mb-2">{category}</div>
                            <div className="flex flex-wrap gap-1">
                              {emojis.map((emoji) => (
                                <button
                                  key={emoji}
                                  onClick={() => insertEmoji(emoji)}
                                  className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded text-lg"
                                >
                                  {emoji}
                                </button>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Editor Area */}
                <div
                  ref={editorRef}
                  contentEditable
                  onInput={updateBodyHtml}
                  className="min-h-[200px] max-h-[400px] overflow-y-auto p-4 bg-white border border-slate-200 rounded-b-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  style={{ fontFamily: currentFont.value, textAlign: alignment }}
                  dir="rtl"
                  data-placeholder="اكتب محتوى البريد هنا..."
                />
              </div>

              {/* Gmail Preview */}
              {showPreview && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-lg overflow-hidden">
                  <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 flex items-center gap-2">
                    <img src="https://www.google.com/gmail/about/static-2.0/images/logo-gmail.png?fingerprint=c2eaf4aae389c3f885e97081bb197b97"
                         alt="Gmail" className="h-6"
                         onError={(e) => { e.target.style.display = 'none'; }}
                    />
                    <span className="text-sm text-slate-600 font-medium">معاينة Gmail</span>
                  </div>
                  <div className="p-4">
                    {/* Email Header */}
                    <div className="border-b border-slate-200 pb-4 mb-4">
                      <div className="text-lg font-medium text-slate-800 mb-2">
                        {subject || '(بدون عنوان)'}
                      </div>
                      <div className="flex items-center gap-3 text-sm text-slate-500">
                        <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center text-white font-bold">
                          أ
                        </div>
                        <div>
                          <div className="text-slate-800 font-medium">أنت</div>
                          <div className="text-xs">إلى: {selectedRecipient?.email || recipients[0]?.email || 'example@email.com'}</div>
                        </div>
                      </div>
                    </div>
                    {/* Email Body */}
                    <div
                      className="prose prose-sm max-w-none"
                      style={{ direction: 'rtl', textAlign: alignment }}
                      dangerouslySetInnerHTML={{ __html: bodyHtml || '<p style="color: #999;">محتوى البريد سيظهر هنا...</p>' }}
                    />
                    {/* Attachments Preview */}
                    {(attachmentFiles.length > 0 || gdriveLink) && (
                      <div className="mt-4 pt-4 border-t border-slate-200">
                        <div className="text-sm text-slate-500 mb-2">المرفقات:</div>
                        <div className="flex flex-wrap gap-2">
                          {attachmentType === 'files' && attachmentFiles.map((file, i) => (
                            <div key={i} className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-lg text-sm">
                              <FileText className="w-4 h-4 text-red-500" />
                              {file.name}
                            </div>
                          ))}
                          {attachmentType === 'gdrive' && gdriveLink && (
                            <div className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-lg text-sm">
                              <FolderOpen className="w-4 h-4 text-yellow-500" />
                              رابط Google Drive
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Send Button */}
              <button
                onClick={sendEmails}
                disabled={isSending || recipients.length === 0 || !subject.trim()}
                className="w-full py-4 bg-gradient-to-l from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:from-slate-400 disabled:to-slate-500 text-white rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-lg disabled:shadow-none"
              >
                {isSending ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" />
                    جارٍ الإرسال...
                  </>
                ) : (
                  <>
                    <Send className="w-6 h-6" />
                    إرسال إلى {recipients.length} مستلم
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Webhook Settings Modal */}
      {showWebhookSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <Settings className="w-6 h-6 text-indigo-600" />
                إعدادات Webhook
              </h3>
              <button
                onClick={() => setShowWebhookSettings(false)}
                className="p-2 hover:bg-slate-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-5">
              {/* Webhook Status */}
              <div className={`p-4 rounded-xl flex items-center gap-3 ${webhookUrl ? 'bg-emerald-50 border border-emerald-200' : 'bg-amber-50 border border-amber-200'}`}>
                {webhookUrl ? (
                  <>
                    <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                    <div>
                      <p className="font-medium text-emerald-800">Webhook متصل</p>
                      <p className="text-xs text-emerald-600 truncate max-w-xs" dir="ltr">{webhookUrl}</p>
                    </div>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-6 h-6 text-amber-600" />
                    <div>
                      <p className="font-medium text-amber-800">لم يتم إعداد Webhook</p>
                      <p className="text-xs text-amber-600">يرجى إدخال رابط Webhook في الإعدادات</p>
                    </div>
                  </>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  رابط Webhook
                </label>
                <input
                  type="url"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  placeholder="https://hook.example.com/..."
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  dir="ltr"
                />
                <p className="text-xs text-slate-500 mt-1">سيتم حفظ الرابط تلقائياً في المتصفح</p>
              </div>

              {/* Instructions */}
              <div className="bg-indigo-50 p-4 rounded-xl">
                <h4 className="font-medium text-indigo-800 mb-3 flex items-center gap-2">
                  <ExternalLink className="w-4 h-4" />
                  كيفية إعداد Webhook
                </h4>
                <ol className="text-sm text-indigo-700 space-y-3 list-decimal list-inside">
                  <li><strong>افتح منصة الأتمتة:</strong> استخدم أي منصة أتمتة تدعم webhooks</li>
                  <li><strong>أنشئ سيناريو جديد:</strong> اختر إنشاء workflow جديد</li>
                  <li><strong>أضف Webhook كـ Trigger:</strong> ابحث عن "Webhooks" واختر "Custom webhook"</li>
                  <li><strong>أضف خدمة البريد:</strong> أضف وحدة لإرسال البريد الإلكتروني</li>
                  <li><strong>اربط الحقول:</strong> اربط to, cc, subject, body من الـ webhook</li>
                  <li><strong>انسخ الرابط:</strong> انسخ رابط الـ webhook والصقه هنا</li>
                </ol>
              </div>

              {/* Expected Payload */}
              <div className="bg-slate-50 p-4 rounded-xl">
                <h4 className="font-medium text-slate-800 mb-2">البيانات المرسلة (Payload):</h4>
                <pre className="text-xs bg-slate-800 text-slate-100 p-3 rounded-lg overflow-x-auto" dir="ltr">
{`{
  "to": "email@example.com",
  "cc": "manager@example.com",
  "subject": "عنوان البريد",
  "body": "<html>محتوى البريد</html>",
  "recipientName": "اسم المستلم",
  "attachments": [{
    "name": "file.pdf",
    "data": "base64...",
    "type": "application/pdf"
  }]
}`}
                </pre>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => { setWebhookUrl(''); localStorage.removeItem('emailWebhookUrl'); }}
                  className="px-4 py-3 bg-red-100 hover:bg-red-200 text-red-700 rounded-xl font-medium transition-colors"
                >
                  مسح
                </button>
                <button
                  onClick={() => setShowWebhookSettings(false)}
                  className="flex-1 py-3 bg-slate-200 hover:bg-slate-300 rounded-xl font-medium transition-colors"
                >
                  إغلاق
                </button>
                <button
                  onClick={() => setShowWebhookSettings(false)}
                  className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium transition-colors"
                >
                  حفظ
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CSS for placeholder */}
      <style>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: #9ca3af;
          pointer-events: none;
        }
      `}</style>
    </div>
  );
};

export default EmailAutomation;
