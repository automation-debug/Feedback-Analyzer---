import React, { useState } from 'react';
import {
  FileSignature,
  Calendar,
  Users,
  CheckCircle2,
  ArrowLeft,
  Scale,
  AlertCircle,
  Link2,
  Shield,
  Zap,
  Info
} from 'lucide-react';
import { createLogger } from '../utils/logger';

const logger = createLogger('AssessmentTypeSelector');

/**
 * Assessment Type Selector Component
 *
 * Allows users to select which data sources to include in the assessment:
 * - Leader Assessment (تقييم المدير المباشر)
 * - Periodic Evaluation (التقييم الدوري مارس 2025)
 * - Both
 * - Neither (360° only)
 *
 * Also provides option to enable URL validation for development plan resources.
 *
 * This component appears immediately after mode selection (single/batch)
 */
const AssessmentTypeSelector = ({
  mode, // 'single' or 'batch'
  onSelect,
  onBack,
  selectedType = null,
  urlValidationEnabled = false,
  onUrlValidationChange = null
}) => {
  const [showUrlValidationInfo, setShowUrlValidationInfo] = useState(false);

  // Assessment type configurations
  const assessmentTypes = [
    {
      id: 'full',
      title: 'تقييم شامل (المدير + الدوري + 360°)',
      titleEn: 'Full Assessment',
      description: 'يجمع بين تقييم المدير المباشر، التقييم الدوري، وتقييم 360° للحصول على صورة كاملة',
      weights: { leader: 50, periodic: 10, feedback360: 40 },
      icons: ['leader', 'periodic', 'feedback360'],
      color: 'indigo',
      recommended: true
    },
    {
      id: 'leader_only',
      title: 'تقييم المدير + 360°',
      titleEn: 'Leader + 360°',
      description: 'يعطي الأولوية لتقييم المدير المباشر مع دعم من تقييم 360°',
      weights: { leader: 60, periodic: 0, feedback360: 40 },
      icons: ['leader', 'feedback360'],
      color: 'orange'
    },
    {
      id: 'periodic_only',
      title: 'التقييم الدوري + 360°',
      titleEn: 'Periodic + 360°',
      description: 'يستخدم بيانات التقييم الدوري كمصدر إضافي لتقييم 360°',
      weights: { leader: 0, periodic: 10, feedback360: 90 },
      icons: ['periodic', 'feedback360'],
      color: 'teal'
    },
    {
      id: 'feedback360_only',
      title: 'تقييم 360° فقط',
      titleEn: '360° Only',
      description: 'يعتمد فقط على التغذية الراجعة من الزملاء والمرؤوسين والعملاء',
      weights: { leader: 0, periodic: 0, feedback360: 100 },
      icons: ['feedback360'],
      color: 'purple'
    }
  ];

  const handleSelect = (type) => {
    logger.info('Assessment type selected', {
      type: type.id,
      mode,
      weights: type.weights
    });
    onSelect(type);
  };

  const getIcon = (iconType, className) => {
    switch (iconType) {
      case 'leader':
        return <FileSignature className={className} />;
      case 'periodic':
        return <Calendar className={className} />;
      case 'feedback360':
        return <Users className={className} />;
      default:
        return null;
    }
  };

  const getColorClasses = (color, isSelected) => {
    const colors = {
      indigo: {
        border: isSelected ? 'border-indigo-500 ring-2 ring-indigo-200' : 'border-slate-200 hover:border-indigo-300',
        bg: isSelected ? 'bg-indigo-50' : 'bg-white hover:bg-indigo-50/50',
        icon: 'text-indigo-600',
        badge: 'bg-indigo-600',
        weight: 'bg-indigo-500'
      },
      orange: {
        border: isSelected ? 'border-orange-500 ring-2 ring-orange-200' : 'border-slate-200 hover:border-orange-300',
        bg: isSelected ? 'bg-orange-50' : 'bg-white hover:bg-orange-50/50',
        icon: 'text-orange-600',
        badge: 'bg-orange-600',
        weight: 'bg-orange-500'
      },
      teal: {
        border: isSelected ? 'border-teal-500 ring-2 ring-teal-200' : 'border-slate-200 hover:border-teal-300',
        bg: isSelected ? 'bg-teal-50' : 'bg-white hover:bg-teal-50/50',
        icon: 'text-teal-600',
        badge: 'bg-teal-600',
        weight: 'bg-teal-500'
      },
      purple: {
        border: isSelected ? 'border-purple-500 ring-2 ring-purple-200' : 'border-slate-200 hover:border-purple-300',
        bg: isSelected ? 'bg-purple-50' : 'bg-white hover:bg-purple-50/50',
        icon: 'text-purple-600',
        badge: 'bg-purple-600',
        weight: 'bg-purple-500'
      }
    };
    return colors[color] || colors.indigo;
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-indigo-900 via-indigo-800 to-slate-900 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Scale className="w-8 h-8 text-indigo-300" />
              <div>
                <h2 className="text-xl font-bold">اختر نوع التقييم</h2>
                <p className="text-indigo-300 text-sm">
                  {mode === 'single' ? 'تقرير فردي' : 'معالجة جماعية'} - الخطوة 2 من 3
                </p>
              </div>
            </div>
            <button
              onClick={onBack}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl transition-colors text-sm font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              رجوع
            </button>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-50 border-b border-blue-100 px-6 py-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-800">
              <p className="font-bold mb-1">كيف تعمل الأوزان؟</p>
              <p className="text-blue-700">
                كل مصدر بيانات يساهم بنسبة معينة في التقييم النهائي. اختر النوع المناسب بناءً على البيانات المتاحة لديك.
              </p>
            </div>
          </div>
        </div>

        {/* Assessment Type Cards */}
        <div className="p-6 space-y-4">
          {assessmentTypes.map((type) => {
            const isSelected = selectedType?.id === type.id;
            const colors = getColorClasses(type.color, isSelected);

            return (
              <button
                key={type.id}
                onClick={() => handleSelect(type)}
                className={`w-full p-5 rounded-2xl border-2 transition-all text-right ${colors.border} ${colors.bg}`}
              >
                <div className="flex items-start gap-4">
                  {/* Icons Column */}
                  <div className="flex flex-col gap-2 items-center min-w-[60px]">
                    {type.icons.map((iconType, idx) => (
                      <div
                        key={iconType}
                        className={`p-2 rounded-xl ${isSelected ? 'bg-white shadow-sm' : 'bg-slate-100'}`}
                      >
                        {getIcon(iconType, `w-5 h-5 ${colors.icon}`)}
                      </div>
                    ))}
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-bold text-slate-800">{type.title}</h3>
                      {type.recommended && (
                        <span className={`${colors.badge} text-white text-[10px] font-bold px-2 py-0.5 rounded-full`}>
                          موصى به
                        </span>
                      )}
                      {isSelected && (
                        <CheckCircle2 className={`w-5 h-5 ${colors.icon} mr-auto`} />
                      )}
                    </div>
                    <p className="text-sm text-slate-600 mb-3">{type.description}</p>

                    {/* Weights Display */}
                    <div className="flex items-center gap-3 flex-wrap">
                      {type.weights.leader > 0 && (
                        <div className="flex items-center gap-1.5">
                          <span className="w-12 h-6 bg-orange-500 text-white rounded-md flex items-center justify-center text-xs font-bold">
                            {type.weights.leader}%
                          </span>
                          <span className="text-xs text-slate-500">المدير</span>
                        </div>
                      )}
                      {type.weights.periodic > 0 && (
                        <>
                          {type.weights.leader > 0 && <span className="text-slate-300">+</span>}
                          <div className="flex items-center gap-1.5">
                            <span className="w-12 h-6 bg-teal-500 text-white rounded-md flex items-center justify-center text-xs font-bold">
                              {type.weights.periodic}%
                            </span>
                            <span className="text-xs text-slate-500">الدوري</span>
                          </div>
                        </>
                      )}
                      {type.weights.feedback360 > 0 && (
                        <>
                          {(type.weights.leader > 0 || type.weights.periodic > 0) && <span className="text-slate-300">+</span>}
                          <div className="flex items-center gap-1.5">
                            <span className="w-12 h-6 bg-purple-500 text-white rounded-md flex items-center justify-center text-xs font-bold">
                              {type.weights.feedback360}%
                            </span>
                            <span className="text-xs text-slate-500">360°</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="px-6 pb-6">
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
            <h4 className="text-sm font-bold text-slate-700 mb-3">مصادر البيانات المطلوبة:</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-orange-100 rounded-lg">
                  <FileSignature className="w-4 h-4 text-orange-600" />
                </div>
                <div>
                  <p className="font-bold text-slate-700">تقييم المدير</p>
                  <p className="text-slate-500">نص التقييم الدوري</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-teal-100 rounded-lg">
                  <Calendar className="w-4 h-4 text-teal-600" />
                </div>
                <div>
                  <p className="font-bold text-slate-700">التقييم الدوري</p>
                  <p className="text-slate-500">ملف Excel بأسماء الموظفين</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-purple-100 rounded-lg">
                  <Users className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <p className="font-bold text-slate-700">تقييم 360°</p>
                  <p className="text-slate-500">ملفات التغذية الراجعة</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* URL Validation Option */}
        {onUrlValidationChange && (
          <div className="px-6 pb-6">
            <div className={`rounded-xl p-4 border-2 transition-all ${
              urlValidationEnabled
                ? 'bg-emerald-50 border-emerald-300'
                : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${urlValidationEnabled ? 'bg-emerald-100' : 'bg-slate-100'}`}>
                    <Link2 className={`w-5 h-5 ${urlValidationEnabled ? 'text-emerald-600' : 'text-slate-500'}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-800">التحقق من روابط المصادر</h4>
                      <button
                        type="button"
                        onClick={() => setShowUrlValidationInfo(!showUrlValidationInfo)}
                        className="p-1 hover:bg-slate-200 rounded-full transition-colors"
                      >
                        <Info className="w-4 h-4 text-slate-400" />
                      </button>
                    </div>
                    <p className="text-sm text-slate-600">
                      {urlValidationEnabled
                        ? 'سيتم التحقق من جميع الروابط واستبدال المعطلة تلقائياً'
                        : 'الروابط ستُستخدم كما هي بدون تحقق'
                      }
                    </p>
                  </div>
                </div>

                {/* Toggle Switch */}
                <button
                  type="button"
                  onClick={() => {
                    logger.info('URL validation toggled', { newValue: !urlValidationEnabled });
                    onUrlValidationChange(!urlValidationEnabled);
                  }}
                  className={`relative w-14 h-7 rounded-full transition-colors ${
                    urlValidationEnabled ? 'bg-emerald-500' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform ${
                      urlValidationEnabled ? 'right-0.5' : 'left-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Info Panel */}
              {showUrlValidationInfo && (
                <div className="mt-4 pt-4 border-t border-slate-200">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-start gap-2">
                      <Shield className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-slate-700">فحص شامل</p>
                        <p className="text-slate-500 text-xs">التحقق من كل رابط في خطة التطوير للتأكد من صلاحيته</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Zap className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium text-slate-700">استبدال تلقائي</p>
                        <p className="text-slate-500 text-xs">الروابط المعطلة تُستبدل بروابط صالحة عبر الذكاء الاصطناعي</p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                    <p className="text-xs text-amber-800">
                      <span className="font-bold">ملاحظة:</span> تفعيل هذه الميزة قد يزيد من وقت المعالجة بشكل ملحوظ، خاصة للمعالجة الجماعية.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AssessmentTypeSelector;
