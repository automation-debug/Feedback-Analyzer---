import React, { useState } from 'react';
import {
  X,
  Loader2,
  Send,
  Check,
  RotateCcw,
  AlertCircle,
  Sparkles,
  Eye,
  ArrowLeft,
  Brain
} from 'lucide-react';
import { REPORT_SECTIONS } from '../types/reportSchema';

// Section names in Arabic
const SECTION_NAMES = {
  [REPORT_SECTIONS.HEADER]: 'المعلومات الأساسية والملخص التنفيذي',
  [REPORT_SECTIONS.LEADERSHIP_PATH]: 'مؤشر درب القيادة',
  [REPORT_SECTIONS.MANAGER_MESSAGE]: 'رسالة المدير المباشر',
  [REPORT_SECTIONS.CORE_METRICS]: 'المؤشرات الأساسية الأربعة',
  [REPORT_SECTIONS.PERSONALITY]: 'تحليل الشخصية والقيادة',
  [REPORT_SECTIONS.STRENGTHS]: 'نقاط القوة',
  [REPORT_SECTIONS.WEAKNESSES]: 'نقاط الضعف',
  [REPORT_SECTIONS.FEEDBACK]: 'صوت الفريق',
  [REPORT_SECTIONS.ROADMAP]: 'خارطة الطريق للتحسين',
  [REPORT_SECTIONS.DEVELOPMENT]: 'خطة التطوير والتعلم'
};

// Section descriptions
const SECTION_DESCRIPTIONS = {
  [REPORT_SECTIONS.HEADER]: 'اسم الموظف، المسمى الوظيفي، عدد المقيمين، والملخص التنفيذي',
  [REPORT_SECTIONS.LEADERSHIP_PATH]: 'النتيجة الإجمالية (0-100) والحالة والوصف',
  [REPORT_SECTIONS.MANAGER_MESSAGE]: 'الملخص التنفيذي، استراتيجية الاحتواء، الخطوط الحمراء، التوصيات',
  [REPORT_SECTIONS.CORE_METRICS]: 'الوضوح والهيكلة، الكفاءة التشغيلية، الأمان النفسي، تمكين الفريق',
  [REPORT_SECTIONS.PERSONALITY]: '16 Personalities, DiSC, Enneagram, Big Five',
  [REPORT_SECTIONS.STRENGTHS]: 'قائمة نقاط القوة الرئيسية للاستفادة منها',
  [REPORT_SECTIONS.WEAKNESSES]: 'قائمة نقاط الضعف التي تحتاج تغيير فوري',
  [REPORT_SECTIONS.FEEDBACK]: 'اقتباسات من الفريق حول الثقة، الاجتماعات، البيئة، الرؤية',
  [REPORT_SECTIONS.ROADMAP]: 'الإجراءات ذات الأولوية القصوى، العاجلة، والمستمرة',
  [REPORT_SECTIONS.DEVELOPMENT]: 'الكتب، المقالات، البودكاست، والفيديوهات الموصى بها'
};

/**
 * SectionEditor Component
 * Modal for editing report sections using AI
 */
const SectionEditor = ({
  isOpen,
  onClose,
  sectionId,
  currentContent,
  onApplyEdit,
  fullReport
}) => {
  const [editInstruction, setEditInstruction] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewContent, setPreviewContent] = useState(null);
  const [error, setError] = useState(null);

  if (!isOpen) return null;

  const handleGeneratePreview = async () => {
    if (!editInstruction.trim()) {
      setError('يرجى إدخال وصف التعديل المطلوب.');
      return;
    }

    setError(null);
    setIsProcessing(true);
    setPreviewContent(null);

    try {
      const { editReportSection } = await import('../services/geminiService');
      const result = await editReportSection(
        sectionId,
        currentContent,
        editInstruction,
        fullReport
      );
      setPreviewContent(result);
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء معالجة التعديل.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApply = () => {
    if (previewContent) {
      onApplyEdit(sectionId, previewContent, editInstruction);
      handleClose();
    }
  };

  const handleClose = () => {
    setEditInstruction('');
    setPreviewContent(null);
    setError(null);
    onClose();
  };

  const handleReset = () => {
    setPreviewContent(null);
    setError(null);
  };

  // Render a single value in human-readable format
  const renderValue = (value, key = null) => {
    if (value === null || value === undefined) return null;

    if (typeof value === 'string') {
      return <span className="text-slate-700">{value}</span>;
    }

    if (typeof value === 'number') {
      // Format numbers - show percentage if key suggests it
      const isPercentage = key && (key.toLowerCase().includes('score') || key.toLowerCase().includes('percentage') || key.toLowerCase().includes('نسبة'));
      return <span className="text-indigo-600 font-bold">{value}{isPercentage ? '%' : ''}</span>;
    }

    if (typeof value === 'boolean') {
      return <span className="text-slate-600">{value ? 'نعم' : 'لا'}</span>;
    }

    return null;
  };

  // Render an object item (like a metric, resource, or feedback item)
  const renderObjectItem = (item, idx) => {
    if (!item || typeof item !== 'object') {
      return <p className="text-sm text-slate-700">{String(item)}</p>;
    }

    // Get displayable fields (prioritize common fields)
    const priorityFields = ['title', 'name', 'عنوان', 'اسم', 'category', 'فئة', 'type', 'نوع'];
    const scoreFields = ['score', 'percentage', 'نتيجة', 'نسبة', 'درجة'];
    const descFields = ['description', 'text', 'content', 'وصف', 'نص', 'محتوى', 'details', 'تفاصيل'];

    const entries = Object.entries(item);

    // Find title/name field
    const titleEntry = entries.find(([k]) => priorityFields.some(f => k.toLowerCase().includes(f.toLowerCase())));
    // Find score field
    const scoreEntry = entries.find(([k]) => scoreFields.some(f => k.toLowerCase().includes(f.toLowerCase())));
    // Find description field
    const descEntry = entries.find(([k]) => descFields.some(f => k.toLowerCase().includes(f.toLowerCase())));

    // Other fields
    const usedKeys = [titleEntry?.[0], scoreEntry?.[0], descEntry?.[0]].filter(Boolean);
    const otherEntries = entries.filter(([k]) => !usedKeys.includes(k) && typeof item[k] !== 'object');

    return (
      <div key={idx} className="bg-white p-3 rounded-lg mb-2 border border-slate-200">
        {/* Title/Name */}
        {titleEntry && (
          <h5 className="font-bold text-slate-800 text-sm mb-1">{String(titleEntry[1])}</h5>
        )}

        {/* Score */}
        {scoreEntry && (
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs text-slate-500">{scoreEntry[0]}:</span>
            <span className="text-indigo-600 font-bold text-sm">{scoreEntry[1]}%</span>
            <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-l from-indigo-500 to-indigo-600 rounded-full transition-all"
                style={{ width: `${Math.min(100, Math.max(0, scoreEntry[1]))}%` }}
              />
            </div>
          </div>
        )}

        {/* Description */}
        {descEntry && (
          <p className="text-sm text-slate-600 mb-2">{String(descEntry[1])}</p>
        )}

        {/* Other fields */}
        {otherEntries.length > 0 && (
          <div className="space-y-1 text-xs">
            {otherEntries.map(([key, val]) => (
              <div key={key} className="flex gap-2">
                <span className="text-slate-500 font-medium">{key}:</span>
                <span className="text-slate-700">{String(val)}</span>
              </div>
            ))}
          </div>
        )}

        {/* Nested arrays */}
        {entries.filter(([k, v]) => Array.isArray(v)).map(([key, arr]) => (
          <div key={key} className="mt-2 pt-2 border-t border-slate-100">
            <span className="text-xs text-slate-500 font-medium">{key}:</span>
            <ul className="list-disc list-inside mt-1 space-y-0.5">
              {arr.map((item, i) => (
                <li key={i} className="text-xs text-slate-700">
                  {typeof item === 'object' ? (item.title || item.name || item.text || JSON.stringify(item)) : String(item)}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    );
  };

  // Format content for preview display
  const formatPreviewContent = (content) => {
    if (!content) return null;

    // String content
    if (typeof content === 'string') {
      return <p className="text-sm text-slate-700">{content}</p>;
    }

    // Number content
    if (typeof content === 'number') {
      return <p className="text-sm text-indigo-600 font-bold">{content}</p>;
    }

    // Array content
    if (Array.isArray(content)) {
      if (content.length === 0) {
        return <p className="text-sm text-slate-400 italic">لا توجد عناصر</p>;
      }

      // Simple array of strings/numbers
      if (content.every(item => typeof item === 'string' || typeof item === 'number')) {
        return (
          <ul className="list-disc list-inside space-y-1">
            {content.map((item, idx) => (
              <li key={idx} className="text-sm text-slate-700">{String(item)}</li>
            ))}
          </ul>
        );
      }

      // Array of objects
      return content.map((item, idx) => renderObjectItem(item, idx));
    }

    // Object content
    if (typeof content === 'object') {
      const entries = Object.entries(content);

      if (entries.length === 0) {
        return <p className="text-sm text-slate-400 italic">لا توجد بيانات</p>;
      }

      return (
        <div className="space-y-3">
          {entries.map(([key, value]) => {
            // Skip null/undefined
            if (value === null || value === undefined) return null;

            // Nested object
            if (typeof value === 'object' && !Array.isArray(value)) {
              return (
                <div key={key} className="bg-white p-3 rounded-lg border border-slate-200">
                  <h5 className="font-bold text-slate-800 text-sm mb-2">{key}</h5>
                  <div className="pr-3 border-r-2 border-indigo-200">
                    {formatPreviewContent(value)}
                  </div>
                </div>
              );
            }

            // Array
            if (Array.isArray(value)) {
              return (
                <div key={key} className="bg-white p-3 rounded-lg border border-slate-200">
                  <h5 className="font-bold text-slate-800 text-sm mb-2">{key}</h5>
                  {formatPreviewContent(value)}
                </div>
              );
            }

            // Simple value
            return (
              <div key={key} className="flex items-start gap-2 bg-white p-2 rounded-lg border border-slate-100">
                <span className="text-sm text-slate-500 font-medium min-w-[80px]">{key}:</span>
                <span className="text-sm">{renderValue(value, key)}</span>
              </div>
            );
          })}
        </div>
      );
    }

    // Fallback
    return <p className="text-sm text-slate-700">{String(content)}</p>;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col" dir="rtl">
        {/* Header */}
        <div className="bg-gradient-to-l from-indigo-600 via-indigo-700 to-slate-800 px-6 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">
                  تعديل: {SECTION_NAMES[sectionId]}
                </h3>
                <p className="text-indigo-200 text-xs mt-1">
                  {SECTION_DESCRIPTIONS[sectionId]}
                </p>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="text-white/80 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-xl"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Current Content Preview */}
          <div>
            <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
              <Eye className="w-4 h-4 text-indigo-600" />
              المحتوى الحالي
            </h4>
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 max-h-48 overflow-y-auto">
              {formatPreviewContent(currentContent)}
            </div>
          </div>

          {/* Edit Instruction Input */}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
              <Brain className="w-4 h-4 text-indigo-600" />
              صف التعديل المطلوب
            </label>
            <textarea
              value={editInstruction}
              onChange={(e) => setEditInstruction(e.target.value)}
              placeholder="مثال: غير النتيجة إلى 75% وعدل الوصف ليعكس تحسن في الأداء..."
              className="w-full px-4 py-4 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-none h-28 text-base"
              disabled={isProcessing}
            />
            <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              يمكنك وصف التعديلات بلغة طبيعية وسيقوم الذكاء الاصطناعي بتنفيذها
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="flex items-start gap-3 bg-red-50 text-red-800 px-4 py-3 rounded-xl border border-red-200">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <h5 className="font-bold text-sm">خطأ</h5>
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          )}

          {/* Preview Result */}
          {previewContent && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-green-700 flex items-center gap-2">
                <Check className="w-4 h-4" />
                معاينة التعديل
              </h4>
              <div className="bg-green-50 rounded-xl p-4 border border-green-200 max-h-64 overflow-y-auto">
                {formatPreviewContent(previewContent)}
              </div>

              {/* Comparison Arrow */}
              <div className="flex items-center justify-center gap-3 text-slate-400 py-2">
                <span className="text-xs bg-slate-100 px-3 py-1 rounded-full">المحتوى الأصلي</span>
                <ArrowLeft className="w-4 h-4" />
                <span className="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-bold">المحتوى المعدل</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 px-6 py-5 border-t border-slate-200 flex items-center gap-3">
          {previewContent ? (
            <>
              <button
                onClick={handleApply}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-l from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-4 py-4 rounded-xl font-bold transition-all shadow-lg"
              >
                <Check className="w-5 h-5" />
                تطبيق التعديل
              </button>
              <button
                onClick={handleReset}
                className="flex items-center justify-center gap-2 bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-4 rounded-xl font-medium transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                تعديل آخر
              </button>
            </>
          ) : (
            <button
              onClick={handleGeneratePreview}
              disabled={isProcessing || !editInstruction.trim()}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 rounded-xl font-bold transition-all ${
                isProcessing || !editInstruction.trim()
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-l from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white shadow-lg'
              }`}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  جاري المعالجة بالذكاء الاصطناعي...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  معاينة التعديل
                </>
              )}
            </button>
          )}

          <button
            onClick={handleClose}
            className="px-6 py-4 rounded-xl font-medium text-slate-600 hover:bg-slate-200 transition-colors"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};

export default SectionEditor;
