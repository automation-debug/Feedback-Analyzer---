import React, { useRef, useState, useEffect } from 'react';
import {
  Users,
  Target,
  ShieldAlert,
  Briefcase,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  BookOpen,
  HeartHandshake,
  UserMinus,
  BarChart3,
  MessageSquare,
  Quote,
  ExternalLink,
  Download,
  UserCheck,
  Fingerprint,
  Loader2,
  ListChecks,
  Calendar,
  FileSignature,
  Building2,
  UsersRound,
  PlusCircle,
  MinusCircle,
  TrendingUp,
  Lightbulb,
  Edit3,
  FileSpreadsheet,
  FileText
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { SCORE_COLORS } from '../types/reportSchema';
import { exportSingleReportToExcel, convertSingleReportToRow } from '../services/exportService';

// Icon mapping for dynamic icon rendering
const iconMap = {
  Users, Target, ShieldAlert, Briefcase, CheckCircle2, XCircle, AlertTriangle,
  BookOpen, HeartHandshake, UserMinus, BarChart3, MessageSquare, Quote,
  ExternalLink, UserCheck, Fingerprint, ListChecks, Building2,
  UsersRound, PlusCircle, MinusCircle, TrendingUp, Lightbulb
};

const getIcon = (iconName, className = "w-5 h-5") => {
  const IconComponent = iconMap[iconName] || Target;
  return <IconComponent className={className} />;
};

/**
 * LeadershipReport Component
 * Displays the full leadership scorecard with edit buttons for each section
 */
const LeadershipReport = ({ report, onEditSection, isExporting = false }) => {
  const reportRef = useRef(null);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  useEffect(() => {
    // Inject PDF libraries
    const scriptDomToImage = document.createElement('script');
    scriptDomToImage.src = "https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.min.js";
    scriptDomToImage.async = true;
    document.body.appendChild(scriptDomToImage);

    const scriptJsPDF = document.createElement('script');
    scriptJsPDF.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    scriptJsPDF.async = true;
    document.body.appendChild(scriptJsPDF);

    return () => {
      if (document.body.contains(scriptDomToImage)) document.body.removeChild(scriptDomToImage);
      if (document.body.contains(scriptJsPDF)) document.body.removeChild(scriptJsPDF);
    };
  }, []);

  const handleDownloadPDF = async () => {
    if (!window.domtoimage || !window.jspdf) {
      alert('جاري تحميل مكتبات PDF، يرجى الانتظار قليلاً والمحاولة مرة أخرى...');
      return;
    }

    setIsGeneratingPDF(true);
    const element = reportRef.current;

    try {
      const elementWidth = element.scrollWidth;
      const elementHeight = element.scrollHeight;
      const scale = 2;

      const style = {
        transform: 'scale(' + scale + ')',
        transformOrigin: 'top left',
        width: elementWidth + 'px',
        height: elementHeight + 'px',
        margin: '0',
        left: '0'
      };

      const param = {
        height: elementHeight * scale,
        width: elementWidth * scale,
        quality: 0.9,
        style,
        bgcolor: '#ffffff'
      };

      const dataUrl = await window.domtoimage.toJpeg(element, param);
      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF('p', 'mm', 'a4');

      const imgProps = pdf.getImageProperties(dataUrl);
      const pdfPageWidth = pdf.internal.pageSize.getWidth();
      const pdfPageHeight = pdf.internal.pageSize.getHeight();

      const margin = 5;
      const availableWidth = pdfPageWidth - (margin * 2);
      const pdfImageWidth = availableWidth;
      const pdfImageHeight = (imgProps.height * pdfImageWidth) / imgProps.width;
      const xPosition = (pdfPageWidth - pdfImageWidth) / 2;
      const yPosition = 10;

      let currentPdf;
      if (pdfImageHeight > pdfPageHeight) {
        currentPdf = new jsPDF('p', 'mm', [pdfPageWidth, pdfImageHeight + 20]);
        currentPdf.addImage(dataUrl, 'JPEG', xPosition, yPosition, pdfImageWidth, pdfImageHeight);
      } else {
        currentPdf = pdf;
        currentPdf.addImage(dataUrl, 'JPEG', xPosition, yPosition, pdfImageWidth, pdfImageHeight);
      }

      const links = element.querySelectorAll('a');
      const scaleRatio = pdfImageWidth / element.offsetWidth;

      links.forEach(link => {
        const rect = link.getBoundingClientRect();
        const containerRect = element.getBoundingClientRect();
        const relativeX = rect.left - containerRect.left;
        const relativeY = rect.top - containerRect.top;
        const linkX = xPosition + (relativeX * scaleRatio);
        const linkY = yPosition + (relativeY * scaleRatio);
        const linkW = rect.width * scaleRatio;
        const linkH = rect.height * scaleRatio;
        currentPdf.link(linkX, linkY, linkW, linkH, { url: link.href });
      });

      currentPdf.save(`Leadership_Scorecard_${report.header?.employeeName || 'Report'}.pdf`);
    } catch (error) {
      console.error('PDF Generation Error:', error);
      alert('حدث خطأ أثناء توليد الملف. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  // Convert report to flat data for export
  const getExportData = () => {
    const rows = [];

    // Header info
    rows.push(['معلومات التقرير', '']);
    rows.push(['اسم الموظف', report.header?.employeeName || '']);
    rows.push(['المسمى الوظيفي', report.header?.jobTitle || '']);
    rows.push(['عدد المقيمين', report.header?.reviewerCount || '']);
    rows.push(['التاريخ', report.header?.date || '']);
    rows.push(['الملخص التنفيذي', report.header?.executiveSummary || '']);
    rows.push(['', '']);

    // Leadership Path
    rows.push(['مؤشر درب القيادة', '']);
    rows.push(['الدرجة', report.leadershipPath?.score || '']);
    rows.push(['الحالة', report.leadershipPath?.statusLabelAr || '']);
    rows.push(['الوصف', report.leadershipPath?.description || '']);
    rows.push(['', '']);

    // Core Metrics
    rows.push(['المؤشرات الأساسية', '']);
    if (report.coreMetrics) {
      report.coreMetrics.forEach(metric => {
        rows.push([metric.nameAr, `${metric.score}% - ${metric.ratingAr}`]);
        metric.bulletPoints?.forEach(point => {
          rows.push(['', `• ${point}`]);
        });
      });
    }
    rows.push(['', '']);

    // Strengths
    rows.push(['نقاط القوة', '']);
    if (report.strengths) {
      report.strengths.forEach(s => {
        rows.push([s.title, s.description]);
      });
    }
    rows.push(['', '']);

    // Weaknesses
    rows.push(['نقاط الضعف', '']);
    if (report.weaknesses) {
      report.weaknesses.forEach(w => {
        rows.push([w.title, w.description]);
      });
    }
    rows.push(['', '']);

    // Team Voice (formerly Employee Feedback)
    rows.push(['صوت الفريق', '']);
    if (report.teamVoice) {
      report.teamVoice.forEach(f => {
        rows.push([f.title, f.content]);
      });
    }
    rows.push(['', '']);

    // Roadmap
    rows.push(['خارطة الطريق', '']);
    if (report.roadmap) {
      report.roadmap.forEach(r => {
        rows.push([`${r.priorityAr}: ${r.title}`, '']);
        r.steps?.forEach(item => {
          rows.push(['', `☐ ${item}`]);
        });
      });
    }

    return rows;
  };

  // Export as Excel (flat format - one row with all columns for Figma mapping)
  const handleDownloadExcel = () => {
    try {
      exportSingleReportToExcel(report, 'leadership_report');
    } catch (error) {
      console.error('Excel export error:', error);
      alert('حدث خطأ أثناء تصدير الملف');
    }
  };

  // Export as CSV (same flat format as Excel - one row per person)
  const handleDownloadCSV = () => {
    try {
      const row = convertSingleReportToRow(report);
      const headers = Object.keys(row);
      const values = Object.values(row);

      // Create CSV with headers row and data row
      const headerRow = headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(',');
      const dataRow = values.map(v => `"${String(v || '').replace(/"/g, '""')}"`).join(',');
      const csvContent = headerRow + '\n' + dataRow;

      const BOM = '\uFEFF'; // UTF-8 BOM for Arabic support
      const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Leadership_Report_${report.header?.employeeName || 'Report'}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('CSV export error:', error);
      alert('حدث خطأ أثناء تصدير الملف');
    }
  };

  // Edit button component
  const EditButton = ({ sectionId, label }) => {
    if (isExporting) return null;
    return (
      <button
        onClick={() => onEditSection(sectionId)}
        className="flex items-center gap-1 text-xs bg-indigo-100 hover:bg-indigo-200 text-indigo-700 px-3 py-1.5 rounded-lg transition-colors font-medium"
      >
        <Edit3 className="w-3 h-3" />
        تعديل
      </button>
    );
  };

  // Calculate position for leadership path indicator
  // Bar layout (LEFT to RIGHT): green (فخر) → light green (خضر) → yellow (صفر) → orange (حمر) → red (خطر)
  // So: high scores (100%) = left (0%), low scores (0%) = right (100%)
  const getIndicatorPosition = (score) => {
    return `${100 - score}%`;
  };

  // Get indicator badge color based on score
  const getIndicatorColor = (score) => {
    if (score >= 92) return { bg: SCORE_COLORS.excellent, border: '#3d6147' };
    if (score >= 83) return { bg: SCORE_COLORS.good, border: '#6b8f4a' };
    if (score >= 74) return { bg: SCORE_COLORS.average, border: '#b5a23a' };
    if (score >= 64) return { bg: SCORE_COLORS.below, border: '#a85f4d' };
    return { bg: SCORE_COLORS.critical, border: '#7a271f' };
  };

  if (!report) return null;

  return (
    <div className="min-h-screen bg-gray-100 p-4 sm:p-8 font-sans" dir="rtl">
      {/* Action Bar */}
      {!isExporting && (
        <div className="max-w-7xl mx-auto mb-6 flex justify-end gap-3">
          <button
            onClick={handleDownloadCSV}
            className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-700 px-4 py-3 rounded-xl shadow-md transition-all text-sm font-bold border border-slate-200"
          >
            <FileText className="w-4 h-4" />
            CSV
          </button>
          <button
            onClick={handleDownloadExcel}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-3 rounded-xl shadow-lg transition-all text-sm font-bold border border-emerald-500"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Excel
          </button>
          <button
            onClick={handleDownloadPDF}
            disabled={isGeneratingPDF}
            className={`flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl shadow-lg transition-all text-sm font-bold border border-indigo-500 ${isGeneratingPDF ? 'opacity-75 cursor-wait' : ''}`}
          >
            {isGeneratingPDF ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                جاري التصدير...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                PDF
              </>
            )}
          </button>
        </div>
      )}

      {/* Report Container */}
      <div
        ref={reportRef}
        className="max-w-7xl mx-auto bg-white p-8 rounded-3xl shadow-xl border border-slate-200"
        id="printable-report"
      >
        {/* Header Section */}
        <header className="flex flex-col lg:flex-row justify-between items-start gap-6 border-b border-slate-100 pb-8 mb-8">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-indigo-50 rounded-2xl">
                  <BarChart3 className="w-10 h-10 text-indigo-600" />
                </div>
                <div>
                  <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
                    تقرير الكفاءة القيادية
                  </h1>
                  <div className="flex flex-wrap items-center gap-3 mt-2 text-sm font-semibold text-slate-500">
                    <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                      الاسم: {report.header?.employeeName}
                    </span>
                    <span className="text-slate-300">|</span>
                    <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                      المنصب: {report.header?.jobTitle}
                    </span>
                    <span className="text-slate-300">|</span>
                    <div className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded border border-slate-200 text-xs">
                      <FileSignature className="w-3 h-3" />
                      <span>عدد المقيمين: {report.header?.reviewerCount}</span>
                    </div>
                    <div className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded border border-slate-200 text-xs">
                      <Calendar className="w-3 h-3" />
                      <span dir="ltr" className="font-sans">{report.header?.date}</span>
                    </div>
                  </div>
                </div>
              </div>
              <EditButton sectionId="header" />
            </div>
            <p className="text-slate-500 text-sm leading-relaxed mt-4 max-w-2xl font-bold bg-yellow-50 p-3 rounded border border-yellow-100">
              ملخص النتائج: {report.header?.executiveSummary}
            </p>
            {/* Extended: Second executive summary with title + bullet points */}
            {report.header?.executiveSummary2 && (
              <div className="mt-4 max-w-2xl bg-yellow-50 p-4 rounded border border-yellow-100">
                <h4 className="text-slate-700 font-bold text-sm mb-3">
                  {report.header.executiveSummary2.title}
                </h4>
                <ul className="space-y-2">
                  {Array.isArray(report.header.executiveSummary2.bulletPoints) && report.header.executiveSummary2.bulletPoints.map((point, idx) => (
                    <li key={idx} className="text-slate-500 text-sm leading-relaxed flex items-start gap-2">
                      <span className="text-yellow-600 mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Leadership Path Visualization */}
          <div className="w-full lg:w-auto bg-slate-50 p-6 rounded-2xl border border-slate-200">
            <div className="flex justify-between items-center mb-6">
              <span className="text-4xl font-black text-slate-800">درب القيادة</span>
              <EditButton sectionId="leadershipPath" />
            </div>

            <div className="relative flex flex-col w-full lg:w-[350px]" dir="ltr">
              {/* Indicator Container */}
              <div className="relative w-full h-16 mb-1">
                <div
                  className="absolute bottom-0 transform -translate-x-1/2 flex flex-col items-center transition-all duration-500 ease-out"
                  style={{ left: getIndicatorPosition(report.leadershipPath?.score || 50) }}
                >
                  <div
                    style={{
                      backgroundColor: getIndicatorColor(report.leadershipPath?.score || 50).bg,
                      borderColor: getIndicatorColor(report.leadershipPath?.score || 50).border
                    }}
                    className="mb-2 text-white px-6 py-2 rounded-xl border-2 shadow-md font-bold text-lg relative whitespace-nowrap"
                  >
                    <span>دربك</span>
                    <br />
                    <span>{report.leadershipPath?.statusLabelAr}</span>
                    <div
                      style={{ borderTopColor: getIndicatorColor(report.leadershipPath?.score || 50).border }}
                      className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px]"
                    ></div>
                  </div>
                  <div className="animate-bounce">
                    <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[15px] border-t-slate-800"></div>
                  </div>
                </div>
              </div>

              {/* The Color Bar - LEFT=red(low) to RIGHT=green(high) */}
              <div className="flex w-full h-8 text-white text-[9px] font-bold text-center overflow-hidden rounded-lg border border-slate-300 shadow-inner relative z-10">
                <div style={{ backgroundColor: SCORE_COLORS.critical }} className="w-[20%] flex items-center justify-center opacity-80"></div>
                <div style={{ backgroundColor: SCORE_COLORS.below }} className="w-[20%] flex items-center justify-center opacity-80"></div>
                <div style={{ backgroundColor: SCORE_COLORS.average }} className="w-[20%] flex items-center justify-center opacity-80"></div>
                <div style={{ backgroundColor: SCORE_COLORS.good }} className="w-[20%] flex items-center justify-center opacity-80"></div>
                <div style={{ backgroundColor: SCORE_COLORS.excellent }} className="w-[20%] flex items-center justify-center opacity-80"></div>
              </div>

              <div className="mt-3 text-center">
                <p className="text-[10px] text-slate-600 max-w-xs mx-auto leading-relaxed font-bold bg-slate-100 px-2 py-1 rounded border border-slate-200">
                  {report.leadershipPath?.description}
                </p>
              </div>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Core Metrics Section */}
          <div className="md:col-span-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {Array.isArray(report.coreMetrics) && report.coreMetrics.map((metric, idx) => (
              <div key={metric.id || idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
                <div style={{ backgroundColor: metric.color || SCORE_COLORS.average }} className="absolute top-0 right-0 w-1.5 h-full"></div>
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm font-bold text-slate-600">{metric.nameAr}</span>
                  {idx === 0 && <EditButton sectionId="coreMetrics" />}
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-black text-slate-800 tracking-tight">{metric.score}%</span>
                </div>
                <ul className="text-xs text-slate-500 mt-4 pt-3 border-t border-slate-100 leading-relaxed list-disc list-inside">
                  {Array.isArray(metric.bulletPoints) && metric.bulletPoints.map((point, pIdx) => (
                    <li key={pIdx}>{point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Personality Analysis Section */}
          <div className="md:col-span-12 bg-white p-6 rounded-2xl border border-slate-200 mb-4">
            <div className="flex justify-between items-center mb-5 border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-indigo-900 flex items-center gap-2">
                <Fingerprint className="w-6 h-6 text-indigo-600" /> تحليل الشخصية والقيادة (نظرة متعمقة)
              </h3>
              <EditButton sectionId="personalityAnalysis" />
            </div>

            {/* Overview */}
            {report.personalityAnalysis?.overview && (
              <div className="mb-6 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <p className="text-sm text-slate-700 leading-relaxed">{report.personalityAnalysis.overview}</p>
                {/* Extended: Second overview with title + bullet points */}
                {report.personalityAnalysis?.overview2 && (
                  <div className="mt-4 pt-4 border-t border-slate-200">
                    <h4 className="text-slate-700 font-bold text-sm mb-3">
                      {report.personalityAnalysis.overview2.title}
                    </h4>
                    <ul className="space-y-2">
                      {Array.isArray(report.personalityAnalysis.overview2.bulletPoints) && report.personalityAnalysis.overview2.bulletPoints.map((point, idx) => (
                        <li key={idx} className="text-slate-600 text-sm leading-relaxed flex items-start gap-2">
                          <span className="text-indigo-500 mt-1">•</span>
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Personality Type Badges */}
            <div className="flex flex-wrap gap-3 mb-6">
              {report.personalityAnalysis?.mbpiType && (
                <span className="bg-indigo-600 text-white text-xs px-3 py-1.5 rounded-full font-bold">
                  MBTI: {report.personalityAnalysis.mbpiType}
                </span>
              )}
              {report.personalityAnalysis?.enneagramType && (
                <span className="bg-purple-600 text-white text-xs px-3 py-1.5 rounded-full font-bold">
                  Enneagram: {report.personalityAnalysis.enneagramType}
                </span>
              )}
              {report.personalityAnalysis?.discType && (
                <span className="bg-orange-500 text-white text-xs px-3 py-1.5 rounded-full font-bold">
                  DISC: {report.personalityAnalysis.discType}
                </span>
              )}
              {report.personalityAnalysis?.bigFiveType && (
                <span className="bg-teal-600 text-white text-xs px-3 py-1.5 rounded-full font-bold">
                  Big Five: {report.personalityAnalysis.bigFiveType}
                </span>
              )}
            </div>

            {/* Strengths and Weaknesses */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-5 rounded-xl border border-green-200">
                <h5 className="text-sm font-bold text-green-700 mb-3 flex items-center gap-2">
                  <PlusCircle className="w-4 h-4" /> نقاط القوة الشخصية
                </h5>
                <ul className="text-xs text-slate-600 space-y-2">
                  {Array.isArray(report.personalityAnalysis?.strengths) && report.personalityAnalysis.strengths.map((s, sIdx) => (
                    <li key={sIdx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-red-50 p-5 rounded-xl border border-red-200">
                <h5 className="text-sm font-bold text-red-700 mb-3 flex items-center gap-2">
                  <MinusCircle className="w-4 h-4" /> نقاط الضعف الشخصية
                </h5>
                <ul className="text-xs text-slate-600 space-y-2">
                  {Array.isArray(report.personalityAnalysis?.weaknesses) && report.personalityAnalysis.weaknesses.map((w, wIdx) => (
                    <li key={wIdx} className="flex items-start gap-2">
                      <XCircle className="w-3 h-3 text-red-500 mt-0.5 flex-shrink-0" />
                      <span>{w}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Strengths Section */}
          <div className="md:col-span-6 bg-white p-6 rounded-2xl border border-slate-200">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-base font-bold text-green-700 flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6" /> نقاط القوة (للحفاظ عليها)
              </h3>
              <EditButton sectionId="strengths" />
            </div>
            <div className="space-y-4">
              {Array.isArray(report.strengths) && report.strengths.map((strength, idx) => (
                <div key={idx} className="flex gap-3">
                  {getIcon(strength.icon, "w-5 h-5 text-green-600 flex-shrink-0")}
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{strength.title}</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{strength.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weaknesses Section */}
          <div className="md:col-span-6 bg-white p-6 rounded-2xl border border-slate-200">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-base font-bold text-red-700 flex items-center gap-2">
                <XCircle className="w-6 h-6" /> نقاط الضعف (للتغيير الفوري)
              </h3>
              <EditButton sectionId="weaknesses" />
            </div>
            <div className="space-y-4">
              {Array.isArray(report.weaknesses) && report.weaknesses.map((weakness, idx) => (
                <div key={idx} className="flex gap-3">
                  {getIcon(weakness.icon, "w-5 h-5 text-red-600 flex-shrink-0")}
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{weakness.title}</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{weakness.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Team Voice Section */}
          <div className="md:col-span-12 bg-slate-50 p-8 rounded-2xl border border-slate-200 mt-2">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-700 flex items-center gap-2">
                <Quote className="w-6 h-6" /> صوت الفريق (تحليل الانطباعات العامة)
              </h3>
              <EditButton sectionId="teamVoice" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {Array.isArray(report.teamVoice) && report.teamVoice.map((feedback, idx) => (
                <div
                  key={idx}
                  className="bg-white p-6 rounded-xl shadow-sm border-r-4 border-indigo-500"
                >
                  <div className="text-xs font-bold mb-2 uppercase tracking-wider text-indigo-600">
                    {feedback.title}
                  </div>
                  <p className="text-base font-black text-slate-800 leading-relaxed">
                    "{feedback.content}"
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Roadmap Section */}
          <div className="md:col-span-12 bg-white p-6 rounded-2xl border border-slate-200 mt-4">
            <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-indigo-600" /> خارطة الطريق للتحسين
              </h3>
              <EditButton sectionId="roadmap" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {Array.isArray(report.roadmap) && report.roadmap.map((action, idx) => {
                const colorMap = {
                  indigo: { bg: 'bg-indigo-50', border: 'border-indigo-100', badge: 'bg-indigo-600', icon: 'text-indigo-600', check: 'text-indigo-500' },
                  orange: { bg: 'bg-orange-50', border: 'border-orange-100', badge: 'bg-orange-500', icon: 'text-orange-600', check: 'text-orange-500' },
                  green: { bg: 'bg-green-50', border: 'border-green-100', badge: 'bg-green-600', icon: 'text-green-600', check: 'text-green-600' }
                };
                const colors = colorMap[action.color] || colorMap.indigo;

                return (
                  <div key={idx} className={`${colors.bg} rounded-2xl p-5 border ${colors.border}`}>
                    <div className="flex justify-between items-center mb-3">
                      {getIcon(action.icon, `w-5 h-5 ${colors.icon}`)}
                      <span className={`${colors.badge} text-white text-[10px] font-bold px-2 py-1 rounded-full`}>
                        {action.priorityAr}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-800 mb-3">{action.title}</h4>
                    <ul className="space-y-2">
                      {Array.isArray(action.steps) && action.steps.map((item, itemIdx) => (
                        <li key={itemIdx} className="flex items-start gap-2">
                          <ListChecks className={`w-4 h-4 ${colors.check} mt-0.5 flex-shrink-0`} />
                          <span className="text-xs text-slate-600 leading-relaxed">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Development Plan Section */}
          <div className="md:col-span-12 bg-indigo-900 p-8 rounded-3xl shadow-2xl text-white relative overflow-hidden mt-4">
            <div className="flex justify-between items-center mb-8 border-b border-indigo-800 pb-4">
              <h3 className="text-xl font-bold text-white flex items-center gap-3 relative z-10">
                <BookOpen className="w-7 h-7 text-indigo-400" /> خطة التطوير والتعلم (مكتبة المصادر)
              </h3>
              <EditButton sectionId="developmentPlan" />
            </div>

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
              {Array.isArray(report.developmentPlan) && report.developmentPlan.map((category, idx) => {
                const colorMap = {
                  red: 'bg-red-50/10 border-red-200/20',
                  orange: 'bg-orange-50/10 border-orange-200/20',
                  blue: 'bg-blue-50/10 border-blue-200/20',
                  green: 'bg-green-50/10 border-green-200/20'
                };

                return (
                  <div key={idx} className={`rounded-2xl p-6 border ${colorMap[category.color] || colorMap.blue}`}>
                    <div className="flex items-center gap-3 mb-6 border-b border-white/10 pb-3">
                      <div className="p-2 bg-white/10 rounded-lg">
                        {getIcon(category.icon, "w-5 h-5 text-white")}
                      </div>
                      <h4 className="text-lg font-bold text-white">{category.categoryTitle}</h4>
                    </div>

                    <div className="space-y-4">
                      {Array.isArray(category.resources) && category.resources.map((resource, rIdx) => (
                        <div key={rIdx} className="bg-white/5 p-4 rounded-xl border border-white/10 hover:bg-white/10 transition-colors group">
                          <div className="flex justify-between items-start">
                            <div>
                              <h5 className="text-sm font-bold text-white mb-1 group-hover:text-indigo-300 transition-colors">
                                {resource.title}
                              </h5>
                              <div className="text-[10px] text-indigo-300">
                                {resource.author} <span className="mx-1">•</span> {resource.typeAr}
                              </div>
                            </div>
                            <a
                              href={resource.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-white/50 hover:text-white transition-colors"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Background Decor */}
            <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
              <div className="absolute -top-40 -left-40 w-96 h-96 bg-indigo-500 rounded-full mix-blend-overlay filter blur-3xl"></div>
              <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-500 rounded-full mix-blend-overlay filter blur-3xl"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeadershipReport;
