import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Upload,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  Loader2,
  X,
  FileText,
  User,
  Briefcase,
  Sparkles,
  Table,
  ArrowLeft,
  MessageCircle,
  AlignLeft,
  Scale,
  Search,
  Users,
  ChevronDown,
  Settings2
} from 'lucide-react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { FILE_SCHEMAS, detectFileSchema, getSchemaDetails, getNumericColumns, getTextColumns } from '../config/fileSchemas';
import { extractUniquePersons, findFeedbackForPerson, normalizeArabicName } from '../utils/fuzzyMatch';

/**
 * FileUpload Component
 * Handles CSV/Excel file uploads and direct text input for feedback data
 */
const FileUpload = ({ onDataParsed, onEmployeeInfoChange }) => {
  // Input mode: 'file' or 'text'
  const [inputMode, setInputMode] = useState('file');

  // File upload state
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState([]);
  const [parsing, setParsing] = useState(false);
  const [error, setError] = useState(null);
  const [parsedData, setParsedData] = useState(null);
  const [fileDetails, setFileDetails] = useState([]); // Track file names and sheet info

  // Text input state
  const [textInput, setTextInput] = useState('');

  // Employee info
  const [employeeName, setEmployeeName] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const fileInputRef = useRef(null);

  // Weighted assessment state
  const [showWeightConfig, setShowWeightConfig] = useState(false);
  const [weights, setWeights] = useState({}); // { 'filename::sheetname': weight }
  const [detectedSchema, setDetectedSchema] = useState(null);
  const [detectedPersons, setDetectedPersons] = useState([]);
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [personSearchQuery, setPersonSearchQuery] = useState('');
  const [showPersonDropdown, setShowPersonDropdown] = useState(false);

  // Calculate total weight
  const totalWeight = useMemo(() => {
    return Object.values(weights).reduce((sum, w) => sum + (parseFloat(w) || 0), 0);
  }, [weights]);

  // Filter persons based on search
  const filteredPersons = useMemo(() => {
    if (!personSearchQuery.trim()) return detectedPersons;
    const query = normalizeArabicName(personSearchQuery);
    return detectedPersons.filter(p =>
      normalizeArabicName(p.primaryName).includes(query) ||
      p.variations.some(v => normalizeArabicName(v).includes(query))
    );
  }, [detectedPersons, personSearchQuery]);

  // Detect schema and persons when data changes
  useEffect(() => {
    if (parsedData && parsedData.length > 0 && fileDetails.length > 0) {
      const columns = Object.keys(parsedData[0]);
      const schemaId = detectFileSchema(columns);

      // Initialize weights from file details
      const initialWeights = {};
      const totalSheets = fileDetails.reduce((sum, f) => sum + f.sheets.length, 0);
      const defaultWeight = totalSheets > 0 ? Math.floor(100 / totalSheets) : 0;

      if (schemaId) {
        const schema = getSchemaDetails(schemaId);
        setDetectedSchema(schema);

        // Extract unique persons from the person identifier column
        const persons = extractUniquePersons(parsedData, schema.personIdentifierColumn);
        setDetectedPersons(persons);

        // Initialize weights - use schema defaults if available
        fileDetails.forEach(file => {
          file.sheets.forEach(sheet => {
            const key = `${file.name}::${sheet.name}`;
            // Check if sheet matches known schema sheets
            const matchedSheet = Object.entries(schema.sheets).find(([sheetName]) =>
              sheet.name.includes(sheetName) || sheetName.includes(sheet.name)
            );
            initialWeights[key] = matchedSheet ? matchedSheet[1].defaultWeight : defaultWeight;
          });
        });
      } else {
        // No schema detected - distribute weights equally
        setDetectedSchema(null);
        setDetectedPersons([]);

        fileDetails.forEach(file => {
          file.sheets.forEach(sheet => {
            const key = `${file.name}::${sheet.name}`;
            initialWeights[key] = defaultWeight;
          });
        });
      }

      setWeights(initialWeights);
    }
  }, [parsedData, fileDetails]);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    if (droppedFiles.length > 0) {
      processFiles(droppedFiles);
    }
  };

  const handleFileSelect = (e) => {
    const selectedFiles = Array.from(e.target.files);
    if (selectedFiles.length > 0) {
      processFiles(selectedFiles);
    }
  };

  const processFiles = async (newFiles) => {
    setError(null);
    setParsing(true);

    // Combine with existing files
    const allFiles = [...files, ...newFiles];
    setFiles(allFiles);

    try {
      let allData = [];
      const details = [];

      for (const file of allFiles) {
        const fileExtension = file.name.split('.').pop().toLowerCase();

        if (!['csv', 'xlsx', 'xls'].includes(fileExtension)) {
          throw new Error(`نوع الملف "${file.name}" غير مدعوم. يرجى استخدام ملف CSV أو Excel.`);
        }

        let fileData;
        let sheetsInfo = [];

        if (fileExtension === 'csv') {
          fileData = await parseCSV(file);
          sheetsInfo = [{ name: 'CSV', rows: fileData.length }];
        } else {
          const result = await parseExcel(file);
          fileData = result.data;
          sheetsInfo = result.sheets;
        }

        if (fileData && fileData.length > 0) {
          allData = [...allData, ...fileData];
          details.push({
            name: file.name,
            sheets: sheetsInfo,
            totalRows: fileData.length
          });
        }
      }

      if (allData.length === 0) {
        throw new Error('الملفات فارغة أو لا تحتوي على بيانات صالحة.');
      }

      setParsedData(allData);
      setFileDetails(details);
      setParsing(false);
    } catch (err) {
      setError(err.message);
      setParsing(false);
      setFiles([]);
      setFileDetails([]);
    }
  };

  const parseCSV = (file) => {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          if (results.errors.length > 0) {
            reject(new Error('خطأ في قراءة ملف CSV: ' + results.errors[0].message));
          } else {
            // Add source file info to each row
            const dataWithSource = results.data.map(row => ({
              ...row,
              _sourceFile: file.name,
              _sourceSheet: 'CSV'
            }));
            resolve(dataWithSource);
          }
        },
        error: (error) => {
          reject(new Error('خطأ في قراءة ملف CSV: ' + error.message));
        }
      });
    });
  };

  const parseExcel = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const workbook = XLSX.read(e.target.result, { type: 'binary' });

          // Read ALL sheets from the Excel file
          let allData = [];
          const sheetsInfo = [];

          for (const sheetName of workbook.SheetNames) {
            const worksheet = workbook.Sheets[sheetName];
            const sheetData = XLSX.utils.sheet_to_json(worksheet);

            if (sheetData.length > 0) {
              // Add source file and sheet info to each row for tracking
              const dataWithSource = sheetData.map(row => ({
                ...row,
                _sourceFile: file.name,
                _sourceSheet: sheetName
              }));
              allData = [...allData, ...dataWithSource];
              sheetsInfo.push({ name: sheetName, rows: sheetData.length });
            }
          }

          resolve({ data: allData, sheets: sheetsInfo });
        } catch (error) {
          reject(new Error('خطأ في قراءة ملف Excel: ' + error.message));
        }
      };
      reader.onerror = () => {
        reject(new Error('فشل في قراءة الملف.'));
      };
      reader.readAsBinaryString(file);
    });
  };

  // Parse text input into structured feedback data
  const parseTextInput = (text) => {
    if (!text.trim()) {
      return null;
    }

    // Split by common delimiters (new lines, numbered lists)
    const lines = text
      .split(/\n/)
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .map(line => line.replace(/^\d+[\.\)\-]\s*/, '')); // Remove numbering

    if (lines.length === 0) {
      return null;
    }

    // Create feedback entries from text lines
    // Each non-empty line becomes a separate feedback entry
    return lines.map((line, index) => ({
      feedback_id: index + 1,
      feedback_text: line,
      source: 'text_input'
    }));
  };

  const handleSubmit = () => {
    if (!employeeName.trim()) {
      setError('يرجى إدخال اسم الموظف.');
      return;
    }
    if (!jobTitle.trim()) {
      setError('يرجى إدخال المسمى الوظيفي.');
      return;
    }

    let dataToSubmit = null;

    if (inputMode === 'file') {
      if (!parsedData) {
        setError('يرجى رفع ملف البيانات أولاً.');
        return;
      }

      // If we have a detected schema and selected person, filter data
      if (detectedSchema && selectedPerson) {
        const personFeedback = findFeedbackForPerson(
          parsedData,
          detectedSchema.personIdentifierColumn,
          selectedPerson.primaryName
        );

        if (personFeedback.length === 0) {
          setError('لم يتم العثور على تقييمات لهذا الشخص.');
          return;
        }

        // Add weight information to the data
        dataToSubmit = personFeedback.map(row => {
          const sourceKey = `${row._sourceFile}::${row._sourceSheet}`;
          return {
            ...row,
            _weight: weights[sourceKey] || 0
          };
        });
      } else {
        dataToSubmit = parsedData;
      }
    } else {
      // Text input mode
      if (!textInput.trim()) {
        setError('يرجى إدخال نص التغذية الراجعة.');
        return;
      }
      dataToSubmit = parseTextInput(textInput);
      if (!dataToSubmit || dataToSubmit.length === 0) {
        setError('لم يتم العثور على تغذية راجعة صالحة في النص.');
        return;
      }
    }

    // Include schema and weight info in the submission
    const submissionData = {
      data: dataToSubmit,
      schema: detectedSchema,
      weights: weights,
      selectedPerson: selectedPerson
    };

    onEmployeeInfoChange({ employeeName, jobTitle });
    onDataParsed(dataToSubmit, submissionData);
  };

  const clearFiles = () => {
    setFiles([]);
    setParsedData(null);
    setFileDetails([]);
    setError(null);
    setDetectedSchema(null);
    setDetectedPersons([]);
    setSelectedPerson(null);
    setWeights({});
    setShowWeightConfig(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Update weight for a specific source
  const updateWeight = (sourceKey, value) => {
    const numValue = Math.max(0, Math.min(100, parseFloat(value) || 0));
    setWeights(prev => ({
      ...prev,
      [sourceKey]: numValue
    }));
  };

  // Select a person and auto-fill employee name
  const handleSelectPerson = (person) => {
    setSelectedPerson(person);
    setEmployeeName(person.primaryName);
    setPersonSearchQuery('');
    setShowPersonDropdown(false);
  };

  const removeFile = (index) => {
    const newFiles = files.filter((_, i) => i !== index);
    if (newFiles.length === 0) {
      clearFiles();
    } else {
      // Re-process remaining files
      setFiles([]);
      processFiles(newFiles);
    }
  };

  const clearTextInput = () => {
    setTextInput('');
    setError(null);
  };

  // Switch input mode and clear previous data
  const switchInputMode = (mode) => {
    setInputMode(mode);
    setError(null);
    if (mode === 'file') {
      setTextInput('');
    } else {
      clearFiles();
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-indigo-600 via-indigo-700 to-slate-800 px-8 py-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 rounded-2xl">
              <FileSpreadsheet className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white">
                إدخال بيانات التغذية الراجعة
              </h2>
              <p className="text-indigo-200 text-sm mt-1">
                قم برفع ملف أو الصق نص التقييمات مباشرة
              </p>
            </div>
          </div>
        </div>

        {/* Input Mode Tabs */}
        <div className="flex border-b border-slate-200">
          <button
            onClick={() => switchInputMode('file')}
            className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 font-bold text-sm transition-all ${
              inputMode === 'file'
                ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/50'
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Upload className="w-5 h-5" />
            رفع ملفات (CSV / Excel)
          </button>
          <button
            onClick={() => switchInputMode('text')}
            className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 font-bold text-sm transition-all ${
              inputMode === 'text'
                ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/50'
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <MessageCircle className="w-5 h-5" />
            إدخال نص مباشر
          </button>
        </div>

        <div className="p-8 space-y-8">
          {/* Person Selection - Only show when schema detected and persons found */}
          {inputMode === 'file' && detectedSchema && detectedPersons.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                اختيار الشخص المُقيَّم
                <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full mr-2">
                  {detectedPersons.length} شخص
                </span>
              </h3>

              {/* Schema detected badge */}
              <div className="mb-4 flex items-center gap-2 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span className="text-green-700">
                  تم اكتشاف نوع الملف: <span className="font-bold">{detectedSchema.name}</span>
                </span>
              </div>

              {/* Person Search */}
              <div className="relative">
                <div className="relative">
                  <input
                    type="text"
                    value={selectedPerson ? selectedPerson.primaryName : personSearchQuery}
                    onChange={(e) => {
                      setPersonSearchQuery(e.target.value);
                      setSelectedPerson(null);
                      setShowPersonDropdown(true);
                    }}
                    onFocus={() => setShowPersonDropdown(true)}
                    placeholder="ابحث عن اسم الشخص المراد تقييمه..."
                    className="w-full px-4 py-3.5 pr-12 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-lg"
                  />
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  {selectedPerson && (
                    <button
                      onClick={() => {
                        setSelectedPerson(null);
                        setEmployeeName('');
                      }}
                      className="absolute left-12 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Dropdown */}
                {showPersonDropdown && !selectedPerson && (
                  <div className="absolute z-10 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg max-h-60 overflow-y-auto">
                    {filteredPersons.length === 0 ? (
                      <div className="px-4 py-3 text-sm text-slate-500 text-center">
                        لا توجد نتائج
                      </div>
                    ) : (
                      filteredPersons.map((person, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSelectPerson(person)}
                          className="w-full px-4 py-3 text-right hover:bg-indigo-50 transition-colors flex items-center justify-between border-b border-slate-100 last:border-0"
                        >
                          <span className="bg-slate-100 text-slate-600 text-xs px-2 py-0.5 rounded-full">
                            {person.count} تقييم
                          </span>
                          <span className="font-medium text-slate-800">{person.primaryName}</span>
                        </button>
                      ))
                    )}
                  </div>
                )}
              </div>

              {/* Selected person info */}
              {selectedPerson && (
                <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-xl">
                  <div className="flex items-center gap-2 text-green-700">
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      تم اختيار: <span className="font-bold">{selectedPerson.primaryName}</span>
                    </span>
                    <span className="text-xs bg-green-100 px-2 py-0.5 rounded-full">
                      {selectedPerson.count} تقييم
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Employee Info Section */}
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <User className="w-5 h-5 text-indigo-600" />
              معلومات الموظف
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  اسم الموظف <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={employeeName}
                    onChange={(e) => setEmployeeName(e.target.value)}
                    placeholder="مثال: أحمد محمد"
                    className="w-full px-4 py-3.5 pr-12 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-lg"
                  />
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">
                  المسمى الوظيفي <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder="مثال: مدير قسم المبيعات"
                    className="w-full px-4 py-3.5 pr-12 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-lg"
                  />
                  <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                </div>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-slate-200"></div>

          {/* File Upload Section - Only show in file mode */}
          {inputMode === 'file' && (
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Table className="w-5 h-5 text-indigo-600" />
              ملفات التقييمات
            </h3>

            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`relative border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all ${
                isDragging
                  ? 'border-indigo-500 bg-indigo-50 scale-[1.02]'
                  : files.length > 0
                    ? 'border-green-400 bg-green-50'
                    : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileSelect}
                className="hidden"
                multiple
              />

              {parsing ? (
                <div className="flex flex-col items-center gap-4">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-indigo-200 rounded-full"></div>
                    <div className="absolute inset-0 w-16 h-16 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
                  </div>
                  <p className="text-slate-600 font-bold text-lg">جاري تحليل الملفات...</p>
                </div>
              ) : files.length > 0 ? (
                <div className="flex flex-col items-center gap-4" onClick={(e) => e.stopPropagation()}>
                  <div className="relative">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10 text-green-600" />
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        clearFiles();
                      }}
                      className="absolute -top-2 -left-2 bg-red-500 text-white rounded-full p-1.5 hover:bg-red-600 transition-colors shadow-lg"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Files List */}
                  <div className="w-full max-w-md space-y-2">
                    {fileDetails.map((file, idx) => (
                      <div key={idx} className="bg-white rounded-lg p-3 border border-green-200 text-right">
                        <div className="flex items-center justify-between">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              removeFile(idx);
                            }}
                            className="text-red-500 hover:text-red-600 p-1"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          <div className="flex items-center gap-2">
                            <FileSpreadsheet className="w-4 h-4 text-green-600" />
                            <span className="font-bold text-slate-800 text-sm">{file.name}</span>
                          </div>
                        </div>
                        {/* Sheet details */}
                        {file.sheets && file.sheets.length > 0 && (
                          <div className="mt-2 pt-2 border-t border-green-100">
                            <p className="text-xs text-slate-500 mb-1">الأوراق ({file.sheets.length}):</p>
                            <div className="flex flex-wrap gap-1 justify-end">
                              {file.sheets.map((sheet, sheetIdx) => (
                                <span key={sheetIdx} className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full">
                                  {sheet.name} ({sheet.rows} صف)
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="text-center">
                    <p className="text-green-600 text-sm">
                      إجمالي: <span className="font-bold">{parsedData?.length || 0}</span> تقييم من <span className="font-bold">{files.length}</span> ملف
                    </p>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="mt-2 text-indigo-600 hover:text-indigo-700 text-sm font-medium underline"
                    >
                      + إضافة ملفات أخرى
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                    <Upload className="w-8 h-8 text-slate-400" />
                  </div>
                  <div>
                    <p className="text-slate-700 font-bold text-lg">اسحب الملفات هنا أو انقر للاختيار</p>
                    <p className="text-slate-500 text-sm mt-2">
                      يدعم ملفات <span className="font-bold text-indigo-600">CSV</span> و <span className="font-bold text-indigo-600">Excel</span> (.xlsx, .xls)
                    </p>
                    <p className="text-indigo-600 text-xs mt-1 font-medium">
                      يمكنك رفع عدة ملفات - سيتم قراءة جميع الأوراق من كل ملف Excel
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
          )}

          {/* Weight Configuration Panel - Only show when files uploaded and schema detected */}
          {inputMode === 'file' && parsedData && fileDetails.length > 0 && Object.keys(weights).length > 0 && (
            <div className="bg-gradient-to-l from-amber-50 to-orange-50 rounded-2xl p-5 border border-amber-200">
              <div className="flex items-center justify-between mb-4">
                <button
                  onClick={() => setShowWeightConfig(!showWeightConfig)}
                  className="flex items-center gap-2 text-amber-800 hover:text-amber-900 transition-colors"
                >
                  <ChevronDown className={`w-5 h-5 transition-transform ${showWeightConfig ? 'rotate-180' : ''}`} />
                  <span className="text-sm">{showWeightConfig ? 'إخفاء' : 'عرض'} الإعدادات</span>
                </button>
                <h4 className="text-sm font-bold text-amber-800 flex items-center gap-2">
                  <Scale className="w-4 h-4" />
                  إعدادات الأوزان
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    Math.abs(totalWeight - 100) < 0.1
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {totalWeight}%
                  </span>
                </h4>
              </div>

              {showWeightConfig && (
                <div className="space-y-4">
                  {/* Weight warning */}
                  {Math.abs(totalWeight - 100) >= 0.1 && (
                    <div className="flex items-center gap-2 text-red-600 text-sm bg-red-50 px-3 py-2 rounded-lg">
                      <AlertCircle className="w-4 h-4" />
                      <span>مجموع الأوزان يجب أن يساوي 100% (الحالي: {totalWeight}%)</span>
                    </div>
                  )}

                  {/* File/Sheet weights */}
                  {fileDetails.map((file, fileIdx) => (
                    <div key={fileIdx} className="bg-white rounded-xl p-4 border border-amber-100">
                      <div className="flex items-center gap-2 mb-3">
                        <FileSpreadsheet className="w-4 h-4 text-amber-600" />
                        <span className="font-bold text-slate-800 text-sm">{file.name}</span>
                      </div>

                      <div className="space-y-2">
                        {file.sheets.map((sheet, sheetIdx) => {
                          const sourceKey = `${file.name}::${sheet.name}`;
                          const weight = weights[sourceKey] || 0;

                          return (
                            <div key={sheetIdx} className="flex items-center gap-3 bg-slate-50 rounded-lg p-2">
                              <div className="flex-1 text-right">
                                <span className="text-sm text-slate-700">{sheet.name}</span>
                                <span className="text-xs text-slate-400 mr-2">({sheet.rows} صف)</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  min="0"
                                  max="100"
                                  step="1"
                                  value={weight}
                                  onChange={(e) => updateWeight(sourceKey, e.target.value)}
                                  className="w-20 px-2 py-1.5 border border-slate-200 rounded-lg text-center text-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                                />
                                <span className="text-sm text-slate-500">%</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}

                  {/* Total weight summary */}
                  <div className="flex items-center justify-between pt-3 border-t border-amber-200">
                    <span className={`text-sm font-bold ${
                      Math.abs(totalWeight - 100) < 0.1 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {Math.abs(totalWeight - 100) < 0.1 ? '✓ الأوزان صحيحة' : `✗ المجموع: ${totalWeight}%`}
                    </span>
                    <span className="text-sm text-amber-700">المجموع الكلي</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Text Input Section - Only show in text mode */}
          {inputMode === 'text' && (
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-indigo-600" />
              نص التغذية الراجعة
            </h3>

            <div className="relative">
              <textarea
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="الصق هنا تقييمات الفريق...

مثال:
- القائد يتميز بالحزم في اتخاذ القرارات لكنه لا يستمع للآراء المخالفة
- بيئة العمل مشحونة بالتوتر والخوف من ارتكاب الأخطاء
- يضع أهدافاً واضحة لكنه يتدخل في أدق التفاصيل
- الاجتماعات تتحول إلى محاضرات من طرف واحد
- جودة المخرجات ممتازة لكن على حساب راحة الفريق"
                className="w-full h-64 px-4 py-4 border-2 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-base resize-none leading-relaxed"
                dir="rtl"
              />
              {textInput && (
                <button
                  onClick={clearTextInput}
                  className="absolute top-3 left-3 bg-slate-200 hover:bg-slate-300 text-slate-600 rounded-full p-1.5 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Text input info */}
            {textInput && (
              <div className="mt-3 flex items-center gap-2 text-sm text-slate-500">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span>
                  تم اكتشاف <span className="font-bold text-indigo-600">{textInput.split('\n').filter(l => l.trim()).length}</span> سطر من التغذية الراجعة
                </span>
              </div>
            )}

            <p className="text-xs text-slate-500 mt-3 flex items-center gap-1">
              <AlignLeft className="w-3 h-3" />
              أدخل كل تقييم في سطر منفصل، أو استخدم الترقيم (1. 2. 3.)
            </p>
          </div>
          )}

          {/* Preview parsed data - Only for file mode */}
          {inputMode === 'file' && parsedData && parsedData.length > 0 && (
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
              <h4 className="text-sm font-bold text-slate-700 mb-4 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                معاينة البيانات
                <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full mr-2">
                  {parsedData.length} صف
                </span>
              </h4>
              <div className="overflow-x-auto max-h-48 overflow-y-auto rounded-xl border border-slate-200 bg-white">
                <table className="w-full text-sm">
                  <thead className="bg-slate-100 sticky top-0">
                    <tr>
                      {Object.keys(parsedData[0]).slice(0, 5).map((key, idx) => (
                        <th key={idx} className="px-4 py-3 text-right font-bold text-slate-700 border-b border-slate-200">
                          {key}
                        </th>
                      ))}
                      {Object.keys(parsedData[0]).length > 5 && (
                        <th className="px-4 py-3 text-right font-bold text-slate-400 border-b border-slate-200">
                          +{Object.keys(parsedData[0]).length - 5} أعمدة
                        </th>
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {parsedData.slice(0, 3).map((row, rowIdx) => (
                      <tr key={rowIdx} className="border-b border-slate-100 hover:bg-slate-50">
                        {Object.values(row).slice(0, 5).map((value, colIdx) => (
                          <td key={colIdx} className="px-4 py-3 text-slate-600 truncate max-w-[150px]">
                            {String(value).substring(0, 40)}
                            {String(value).length > 40 ? '...' : ''}
                          </td>
                        ))}
                        {Object.keys(row).length > 5 && (
                          <td className="px-4 py-3 text-slate-400">...</td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
                {parsedData.length > 3 && (
                  <p className="text-center text-xs text-slate-400 py-3 bg-slate-50 border-t border-slate-200">
                    ... و {parsedData.length - 3} صفوف أخرى
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="flex items-start gap-4 bg-red-50 text-red-800 px-5 py-4 rounded-xl border border-red-200">
              <AlertCircle className="w-6 h-6 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold">خطأ</h4>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={
              !employeeName ||
              !jobTitle ||
              (inputMode === 'file' ? !parsedData : !textInput.trim())
            }
            className={`w-full py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-3 ${
              employeeName && jobTitle && (inputMode === 'file' ? parsedData : textInput.trim())
                ? 'bg-gradient-to-l from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Sparkles className="w-6 h-6" />
            إنشاء التقرير القيادي
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Instructions Card - Different for each mode */}
      <div className="mt-8 bg-gradient-to-l from-amber-50 to-orange-50 rounded-2xl p-6 border border-amber-200">
        <h4 className="font-bold text-amber-800 mb-4 text-lg flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {inputMode === 'file' ? 'تعليمات تنسيق الملف' : 'تعليمات إدخال النص'}
        </h4>
        {inputMode === 'file' ? (
          <ul className="text-sm text-amber-700 space-y-3">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>يمكنك رفع <strong>ملفات متعددة</strong> في نفس الوقت (CSV أو Excel)</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>سيتم قراءة <strong>جميع الأوراق (Sheets)</strong> من كل ملف Excel تلقائياً</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>يجب أن يحتوي كل ملف على <strong>صف رأس</strong> (Header Row) بأسماء الأعمدة</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>أمثلة على الأعمدة: <strong>القيادة، التواصل، التفويض، بيئة العمل، ملاحظات عامة</strong></span>
            </li>
          </ul>
        ) : (
          <ul className="text-sm text-amber-700 space-y-3">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>أدخل كل تقييم أو ملاحظة في <strong>سطر منفصل</strong></span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>يمكنك استخدام <strong>الترقيم</strong> (1. أو 1) أو <strong>الشرطات</strong> (-)</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>اكتب تقييمات <strong>صريحة وواضحة</strong> للحصول على تحليل أدق</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>مثال: <strong>"القائد منظم لكنه لا يستمع للآراء المخالفة"</strong></span>
            </li>
          </ul>
        )}
      </div>
    </div>
  );
};

export default FileUpload;
