import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Upload,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  Loader2,
  X,
  Trash2,
  Scale,
  Users,
  ArrowLeft,
  AlertTriangle,
  Database,
  User,
  FileText,
  RefreshCw,
  Eye,
  Plus,
  Info,
  Target,
  Search,
  Calendar,
  FileSignature
} from 'lucide-react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { createLogger, subscribeToLogs, getLogHistory } from '../utils/logger';

const logger = createLogger('BatchFileUpload');

/**
 * File type configurations with weights and descriptions
 * Based on actual Thamaniya assessment files
 */
const FILE_TYPE_CONFIG = {
  'leadership_assessment_dec_2025': {
    weight: 60,
    name: 'تقييم القادة - Tally ديسمبر 2025',
    description: 'أحدث تقييم 360° للقادة من Tally - المصدر الرئيسي والأهم',
    color: 'indigo',
    priority: 1,
    identifierColumn: 'القائـد',
    sheets: [{ name: 'default', weight: 60 }]
  },
  '360_leadership_feedback': {
    weight: 10,
    name: 'تقييم القادة 2024-2025',
    description: 'تقييم 360° شامل للقادة مع أوراق متعددة',
    color: 'blue',
    priority: 2,
    identifierColumn: 'أود تقييم',
    sheets: [
      { name: 'بعد تعديل المجاملين - أغسطس 2024', weight: 3 },
      { name: 'تقييم القادة 2025 - معتمد', weight: 7 }
    ]
  },
  'station_checkin': {
    weight: 8,
    name: 'تحليل المحطة - مايو 2025',
    description: 'اجتماعات المحطة الفردية مع المدير المباشر',
    color: 'green',
    priority: 3,
    identifierColumn: '*دخول المحطة ⛽️🔑*',
    sheets: [{ name: 'default', weight: 8 }]
  },
  'quarterly_review': {
    weight: 7,
    name: 'تحليل تقييم الدوري - أبريل 2025',
    description: 'تقييم الأداء الربعي مع نظام الدروب',
    color: 'amber',
    priority: 4,
    identifierColumn: 'اسم الموظف',
    hasMultiRowHeader: true,
    headerRowIndex: 1, // 0-indexed, so row 2 in Excel
    sheets: [{ name: 'default', weight: 7 }]
  },
  'leadership_analysis_2025': {
    weight: 6,
    name: 'تحليل تقييم القيادة - أبريل 2025',
    description: 'تحليل نوعي شامل مع نقاط القوة والضعف والتوصيات',
    color: 'purple',
    priority: 5,
    identifierColumn: null, // Transposed format
    sheets: [{ name: 'default', weight: 6 }]
  },
  'periodic_evaluation_2024': {
    weight: 5,
    name: 'التقييم الدوري - جميع الأقسام 2024',
    description: 'التقييم الدوري الشامل مع تقييم القيادة',
    color: 'slate',
    priority: 6,
    identifierColumn: 'اسم الموظف',
    hasMultiRowHeader: true,
    headerRowIndex: 1, // 0-indexed, so row 2 in Excel
    sheets: [
      { name: 'النهائي منسق - أغسطس 2024', weight: 2 },
      { name: 'نوفمبر 2024 - منسق', weight: 3 }
    ]
  },
  '360_new_full': {
    weight: 4,
    name: 'تقرير 360 جديد - كامل',
    description: 'نموذج أبدأ/أستمر/أتوقف الشامل',
    color: 'teal',
    priority: 7,
    identifierColumn: 'أود تقييم',
    sheets: [{ name: 'default', weight: 4 }]
  }
};

const getColorClasses = (colorName) => {
  const colors = {
    indigo: {
      bg: 'bg-indigo-50',
      bgHover: 'hover:bg-indigo-100',
      border: 'border-indigo-300',
      borderDashed: 'border-indigo-300',
      text: 'text-indigo-700',
      badge: 'bg-indigo-100 text-indigo-700',
      icon: 'text-indigo-500',
      gradient: 'from-indigo-500 to-indigo-600',
      ring: 'ring-indigo-500'
    },
    blue: {
      bg: 'bg-blue-50',
      bgHover: 'hover:bg-blue-100',
      border: 'border-blue-300',
      borderDashed: 'border-blue-300',
      text: 'text-blue-700',
      badge: 'bg-blue-100 text-blue-700',
      icon: 'text-blue-500',
      gradient: 'from-blue-500 to-blue-600',
      ring: 'ring-blue-500'
    },
    green: {
      bg: 'bg-green-50',
      bgHover: 'hover:bg-green-100',
      border: 'border-green-300',
      borderDashed: 'border-green-300',
      text: 'text-green-700',
      badge: 'bg-green-100 text-green-700',
      icon: 'text-green-500',
      gradient: 'from-green-500 to-green-600',
      ring: 'ring-green-500'
    },
    amber: {
      bg: 'bg-amber-50',
      bgHover: 'hover:bg-amber-100',
      border: 'border-amber-300',
      borderDashed: 'border-amber-300',
      text: 'text-amber-700',
      badge: 'bg-amber-100 text-amber-700',
      icon: 'text-amber-500',
      gradient: 'from-amber-500 to-amber-600',
      ring: 'ring-amber-500'
    },
    purple: {
      bg: 'bg-purple-50',
      bgHover: 'hover:bg-purple-100',
      border: 'border-purple-300',
      borderDashed: 'border-purple-300',
      text: 'text-purple-700',
      badge: 'bg-purple-100 text-purple-700',
      icon: 'text-purple-500',
      gradient: 'from-purple-500 to-purple-600',
      ring: 'ring-purple-500'
    },
    slate: {
      bg: 'bg-slate-50',
      bgHover: 'hover:bg-slate-100',
      border: 'border-slate-300',
      borderDashed: 'border-slate-300',
      text: 'text-slate-700',
      badge: 'bg-slate-100 text-slate-700',
      icon: 'text-slate-500',
      gradient: 'from-slate-500 to-slate-600',
      ring: 'ring-slate-500'
    },
    teal: {
      bg: 'bg-teal-50',
      bgHover: 'hover:bg-teal-100',
      border: 'border-teal-300',
      borderDashed: 'border-teal-300',
      text: 'text-teal-700',
      badge: 'bg-teal-100 text-teal-700',
      icon: 'text-teal-500',
      gradient: 'from-teal-500 to-teal-600',
      ring: 'ring-teal-500'
    }
  };
  return colors[colorName] || colors.slate;
};

/**
 * Normalize Arabic name for fuzzy matching
 */
function normalizeArabicName(name) {
  if (!name) return '';
  return String(name)
    .trim()
    .toLowerCase()
    .replace(/[\u064B-\u065F]/g, '') // Remove Arabic diacritics
    .replace(/[أإآا]/g, 'ا')
    .replace(/[ةه]/g, 'ه')
    .replace(/[ىي]/g, 'ي')
    .replace(/\s+/g, ' ');
}

/**
 * Calculate fuzzy match score between two names
 */
function fuzzyMatchScore(name1, name2) {
  const n1 = normalizeArabicName(name1);
  const n2 = normalizeArabicName(name2);

  if (n1 === n2) return 100;
  if (n1.includes(n2) || n2.includes(n1)) return 90;

  const longer = n1.length > n2.length ? n1 : n2;
  const shorter = n1.length > n2.length ? n2 : n1;

  if (longer.length === 0) return 100;

  // Check word overlap
  const words1 = n1.split(' ').filter(w => w.length > 1);
  const words2 = n2.split(' ').filter(w => w.length > 1);
  const commonWords = words1.filter(w => words2.some(w2 => w.includes(w2) || w2.includes(w)));

  if (commonWords.length >= 2) return 85;
  if (commonWords.length >= 1) return 70;

  return Math.round((1 - levenshteinDistance(n1, n2) / longer.length) * 100);
}

function levenshteinDistance(s1, s2) {
  const m = s1.length, n = s2.length;
  const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = s1[i-1] === s2[j-1]
        ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
    }
  }
  return dp[m][n];
}

/**
 * Preprocess Excel data - find actual header row
 */
function preprocessExcelData(rawData) {
  if (!rawData || rawData.length === 0) return rawData;

  const firstRow = rawData[0];
  const keys = Object.keys(firstRow);

  // If keys are generic, find actual headers
  const isGenericHeaders = keys.every(k => /^(Column|__EMPTY|Field)\d*$/i.test(k) || k.startsWith('__'));

  if (isGenericHeaders && rawData.length > 1) {
    for (let i = 0; i < Math.min(10, rawData.length); i++) {
      const row = rawData[i];
      const values = Object.values(row).filter(v => v != null && String(v).trim());

      const looksLikeHeaders = values.length >= 3 &&
        values.every(v => typeof v === 'string' && v.length < 100);

      if (looksLikeHeaders) {
        const newHeaders = Object.values(row);
        const newData = rawData.slice(i + 1).map(dataRow => {
          const newRow = {};
          Object.values(dataRow).forEach((val, idx) => {
            if (newHeaders[idx]) {
              newRow[newHeaders[idx]] = val;
            }
          });
          return newRow;
        });
        logger.info(`Found headers at row ${i + 1}`, { headers: newHeaders.slice(0, 5) });
        return newData;
      }
    }
  }

  return rawData;
}

/**
 * Individual file type upload section component
 */
const FileTypeUploadSection = ({
  schemaId,
  config,
  files,
  onFilesAdded,
  onFileRemove,
  isDraggingOver,
  onDragEnter,
  onDragLeave,
  onDrop,
  parsing
}) => {
  const fileInputRef = useRef(null);
  const colors = getColorClasses(config.color);
  const hasFiles = files.length > 0;

  return (
    <div className={`rounded-2xl border-2 ${hasFiles ? colors.border : 'border-slate-200'} overflow-hidden transition-all`}>
      {/* Header with weight badge */}
      <div className={`p-4 ${hasFiles ? colors.bg : 'bg-slate-50'} border-b ${hasFiles ? colors.border : 'border-slate-200'}`}>
        <div className="flex items-start gap-4">
          {/* Weight Badge */}
          <div className={`w-16 h-16 rounded-xl flex flex-col items-center justify-center font-black shadow-sm ${
            hasFiles ? `bg-gradient-to-br ${colors.gradient} text-white` : 'bg-slate-200 text-slate-500'
          }`}>
            <span className="text-xl">{config.weight}%</span>
            <span className="text-[10px] opacity-80">وزن</span>
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className={`text-lg font-bold ${hasFiles ? colors.text : 'text-slate-700'}`}>
                {config.name}
              </h3>
              {hasFiles && (
                <CheckCircle2 className={`w-5 h-5 ${colors.icon}`} />
              )}
            </div>
            <p className="text-sm text-slate-500 mt-1">{config.description}</p>

            {/* Sheet weights breakdown */}
            {config.sheets && config.sheets.length > 1 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {config.sheets.map((sheet, idx) => (
                  <span key={idx} className="text-xs bg-white/80 text-slate-600 px-2 py-0.5 rounded border">
                    {sheet.name}: {sheet.weight}%
                  </span>
                ))}
              </div>
            )}

            <div className="flex items-center gap-2 mt-2">
              <span className="text-xs text-slate-400">الأولوية: {config.priority}</span>
              {config.identifierColumn && (
                <span className="text-xs text-slate-400">| عمود التعريف: {config.identifierColumn}</span>
              )}
              {hasFiles && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${colors.badge}`}>
                  {files.length} ملف • {files.reduce((s, f) => s + f.rowCount, 0)} صف
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Upload Area */}
      <div className="p-4 bg-white">
        {/* Drop Zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); onDragEnter(schemaId); }}
          onDragLeave={(e) => { e.preventDefault(); onDragLeave(); }}
          onDrop={(e) => { e.preventDefault(); onDrop(schemaId, Array.from(e.dataTransfer.files)); }}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
            isDraggingOver
              ? `${colors.borderDashed} ${colors.bg} ring-2 ${colors.ring}`
              : `border-slate-300 hover:${colors.borderDashed} ${colors.bgHover}`
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={(e) => onFilesAdded(schemaId, Array.from(e.target.files))}
            className="hidden"
            multiple
          />

          {parsing === schemaId ? (
            <div className="flex flex-col items-center gap-2 py-2">
              <Loader2 className={`w-6 h-6 ${colors.icon} animate-spin`} />
              <p className="text-sm text-slate-600">جاري التحليل...</p>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-3 py-2">
              <div className={`p-2 rounded-lg ${colors.bg}`}>
                <Plus className={`w-5 h-5 ${colors.icon}`} />
              </div>
              <div className="text-right">
                <p className={`text-sm font-medium ${colors.text}`}>
                  اسحب الملف هنا أو انقر للاختيار
                </p>
                <p className="text-xs text-slate-400">CSV أو Excel</p>
              </div>
            </div>
          )}
        </div>

        {/* Uploaded Files List */}
        {hasFiles && (
          <div className="mt-3 space-y-2">
            {files.map(file => (
              <div
                key={file.id}
                className={`flex items-center justify-between p-3 rounded-lg ${colors.bg} border ${colors.border}`}
              >
                <div className="flex items-center gap-3">
                  <FileText className={`w-5 h-5 ${colors.icon}`} />
                  <div>
                    <p className={`font-medium text-sm ${colors.text}`}>{file.name}</p>
                    <p className="text-xs text-slate-500">
                      {file.rowCount} صف
                      {file.sheets?.length > 1 && ` • ${file.sheets.length} أوراق`}
                      {file.preprocessed && ' • تم المعالجة'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onFileRemove(schemaId, file.id)}
                  className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4 text-red-500" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const BatchFileUpload = ({ onFilesReady, onCancel, assessmentType }) => {
  const [filesByType, setFilesByType] = useState({});
  const [draggingOver, setDraggingOver] = useState(null);
  const [parsing, setParsing] = useState(null);
  const [error, setError] = useState(null);
  const [allCandidates, setAllCandidates] = useState([]);

  // Derive assessment requirements from assessmentType prop
  const requiresLeaderAssessment = assessmentType?.id === 'full' || assessmentType?.id === 'leader_only';
  const requiresPeriodicEvaluation = assessmentType?.id === 'full' || assessmentType?.id === 'periodic_only';

  // Periodic Evaluation state for batch mode
  const [periodicEvaluationFile, setPeriodicEvaluationFile] = useState(null);
  const [periodicEvaluationData, setPeriodicEvaluationData] = useState(null);
  const [parsingPeriodicEval, setParsingPeriodicEval] = useState(false);

  // Log assessment type on mount
  useEffect(() => {
    logger.info('BatchFileUpload initialized', {
      assessmentType: assessmentType?.id,
      requiresLeaderAssessment,
      requiresPeriodicEvaluation,
      weights: assessmentType?.weights
    });
  }, [assessmentType]);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [candidatePreview, setCandidatePreview] = useState(null);
  const [showLogs, setShowLogs] = useState(false);
  const [logs, setLogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Subscribe to logs
  useEffect(() => {
    const unsubscribe = subscribeToLogs((entry, history) => {
      setLogs([...history].reverse().slice(0, 50));
    });
    setLogs(getLogHistory().reverse().slice(0, 50));
    return unsubscribe;
  }, []);

  // Calculate coverage
  const totalWeight = Object.entries(filesByType)
    .filter(([_, files]) => files && files.length > 0)
    .reduce((sum, [schemaId]) => sum + (FILE_TYPE_CONFIG[schemaId]?.weight || 0), 0);

  const uploadedTypesCount = Object.entries(filesByType).filter(([_, files]) => files && files.length > 0).length;

  // Extract candidates when files change
  useEffect(() => {
    logger.info('Extracting candidates from files');
    const candidateMap = new Map();

    Object.entries(filesByType).forEach(([schemaId, files]) => {
      if (!files || files.length === 0) return;

      const config = FILE_TYPE_CONFIG[schemaId];
      if (!config) {
        logger.warn(`No config found for schema ${schemaId}`);
        return;
      }

      const identifierCol = config.identifierColumn;
      if (!identifierCol) {
        logger.debug(`No identifier column for ${schemaId} (may be transposed format)`);
        return;
      }

      files.forEach(file => {
        if (!file.data || !Array.isArray(file.data)) return;

        file.data.forEach(row => {
          if (!row) return;

          const name = row[identifierCol];
          if (!name) return;

          const normalizedName = normalizeArabicName(name);
          if (!normalizedName) return;

          if (!candidateMap.has(normalizedName)) {
            candidateMap.set(normalizedName, {
              name: String(name).trim(),
              normalizedName,
              jobTitle: row['المسمى الوظيفي'] || row['المسمى'] || 'غير محدد',
              sources: {},
              totalEvaluations: 0
            });
          }

          const candidate = candidateMap.get(normalizedName);
          if (!candidate.sources[schemaId]) {
            candidate.sources[schemaId] = [];
          }
          candidate.sources[schemaId].push(row);
          candidate.totalEvaluations++;
        });
      });
    });

    const candidates = Array.from(candidateMap.values()).sort((a, b) =>
      a.name.localeCompare(b.name, 'ar')
    );
    logger.info(`Found ${candidates.length} unique candidates`);
    setAllCandidates(candidates);
  }, [filesByType]);

  // Generate preview when candidate selected
  useEffect(() => {
    if (!selectedCandidate) {
      setCandidatePreview(null);
      return;
    }

    const preview = {};
    Object.entries(selectedCandidate.sources).forEach(([schemaId, rows]) => {
      const config = FILE_TYPE_CONFIG[schemaId];
      if (!config) return;

      preview[schemaId] = {
        name: config.name,
        weight: config.weight,
        color: config.color,
        rowCount: rows.length,
        sampleData: rows.slice(0, 2)
      };
    });
    setCandidatePreview(preview);
  }, [selectedCandidate]);

  const parseCSV = (file) => new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.errors.length) reject(new Error('CSV error'));
        else {
          const preprocessed = preprocessExcelData(results.data);
          resolve(preprocessed.map(row => ({ ...row, _sourceFile: file.name })));
        }
      },
      error: reject
    });
  });

  const parseExcel = (file, schemaConfig = null) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: 'binary' });
        let allData = [];
        const sheets = [];

        workbook.SheetNames.forEach(sheetName => {
          let sheetData;

          // Handle multi-row header format (e.g., periodic_evaluation_2024, quarterly_review)
          if (schemaConfig?.hasMultiRowHeader) {
            const worksheet = workbook.Sheets[sheetName];
            const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            const headerRowIndex = schemaConfig.headerRowIndex || 1;

            if (rawData.length > headerRowIndex + 1) {
              // Get both header rows - Row 1 has category headers, Row 2 has column names
              const categoryRow = rawData[0] || []; // Row 1: الدرب, تقييم القيادة, etc.
              const headerRow = rawData[headerRowIndex] || []; // Row 2: اسم الموظف, القسم, etc.

              // Merge headers: use Row 2 if available, otherwise fall back to Row 1
              const mergedHeaders = [];
              const maxCols = Math.max(categoryRow.length, headerRow.length);
              for (let i = 0; i < maxCols; i++) {
                const header2 = headerRow[i];
                const header1 = categoryRow[i];
                // Prefer Row 2 header, but use Row 1 if Row 2 is empty
                if (header2 && String(header2).trim()) {
                  mergedHeaders[i] = String(header2).trim();
                } else if (header1 && String(header1).trim()) {
                  mergedHeaders[i] = String(header1).trim();
                } else {
                  mergedHeaders[i] = null;
                }
              }

              // Convert data rows to objects using the merged headers
              sheetData = [];
              for (let i = headerRowIndex + 1; i < rawData.length; i++) {
                const row = rawData[i];
                const rowObj = {};
                let hasData = false;

                mergedHeaders.forEach((header, colIdx) => {
                  if (header && row[colIdx] !== undefined && row[colIdx] !== null && row[colIdx] !== '') {
                    rowObj[header] = row[colIdx];
                    hasData = true;
                  }
                });

                if (hasData) {
                  sheetData.push(rowObj);
                }
              }

              logger.info(`Parsed multi-row header sheet: ${sheetName}`, {
                categoryRow: categoryRow?.slice(0, 5),
                headerRow: headerRow?.slice(0, 5),
                mergedHeaders: mergedHeaders?.slice(0, 10),
                dataRows: sheetData.length
              });
            } else {
              sheetData = [];
            }
          } else {
            // Standard parsing
            sheetData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
            // Preprocess to find actual headers
            sheetData = preprocessExcelData(sheetData);
          }

          if (sheetData.length) {
            allData.push(...sheetData.map(row => ({
              ...row,
              _sourceFile: file.name,
              _sourceSheet: sheetName
            })));
            sheets.push({ name: sheetName, rows: sheetData.length });
          }
        });
        resolve({ data: allData, sheets, preprocessed: true });
      } catch (err) { reject(err); }
    };
    reader.onerror = () => reject(new Error('File read error'));
    reader.readAsBinaryString(file);
  });

  /**
   * Parse periodic evaluation file (transposed format - employee names in columns)
   * Returns raw data and list of available employee names
   */
  const parsePeriodicEvaluationFile = (file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        // Get raw data as array of arrays to handle transposed format
        const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (!rawData || rawData.length < 2) {
          reject(new Error('ملف التقييم الدوري فارغ أو غير صالح'));
          return;
        }

        // First row contains employee names (starting from column index 1 or later)
        const headerRow = rawData[0];
        const employeeNames = [];

        // Known label values that should be skipped (not employee names)
        const knownLabels = ['اسم الموظف', 'الاسم', 'Employee Name', 'Name'];

        // Find employee name columns (skip first column which is usually row labels)
        for (let i = 1; i < headerRow.length; i++) {
          let name = headerRow[i];
          // Convert to string if it's not already (handles Date objects, numbers, etc.)
          if (name !== null && name !== undefined) {
            if (typeof name === 'object') {
              name = name instanceof Date ? name.toLocaleDateString('ar-SA') : String(name);
            } else {
              name = String(name);
            }
            const trimmedName = name.trim();
            // Skip known label columns
            if (trimmedName && !knownLabels.includes(trimmedName)) {
              employeeNames.push({
                index: i,
                name: trimmedName
              });
            }
          }
        }

        // Convert row labels to strings as well
        const rowLabels = rawData.slice(1).map(row => {
          const label = row[0];
          if (label === null || label === undefined) return null;
          if (typeof label === 'object') {
            return label instanceof Date ? label.toLocaleDateString('ar-SA') : String(label);
          }
          return String(label);
        }).filter(Boolean);

        logger.info('Parsed periodic evaluation file for batch', {
          totalRows: rawData.length,
          employeeCount: employeeNames.length,
          sampleNames: employeeNames.slice(0, 5).map(e => e.name)
        });

        resolve({
          rawData,
          employeeNames,
          rowLabels
        });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('فشل في قراءة الملف'));
    reader.readAsBinaryString(file);
  });

  /**
   * Handle periodic evaluation file upload for batch mode
   */
  const handlePeriodicEvaluationUpload = async (files) => {
    if (!files || files.length === 0) return;

    const file = files[0];
    const ext = file.name.split('.').pop().toLowerCase();

    if (!['xlsx', 'xls'].includes(ext)) {
      setError('يرجى رفع ملف Excel فقط (.xlsx أو .xls)');
      return;
    }

    setParsingPeriodicEval(true);
    setError(null);

    try {
      const data = await parsePeriodicEvaluationFile(file);
      setPeriodicEvaluationFile({
        name: file.name,
        employeeCount: data.employeeNames.length
      });
      setPeriodicEvaluationData(data);
      logger.info('Periodic evaluation file loaded for batch', {
        fileName: file.name,
        employees: data.employeeNames.length
      });
    } catch (err) {
      logger.error('Failed to parse periodic evaluation file', { error: err.message });
      setError(`فشل في قراءة ملف التقييم الدوري: ${err.message}`);
      setPeriodicEvaluationFile(null);
      setPeriodicEvaluationData(null);
    } finally {
      setParsingPeriodicEval(false);
    }
  };

  const handleFilesAdded = async (targetSchemaId, files) => {
    logger.info(`Processing files for ${targetSchemaId}`, { count: files.length });
    setParsing(targetSchemaId);
    setError(null);

    try {
      const newFiles = [];

      for (const file of files) {
        const ext = file.name.split('.').pop().toLowerCase();
        if (!['csv', 'xlsx', 'xls'].includes(ext)) {
          logger.warn(`Skipping unsupported file: ${file.name}`);
          continue;
        }

        let data, sheets, preprocessed = false;
        const schemaConfig = FILE_TYPE_CONFIG[targetSchemaId];
        try {
          if (ext === 'csv') {
            data = await parseCSV(file);
            sheets = [{ name: 'CSV', rows: data.length }];
          } else {
            // Pass schema config to handle multi-row headers (e.g., periodic_evaluation_2024)
            const result = await parseExcel(file, schemaConfig);
            data = result.data;
            sheets = result.sheets;
            preprocessed = result.preprocessed;
          }
        } catch (parseError) {
          logger.error(`Parse error: ${file.name}`, { error: parseError.message });
          setError(`فشل في قراءة: ${file.name}`);
          continue;
        }

        if (!data || data.length === 0) {
          logger.warn(`Empty file: ${file.name}`);
          continue;
        }

        logger.info(`Adding file ${file.name} to ${targetSchemaId}`, { rows: data.length });

        newFiles.push({
          id: `${file.name}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          data,
          sheets,
          columns: Object.keys(data[0] || {}),
          rowCount: data.length,
          preprocessed
        });
      }

      if (newFiles.length > 0) {
        setFilesByType(prev => ({
          ...prev,
          [targetSchemaId]: [...(prev[targetSchemaId] || []), ...newFiles]
        }));
      }
    } catch (err) {
      logger.error('Processing error', { error: err.message });
      setError(err.message);
    } finally {
      setParsing(null);
    }
  };

  const removeFile = (schemaId, fileId) => {
    logger.info(`Removing file from ${schemaId}`, { fileId });
    setFilesByType(prev => ({
      ...prev,
      [schemaId]: (prev[schemaId] || []).filter(f => f.id !== fileId)
    }));
  };

  const clearAll = () => {
    logger.info('Clearing all files');
    setFilesByType({});
    setAllCandidates([]);
    setSelectedCandidate(null);
    setCandidatePreview(null);
    setSearchQuery('');
  };

  const handleStartProcessing = () => {
    logger.info('Starting batch processing');
    const allFilesData = {};
    Object.entries(filesByType).forEach(([schemaId, files]) => {
      if (files && files.length > 0) {
        allFilesData[schemaId] = files.flatMap(f => f.data);
      }
    });
    logger.info('Data prepared for batch', {
      schemas: Object.keys(allFilesData),
      candidateCount: allCandidates.length,
      hasPeriodicEvaluation: !!periodicEvaluationData,
      assessmentType: assessmentType?.id
    });
    // Pass periodic evaluation data and assessment type to parent
    onFilesReady(allFilesData, filesByType, {
      periodicEvaluationData: requiresPeriodicEvaluation ? periodicEvaluationData : null,
      assessmentType
    });
  };

  // Filter candidates for preview
  const filteredCandidates = searchQuery.trim()
    ? allCandidates
        .map(c => ({
          ...c,
          matchScore: fuzzyMatchScore(c.name, searchQuery)
        }))
        .filter(c => c.matchScore >= 50)
        .sort((a, b) => b.matchScore - a.matchScore)
    : allCandidates;

  const sortedFileTypes = Object.entries(FILE_TYPE_CONFIG).sort((a, b) => a[1].priority - b[1].priority);
  const hasFiles = Object.values(filesByType).some(files => files && files.length > 0);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-indigo-600 via-indigo-700 to-slate-800 px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/10 rounded-2xl">
                <FileSpreadsheet className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-white">معالجة دفعية</h2>
                <p className="text-indigo-200 text-sm mt-1">
                  ارفع الملفات لإنشاء تقارير لجميع المرشحين دفعة واحدة
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowLogs(!showLogs)}
                className={`p-2 rounded-lg transition-colors ${showLogs ? 'bg-white/20' : 'bg-white/10 hover:bg-white/20'}`}
                title="سجل العمليات"
              >
                <Database className="w-5 h-5 text-white" />
              </button>
              {hasFiles && (
                <button
                  onClick={clearAll}
                  className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors"
                  title="مسح الكل"
                >
                  <Trash2 className="w-5 h-5 text-red-200" />
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Logs Panel */}
          {showLogs && (
            <div className="bg-slate-900 rounded-xl p-4 max-h-48 overflow-y-auto text-xs font-mono">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400">سجل العمليات</span>
                <button onClick={() => setLogs([])} className="text-slate-500 hover:text-slate-300">
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>
              {logs.length === 0 ? (
                <p className="text-slate-500">لا توجد سجلات</p>
              ) : (
                logs.map((log, idx) => (
                  <div key={idx} className={`py-1 ${
                    log.level === 'ERROR' ? 'text-red-400' :
                    log.level === 'WARN' ? 'text-amber-400' :
                    log.level === 'INFO' ? 'text-green-400' : 'text-slate-400'
                  }`}>
                    <span className="text-slate-600">{log.timestamp?.split('T')[1]?.split('.')[0]}</span>
                    {' '}<span className="text-slate-500">[{log.context}]</span> {log.message}
                  </div>
                ))
              )}
            </div>
          )}

          {error && (
            <div className="flex items-start gap-3 bg-red-50 text-red-800 px-4 py-3 rounded-xl border border-red-200">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">خطأ</p>
                <p className="text-sm">{error}</p>
              </div>
            </div>
          )}

          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-800">
              <p className="font-bold mb-1">المعالجة الدفعية:</p>
              <ul className="list-disc list-inside space-y-1 text-blue-700">
                <li>ارفع جميع الملفات في أقسامها المناسبة</li>
                <li>سيتم إنشاء تقارير لجميع المرشحين المكتشفين تلقائياً</li>
                <li>يمكنك تصدير جميع التقارير بصيغة Excel</li>
              </ul>
            </div>
          </div>

          {/* Assessment Type Banner */}
          {assessmentType && (
            <div className="bg-gradient-to-l from-indigo-100 to-purple-100 rounded-2xl p-4 border-2 border-indigo-200">
              <div className="flex items-center gap-3">
                <Scale className="w-6 h-6 text-indigo-600" />
                <div>
                  <h4 className="font-bold text-slate-800">نوع التقييم: {assessmentType.title}</h4>
                  <div className="flex items-center gap-3 mt-1 flex-wrap">
                    {assessmentType.weights.leader > 0 && (
                      <span className="bg-orange-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                        المدير {assessmentType.weights.leader}%
                      </span>
                    )}
                    {assessmentType.weights.periodic > 0 && (
                      <span className="bg-teal-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                        الدوري {assessmentType.weights.periodic}%
                      </span>
                    )}
                    <span className="bg-purple-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                      360° {assessmentType.weights.feedback360}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Warning: Leader Assessment not supported in batch mode */}
          {requiresLeaderAssessment && (
            <div className="bg-red-50 border-2 border-red-300 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-red-800">
                <p className="font-bold mb-1">تقييم المدير غير مدعوم في المعالجة الدفعية</p>
                <p className="text-red-700">
                  نوع التقييم المختار يتطلب تقييم المدير المباشر، لكن هذه الميزة غير متوفرة في وضع المعالجة الدفعية.
                  للحصول على تقييم شامل مع تقييم المدير، استخدم <span className="font-bold">التقرير الفردي</span>.
                </p>
                <p className="mt-2 text-red-600 text-xs">
                  سيتم تجاهل وزن تقييم المدير ({assessmentType?.weights?.leader}%) وتوزيعه على المصادر الأخرى.
                </p>
              </div>
            </div>
          )}

          {/* Periodic Evaluation Section - Required when assessment type includes it */}
          {requiresPeriodicEvaluation && (
            <div className="border-2 border-teal-300 bg-teal-50/30 rounded-2xl overflow-hidden">
              <div className="p-4 bg-gradient-to-l from-teal-100 to-cyan-100 flex items-center gap-3 border-b border-teal-200">
                <Calendar className="w-5 h-5 text-teal-600" />
                <div>
                  <h4 className="font-bold text-slate-800 flex items-center gap-2">
                    التقييم الدوري - مارس 2025
                    <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">مطلوب</span>
                  </h4>
                  <p className="text-sm text-slate-500">
                    وزن {assessmentType?.weights?.periodic}% - ملف واحد يحتوي على جميع الموظفين
                  </p>
                </div>
              </div>

              <div className="p-4 bg-white">
                {!periodicEvaluationFile ? (
                  <div
                    onClick={() => document.getElementById('batch-periodic-eval-upload').click()}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      handlePeriodicEvaluationUpload(Array.from(e.dataTransfer.files));
                    }}
                    className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                      parsingPeriodicEval ? 'border-teal-500 bg-teal-50' : 'border-teal-300 hover:bg-teal-50'
                    }`}
                  >
                    <input
                      id="batch-periodic-eval-upload"
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={(e) => handlePeriodicEvaluationUpload(Array.from(e.target.files))}
                      className="hidden"
                    />
                    {parsingPeriodicEval ? (
                      <div className="flex flex-col items-center gap-2">
                        <Loader2 className="w-8 h-8 text-teal-500 animate-spin" />
                        <p className="text-sm text-slate-600">جاري تحليل الملف...</p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <Upload className="w-8 h-8 text-teal-500" />
                        <p className="text-sm font-medium text-teal-700">
                          اسحب ملف التقييم الدوري هنا أو انقر للاختيار
                        </p>
                        <p className="text-xs text-slate-400">
                          Excel فقط (.xlsx أو .xls)
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="bg-teal-50 border border-teal-200 rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <FileSpreadsheet className="w-6 h-6 text-teal-600" />
                        <div>
                          <p className="font-medium text-teal-700">{periodicEvaluationFile.name}</p>
                          <p className="text-xs text-slate-500">
                            {periodicEvaluationFile.employeeCount} موظف في الملف
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setPeriodicEvaluationFile(null);
                          setPeriodicEvaluationData(null);
                        }}
                        className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                      >
                        <X className="w-4 h-4 text-red-500" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Coverage Summary Bar */}
          <div className="bg-gradient-to-l from-slate-50 to-slate-100 rounded-2xl p-4 border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-slate-600" />
                <span className="font-bold text-slate-700">تغطية الأوزان</span>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-slate-500">
                  <span className="font-bold text-indigo-600">{uploadedTypesCount}</span>/7 أنواع
                </span>
                <span className="text-slate-500">
                  <span className="font-bold text-purple-600">{allCandidates.length}</span> مرشح
                </span>
              </div>
            </div>
            <div className="h-4 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-l from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
                style={{ width: `${totalWeight}%` }}
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-slate-500">
              <span>0%</span>
              <span className={`font-bold ${totalWeight >= 60 ? 'text-green-600' : 'text-amber-600'}`}>
                {totalWeight}% مكتمل
              </span>
              <span>100%</span>
            </div>
          </div>

          {/* File Type Sections - Each with its own upload */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Upload className="w-5 h-5" />
              أقسام رفع الملفات (7 أنواع)
            </h3>

            <div className="grid gap-4">
              {sortedFileTypes.map(([schemaId, config]) => (
                <FileTypeUploadSection
                  key={schemaId}
                  schemaId={schemaId}
                  config={config}
                  files={filesByType[schemaId] || []}
                  onFilesAdded={handleFilesAdded}
                  onFileRemove={removeFile}
                  isDraggingOver={draggingOver === schemaId}
                  onDragEnter={setDraggingOver}
                  onDragLeave={() => setDraggingOver(null)}
                  onDrop={(id, files) => { setDraggingOver(null); handleFilesAdded(id, files); }}
                  parsing={parsing}
                />
              ))}
            </div>
          </div>

          {/* Candidate Preview */}
          {allCandidates.length > 0 && (
            <div className="border-2 border-slate-200 rounded-2xl overflow-hidden">
              <div className="p-4 bg-gradient-to-l from-indigo-50 to-purple-50 flex items-center justify-between border-b border-slate-200">
                <div className="flex items-center gap-3">
                  <Eye className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h4 className="font-bold text-slate-800">معاينة المرشحين</h4>
                    <p className="text-sm text-slate-500">اختر مرشح لرؤية بياناته (البحث يدعم fuzzy matching)</p>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-white">
                {/* Search */}
                <div className="relative mb-4">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن اسم المرشح..."
                    className="w-full px-4 py-3 pr-12 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                  />
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                </div>

                <select
                  value={selectedCandidate?.normalizedName || ''}
                  onChange={(e) => setSelectedCandidate(filteredCandidates.find(c => c.normalizedName === e.target.value) || null)}
                  className="w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                >
                  <option value="">اختر مرشح للمعاينة...</option>
                  {filteredCandidates.map(c => (
                    <option key={c.normalizedName} value={c.normalizedName}>
                      {c.name} ({Object.keys(c.sources).length} مصادر • {c.totalEvaluations} تقييم)
                      {c.matchScore && c.matchScore < 100 && ` - تطابق ${c.matchScore}%`}
                    </option>
                  ))}
                </select>

                {candidatePreview && selectedCandidate && (
                  <div className="mt-4 space-y-3">
                    <div className="p-3 bg-indigo-50 rounded-xl flex items-center gap-3 border border-indigo-200">
                      <div className="p-2 bg-indigo-100 rounded-lg">
                        <User className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <span className="font-bold text-indigo-800">{selectedCandidate.name}</span>
                        <span className="text-sm text-indigo-600 mr-2">• {selectedCandidate.jobTitle}</span>
                      </div>
                    </div>

                    <div className="grid gap-2">
                      {Object.entries(candidatePreview).map(([schemaId, preview]) => {
                        const colors = getColorClasses(preview.color);
                        return (
                          <div key={schemaId} className={`p-3 rounded-xl ${colors.bg} border ${colors.border}`}>
                            <div className="flex items-center justify-between mb-2">
                              <span className={`font-bold ${colors.text}`}>{preview.name}</span>
                              <div className="flex items-center gap-2">
                                <span className={`text-xs px-2 py-0.5 rounded-full ${colors.badge}`}>
                                  {preview.rowCount} تقييم
                                </span>
                                <span className={`text-xs px-2 py-0.5 rounded-full bg-white ${colors.text}`}>
                                  {preview.weight}%
                                </span>
                              </div>
                            </div>
                            <div className="text-xs bg-white/80 rounded-lg p-2 max-h-20 overflow-y-auto">
                              {preview.sampleData.map((row, i) => (
                                <div key={i} className="truncate text-slate-600 mb-1">
                                  {Object.entries(row)
                                    .filter(([k]) => !k.startsWith('_'))
                                    .slice(0, 4)
                                    .map(([k, v]) => `${k}: ${String(v).slice(0, 20)}`)
                                    .join(' | ')}
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-4 pt-4 border-t border-slate-200">
            {onCancel && (
              <button
                onClick={onCancel}
                className="flex-1 py-3 rounded-xl border-2 border-slate-300 text-slate-600 font-bold hover:bg-slate-50 transition-colors"
              >
                إلغاء
              </button>
            )}
            <button
              onClick={handleStartProcessing}
              disabled={!hasFiles || allCandidates.length === 0}
              className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all ${
                hasFiles && allCandidates.length > 0
                  ? 'bg-gradient-to-l from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white shadow-lg hover:shadow-xl'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Users className="w-5 h-5" />
              بدء التحليل الدفعي ({allCandidates.length} مرشح)
              <ArrowLeft className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BatchFileUpload;
