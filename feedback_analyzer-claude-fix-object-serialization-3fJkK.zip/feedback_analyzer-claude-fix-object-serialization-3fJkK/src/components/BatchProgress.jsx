import React, { useEffect, useRef } from 'react';
import {
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  Brain,
  Users,
  AlertTriangle,
  Send,
  Download,
  Info,
  CheckCircle,
  AlertCircle,
  Terminal
} from 'lucide-react';

/**
 * BatchProgress Component
 * Shows real-time progress of batch candidate processing
 */
const BatchProgress = ({
  totalCandidates,
  processedCount,
  currentCandidate,
  successCount,
  failedCount,
  status, // 'processing', 'completed', 'error'
  startTime,
  estimatedTimeRemaining,
  logs = []
}) => {
  const progress = totalCandidates > 0 ? (processedCount / totalCandidates) * 100 : 0;
  const logContainerRef = useRef(null);

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // Get icon and color for log type
  const getLogStyle = (type) => {
    switch (type) {
      case 'sending':
        return { icon: Send, color: 'text-blue-500', bg: 'bg-blue-50' };
      case 'received':
        return { icon: Download, color: 'text-purple-500', bg: 'bg-purple-50' };
      case 'success':
        return { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-50' };
      case 'error':
        return { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50' };
      case 'complete':
        return { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' };
      case 'info':
      default:
        return { icon: Info, color: 'text-slate-500', bg: 'bg-slate-50' };
    }
  };

  const formatLogTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const formatTime = (ms) => {
    if (!ms || ms < 0) return '--:--';
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getElapsedTime = () => {
    if (!startTime) return '--:--';
    const elapsed = Date.now() - new Date(startTime).getTime();
    return formatTime(elapsed);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl p-8 border border-slate-200">
        {/* Header */}
        <div className="text-center mb-8">
          {status === 'processing' ? (
            <>
              <div className="relative w-24 h-24 mx-auto mb-6">
                <div className="absolute inset-0 bg-indigo-100 rounded-full animate-ping opacity-30"></div>
                <div className="absolute inset-2 bg-indigo-50 rounded-full"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Brain className="w-12 h-12 text-indigo-600 animate-pulse" />
                </div>
              </div>
              <h2 className="text-2xl font-black text-slate-800">
                جاري تحليل المرشحين
              </h2>
              <p className="text-slate-500 mt-2">
                يتم إنشاء التقارير باستخدام الذكاء الاصطناعي
              </p>
            </>
          ) : status === 'completed' ? (
            <>
              <div className="w-24 h-24 mx-auto mb-6 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-12 h-12 text-green-600" />
              </div>
              <h2 className="text-2xl font-black text-slate-800">
                اكتمل التحليل
              </h2>
              <p className="text-slate-500 mt-2">
                تم إنشاء جميع التقارير بنجاح
              </p>
            </>
          ) : (
            <>
              <div className="w-24 h-24 mx-auto mb-6 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-12 h-12 text-red-600" />
              </div>
              <h2 className="text-2xl font-black text-slate-800">
                حدث خطأ
              </h2>
              <p className="text-slate-500 mt-2">
                توقفت العملية بسبب خطأ غير متوقع
              </p>
            </>
          )}
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-slate-600">التقدم</span>
            <span className="text-sm font-bold text-indigo-600">
              {processedCount} / {totalCandidates}
            </span>
          </div>
          <div className="h-4 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                status === 'completed'
                  ? 'bg-green-500'
                  : status === 'error'
                    ? 'bg-red-500'
                    : 'bg-gradient-to-l from-indigo-500 to-purple-500'
              }`}
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between mt-2 text-xs text-slate-500">
            <span>{Math.round(progress)}% مكتمل</span>
            {status === 'processing' && estimatedTimeRemaining && (
              <span>الوقت المتبقي: ~{formatTime(estimatedTimeRemaining)}</span>
            )}
          </div>
        </div>

        {/* Current Processing */}
        {status === 'processing' && currentCandidate && (
          <div className="bg-indigo-50 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <Loader2 className="w-5 h-5 text-indigo-600 animate-spin" />
              <div>
                <p className="text-sm font-bold text-indigo-800">
                  جاري التحليل الآن:
                </p>
                <p className="text-indigo-600">{currentCandidate}</p>
              </div>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-3">
          <div className="bg-slate-50 rounded-xl p-3 text-center">
            <Users className="w-5 h-5 text-slate-400 mx-auto mb-1" />
            <p className="text-lg font-black text-slate-700">{totalCandidates}</p>
            <p className="text-xs text-slate-500">إجمالي</p>
          </div>
          <div className="bg-green-50 rounded-xl p-3 text-center">
            <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto mb-1" />
            <p className="text-lg font-black text-green-600">{successCount}</p>
            <p className="text-xs text-slate-500">ناجح</p>
          </div>
          <div className="bg-red-50 rounded-xl p-3 text-center">
            <XCircle className="w-5 h-5 text-red-500 mx-auto mb-1" />
            <p className="text-lg font-black text-red-600">{failedCount}</p>
            <p className="text-xs text-slate-500">فاشل</p>
          </div>
          <div className="bg-amber-50 rounded-xl p-3 text-center">
            <Clock className="w-5 h-5 text-amber-500 mx-auto mb-1" />
            <p className="text-lg font-black text-amber-600">{getElapsedTime()}</p>
            <p className="text-xs text-slate-500">الوقت</p>
          </div>
        </div>

        {/* Activity Log */}
        {logs.length > 0 && (
          <div className="mt-6 border-t border-slate-200 pt-6">
            <div className="flex items-center gap-2 mb-3">
              <Terminal className="w-4 h-4 text-slate-500" />
              <h3 className="text-sm font-bold text-slate-700">سجل العمليات</h3>
              <span className="text-xs text-slate-400">({logs.length})</span>
            </div>
            <div
              ref={logContainerRef}
              className="bg-slate-900 rounded-xl p-4 max-h-48 overflow-y-auto text-sm font-mono"
              dir="rtl"
            >
              {logs.map((log) => {
                const style = getLogStyle(log.type);
                const IconComponent = style.icon;
                return (
                  <div
                    key={log.id}
                    className="flex items-start gap-2 py-1.5 border-b border-slate-800 last:border-0"
                  >
                    <span className="text-slate-500 text-xs shrink-0 mt-0.5">
                      {formatLogTime(log.timestamp)}
                    </span>
                    <IconComponent className={`w-4 h-4 shrink-0 mt-0.5 ${style.color}`} />
                    <span className={`${log.type === 'error' ? 'text-red-400' : log.type === 'success' ? 'text-green-400' : 'text-slate-300'}`}>
                      {log.message}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Processing Animation */}
        {status === 'processing' && (
          <div className="mt-8 flex justify-center gap-2">
            {[0, 1, 2, 3, 4].map(i => (
              <div
                key={i}
                className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BatchProgress;
