import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  Loader2,
  X,
  Trash2,
  Scale,
  ArrowLeft,
  Database,
  User,
  FileText,
  RefreshCw,
  Eye,
  Plus,
  Search,
  Sparkles,
  Briefcase,
  Info,
  Target,
  ClipboardPaste,
  FileSignature,
  Calendar
} from 'lucide-react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { createLogger, subscribeToLogs, getLogHistory } from '../utils/logger';

const logger = createLogger('SingleCandidateUpload');

/**
 * File type configurations with weights and descriptions
 * Based on actual Thamaniya assessment files
 */
const FILE_TYPE_CONFIG = {
  'leadership_assessment_dec_2025': {
    weight: 60,
    name: 'تقييم القادة - Tally ديسمبر 2025',
    description: 'أحدث تقييم 360° للقادة من Tally - المصدر الرئيسي والأهم',
    color: 'indigo',
    priority: 1,
    identifierColumn: 'القائـد',
    sheets: [{ name: 'default', weight: 60 }]
  },
  '360_leadership_feedback': {
    weight: 10,
    name: 'تقييم القادة 2024-2025',
    description: 'تقييم 360° شامل للقادة مع أوراق متعددة',
    color: 'blue',
    priority: 2,
    identifierColumn: 'أود تقييم',
    sheets: [
      { name: 'بعد تعديل المجاملين - أغسطس 2024', weight: 3 },
      { name: 'تقييم القادة 2025 - معتمد', weight: 7 }
    ]
  },
  'station_checkin': {
    weight: 8,
    name: 'تحليل المحطة - مايو 2025',
    description: 'اجتماعات المحطة الفردية مع المدير المباشر',
    color: 'green',
    priority: 3,
    identifierColumn: '*دخول المحطة ⛽️🔑*',
    sheets: [{ name: 'default', weight: 8 }]
  },
  'quarterly_review': {
    weight: 7,
    name: 'تحليل تقييم الدوري - أبريل 2025',
    description: 'تقييم الأداء الربعي مع نظام الدروب',
    color: 'amber',
    priority: 4,
    identifierColumn: 'اسم الموظف',
    hasMultiRowHeader: true,
    headerRowIndex: 1, // 0-indexed, so row 2 in Excel
    sheets: [{ name: 'default', weight: 7 }]
  },
  'leadership_analysis_2025': {
    weight: 6,
    name: 'تحليل تقييم القيادة - أبريل 2025',
    description: 'تحليل نوعي شامل مع نقاط القوة والضعف والتوصيات',
    color: 'purple',
    priority: 5,
    identifierColumn: null, // Transposed format
    sheets: [{ name: 'default', weight: 6 }]
  },
  'periodic_evaluation_2024': {
    weight: 5,
    name: 'التقييم الدوري - جميع الأقسام 2024',
    description: 'التقييم الدوري الشامل مع تقييم القيادة',
    color: 'slate',
    priority: 6,
    identifierColumn: 'اسم الموظف',
    hasMultiRowHeader: true,
    headerRowIndex: 1, // 0-indexed, so row 2 in Excel
    sheets: [
      { name: 'النهائي منسق - أغسطس 2024', weight: 2 },
      { name: 'نوفمبر 2024 - منسق', weight: 3 }
    ]
  },
  '360_new_full': {
    weight: 4,
    name: 'تقرير 360 جديد - كامل',
    description: 'نموذج أبدأ/أستمر/أتوقف الشامل',
    color: 'teal',
    priority: 7,
    identifierColumn: 'أود تقييم',
    sheets: [{ name: 'default', weight: 4 }]
  }
};

const getColorClasses = (colorName) => {
  const colors = {
    indigo: {
      bg: 'bg-indigo-50',
      bgHover: 'hover:bg-indigo-100',
      border: 'border-indigo-300',
      borderDashed: 'border-indigo-300',
      text: 'text-indigo-700',
      badge: 'bg-indigo-100 text-indigo-700',
      icon: 'text-indigo-500',
      gradient: 'from-indigo-500 to-indigo-600',
      ring: 'ring-indigo-500'
    },
    blue: {
      bg: 'bg-blue-50',
      bgHover: 'hover:bg-blue-100',
      border: 'border-blue-300',
      borderDashed: 'border-blue-300',
      text: 'text-blue-700',
      badge: 'bg-blue-100 text-blue-700',
      icon: 'text-blue-500',
      gradient: 'from-blue-500 to-blue-600',
      ring: 'ring-blue-500'
    },
    green: {
      bg: 'bg-green-50',
      bgHover: 'hover:bg-green-100',
      border: 'border-green-300',
      borderDashed: 'border-green-300',
      text: 'text-green-700',
      badge: 'bg-green-100 text-green-700',
      icon: 'text-green-500',
      gradient: 'from-green-500 to-green-600',
      ring: 'ring-green-500'
    },
    amber: {
      bg: 'bg-amber-50',
      bgHover: 'hover:bg-amber-100',
      border: 'border-amber-300',
      borderDashed: 'border-amber-300',
      text: 'text-amber-700',
      badge: 'bg-amber-100 text-amber-700',
      icon: 'text-amber-500',
      gradient: 'from-amber-500 to-amber-600',
      ring: 'ring-amber-500'
    },
    purple: {
      bg: 'bg-purple-50',
      bgHover: 'hover:bg-purple-100',
      border: 'border-purple-300',
      borderDashed: 'border-purple-300',
      text: 'text-purple-700',
      badge: 'bg-purple-100 text-purple-700',
      icon: 'text-purple-500',
      gradient: 'from-purple-500 to-purple-600',
      ring: 'ring-purple-500'
    },
    slate: {
      bg: 'bg-slate-50',
      bgHover: 'hover:bg-slate-100',
      border: 'border-slate-300',
      borderDashed: 'border-slate-300',
      text: 'text-slate-700',
      badge: 'bg-slate-100 text-slate-700',
      icon: 'text-slate-500',
      gradient: 'from-slate-500 to-slate-600',
      ring: 'ring-slate-500'
    },
    teal: {
      bg: 'bg-teal-50',
      bgHover: 'hover:bg-teal-100',
      border: 'border-teal-300',
      borderDashed: 'border-teal-300',
      text: 'text-teal-700',
      badge: 'bg-teal-100 text-teal-700',
      icon: 'text-teal-500',
      gradient: 'from-teal-500 to-teal-600',
      ring: 'ring-teal-500'
    }
  };
  return colors[colorName] || colors.slate;
};

/**
 * Normalize Arabic name for fuzzy matching
 */
function normalizeArabicName(name) {
  if (!name) return '';
  return String(name)
    .trim()
    .toLowerCase()
    .replace(/[\u064B-\u065F]/g, '') // Remove Arabic diacritics
    .replace(/[أإآا]/g, 'ا')
    .replace(/[ةه]/g, 'ه')
    .replace(/[ىي]/g, 'ي')
    .replace(/\s+/g, ' ');
}

/**
 * Calculate fuzzy match score between two names
 */
function fuzzyMatchScore(name1, name2) {
  const n1 = normalizeArabicName(name1);
  const n2 = normalizeArabicName(name2);

  if (n1 === n2) return 100;
  if (n1.includes(n2) || n2.includes(n1)) return 90;

  // Simple Levenshtein-based score
  const longer = n1.length > n2.length ? n1 : n2;
  const shorter = n1.length > n2.length ? n2 : n1;

  if (longer.length === 0) return 100;

  // Check word overlap
  const words1 = n1.split(' ').filter(w => w.length > 1);
  const words2 = n2.split(' ').filter(w => w.length > 1);
  const commonWords = words1.filter(w => words2.some(w2 => w.includes(w2) || w2.includes(w)));

  if (commonWords.length >= 2) return 85;
  if (commonWords.length >= 1) return 70;

  return Math.round((1 - levenshteinDistance(n1, n2) / longer.length) * 100);
}

function levenshteinDistance(s1, s2) {
  const m = s1.length, n = s2.length;
  const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = s1[i-1] === s2[j-1]
        ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
    }
  }
  return dp[m][n];
}

/**
 * Preprocess Excel data - find actual header row
 */
function preprocessExcelData(rawData) {
  if (!rawData || !Array.isArray(rawData) || rawData.length === 0) return [];

  // Check if first row looks like headers
  const firstRow = rawData[0];
  const keys = Object.keys(firstRow);

  // If keys are generic (Column1, Column2, etc), find actual headers
  const isGenericHeaders = keys.every(k => /^(Column|__EMPTY|Field)\d*$/i.test(k) || k.startsWith('__'));

  if (isGenericHeaders && rawData.length > 1) {
    // Look for a row that contains actual column names
    for (let i = 0; i < Math.min(10, rawData.length); i++) {
      const row = rawData[i];
      const values = Object.values(row).filter(v => v != null && String(v).trim());

      // Check if this row looks like headers (mostly strings, reasonable length)
      const looksLikeHeaders = values.length >= 3 &&
        values.every(v => typeof v === 'string' && v.length < 100);

      if (looksLikeHeaders) {
        // Use this row as headers
        const newHeaders = Object.values(row);
        const newData = rawData.slice(i + 1).map(dataRow => {
          const newRow = {};
          Object.values(dataRow).forEach((val, idx) => {
            if (newHeaders[idx]) {
              newRow[newHeaders[idx]] = val;
            }
          });
          return newRow;
        });
        logger.info(`Found headers at row ${i + 1}`, { headers: newHeaders.slice(0, 5) });
        return newData;
      }
    }
  }

  return rawData;
}

/**
 * Individual file type upload section component
 */
const FileTypeUploadSection = ({
  schemaId,
  config,
  files,
  onFilesAdded,
  onFileRemove,
  isDraggingOver,
  onDragEnter,
  onDragLeave,
  onDrop,
  parsing
}) => {
  const fileInputRef = useRef(null);
  const colors = getColorClasses(config.color);
  const hasFiles = files.length > 0;

  return (
    <div className={`rounded-2xl border-2 ${hasFiles ? colors.border : 'border-slate-200'} overflow-hidden transition-all`}>
      {/* Header with weight badge */}
      <div className={`p-4 ${hasFiles ? colors.bg : 'bg-slate-50'} border-b ${hasFiles ? colors.border : 'border-slate-200'}`}>
        <div className="flex items-start gap-4">
          {/* Weight Badge */}
          <div className={`w-16 h-16 rounded-xl flex flex-col items-center justify-center font-black shadow-sm ${
            hasFiles ? `bg-gradient-to-br ${colors.gradient} text-white` : 'bg-slate-200 text-slate-500'
          }`}>
            <span className="text-xl">{config.weight}%</span>
            <span className="text-[10px] opacity-80">وزن</span>
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className={`text-lg font-bold ${hasFiles ? colors.text : 'text-slate-700'}`}>
                {config.name}
              </h3>
              {hasFiles && (
                <CheckCircle2 className={`w-5 h-5 ${colors.icon}`} />
              )}
            </div>
            <p className="text-sm text-slate-500 mt-1">{config.description}</p>

            {/* Sheet weights breakdown */}
            {config.sheets && config.sheets.length > 1 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {config.sheets.map((sheet, idx) => (
                  <span key={idx} className="text-xs bg-white/80 text-slate-600 px-2 py-0.5 rounded border">
                    {sheet.name}: {sheet.weight}%
                  </span>
                ))}
              </div>
            )}

            <div className="flex items-center gap-2 mt-2">
              <span className="text-xs text-slate-400">الأولوية: {config.priority}</span>
              {config.identifierColumn && (
                <span className="text-xs text-slate-400">| عمود التعريف: {config.identifierColumn}</span>
              )}
              {hasFiles && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${colors.badge}`}>
                  {files.length} ملف • {files.reduce((s, f) => s + f.rowCount, 0)} صف
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Upload Area */}
      <div className="p-4 bg-white">
        {/* Drop Zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); onDragEnter(schemaId); }}
          onDragLeave={(e) => { e.preventDefault(); onDragLeave(); }}
          onDrop={(e) => { e.preventDefault(); onDrop(schemaId, Array.from(e.dataTransfer.files)); }}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
            isDraggingOver
              ? `${colors.borderDashed} ${colors.bg} ring-2 ${colors.ring}`
              : `border-slate-300 hover:${colors.borderDashed} ${colors.bgHover}`
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={(e) => onFilesAdded(schemaId, Array.from(e.target.files))}
            className="hidden"
            multiple
          />

          {parsing === schemaId ? (
            <div className="flex flex-col items-center gap-2 py-2">
              <Loader2 className={`w-6 h-6 ${colors.icon} animate-spin`} />
              <p className="text-sm text-slate-600">جاري التحليل...</p>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-3 py-2">
              <div className={`p-2 rounded-lg ${colors.bg}`}>
                <Plus className={`w-5 h-5 ${colors.icon}`} />
              </div>
              <div className="text-right">
                <p className={`text-sm font-medium ${colors.text}`}>
                  اسحب الملف هنا أو انقر للاختيار
                </p>
                <p className="text-xs text-slate-400">CSV أو Excel</p>
              </div>
            </div>
          )}
        </div>

        {/* Uploaded Files List */}
        {hasFiles && (
          <div className="mt-3 space-y-2">
            {files.map(file => (
              <div
                key={file.id}
                className={`flex items-center justify-between p-3 rounded-lg ${colors.bg} border ${colors.border}`}
              >
                <div className="flex items-center gap-3">
                  <FileText className={`w-5 h-5 ${colors.icon}`} />
                  <div>
                    <p className={`font-medium text-sm ${colors.text}`}>{file.name}</p>
                    <p className="text-xs text-slate-500">
                      {file.rowCount} صف
                      {file.sheets?.length > 1 && ` • ${file.sheets.length} أوراق`}
                      {file.preprocessed && ' • تم المعالجة'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onFileRemove(schemaId, file.id)}
                  className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4 text-red-500" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const SingleCandidateUpload = ({ onDataParsed, onEmployeeInfoChange, onCancel, assessmentType }) => {
  const [filesByType, setFilesByType] = useState({});
  const [draggingOver, setDraggingOver] = useState(null);
  const [parsing, setParsing] = useState(null);
  const [error, setError] = useState(null);
  const [allCandidates, setAllCandidates] = useState([]);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [candidatePreview, setCandidatePreview] = useState(null);
  const [showLogs, setShowLogs] = useState(false);
  const [logs, setLogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [showRawData, setShowRawData] = useState(false);

  // Derive assessment requirements from assessmentType prop
  // 'full' = Leader + Periodic + 360°
  // 'leader_only' = Leader + 360°
  // 'periodic_only' = Periodic + 360°
  // 'feedback360_only' = 360° only
  const requiresLeaderAssessment = assessmentType?.id === 'full' || assessmentType?.id === 'leader_only';
  const requiresPeriodicEvaluation = assessmentType?.id === 'full' || assessmentType?.id === 'periodic_only';

  // Leader Assessment state
  const [leaderAssessmentText, setLeaderAssessmentText] = useState('');

  // Periodic Evaluation state (التقييم الدوري)
  const [periodicEvaluationFile, setPeriodicEvaluationFile] = useState(null);
  const [periodicEvaluationData, setPeriodicEvaluationData] = useState(null);
  const [parsingPeriodicEval, setParsingPeriodicEval] = useState(false);

  // Log assessment type on mount
  useEffect(() => {
    logger.info('SingleCandidateUpload initialized', {
      assessmentType: assessmentType?.id,
      requiresLeaderAssessment,
      requiresPeriodicEvaluation,
      weights: assessmentType?.weights
    });
  }, [assessmentType]);

  // Subscribe to logs
  useEffect(() => {
    const unsubscribe = subscribeToLogs((entry, history) => {
      setLogs([...history].reverse().slice(0, 50));
    });
    setLogs(getLogHistory().reverse().slice(0, 50));
    return unsubscribe;
  }, []);

  // Calculate coverage
  const totalWeight = Object.entries(filesByType)
    .filter(([_, files]) => files && files.length > 0)
    .reduce((sum, [schemaId]) => sum + (FILE_TYPE_CONFIG[schemaId]?.weight || 0), 0);

  const uploadedTypesCount = Object.entries(filesByType).filter(([_, files]) => files && files.length > 0).length;

  // Extract candidates when files change
  useEffect(() => {
    logger.info('Extracting candidates from files');
    const candidateMap = new Map();

    Object.entries(filesByType).forEach(([schemaId, files]) => {
      if (!files || files.length === 0) return;

      const config = FILE_TYPE_CONFIG[schemaId];
      if (!config) {
        logger.warn(`No config found for schema ${schemaId}`);
        return;
      }

      const identifierCol = config.identifierColumn;
      if (!identifierCol) {
        logger.debug(`No identifier column for ${schemaId} (may be transposed format)`);
        return;
      }

      files.forEach(file => {
        if (!file.data || !Array.isArray(file.data)) return;

        file.data.forEach(row => {
          if (!row) return;

          const name = row[identifierCol];
          if (!name) return;

          const normalizedName = normalizeArabicName(name);
          if (!normalizedName) return;

          if (!candidateMap.has(normalizedName)) {
            candidateMap.set(normalizedName, {
              name: String(name).trim(),
              normalizedName,
              jobTitle: row['المسمى الوظيفي'] || row['المسمى'] || '',
              sources: {},
              totalEvaluations: 0,
              matchScores: {}
            });
          }

          const candidate = candidateMap.get(normalizedName);
          if (!candidate.sources[schemaId]) {
            candidate.sources[schemaId] = [];
          }
          candidate.sources[schemaId].push(row);
          candidate.totalEvaluations++;
        });
      });
    });

    const candidates = Array.from(candidateMap.values()).sort((a, b) =>
      a.name.localeCompare(b.name, 'ar')
    );
    logger.info(`Found ${candidates.length} unique candidates`);
    setAllCandidates(candidates);
  }, [filesByType]);

  // Generate preview when candidate selected
  useEffect(() => {
    if (!selectedCandidate) {
      setCandidatePreview(null);
      return;
    }

    const preview = {};
    Object.entries(selectedCandidate.sources).forEach(([schemaId, rows]) => {
      const config = FILE_TYPE_CONFIG[schemaId];
      if (!config) return;

      preview[schemaId] = {
        name: config.name,
        weight: config.weight,
        color: config.color,
        rowCount: rows.length,
        sampleData: rows.slice(0, 2)
      };
    });
    setCandidatePreview(preview);

    // Auto-fill job title if available
    if (selectedCandidate.jobTitle && !jobTitle) {
      setJobTitle(selectedCandidate.jobTitle);
    }
  }, [selectedCandidate, jobTitle]);

  const parseCSV = (file) => new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.errors.length) reject(new Error('CSV error'));
        else {
          const preprocessed = preprocessExcelData(results.data);
          const safeData = Array.isArray(preprocessed) ? preprocessed : [];
          resolve(safeData.map(row => ({ ...row, _sourceFile: file.name })));
        }
      },
      error: reject
    });
  });

  const parseExcel = (file, schemaConfig = null) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: 'binary' });
        let allData = [];
        const sheets = [];

        workbook.SheetNames.forEach(sheetName => {
          let sheetData;

          // Handle multi-row header format (e.g., periodic_evaluation_2024, quarterly_review)
          if (schemaConfig?.hasMultiRowHeader) {
            const worksheet = workbook.Sheets[sheetName];
            const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            const headerRowIndex = schemaConfig.headerRowIndex || 1;

            if (rawData.length > headerRowIndex + 1) {
              // Get both header rows - Row 1 has category headers, Row 2 has column names
              const categoryRow = rawData[0] || []; // Row 1: الدرب, تقييم القيادة, etc.
              const headerRow = rawData[headerRowIndex] || []; // Row 2: اسم الموظف, القسم, etc.

              // Merge headers: use Row 2 if available, otherwise fall back to Row 1
              const mergedHeaders = [];
              const maxCols = Math.max(categoryRow.length, headerRow.length);
              for (let i = 0; i < maxCols; i++) {
                const header2 = headerRow[i];
                const header1 = categoryRow[i];
                // Prefer Row 2 header, but use Row 1 if Row 2 is empty
                if (header2 && String(header2).trim()) {
                  mergedHeaders[i] = String(header2).trim();
                } else if (header1 && String(header1).trim()) {
                  mergedHeaders[i] = String(header1).trim();
                } else {
                  mergedHeaders[i] = null;
                }
              }

              // Convert data rows to objects using the merged headers
              sheetData = [];
              for (let i = headerRowIndex + 1; i < rawData.length; i++) {
                const row = rawData[i];
                const rowObj = {};
                let hasData = false;

                mergedHeaders.forEach((header, colIdx) => {
                  if (header && row[colIdx] !== undefined && row[colIdx] !== null && row[colIdx] !== '') {
                    rowObj[header] = row[colIdx];
                    hasData = true;
                  }
                });

                if (hasData) {
                  sheetData.push(rowObj);
                }
              }

              logger.info(`Parsed multi-row header sheet: ${sheetName}`, {
                categoryRow: categoryRow?.slice(0, 5),
                headerRow: headerRow?.slice(0, 5),
                mergedHeaders: mergedHeaders?.slice(0, 10),
                dataRows: sheetData.length
              });
            } else {
              sheetData = [];
            }
          } else {
            // Standard parsing
            sheetData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
            // Preprocess to find actual headers
            sheetData = preprocessExcelData(sheetData);
          }

          // Ensure sheetData is always an array before using .length or .map()
          const safeSheetData = Array.isArray(sheetData) ? sheetData : [];
          if (safeSheetData.length) {
            allData.push(...safeSheetData.map(row => ({
              ...row,
              _sourceFile: file.name,
              _sourceSheet: sheetName
            })));
            sheets.push({ name: sheetName, rows: safeSheetData.length });
          }
        });
        resolve({ data: allData, sheets, preprocessed: true });
      } catch (err) { reject(err); }
    };
    reader.onerror = () => reject(new Error('File read error'));
    reader.readAsBinaryString(file);
  });

  /**
   * Parse periodic evaluation file (transposed format - employee names in columns)
   * Returns raw data and list of available employee names
   */
  const parsePeriodicEvaluationFile = (file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        // Get raw data as array of arrays to handle transposed format
        const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (!rawData || rawData.length < 2) {
          reject(new Error('ملف التقييم الدوري فارغ أو غير صالح'));
          return;
        }

        // First row contains employee names (starting from column index 1 or later)
        const headerRow = rawData[0];
        const employeeNames = [];

        // Known label values that should be skipped (not employee names)
        const knownLabels = ['اسم الموظف', 'الاسم', 'Employee Name', 'Name'];

        // Find employee name columns (skip first column which is usually row labels)
        for (let i = 1; i < headerRow.length; i++) {
          let name = headerRow[i];
          // Convert to string if it's not already (handles Date objects, numbers, etc.)
          if (name !== null && name !== undefined) {
            if (typeof name === 'object') {
              name = name instanceof Date ? name.toLocaleDateString('ar-SA') : String(name);
            } else {
              name = String(name);
            }
            const trimmedName = name.trim();
            // Skip known label columns
            if (trimmedName && !knownLabels.includes(trimmedName)) {
              employeeNames.push({
                index: i,
                name: trimmedName
              });
            }
          }
        }

        logger.info('Parsed periodic evaluation file', {
          totalRows: rawData.length,
          employeeCount: employeeNames.length,
          sampleNames: employeeNames.slice(0, 5).map(e => e.name)
        });

        // Convert row labels to strings as well
        const rowLabels = rawData.slice(1).map(row => {
          const label = row[0];
          if (label === null || label === undefined) return null;
          if (typeof label === 'object') {
            return label instanceof Date ? label.toLocaleDateString('ar-SA') : String(label);
          }
          return String(label);
        }).filter(Boolean);

        resolve({
          rawData,
          employeeNames,
          rowLabels
        });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('فشل في قراءة الملف'));
    reader.readAsBinaryString(file);
  });

  /**
   * Extract specific candidate's data from periodic evaluation
   */
  const extractCandidatePeriodicData = (periodicData, candidateName) => {
    if (!periodicData || !periodicData.rawData || !candidateName) return null;

    const normalizedTarget = normalizeArabicName(candidateName);

    // Find the candidate's column
    let candidateColumn = null;
    for (const emp of periodicData.employeeNames) {
      const normalizedEmp = normalizeArabicName(emp.name);
      const matchScore = fuzzyMatchScore(normalizedTarget, normalizedEmp);
      if (matchScore >= 70) {
        candidateColumn = emp;
        break;
      }
    }

    if (!candidateColumn) {
      logger.warn('Candidate not found in periodic evaluation', { candidateName });
      return null;
    }

    // Extract all row data for this candidate
    const candidateData = {};
    const rawData = periodicData.rawData;

    for (let rowIdx = 1; rowIdx < rawData.length; rowIdx++) {
      const row = rawData[rowIdx];
      let rowLabel = row[0];
      let value = row[candidateColumn.index];

      // Convert rowLabel to string if it's a Date or other object
      if (rowLabel !== null && rowLabel !== undefined) {
        if (typeof rowLabel === 'object') {
          rowLabel = rowLabel instanceof Date ? rowLabel.toLocaleDateString('ar-SA') : String(rowLabel);
        } else {
          rowLabel = String(rowLabel);
        }
      }

      // Convert value to string if it's a Date or other object
      if (value !== null && value !== undefined && value !== '') {
        if (typeof value === 'object') {
          value = value instanceof Date ? value.toLocaleDateString('ar-SA') : String(value);
        } else if (typeof value !== 'string') {
          value = String(value);
        }
      }

      if (rowLabel && value !== undefined && value !== null && value !== '') {
        candidateData[rowLabel] = value;
      }
    }

    logger.info('Extracted periodic evaluation data for candidate', {
      candidateName,
      matchedName: candidateColumn.name,
      fieldsExtracted: Object.keys(candidateData).length
    });

    return {
      matchedName: candidateColumn.name,
      data: candidateData
    };
  };

  /**
   * Handle periodic evaluation file upload
   */
  const handlePeriodicEvaluationUpload = async (files) => {
    if (!files || files.length === 0) return;

    const file = files[0];
    const ext = file.name.split('.').pop().toLowerCase();

    if (!['xlsx', 'xls'].includes(ext)) {
      setError('يرجى رفع ملف Excel فقط (.xlsx أو .xls)');
      return;
    }

    setParsingPeriodicEval(true);
    setError(null);

    try {
      const data = await parsePeriodicEvaluationFile(file);
      setPeriodicEvaluationFile({
        name: file.name,
        employeeCount: data.employeeNames.length
      });
      setPeriodicEvaluationData(data);
      logger.info('Periodic evaluation file loaded', {
        fileName: file.name,
        employees: data.employeeNames.length
      });
    } catch (err) {
      logger.error('Failed to parse periodic evaluation file', { error: err.message });
      setError(`فشل في قراءة ملف التقييم الدوري: ${err.message}`);
      setPeriodicEvaluationFile(null);
      setPeriodicEvaluationData(null);
    } finally {
      setParsingPeriodicEval(false);
    }
  };

  const handleFilesAdded = async (targetSchemaId, files) => {
    logger.info(`Processing files for ${targetSchemaId}`, { count: files.length });
    setParsing(targetSchemaId);
    setError(null);

    try {
      const newFiles = [];

      for (const file of files) {
        const ext = file.name.split('.').pop().toLowerCase();
        if (!['csv', 'xlsx', 'xls'].includes(ext)) {
          logger.warn(`Skipping unsupported file: ${file.name}`);
          continue;
        }

        let data, sheets, preprocessed = false;
        const schemaConfig = FILE_TYPE_CONFIG[targetSchemaId];
        try {
          if (ext === 'csv') {
            data = await parseCSV(file);
            sheets = [{ name: 'CSV', rows: data.length }];
          } else {
            // Pass schema config to handle multi-row headers (e.g., periodic_evaluation_2024)
            const result = await parseExcel(file, schemaConfig);
            data = result.data;
            sheets = result.sheets;
            preprocessed = result.preprocessed;
          }
        } catch (parseError) {
          logger.error(`Parse error: ${file.name}`, { error: parseError.message });
          setError(`فشل في قراءة: ${file.name}`);
          continue;
        }

        if (!data || data.length === 0) {
          logger.warn(`Empty file: ${file.name}`);
          continue;
        }

        logger.info(`Adding file ${file.name} to ${targetSchemaId}`, { rows: data.length });

        newFiles.push({
          id: `${file.name}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          data,
          sheets,
          columns: Object.keys(data[0] || {}),
          rowCount: data.length,
          preprocessed
        });
      }

      if (newFiles.length > 0) {
        setFilesByType(prev => ({
          ...prev,
          [targetSchemaId]: [...(prev[targetSchemaId] || []), ...newFiles]
        }));
      }
    } catch (err) {
      logger.error('Processing error', { error: err.message });
      setError(err.message);
    } finally {
      setParsing(null);
    }
  };

  const removeFile = (schemaId, fileId) => {
    logger.info(`Removing file from ${schemaId}`, { fileId });
    setFilesByType(prev => ({
      ...prev,
      [schemaId]: (prev[schemaId] || []).filter(f => f.id !== fileId)
    }));
  };

  const clearAll = () => {
    logger.info('Clearing all files');
    setFilesByType({});
    setAllCandidates([]);
    setSelectedCandidate(null);
    setCandidatePreview(null);
    setJobTitle('');
    setSearchQuery('');
    // Clear periodic evaluation
    setPeriodicEvaluationFile(null);
    setPeriodicEvaluationData(null);
    // Clear leader assessment
    setLeaderAssessmentText('');
  };

  const handleGenerateReport = () => {
    if (!selectedCandidate) {
      logger.warn('Validation failed: No candidate selected');
      setError('يرجى اختيار مرشح أولاً');
      return;
    }
    if (!jobTitle.trim()) {
      logger.warn('Validation failed: No job title');
      setError('يرجى إدخال المسمى الوظيفي');
      return;
    }
    if (requiresLeaderAssessment && !leaderAssessmentText.trim()) {
      logger.warn('Validation failed: Leader assessment required but empty');
      setError('يرجى إدخال نص تقييم المدير المباشر (مطلوب لنوع التقييم المختار)');
      return;
    }
    if (requiresPeriodicEvaluation && !periodicEvaluationData) {
      logger.warn('Validation failed: Periodic evaluation required but no file');
      setError('يرجى رفع ملف التقييم الدوري (مطلوب لنوع التقييم المختار)');
      return;
    }

    // Extract periodic evaluation data for this candidate if required
    let candidatePeriodicData = null;
    if (requiresPeriodicEvaluation && periodicEvaluationData) {
      candidatePeriodicData = extractCandidatePeriodicData(periodicEvaluationData, selectedCandidate.name);
      if (!candidatePeriodicData) {
        logger.error('Candidate not found in periodic evaluation file', {
          candidateName: selectedCandidate.name,
          availableNames: periodicEvaluationData.employeeNames?.slice(0, 5).map(e => e.name)
        });
        setError(`لم يتم العثور على "${selectedCandidate.name}" في ملف التقييم الدوري`);
        return;
      }
    }

    logger.info('Generating report for candidate', {
      name: selectedCandidate.name,
      assessmentType: assessmentType?.id,
      requiresLeaderAssessment,
      leaderAssessmentLength: leaderAssessmentText.length,
      requiresPeriodicEvaluation,
      periodicDataFields: candidatePeriodicData ? Object.keys(candidatePeriodicData.data).length : 0,
      weights: assessmentType?.weights
    });

    // Gather all data for this candidate across all file types
    const candidateData = [];
    Object.entries(selectedCandidate.sources).forEach(([schemaId, rows]) => {
      const config = FILE_TYPE_CONFIG[schemaId];
      rows.forEach(row => {
        candidateData.push({
          ...row,
          _schemaId: schemaId,
          _weight: config?.weight || 0
        });
      });
    });

    // Notify parent about employee info
    onEmployeeInfoChange({
      employeeName: selectedCandidate.name,
      jobTitle: jobTitle
    });

    // Pass the data to parent with leader assessment and periodic evaluation if required
    onDataParsed(candidateData, {
      candidate: selectedCandidate,
      filesByType,
      totalWeight,
      assessmentType: assessmentType,
      leaderAssessment: requiresLeaderAssessment ? leaderAssessmentText.trim() : null,
      periodicEvaluation: requiresPeriodicEvaluation && candidatePeriodicData ? candidatePeriodicData.data : null
    });
  };

  // Filter candidates based on search with fuzzy matching
  const filteredCandidates = searchQuery.trim()
    ? allCandidates
        .map(c => ({
          ...c,
          matchScore: fuzzyMatchScore(c.name, searchQuery)
        }))
        .filter(c => c.matchScore >= 50)
        .sort((a, b) => b.matchScore - a.matchScore)
    : allCandidates;

  const sortedFileTypes = Object.entries(FILE_TYPE_CONFIG).sort((a, b) => a[1].priority - b[1].priority);
  const hasFiles = Object.values(filesByType).some(files => files && files.length > 0);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-indigo-600 via-indigo-700 to-slate-800 px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/10 rounded-2xl">
                <FileSpreadsheet className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-white">تقرير فردي</h2>
                <p className="text-indigo-200 text-sm mt-1">
                  ارفع الملفات حسب نوعها واختر المرشح لإنشاء تقريره
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowLogs(!showLogs)}
                className={`p-2 rounded-lg transition-colors ${showLogs ? 'bg-white/20' : 'bg-white/10 hover:bg-white/20'}`}
                title="سجل العمليات"
              >
                <Database className="w-5 h-5 text-white" />
              </button>
              {hasFiles && (
                <button
                  onClick={clearAll}
                  className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors"
                  title="مسح الكل"
                >
                  <Trash2 className="w-5 h-5 text-red-200" />
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Logs Panel */}
          {showLogs && (
            <div className="bg-slate-900 rounded-xl p-4 max-h-48 overflow-y-auto text-xs font-mono">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-400">سجل العمليات</span>
                <button onClick={() => setLogs([])} className="text-slate-500 hover:text-slate-300">
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>
              {logs.length === 0 ? (
                <p className="text-slate-500">لا توجد سجلات</p>
              ) : (
                logs.map((log, idx) => (
                  <div key={idx} className={`py-1 ${
                    log.level === 'ERROR' ? 'text-red-400' :
                    log.level === 'WARN' ? 'text-amber-400' :
                    log.level === 'INFO' ? 'text-green-400' : 'text-slate-400'
                  }`}>
                    <span className="text-slate-600">{log.timestamp?.split('T')[1]?.split('.')[0]}</span>
                    {' '}<span className="text-slate-500">[{log.context}]</span> {log.message}
                  </div>
                ))
              )}
            </div>
          )}

          {error && (
            <div className="flex items-start gap-3 bg-red-50 text-red-800 px-4 py-3 rounded-xl border border-red-200">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">خطأ</p>
                <p className="text-sm">{error}</p>
              </div>
            </div>
          )}

          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-800">
              <p className="font-bold mb-1">كيفية الاستخدام:</p>
              <ul className="list-disc list-inside space-y-1 text-blue-700">
                <li>ارفع كل ملف في القسم المناسب حسب نوعه</li>
                <li>ملف Tally ديسمبر 2025 هو الأهم (60% من الوزن)</li>
                <li>النظام سيتعرف على الأسماء تلقائياً مع fuzzy matching</li>
                <li>سيتم معالجة ملفات Excel تلقائياً للعثور على الرؤوس الصحيحة</li>
              </ul>
            </div>
          </div>

          {/* Coverage Summary Bar */}
          <div className="bg-gradient-to-l from-slate-50 to-slate-100 rounded-2xl p-4 border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-slate-600" />
                <span className="font-bold text-slate-700">تغطية الأوزان</span>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-slate-500">
                  <span className="font-bold text-indigo-600">{uploadedTypesCount}</span>/7 أنواع
                </span>
                <span className="text-slate-500">
                  <span className="font-bold text-purple-600">{allCandidates.length}</span> مرشح متاح
                </span>
              </div>
            </div>
            <div className="h-4 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-l from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
                style={{ width: `${totalWeight}%` }}
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-slate-500">
              <span>0%</span>
              <span className={`font-bold ${totalWeight >= 60 ? 'text-green-600' : 'text-amber-600'}`}>
                {totalWeight}% مكتمل
              </span>
              <span>100%</span>
            </div>
          </div>

          {/* File Type Sections */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Upload className="w-5 h-5" />
              أقسام رفع الملفات (7 أنواع)
            </h3>

            <div className="grid gap-4">
              {sortedFileTypes.map(([schemaId, config]) => (
                <FileTypeUploadSection
                  key={schemaId}
                  schemaId={schemaId}
                  config={config}
                  files={filesByType[schemaId] || []}
                  onFilesAdded={handleFilesAdded}
                  onFileRemove={removeFile}
                  isDraggingOver={draggingOver === schemaId}
                  onDragEnter={setDraggingOver}
                  onDragLeave={() => setDraggingOver(null)}
                  onDrop={(id, files) => { setDraggingOver(null); handleFilesAdded(id, files); }}
                  parsing={parsing}
                />
              ))}
            </div>
          </div>

          {/* Candidate Selection */}
          {allCandidates.length > 0 && (
            <div className="border-2 border-indigo-200 rounded-2xl overflow-hidden bg-indigo-50/50">
              <div className="p-4 bg-gradient-to-l from-indigo-100 to-purple-100 flex items-center gap-3 border-b border-indigo-200">
                <User className="w-5 h-5 text-indigo-600" />
                <div>
                  <h4 className="font-bold text-slate-800">اختيار المرشح</h4>
                  <p className="text-sm text-slate-500">اختر الشخص المراد إنشاء تقريره (البحث يدعم fuzzy matching)</p>
                </div>
              </div>
              <div className="p-4 bg-white">
                {/* Search */}
                <div className="relative mb-4">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن اسم المرشح..."
                    className="w-full px-4 py-3 pr-12 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                  />
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                </div>

                {/* Candidate List */}
                <div className="max-h-60 overflow-y-auto space-y-2">
                  {filteredCandidates.map(candidate => {
                    const isSelected = selectedCandidate?.normalizedName === candidate.normalizedName;
                    const sourcesCount = Object.keys(candidate.sources).length;
                    return (
                      <button
                        key={candidate.normalizedName}
                        onClick={() => setSelectedCandidate(candidate)}
                        className={`w-full p-3 rounded-xl text-right transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-indigo-100 border-2 border-indigo-500 ring-2 ring-indigo-200'
                            : 'bg-slate-50 border-2 border-transparent hover:bg-indigo-50 hover:border-indigo-200'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {candidate.matchScore && candidate.matchScore < 100 && (
                            <span className={`text-xs px-2 py-0.5 rounded-full flex items-center gap-1 ${
                              candidate.matchScore >= 85 ? 'bg-green-100 text-green-700' :
                              candidate.matchScore >= 70 ? 'bg-amber-100 text-amber-700' :
                              'bg-red-100 text-red-700'
                            }`}>
                              <Target className="w-3 h-3" />
                              {candidate.matchScore}%
                            </span>
                          )}
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            isSelected ? 'bg-indigo-200 text-indigo-700' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {candidate.totalEvaluations} تقييم
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            isSelected ? 'bg-purple-200 text-purple-700' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {sourcesCount} مصدر
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {isSelected && <CheckCircle2 className="w-5 h-5 text-indigo-600" />}
                          <span className={`font-bold ${isSelected ? 'text-indigo-700' : 'text-slate-700'}`}>
                            {candidate.name}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Selected Candidate Preview */}
          {selectedCandidate && candidatePreview && (
            <div className="border-2 border-green-200 rounded-2xl overflow-hidden">
              <div className="p-4 bg-green-50 flex items-center justify-between border-b border-green-200">
                <div className="flex items-center gap-3">
                  <Eye className="w-5 h-5 text-green-600" />
                  <div>
                    <h4 className="font-bold text-slate-800">معاينة بيانات المرشح</h4>
                    <p className="text-sm text-green-600">{selectedCandidate.name} - {selectedCandidate.totalEvaluations} تقييم</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowRawData(!showRawData)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    showRawData ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {showRawData ? '🔍 إخفاء البيانات الخام' : '🔍 عرض البيانات الخام'}
                </button>
              </div>
              <div className="p-4 bg-white space-y-3">
                {/* Job Title Input */}
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    المسمى الوظيفي <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      placeholder="مثال: مدير قسم المبيعات"
                      className="w-full px-4 py-3 pr-12 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                    />
                    <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  </div>
                </div>

                {/* Data per file type */}
                <div className="grid gap-2 mt-4">
                  {Object.entries(candidatePreview).map(([schemaId, preview]) => {
                    const colors = getColorClasses(preview.color);
                    return (
                      <div key={schemaId} className={`p-3 rounded-xl ${colors.bg} border ${colors.border}`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className={`font-bold ${colors.text}`}>{preview.name}</span>
                          <div className="flex items-center gap-2">
                            <span className={`text-xs px-2 py-0.5 rounded-full ${colors.badge}`}>
                              {preview.rowCount} تقييم
                            </span>
                            <span className={`text-xs px-2 py-0.5 rounded-full bg-white ${colors.text}`}>
                              {preview.weight}%
                            </span>
                          </div>
                        </div>
                        <div className="text-xs bg-white/80 rounded-lg p-2 max-h-20 overflow-y-auto">
                          {preview.sampleData.map((row, i) => (
                            <div key={i} className="truncate text-slate-600 mb-1">
                              {Object.entries(row)
                                .filter(([k]) => !k.startsWith('_'))
                                .slice(0, 4)
                                .map(([k, v]) => `${k}: ${String(v).slice(0, 20)}`)
                                .join(' | ')}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* RAW DATA PREVIEW - Full data that will be sent to AI */}
                {showRawData && (
                  <div className="mt-4 border-2 border-amber-300 rounded-xl overflow-hidden">
                    <div className="p-3 bg-amber-50 border-b border-amber-200">
                      <h5 className="font-bold text-amber-800 flex items-center gap-2">
                        <Database className="w-4 h-4" />
                        البيانات الكاملة التي سترسل للذكاء الاصطناعي
                      </h5>
                      <p className="text-xs text-amber-600 mt-1">
                        هذه البيانات بالضبط التي ستستخدم لإنشاء التقرير
                      </p>
                    </div>
                    <div className="bg-slate-900 p-4 max-h-96 overflow-auto">
                      <pre className="text-xs text-green-400 whitespace-pre-wrap font-mono" dir="ltr">
{JSON.stringify(
  Object.entries(selectedCandidate.sources).reduce((acc, [schemaId, rows]) => {
    acc[schemaId] = {
      fileType: FILE_TYPE_CONFIG[schemaId]?.name || schemaId,
      weight: FILE_TYPE_CONFIG[schemaId]?.weight || 0,
      totalRows: rows.length,
      data: rows.map(row => {
        const cleanRow = {};
        Object.entries(row).forEach(([k, v]) => {
          if (!k.startsWith('_')) {
            cleanRow[k] = v;
          }
        });
        return cleanRow;
      })
    };
    return acc;
  }, {}),
  null,
  2
)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Assessment Type Banner - Show selected type */}
          {selectedCandidate && assessmentType && (
            <div className="bg-gradient-to-l from-indigo-100 to-purple-100 rounded-2xl p-4 border-2 border-indigo-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Scale className="w-6 h-6 text-indigo-600" />
                  <div>
                    <h4 className="font-bold text-slate-800">نوع التقييم: {assessmentType.title}</h4>
                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                      {assessmentType.weights.leader > 0 && (
                        <span className="bg-orange-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                          المدير {assessmentType.weights.leader}%
                        </span>
                      )}
                      {assessmentType.weights.periodic > 0 && (
                        <span className="bg-teal-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                          الدوري {assessmentType.weights.periodic}%
                        </span>
                      )}
                      <span className="bg-purple-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                        360° {assessmentType.weights.feedback360}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Leader Assessment Section - Required when assessment type includes it */}
          {selectedCandidate && requiresLeaderAssessment && (
            <div className="border-2 border-orange-300 bg-orange-50/30 rounded-2xl overflow-hidden">
              <div className="p-4 bg-gradient-to-l from-orange-100 to-amber-100 flex items-center gap-3 border-b border-orange-200">
                <FileSignature className="w-5 h-5 text-orange-600" />
                <div>
                  <h4 className="font-bold text-slate-800 flex items-center gap-2">
                    تقييم المدير المباشر
                    <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">مطلوب</span>
                  </h4>
                  <p className="text-sm text-slate-500">
                    وزن {assessmentType?.weights?.leader}% من التقييم النهائي
                  </p>
                </div>
              </div>

              <div className="p-4 bg-white space-y-4">
                {/* Text Area */}
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    نص التقييم من المدير المباشر <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <textarea
                      value={leaderAssessmentText}
                      onChange={(e) => setLeaderAssessmentText(e.target.value)}
                      placeholder="الصق نص التقييم من المدير المباشر هنا...

مثال:
التقييم الدوري
زكية حكمي
الربع الرابع 2024
..."
                      rows={10}
                      className={`w-full px-4 py-3 border-2 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all resize-y min-h-[200px] ${
                        !leaderAssessmentText.trim() ? 'border-red-300 bg-red-50/30' : 'border-slate-200'
                      }`}
                      dir="rtl"
                    />
                    <ClipboardPaste className="absolute left-4 top-4 w-5 h-5 text-slate-300" />
                  </div>
                  <div className="flex items-center justify-between mt-2 text-xs text-slate-500">
                    <span>
                      {leaderAssessmentText.length > 0 ? (
                        <span className="text-green-600 font-bold">
                          ✓ {leaderAssessmentText.length} حرف
                        </span>
                      ) : (
                        <span className="text-red-500 font-medium">
                          ⚠ يرجى إدخال نص التقييم
                        </span>
                      )}
                    </span>
                    {leaderAssessmentText.length > 0 && (
                      <button
                        onClick={() => setLeaderAssessmentText('')}
                        className="text-red-500 hover:text-red-700 font-medium"
                      >
                        مسح النص
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Periodic Evaluation Section - Required when assessment type includes it */}
          {selectedCandidate && requiresPeriodicEvaluation && (
            <div className="border-2 border-teal-300 bg-teal-50/30 rounded-2xl overflow-hidden">
              <div className="p-4 bg-gradient-to-l from-teal-100 to-cyan-100 flex items-center gap-3 border-b border-teal-200">
                <Calendar className="w-5 h-5 text-teal-600" />
                <div>
                  <h4 className="font-bold text-slate-800 flex items-center gap-2">
                    التقييم الدوري - مارس 2025
                    <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">مطلوب</span>
                  </h4>
                  <p className="text-sm text-slate-500">
                    وزن {assessmentType?.weights?.periodic}% من التقييم النهائي
                  </p>
                </div>
              </div>

              <div className="p-4 bg-white space-y-4">
                {/* File Upload */}
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">
                    ملف التقييم الدوري <span className="text-red-500">*</span>
                  </label>

                    {!periodicEvaluationFile ? (
                      <div
                        onClick={() => document.getElementById('periodic-eval-upload').click()}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          handlePeriodicEvaluationUpload(Array.from(e.dataTransfer.files));
                        }}
                        className="border-2 border-dashed border-teal-300 rounded-xl p-6 text-center cursor-pointer hover:bg-teal-50 transition-all"
                      >
                        <input
                          id="periodic-eval-upload"
                          type="file"
                          accept=".xlsx,.xls"
                          onChange={(e) => handlePeriodicEvaluationUpload(Array.from(e.target.files))}
                          className="hidden"
                        />
                        {parsingPeriodicEval ? (
                          <div className="flex flex-col items-center gap-2">
                            <Loader2 className="w-8 h-8 text-teal-500 animate-spin" />
                            <p className="text-sm text-slate-600">جاري تحليل الملف...</p>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-2">
                            <Upload className="w-8 h-8 text-teal-500" />
                            <p className="text-sm font-medium text-teal-700">
                              اسحب الملف هنا أو انقر للاختيار
                            </p>
                            <p className="text-xs text-slate-400">
                              Excel فقط (.xlsx أو .xls)
                            </p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="bg-teal-50 border border-teal-200 rounded-xl p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <FileSpreadsheet className="w-6 h-6 text-teal-600" />
                            <div>
                              <p className="font-medium text-teal-700">{periodicEvaluationFile.name}</p>
                              <p className="text-xs text-slate-500">
                                {periodicEvaluationFile.employeeCount} موظف في الملف
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              setPeriodicEvaluationFile(null);
                              setPeriodicEvaluationData(null);
                            }}
                            className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4 text-red-500" />
                          </button>
                        </div>

                        {/* Show matched candidate preview */}
                        {selectedCandidate && periodicEvaluationData && (
                          <div className="mt-3 pt-3 border-t border-teal-200">
                            {(() => {
                              const match = extractCandidatePeriodicData(periodicEvaluationData, selectedCandidate.name);
                              if (match) {
                                return (
                                  <div className="text-sm">
                                    <p className="text-green-600 font-medium mb-2">
                                      ✓ تم العثور على "{match.matchedName}" في الملف
                                    </p>
                                    <div className="bg-white rounded-lg p-2 text-xs max-h-32 overflow-y-auto">
                                      {Object.entries(match.data).slice(0, 6).map(([k, v]) => (
                                        <div key={k} className="flex justify-between py-1 border-b border-slate-100 last:border-0">
                                          <span className="text-slate-500">{k}:</span>
                                          <span className="text-slate-700 font-medium">{String(v).slice(0, 30)}</span>
                                        </div>
                                      ))}
                                      {Object.keys(match.data).length > 6 && (
                                        <p className="text-slate-400 text-center mt-1">
                                          +{Object.keys(match.data).length - 6} حقول إضافية
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                );
                              } else {
                                return (
                                  <p className="text-amber-600 text-sm">
                                    ⚠ لم يتم العثور على "{selectedCandidate.name}" في الملف
                                  </p>
                                );
                              }
                            })()}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
          )}

          {/* Actions */}
          <div className="flex gap-4 pt-4 border-t border-slate-200">
            {onCancel && (
              <button
                onClick={onCancel}
                className="flex-1 py-3 rounded-xl border-2 border-slate-300 text-slate-600 font-bold hover:bg-slate-50 transition-colors"
              >
                إلغاء
              </button>
            )}
            <button
              onClick={handleGenerateReport}
              disabled={!selectedCandidate || !jobTitle.trim()}
              className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all ${
                selectedCandidate && jobTitle.trim()
                  ? 'bg-gradient-to-l from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white shadow-lg hover:shadow-xl'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Sparkles className="w-5 h-5" />
              إنشاء التقرير القيادي
              <ArrowLeft className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SingleCandidateUpload;
