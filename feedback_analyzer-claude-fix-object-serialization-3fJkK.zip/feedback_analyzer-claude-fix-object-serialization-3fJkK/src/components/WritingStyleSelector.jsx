import React from 'react';
import {
  MessageSquare,
  Target,
  User,
  Users2,
  CheckCircle2,
  ArrowLeft,
  AlertCircle,
  Zap
} from 'lucide-react';
import { createLogger } from '../utils/logger';

const logger = createLogger('WritingStyleSelector');

/**
 * Writing Style Selector Component
 *
 * Allows users to choose the report writing style:
 * - Standard: Current style with 2nd person addressing
 * - Direct: No hedging words, gender-aware writing
 *
 * This component appears after assessment type selection
 */
const WritingStyleSelector = ({
  onSelect,
  onBack,
  selectedStyle = null
}) => {

  // Writing style configurations
  const writingStyles = [
    {
      id: 'standard',
      title: 'الأسلوب المعتاد',
      titleEn: 'Standard Style',
      description: 'أسلوب الكتابة الحالي مع مخاطبة الشخص بضمير المخاطب (أنت)',
      features: [
        'مخاطبة بضمير المخاطب',
        'أسلوب احترافي متوازن',
        'تعبيرات وصفية شاملة'
      ],
      icon: MessageSquare,
      color: 'slate'
    },
    {
      id: 'direct',
      title: 'أسلوب مباشر (مع مراعاة الجنس)',
      titleEn: 'Direct Style (Gender-Aware)',
      description: 'أسلوب مباشر وحازم يخاطب الشخص مباشرة مع مراعاة جنسه في صياغة الجمل',
      features: [
        'مخاطبة مباشرة بدون تحفظ',
        'تجنب عبارات مثل: يلاحظ، يبدو، ربما',
        'مراعاة جنس المُقيَّم في الصياغة',
        'أسلوب حازم وواضح'
      ],
      icon: Target,
      color: 'emerald',
      recommended: true
    }
  ];

  const handleSelect = (style) => {
    logger.info('Writing style selected', {
      style: style.id,
      title: style.title
    });
    onSelect(style);
  };

  const getColorClasses = (color, isSelected) => {
    const colors = {
      slate: {
        border: isSelected ? 'border-slate-500 ring-2 ring-slate-200' : 'border-slate-200 hover:border-slate-400',
        bg: isSelected ? 'bg-slate-50' : 'bg-white hover:bg-slate-50/50',
        icon: 'text-slate-600',
        badge: 'bg-slate-600',
        feature: 'bg-slate-100 text-slate-700'
      },
      emerald: {
        border: isSelected ? 'border-emerald-500 ring-2 ring-emerald-200' : 'border-slate-200 hover:border-emerald-400',
        bg: isSelected ? 'bg-emerald-50' : 'bg-white hover:bg-emerald-50/50',
        icon: 'text-emerald-600',
        badge: 'bg-emerald-600',
        feature: 'bg-emerald-100 text-emerald-700'
      }
    };
    return colors[color] || colors.slate;
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-emerald-900 via-emerald-800 to-slate-900 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-8 h-8 text-emerald-300" />
              <div>
                <h2 className="text-xl font-bold">اختر أسلوب الكتابة</h2>
                <p className="text-emerald-300 text-sm">
                  الخطوة 3 من 4 - تحديد طريقة صياغة التقرير
                </p>
              </div>
            </div>
            <button
              onClick={onBack}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl transition-colors text-sm font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              رجوع
            </button>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-emerald-50 border-b border-emerald-100 px-6 py-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-emerald-800">
              <p className="font-bold mb-1">ما الفرق بين الأسلوبين؟</p>
              <p className="text-emerald-700">
                الأسلوب المباشر يتجنب العبارات التحفظية (مثل: يلاحظ، يبدو، ربما) ويخاطب الشخص بشكل حازم مع مراعاة جنسه في تصريف الأفعال والضمائر.
              </p>
            </div>
          </div>
        </div>

        {/* Style Cards */}
        <div className="p-6 space-y-4">
          {writingStyles.map((style) => {
            const isSelected = selectedStyle?.id === style.id;
            const colors = getColorClasses(style.color, isSelected);
            const IconComponent = style.icon;

            return (
              <button
                key={style.id}
                onClick={() => handleSelect(style)}
                className={`w-full p-5 rounded-2xl border-2 transition-all text-right ${colors.border} ${colors.bg}`}
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div className={`p-3 rounded-xl ${isSelected ? 'bg-white shadow-sm' : 'bg-slate-100'}`}>
                    <IconComponent className={`w-6 h-6 ${colors.icon}`} />
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-bold text-slate-800">{style.title}</h3>
                      {style.recommended && (
                        <span className={`${colors.badge} text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1`}>
                          <Zap className="w-3 h-3" />
                          جديد
                        </span>
                      )}
                      {isSelected && (
                        <CheckCircle2 className={`w-5 h-5 ${colors.icon} mr-auto`} />
                      )}
                    </div>
                    <p className="text-sm text-slate-600 mb-3">{style.description}</p>

                    {/* Features */}
                    <div className="flex flex-wrap gap-2">
                      {style.features.map((feature, idx) => (
                        <span
                          key={idx}
                          className={`text-xs px-2 py-1 rounded-lg ${colors.feature}`}
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Gender Awareness Note */}
        <div className="px-6 pb-6">
          <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
            <div className="flex items-start gap-3">
              <User className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-bold text-amber-800 mb-1">كيف يتم مراعاة الجنس؟</p>
                <p className="text-amber-700">
                  يقوم الذكاء الاصطناعي بتحديد جنس الشخص من اسمه ثم يصرّف الأفعال والضمائر وفقاً لذلك (مثال: تتميز/تتميزين، لديكَ/لديكِ).
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Examples */}
        <div className="px-6 pb-6">
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
            <h4 className="text-sm font-bold text-slate-700 mb-3">أمثلة على الفرق:</h4>
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <p className="text-slate-500 text-xs mb-1">الأسلوب المعتاد:</p>
                  <p className="text-slate-700">"يُلاحظ أن لديك قدرة على التواصل"</p>
                </div>
                <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200">
                  <p className="text-emerald-600 text-xs mb-1">الأسلوب المباشر (ذكر):</p>
                  <p className="text-emerald-800">"لديكَ قدرة عالية على التواصل"</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded-lg border border-slate-200">
                  <p className="text-slate-500 text-xs mb-1">الأسلوب المعتاد:</p>
                  <p className="text-slate-700">"ربما تحتاج إلى تطوير مهارة التفويض"</p>
                </div>
                <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200">
                  <p className="text-emerald-600 text-xs mb-1">الأسلوب المباشر (أنثى):</p>
                  <p className="text-emerald-800">"تحتاجين إلى تطوير مهارة التفويض"</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WritingStyleSelector;
