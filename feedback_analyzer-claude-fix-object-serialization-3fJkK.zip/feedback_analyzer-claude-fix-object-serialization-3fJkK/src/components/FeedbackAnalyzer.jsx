import React, { useState, useCallback, useRef } from 'react';
import {
  Loader2,
  AlertCircle,
  RefreshCcw,
  Sparkles,
  BarChart3,
  FileSpreadsheet,
  Brain,
  Shield,
  Zap,
  ArrowLeft,
  Users,
  Upload,
  UserCheck,
  Mail,
  Eye,
  Target
} from 'lucide-react';
import SingleCandidateUpload from './SingleCandidateUpload';
import BatchFileUpload from './BatchFileUpload';
import BatchProgress from './BatchProgress';
import BatchResults from './BatchResults';
import LeadershipReport from './LeadershipReport';
import SectionEditor from './SectionEditor';
import ChangeTracker from './ChangeTracker';
import AssessmentTypeSelector from './AssessmentTypeSelector';
import EmailAutomation from './EmailAutomation';
import NameMatchingPreview from './NameMatchingPreview';
import {
  generateReportFromFeedback,
  extractUniqueCandidates,
  processBatchCandidates
} from '../services/geminiService';
import { validateReportUrls, validateBatchReportUrls } from '../services/urlValidatorService';
import { createLogger } from '../utils/logger';

const logger = createLogger('FeedbackAnalyzer');

/**
 * FeedbackAnalyzer Component
 * Main application component that orchestrates the feedback analysis workflow
 * Supports both single-candidate and batch processing modes
 */
const FeedbackAnalyzer = () => {
  // Mode selection: 'select', 'single', 'batch'
  const [mode, setMode] = useState('select');

  // Assessment type selection (shown after mode selection)
  // Types: 'full' (Leader+Periodic+360), 'leader_only', 'periodic_only', 'feedback360_only'
  const [assessmentType, setAssessmentType] = useState(null);

  // Writing style selection
  // Styles: 'standard' (current style), 'direct' (direct + gender-aware)
  const [writingStyle, setWritingStyle] = useState(null);

  // URL validation option
  const [urlValidationEnabled, setUrlValidationEnabled] = useState(false);
  const [isValidatingUrls, setIsValidatingUrls] = useState(false);
  const [urlValidationProgress, setUrlValidationProgress] = useState({ processed: 0, total: 0, current: '' });

  // State management
  const [feedbackData, setFeedbackData] = useState(null);
  const [employeeInfo, setEmployeeInfo] = useState({ employeeName: '', jobTitle: '' });
  const [report, setReport] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [step, setStep] = useState('assessment-type'); // 'assessment-type', 'writing-style', 'upload', 'generating', 'report', 'batch-progress', 'batch-results'

  // Batch processing state
  const [batchResults, setBatchResults] = useState(null);
  const [batchProgress, setBatchProgress] = useState({
    total: 0,
    processed: 0,
    current: null,
    success: 0,
    failed: 0,
    startTime: null,
    logs: []
  });
  const processingRef = useRef(false);

  // Editor state
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingSectionId, setEditingSectionId] = useState(null);
  const [editingContent, setEditingContent] = useState(null);

  // Change tracking state
  const [pendingChanges, setPendingChanges] = useState([]);
  const [isCommitting, setIsCommitting] = useState(false);
  const [committedRules, setCommittedRules] = useState([]);

  // Store employee info temporarily for use in generateReport
  const pendingEmployeeInfo = useRef({ employeeName: '', jobTitle: '' });
  // Store leader assessment temporarily
  const pendingLeaderAssessment = useRef(null);
  // Store periodic evaluation temporarily
  const pendingPeriodicEvaluation = useRef(null);

  // Handle file data parsed (single mode)
  const handleDataParsed = async (data, metadata = {}) => {
    setFeedbackData(data);
    setError(null);
    // Store leader assessment and periodic evaluation from metadata
    pendingLeaderAssessment.current = metadata.leaderAssessment || null;
    pendingPeriodicEvaluation.current = metadata.periodicEvaluation || null;
    await generateReport(data, pendingEmployeeInfo.current, metadata.leaderAssessment, metadata.periodicEvaluation);
  };

  // Handle employee info change
  const handleEmployeeInfoChange = (info) => {
    setEmployeeInfo(info);
    pendingEmployeeInfo.current = info;
  };

  // Handle assessment type selection
  const handleAssessmentTypeSelect = (type) => {
    logger.info('Assessment type selected', {
      mode,
      typeId: type.id,
      weights: type.weights,
      writingStyle: writingStyle?.id
    });
    setAssessmentType(type);
    setStep('upload'); // Go directly to upload (writing style already selected on main page)
  };

  // Go back to assessment type selection
  const handleBackToAssessmentType = () => {
    logger.info('Going back to assessment type selection', { mode });
    setAssessmentType(null);
    setStep('assessment-type');
    setError(null);
  };

  // Generate single report
  const generateReport = async (data = feedbackData, empInfo = null, leaderAssessment = null, periodicEvaluation = null) => {
    if (!data) {
      setError('يرجى رفع ملف البيانات أولاً.');
      return;
    }

    const finalEmployeeInfo = empInfo || employeeInfo;
    const finalLeaderAssessment = leaderAssessment || pendingLeaderAssessment.current;
    const finalPeriodicEvaluation = periodicEvaluation || pendingPeriodicEvaluation.current;

    setIsGenerating(true);
    setStep('generating');
    setError(null);

    try {
      let generatedReport = await generateReportFromFeedback(
        data,
        finalEmployeeInfo.employeeName,
        finalEmployeeInfo.jobTitle,
        finalLeaderAssessment,
        finalPeriodicEvaluation,
        writingStyle?.id || 'standard' // Pass the selected writing style
      );

      // Validate URLs if enabled
      if (urlValidationEnabled && generatedReport) {
        logger.info('Starting URL validation for single report');
        setIsValidatingUrls(true);

        try {
          const apiKey = localStorage.getItem('openrouter_api_key');
          generatedReport = await validateReportUrls(
            generatedReport,
            apiKey,
            (processed, total, current) => {
              setUrlValidationProgress({ processed, total, current });
            }
          );
          logger.info('URL validation complete', {
            stats: generatedReport._urlValidation?.stats
          });
        } catch (validationError) {
          logger.error('URL validation failed', { error: validationError.message });
          // Continue with the original report if validation fails
        } finally {
          setIsValidatingUrls(false);
        }
      }

      setReport(generatedReport);
      setStep('report');
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء إنشاء التقرير.');
      setStep('upload');
      console.error('Report generation error:', err);
    } finally {
      setIsGenerating(false);
      setIsValidatingUrls(false);
    }
  };

  // Handle batch files ready
  const handleBatchFilesReady = async (allFilesData, uploadedFiles, metadata = {}) => {
    setError(null);
    processingRef.current = true;

    const { periodicEvaluationData, assessmentType: batchAssessmentType } = metadata;

    try {
      // Extract unique candidates
      const candidates = extractUniqueCandidates(allFilesData);

      if (candidates.length === 0) {
        setError('لم يتم العثور على مرشحين في الملفات المرفوعة');
        return;
      }

      logger.info('Batch processing starting', {
        candidateCount: candidates.length,
        hasPeriodicEvaluation: !!periodicEvaluationData,
        assessmentType: batchAssessmentType?.id
      });

      // Initialize progress
      setBatchProgress({
        total: candidates.length,
        processed: 0,
        current: null,
        success: 0,
        failed: 0,
        startTime: new Date().toISOString(),
        logs: []
      });
      setStep('batch-progress');

      // Process batch with progress and log callbacks
      const results = await processBatchCandidates(
        candidates,
        // Progress callback
        (processed, total, candidateName, status) => {
          if (!processingRef.current) return;

          setBatchProgress(prev => ({
            ...prev,
            processed,
            current: candidateName,
            success: status === 'success' ? prev.success + 1 : prev.success,
            failed: status === 'failed' || status === 'error' ? prev.failed + 1 : prev.failed
          }));
        },
        // Log callback
        (message, type, candidateName) => {
          if (!processingRef.current) return;

          setBatchProgress(prev => ({
            ...prev,
            logs: [...prev.logs, {
              id: Date.now() + Math.random(),
              message,
              type,
              candidateName,
              timestamp: new Date().toISOString()
            }]
          }));
        },
        // Periodic evaluation data for batch processing
        periodicEvaluationData
      );

      // Validate URLs for all successful reports if enabled
      const successfulResults = Array.isArray(results?.successful) ? results.successful : [];
      if (urlValidationEnabled && successfulResults.length > 0) {
        logger.info('Starting URL validation for batch reports', {
          successfulReports: successfulResults.length
        });
        setIsValidatingUrls(true);

        try {
          const apiKey = localStorage.getItem('openrouter_api_key');
          const reportsToValidate = successfulResults.map(r => r.report);

          const validatedReports = await validateBatchReportUrls(
            reportsToValidate,
            apiKey,
            (reportIndex, totalReports, urlProgress) => {
              setUrlValidationProgress({
                processed: urlProgress.processed,
                total: urlProgress.total,
                current: `تقرير ${reportIndex + 1}/${totalReports}: ${urlProgress.current || ''}`
              });
            }
          );

          // Update results with validated reports
          results.successful = successfulResults.map((result, index) => ({
            ...result,
            report: validatedReports[index]
          }));

          logger.info('Batch URL validation complete');
        } catch (validationError) {
          logger.error('Batch URL validation failed', { error: validationError.message });
          // Continue with original reports if validation fails
        } finally {
          setIsValidatingUrls(false);
        }
      }

      setBatchResults(results);
      setStep('batch-results');
    } catch (err) {
      setError(err.message || 'حدث خطأ أثناء معالجة الملفات');
      setStep('upload');
    } finally {
      processingRef.current = false;
      setIsValidatingUrls(false);
    }
  };

  // Handle section edit request
  const handleEditSection = useCallback((sectionId) => {
    if (!report) return;

    setEditingSectionId(sectionId);
    setEditingContent(report[sectionId]);
    setEditorOpen(true);
  }, [report]);

  // Apply edit to section
  const handleApplyEdit = useCallback((sectionId, newContent, instruction) => {
    setReport(prev => ({
      ...prev,
      [sectionId]: newContent
    }));

    setPendingChanges(prev => [
      ...prev,
      {
        id: `${sectionId}-${Date.now()}`,
        sectionId,
        instruction,
        newContent,
        timestamp: new Date().toISOString()
      }
    ]);
  }, []);

  // Revert a specific change
  const handleRevertChange = useCallback((changeId) => {
    setPendingChanges(prev => prev.filter(c => c.id !== changeId));
  }, []);

  // Commit all changes
  const handleCommitChanges = useCallback(async () => {
    setIsCommitting(true);

    try {
      setCommittedRules(prev => [...prev, ...pendingChanges]);
      setPendingChanges([]);
      alert('تم حفظ التغييرات بنجاح! سيتم تطبيقها على التقارير المستقبلية.');
    } catch (err) {
      setError('حدث خطأ أثناء حفظ التغييرات.');
    } finally {
      setIsCommitting(false);
    }
  }, [pendingChanges]);

  // Clear all pending changes
  const handleClearAllChanges = useCallback(() => {
    if (confirm('هل أنت متأكد من تجاهل جميع التغييرات؟')) {
      setPendingChanges([]);
    }
  }, []);

  // View a specific report from batch results
  const handleViewReport = (reportData) => {
    setReport(reportData);
    setStep('report');
  };

  // Reset and start over
  const handleReset = () => {
    logger.info('Resetting application state');
    processingRef.current = false;
    setReport(null);
    setFeedbackData(null);
    setEmployeeInfo({ employeeName: '', jobTitle: '' });
    setPendingChanges([]);
    setError(null);
    setStep('assessment-type');
    setAssessmentType(null);
    setUrlValidationEnabled(false);
    setIsValidatingUrls(false);
    setUrlValidationProgress({ processed: 0, total: 0, current: '' });
    setBatchResults(null);
    setBatchProgress({
      total: 0,
      processed: 0,
      current: null,
      success: 0,
      failed: 0,
      startTime: null,
      logs: []
    });
  };

  // Go back to mode selection
  const handleBackToModeSelect = () => {
    logger.info('Going back to mode selection');
    handleReset();
    setMode('select');
  };

  // Go back to batch results from single report view
  const handleBackToBatchResults = () => {
    setReport(null);
    setStep('batch-results');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-slate-100" dir="rtl">

      {/* Hero Header - Only show on mode select */}
      {mode === 'select' && (
        <div className="bg-gradient-to-l from-indigo-900 via-indigo-800 to-slate-900 text-white">
          <div className="max-w-6xl mx-auto px-4 py-16">
            {/* Logo and Title */}
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center gap-4 mb-6">
                <div className="p-4 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/20">
                  <BarChart3 className="w-12 h-12 text-indigo-300" />
                </div>
                <div className="text-right">
                  <h1 className="text-4xl md:text-5xl font-black tracking-tight">
                    محلل التغذية الراجعة القيادية
                  </h1>
                  <p className="text-indigo-300 text-lg mt-2 font-medium">
                    تقارير قيادية احترافية مدعومة بالذكاء الاصطناعي
                  </p>
                </div>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all">
                <div className="p-3 bg-indigo-500/20 rounded-xl w-fit mb-4">
                  <FileSpreadsheet className="w-6 h-6 text-indigo-300" />
                </div>
                <h3 className="font-bold text-lg mb-2">رفع البيانات</h3>
                <p className="text-indigo-200 text-sm leading-relaxed">
                  ادعم ملفات CSV و Excel مع تحليل تلقائي للبنية
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all">
                <div className="p-3 bg-purple-500/20 rounded-xl w-fit mb-4">
                  <Brain className="w-6 h-6 text-purple-300" />
                </div>
                <h3 className="font-bold text-lg mb-2">تحليل ذكي</h3>
                <p className="text-indigo-200 text-sm leading-relaxed">
                  الذكاء الاصطناعي يحلل البيانات ويستخرج الرؤى
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all">
                <div className="p-3 bg-emerald-500/20 rounded-xl w-fit mb-4">
                  <Shield className="w-6 h-6 text-emerald-300" />
                </div>
                <h3 className="font-bold text-lg mb-2">تقارير شاملة</h3>
                <p className="text-indigo-200 text-sm leading-relaxed">
                  10 أقسام متكاملة مع تحليل الشخصية والتوصيات
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all">
                <div className="p-3 bg-amber-500/20 rounded-xl w-fit mb-4">
                  <Zap className="w-6 h-6 text-amber-300" />
                </div>
                <h3 className="font-bold text-lg mb-2">معالجة جماعية</h3>
                <p className="text-indigo-200 text-sm leading-relaxed">
                  حلل حتى 100 مرشح دفعة واحدة وصدّر النتائج
                </p>
              </div>
            </div>
          </div>

          {/* Wave divider */}
          <div className="h-16 bg-gradient-to-b from-transparent to-slate-50"></div>
        </div>
      )}

      {/* Compact Header - Show on other modes (not email/preview which have their own headers) */}
      {mode !== 'select' && mode !== 'email' && mode !== 'preview' && (
        <div className="bg-gradient-to-l from-indigo-900 via-indigo-800 to-slate-900 text-white py-4 px-4 shadow-lg">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <BarChart3 className="w-6 h-6 text-indigo-300" />
              </div>
              <div>
                <h1 className="text-xl font-bold">محلل التغذية الراجعة القيادية</h1>
                <p className="text-indigo-300 text-xs">
                  {mode === 'batch' ? 'وضع المعالجة الجماعية' : 'تقرير فردي'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {step === 'report' && batchResults && (
                <button
                  onClick={handleBackToBatchResults}
                  className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl transition-colors text-sm font-medium"
                >
                  <ArrowLeft className="w-4 h-4" />
                  العودة للنتائج
                </button>
              )}
              <button
                onClick={handleBackToModeSelect}
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl transition-colors text-sm font-medium"
              >
                <RefreshCcw className="w-4 h-4" />
                تحليل جديد
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="py-8">
        {/* Error Display */}
        {error && (
          <div className="max-w-2xl mx-auto mb-6 px-4">
            <div className="flex items-start gap-4 bg-red-50 text-red-800 px-5 py-4 rounded-2xl border border-red-200 shadow-sm">
              <AlertCircle className="w-6 h-6 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold mb-1">حدث خطأ</h4>
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Mode Selection */}
        {mode === 'select' && (
          <div className="max-w-4xl mx-auto px-4 -mt-8">
            <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 p-8">
              <h2 className="text-2xl font-black text-slate-800 text-center mb-8">
                اختر نوع الخدمة
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Single Mode */}
                <button
                  onClick={() => {
                    logger.info('Single mode selected');
                    setMode('single');
                    setWritingStyle({ id: 'standard', title: 'الأسلوب المعتاد' });
                  }}
                  className="group p-6 border-2 border-slate-200 rounded-2xl hover:border-indigo-500 hover:bg-indigo-50/50 transition-all text-right"
                >
                  <div className="p-4 bg-indigo-100 rounded-2xl w-fit mb-4 group-hover:bg-indigo-200 transition-colors">
                    <UserCheck className="w-8 h-8 text-indigo-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">تقرير فردي</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    تحليل شخص واحد بناءً على ملف تقييمات واحد أو أكثر
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-indigo-600 text-sm font-medium">
                    <span>ابدأ الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </button>

                {/* Single Mode - Direct Style */}
                <button
                  onClick={() => {
                    logger.info('Single mode (direct style) selected');
                    setMode('single');
                    setWritingStyle({ id: 'direct', title: 'أسلوب مباشر' });
                  }}
                  className="group p-6 border-2 border-emerald-300 rounded-2xl hover:border-emerald-500 hover:bg-emerald-50/50 transition-all text-right relative"
                >
                  <div className="absolute top-3 left-3 bg-emerald-500 text-white text-[10px] font-bold px-2 py-1 rounded-full">
                    جديد
                  </div>
                  <div className="p-4 bg-emerald-100 rounded-2xl w-fit mb-4 group-hover:bg-emerald-200 transition-colors">
                    <Target className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">تقرير فردي - أسلوب مباشر</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    أسلوب حازم بدون تحفظ مع مراعاة جنس المُقيَّم في الصياغة
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-emerald-600 text-sm font-medium">
                    <span>ابدأ الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </button>

                {/* Batch Mode */}
                <button
                  onClick={() => {
                    logger.info('Batch mode selected');
                    setMode('batch');
                    setWritingStyle({ id: 'standard', title: 'الأسلوب المعتاد' });
                  }}
                  className="group p-6 border-2 border-slate-200 rounded-2xl hover:border-purple-500 hover:bg-purple-50/50 transition-all text-right"
                >
                  <div className="p-4 bg-purple-100 rounded-2xl w-fit mb-4 group-hover:bg-purple-200 transition-colors">
                    <Users className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">معالجة جماعية</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    تحليل عدة مرشحين دفعة واحدة مع تصدير النتائج إلى Excel
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-purple-600 text-sm font-medium">
                    <span>ابدأ الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </button>

                {/* Batch Mode - Direct Style */}
                <button
                  onClick={() => {
                    logger.info('Batch mode (direct style) selected');
                    setMode('batch');
                    setWritingStyle({ id: 'direct', title: 'أسلوب مباشر' });
                  }}
                  className="group p-6 border-2 border-emerald-300 rounded-2xl hover:border-emerald-500 hover:bg-emerald-50/50 transition-all text-right relative"
                >
                  <div className="absolute top-3 left-3 bg-emerald-500 text-white text-[10px] font-bold px-2 py-1 rounded-full">
                    جديد
                  </div>
                  <div className="p-4 bg-emerald-100 rounded-2xl w-fit mb-4 group-hover:bg-emerald-200 transition-colors">
                    <Target className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">معالجة جماعية - أسلوب مباشر</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    معالجة جماعية بأسلوب حازم مع مراعاة جنس كل مُقيَّم
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-emerald-600 text-sm font-medium">
                    <span>ابدأ الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </button>

                {/* Email Automation Mode */}
                <button
                  onClick={() => {
                    logger.info('Email automation mode selected');
                    setMode('email');
                  }}
                  className="group p-6 border-2 border-slate-200 rounded-2xl hover:border-emerald-500 hover:bg-emerald-50/50 transition-all text-right"
                >
                  <div className="p-4 bg-emerald-100 rounded-2xl w-fit mb-4 group-hover:bg-emerald-200 transition-colors">
                    <Mail className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">أتمتة البريد</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    إرسال رسائل بريدية جماعية مع المرفقات عبر Webhook
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-emerald-600 text-sm font-medium">
                    <span>ابدأ الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </button>

                {/* Name Matching Preview Mode */}
                <button
                  onClick={() => {
                    logger.info('Name matching preview mode selected');
                    setMode('preview');
                  }}
                  className="group p-6 border-2 border-slate-200 rounded-2xl hover:border-cyan-500 hover:bg-cyan-50/50 transition-all text-right"
                >
                  <div className="p-4 bg-cyan-100 rounded-2xl w-fit mb-4 group-hover:bg-cyan-200 transition-colors">
                    <Eye className="w-8 h-8 text-cyan-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">معاينة مطابقة الأسماء</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    تحقق من مطابقة الأسماء عبر الملفات قبل إنشاء التقارير
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-cyan-600 text-sm font-medium">
                    <span>ابدأ الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Email Automation Mode */}
        {mode === 'email' && (
          <EmailAutomation onBack={handleBackToModeSelect} />
        )}

        {/* Name Matching Preview Mode */}
        {mode === 'preview' && (
          <NameMatchingPreview onBack={handleBackToModeSelect} />
        )}

        {/* Assessment Type Selection - Shown after mode selection */}
        {mode !== 'select' && mode !== 'email' && mode !== 'preview' && step === 'assessment-type' && (
          <div className="px-4">
            <AssessmentTypeSelector
              mode={mode}
              onSelect={handleAssessmentTypeSelect}
              onBack={handleBackToModeSelect}
              selectedType={assessmentType}
              urlValidationEnabled={urlValidationEnabled}
              onUrlValidationChange={setUrlValidationEnabled}
            />
          </div>
        )}

        {/* Single Mode: Upload */}
        {mode === 'single' && step === 'upload' && !isGenerating && assessmentType && writingStyle && (
          <div className="px-4">
            <SingleCandidateUpload
              onDataParsed={handleDataParsed}
              onEmployeeInfoChange={handleEmployeeInfoChange}
              onCancel={handleBackToAssessmentType}
              assessmentType={assessmentType}
            />
          </div>
        )}

        {/* Single Mode: Generating */}
        {mode === 'single' && step === 'generating' && (
          <div className="max-w-2xl mx-auto px-4">
            <div className="bg-white rounded-3xl shadow-2xl p-12 text-center border border-slate-200">
              {/* Animated Brain Icon */}
              <div className="relative w-32 h-32 mx-auto mb-8">
                <div className="absolute inset-0 bg-indigo-100 rounded-full animate-ping opacity-20"></div>
                <div className="absolute inset-2 bg-indigo-50 rounded-full"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Brain className="w-16 h-16 text-indigo-600 animate-pulse" />
                </div>
              </div>

              <h3 className="text-2xl font-black text-slate-800 mb-3">
                جاري تحليل البيانات وإنشاء التقرير
              </h3>
              <p className="text-slate-500 text-base mb-8 max-w-md mx-auto">
                يقوم الذكاء الاصطناعي بتحليل <span className="font-bold text-indigo-600">{feedbackData?.length || 0}</span> تقييم وإنشاء تقرير قيادي شامل ومفصل
              </p>

              {/* Progress Steps */}
              <div className="bg-slate-50 rounded-2xl p-6 max-w-md mx-auto">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-right">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isValidatingUrls ? 'bg-green-100' : 'bg-green-100'
                    }`}>
                      <Sparkles className={`w-4 h-4 ${isValidatingUrls ? 'text-green-600' : 'text-green-600'}`} />
                    </div>
                    <span className="text-sm text-slate-600">تحليل بيانات التغذية الراجعة</span>
                  </div>
                  <div className="flex items-center gap-3 text-right">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isValidatingUrls ? 'bg-green-100' : 'bg-indigo-100'
                    }`}>
                      {isValidatingUrls ? (
                        <Sparkles className="w-4 h-4 text-green-600" />
                      ) : (
                        <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                      )}
                    </div>
                    <span className={`text-sm ${isValidatingUrls ? 'text-slate-600' : 'text-slate-600'}`}>
                      استخراج الرؤى والتوصيات
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-right">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isValidatingUrls ? 'bg-green-100' : 'bg-slate-100'
                    }`}>
                      {isValidatingUrls ? (
                        <Sparkles className="w-4 h-4 text-green-600" />
                      ) : (
                        <BarChart3 className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                    <span className={`text-sm ${isValidatingUrls ? 'text-slate-600' : 'text-slate-400'}`}>
                      بناء التقرير النهائي
                    </span>
                  </div>
                  {/* URL Validation Step - Only show if enabled */}
                  {urlValidationEnabled && (
                    <div className="flex items-center gap-3 text-right">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        isValidatingUrls ? 'bg-emerald-100' : 'bg-slate-100'
                      }`}>
                        {isValidatingUrls ? (
                          <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
                        ) : (
                          <Shield className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1">
                        <span className={`text-sm ${isValidatingUrls ? 'text-emerald-700 font-medium' : 'text-slate-400'}`}>
                          التحقق من روابط المصادر
                        </span>
                        {isValidatingUrls && urlValidationProgress.total > 0 && (
                          <div className="text-xs text-emerald-600 mt-1">
                            {urlValidationProgress.processed}/{urlValidationProgress.total} رابط
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Loading Animation */}
              <div className="mt-8 flex justify-center gap-2">
                {[0, 1, 2, 3, 4].map(i => (
                  <div
                    key={i}
                    className="w-3 h-3 bg-indigo-600 rounded-full animate-bounce"
                    style={{ animationDelay: `${i * 0.1}s` }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Batch Mode: Upload */}
        {mode === 'batch' && step === 'upload' && assessmentType && writingStyle && (
          <div className="px-4">
            <BatchFileUpload
              onFilesReady={handleBatchFilesReady}
              onCancel={handleBackToAssessmentType}
              assessmentType={assessmentType}
              writingStyle={writingStyle}
            />
          </div>
        )}

        {/* Batch Mode: Progress */}
        {mode === 'batch' && step === 'batch-progress' && (
          <div className="px-4">
            <BatchProgress
              totalCandidates={batchProgress.total}
              processedCount={batchProgress.processed}
              currentCandidate={batchProgress.current}
              successCount={batchProgress.success}
              failedCount={batchProgress.failed}
              status="processing"
              startTime={batchProgress.startTime}
              logs={batchProgress.logs}
            />
          </div>
        )}

        {/* Batch Mode: Results */}
        {mode === 'batch' && step === 'batch-results' && batchResults && (
          <div className="px-4">
            <BatchResults
              results={batchResults}
              onReset={handleBackToModeSelect}
              onViewReport={handleViewReport}
            />
          </div>
        )}

        {/* Report Display (both modes) */}
        {step === 'report' && report && (
          <LeadershipReport
            report={report}
            onEditSection={handleEditSection}
          />
        )}
      </div>

      {/* Section Editor Modal */}
      <SectionEditor
        isOpen={editorOpen}
        onClose={() => setEditorOpen(false)}
        sectionId={editingSectionId}
        currentContent={editingContent}
        onApplyEdit={handleApplyEdit}
        fullReport={report}
      />

      {/* Change Tracker */}
      <ChangeTracker
        changes={pendingChanges}
        onCommitChanges={handleCommitChanges}
        onRevertChange={handleRevertChange}
        onClearAll={handleClearAllChanges}
        isCommitting={isCommitting}
      />

      {/* Committed Rules Indicator */}
      {committedRules.length > 0 && (
        <div className="fixed bottom-4 right-4 z-40 bg-green-100 text-green-800 px-4 py-2 rounded-xl shadow-lg border border-green-200 text-sm font-medium">
          <span className="font-bold">{committedRules.length}</span> قاعدة محفوظة للتقارير المستقبلية
        </div>
      )}

      {/* Footer - Only on mode select page */}
      {mode === 'select' && (
        <footer className="bg-slate-900 text-slate-400 py-6 mt-12">
          <div className="max-w-6xl mx-auto px-4 text-center">
            <p className="text-xs text-slate-500">
              جميع البيانات يتم معالجتها بشكل آمن ولا يتم تخزينها
            </p>
          </div>
        </footer>
      )}
    </div>
  );
};

export default FeedbackAnalyzer;
