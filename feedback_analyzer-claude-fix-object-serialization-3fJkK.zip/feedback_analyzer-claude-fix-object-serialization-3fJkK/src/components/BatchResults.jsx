import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Download,
  FileSpreadsheet,
  FileText,
  Eye,
  ChevronDown,
  ChevronUp,
  Users,
  TrendingUp,
  AlertTriangle,
  BarChart3,
  RefreshCcw,
  Printer
} from 'lucide-react';
import {
  exportToExcel,
  exportDetailedReportsToExcel,
  exportToJSON,
  printReport
} from '../services/exportService';
import { convertToExcelFormat } from '../services/geminiService';

/**
 * BatchResults Component
 * Displays batch processing results with export options
 */
const BatchResults = ({ results, onReset, onViewReport }) => {
  const [expandedCandidate, setExpandedCandidate] = useState(null);
  const [exportError, setExportError] = useState(null);
  const [sortBy, setSortBy] = useState('name'); // 'name', 'score', 'status'
  const [filterStatus, setFilterStatus] = useState('all'); // 'all', 'success', 'failed'

  if (!results) return null;

  const { successful = [], failed = [], total, duration } = results;

  // Calculate stats
  const avgScore = successful.length > 0
    ? Math.round(successful.reduce((sum, r) => sum + (r.scoreData?.overallScore || 0), 0) / successful.length)
    : 0;

  const minScore = successful.length > 0
    ? Math.min(...successful.map(r => r.scoreData?.overallScore || 0))
    : 0;

  const maxScore = successful.length > 0
    ? Math.max(...successful.map(r => r.scoreData?.overallScore || 0))
    : 0;

  // Filter and sort candidates
  const allCandidates = [
    ...successful.map(r => ({ ...r, status: 'success' })),
    ...failed.map(r => ({ ...r, status: 'failed' }))
  ];

  const filteredCandidates = allCandidates.filter(c => {
    if (filterStatus === 'all') return true;
    return c.status === filterStatus;
  });

  const sortedCandidates = [...filteredCandidates].sort((a, b) => {
    if (sortBy === 'name') {
      return (a.candidateName || '').localeCompare(b.candidateName || '', 'ar');
    }
    if (sortBy === 'score') {
      const scoreA = a.scoreData?.overallScore || 0;
      const scoreB = b.scoreData?.overallScore || 0;
      return scoreB - scoreA;
    }
    if (sortBy === 'status') {
      return a.status === 'success' ? -1 : 1;
    }
    return 0;
  });

  // Export handlers
  const handleExportSummary = () => {
    try {
      setExportError(null);
      const data = convertToExcelFormat(results);
      exportToExcel(data, 'leadership_assessment_summary');
    } catch (err) {
      setExportError(err.message);
    }
  };

  const handleExportDetailed = () => {
    try {
      setExportError(null);
      exportDetailedReportsToExcel(results, 'leadership_detailed_reports');
    } catch (err) {
      setExportError(err.message);
    }
  };

  const handleExportJSON = () => {
    try {
      setExportError(null);
      exportToJSON(results, 'leadership_full_data');
    } catch (err) {
      setExportError(err.message);
    }
  };

  const handlePrintReport = (report) => {
    try {
      printReport(report);
    } catch (err) {
      setExportError(err.message);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 75) return 'text-green-500 bg-green-50';
    if (score >= 60) return 'text-amber-600 bg-amber-100';
    if (score >= 40) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
  };

  const getStatusBadge = (status) => {
    if (status === 'success') {
      return (
        <span className="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
          <CheckCircle2 className="w-3 h-3" />
          ناجح
        </span>
      );
    }
    return (
      <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
        <XCircle className="w-3 h-3" />
        فشل
      </span>
    );
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Summary Stats */}
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-slate-800 flex items-center gap-3">
            <BarChart3 className="w-7 h-7 text-indigo-600" />
            نتائج التحليل
          </h2>
          <button
            onClick={onReset}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-xl transition-colors text-sm font-medium text-slate-600"
          >
            <RefreshCcw className="w-4 h-4" />
            تحليل جديد
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-4 text-center border border-indigo-100">
            <Users className="w-6 h-6 text-indigo-500 mx-auto mb-2" />
            <p className="text-3xl font-black text-indigo-600">{total}</p>
            <p className="text-xs text-slate-500">إجمالي المرشحين</p>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-4 text-center border border-green-100">
            <CheckCircle2 className="w-6 h-6 text-green-500 mx-auto mb-2" />
            <p className="text-3xl font-black text-green-600">{successful.length}</p>
            <p className="text-xs text-slate-500">ناجح</p>
          </div>
          <div className="bg-gradient-to-br from-red-50 to-rose-50 rounded-2xl p-4 text-center border border-red-100">
            <XCircle className="w-6 h-6 text-red-500 mx-auto mb-2" />
            <p className="text-3xl font-black text-red-600">{failed.length}</p>
            <p className="text-xs text-slate-500">فشل</p>
          </div>
          <div className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-2xl p-4 text-center border border-amber-100">
            <TrendingUp className="w-6 h-6 text-amber-500 mx-auto mb-2" />
            <p className="text-3xl font-black text-amber-600">{avgScore}</p>
            <p className="text-xs text-slate-500">متوسط الدرجات</p>
          </div>
          <div className="bg-gradient-to-br from-slate-50 to-gray-50 rounded-2xl p-4 text-center border border-slate-200">
            <p className="text-sm text-slate-400 mb-1">النطاق</p>
            <p className="text-xl font-black text-slate-600">{minScore} - {maxScore}</p>
            <p className="text-xs text-slate-500">أدنى - أعلى</p>
          </div>
        </div>

        {duration && (
          <p className="text-center text-sm text-slate-400 mt-4">
            وقت المعالجة: {Math.round(duration / 1000)} ثانية
          </p>
        )}
      </div>

      {/* Export Options */}
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 p-6 mb-6">
        <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Download className="w-5 h-5 text-indigo-600" />
          تصدير النتائج
        </h3>

        {exportError && (
          <div className="mb-4 bg-red-50 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            {exportError}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={handleExportSummary}
            className="flex items-center justify-center gap-3 bg-green-50 hover:bg-green-100 border-2 border-green-200 text-green-700 py-4 px-6 rounded-xl transition-colors"
          >
            <FileSpreadsheet className="w-5 h-5" />
            <div className="text-right">
              <p className="font-bold">ملخص Excel</p>
              <p className="text-xs text-green-600">جدول بسيط بالنتائج</p>
            </div>
          </button>

          <button
            onClick={handleExportDetailed}
            className="flex items-center justify-center gap-3 bg-indigo-50 hover:bg-indigo-100 border-2 border-indigo-200 text-indigo-700 py-4 px-6 rounded-xl transition-colors"
          >
            <FileText className="w-5 h-5" />
            <div className="text-right">
              <p className="font-bold">تقارير مفصلة</p>
              <p className="text-xs text-indigo-600">Excel بأوراق متعددة</p>
            </div>
          </button>

          <button
            onClick={handleExportJSON}
            className="flex items-center justify-center gap-3 bg-slate-50 hover:bg-slate-100 border-2 border-slate-200 text-slate-700 py-4 px-6 rounded-xl transition-colors"
          >
            <Download className="w-5 h-5" />
            <div className="text-right">
              <p className="font-bold">JSON كامل</p>
              <p className="text-xs text-slate-500">بيانات خام للتكامل</p>
            </div>
          </button>
        </div>
      </div>

      {/* Candidates List */}
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-slate-800">
            قائمة المرشحين ({filteredCandidates.length})
          </h3>

          <div className="flex items-center gap-3">
            {/* Filter */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">الكل</option>
              <option value="success">الناجحون فقط</option>
              <option value="failed">الفاشلون فقط</option>
            </select>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
            >
              <option value="name">ترتيب بالاسم</option>
              <option value="score">ترتيب بالدرجة</option>
              <option value="status">ترتيب بالحالة</option>
            </select>
          </div>
        </div>

        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {sortedCandidates.map((candidate, idx) => (
            <div
              key={idx}
              className={`border rounded-xl overflow-hidden transition-all ${
                candidate.status === 'success'
                  ? 'border-slate-200 hover:border-indigo-300'
                  : 'border-red-200 bg-red-50/30'
              }`}
            >
              {/* Candidate Row */}
              <div
                className="p-4 flex items-center justify-between cursor-pointer"
                onClick={() => setExpandedCandidate(
                  expandedCandidate === idx ? null : idx
                )}
              >
                <div className="flex items-center gap-4">
                  {/* Score Badge */}
                  {candidate.status === 'success' ? (
                    <div className={`w-14 h-14 rounded-xl flex flex-col items-center justify-center ${getScoreColor(candidate.scoreData?.overallScore)}`}>
                      <span className="text-lg font-black">{candidate.scoreData?.overallScore}</span>
                      <span className="text-[10px]">درجة</span>
                    </div>
                  ) : (
                    <div className="w-14 h-14 rounded-xl bg-red-100 flex items-center justify-center">
                      <XCircle className="w-6 h-6 text-red-500" />
                    </div>
                  )}

                  {/* Name and Info */}
                  <div>
                    <p className="font-bold text-slate-800">{candidate.candidateName}</p>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span>{candidate.jobTitle || 'غير محدد'}</span>
                      {candidate.status === 'success' && (
                        <>
                          <span>|</span>
                          <span>{candidate.scoreData?.totalReviewerCount || 0} مقيّم</span>
                          <span>|</span>
                          <span>{candidate.report?.leadershipPath?.statusLabelAr}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {getStatusBadge(candidate.status)}
                  {candidate.status === 'success' && (
                    <>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onViewReport(candidate.report);
                        }}
                        className="p-2 hover:bg-indigo-100 rounded-lg transition-colors"
                        title="عرض التقرير"
                      >
                        <Eye className="w-4 h-4 text-indigo-600" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePrintReport(candidate.report);
                        }}
                        className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
                        title="طباعة"
                      >
                        <Printer className="w-4 h-4 text-slate-500" />
                      </button>
                    </>
                  )}
                  {expandedCandidate === idx ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Expanded Details */}
              {expandedCandidate === idx && (
                <div className="border-t border-slate-200 p-4 bg-slate-50">
                  {candidate.status === 'success' ? (
                    <div className="space-y-4">
                      {/* Core Metrics */}
                      <div>
                        <p className="text-xs font-bold text-slate-600 mb-2">المؤشرات الأساسية:</p>
                        <div className="grid grid-cols-4 gap-2">
                          {(candidate.report?.coreMetrics || []).map((metric, mIdx) => (
                            <div
                              key={mIdx}
                              className="bg-white rounded-lg p-2 text-center border"
                              style={{ borderColor: metric.color }}
                            >
                              <p className="text-xs text-slate-500 truncate">{metric.nameAr}</p>
                              <p className="text-lg font-bold" style={{ color: metric.color }}>
                                {metric.score}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Personality */}
                      {candidate.report?.personalityAnalysis && (
                        <div>
                          <p className="text-xs font-bold text-slate-600 mb-2">تحليل الشخصية:</p>
                          <div className="flex flex-wrap gap-2">
                            {candidate.report.personalityAnalysis.mbpiType && (
                              <span className="bg-white border border-slate-200 text-xs px-2 py-1 rounded-lg">
                                <span className="text-slate-400">MBTI:</span>{' '}
                                <span className="font-bold text-slate-700">{candidate.report.personalityAnalysis.mbpiType}</span>
                              </span>
                            )}
                            {candidate.report.personalityAnalysis.enneagramType && (
                              <span className="bg-white border border-slate-200 text-xs px-2 py-1 rounded-lg">
                                <span className="text-slate-400">Enneagram:</span>{' '}
                                <span className="font-bold text-slate-700">{candidate.report.personalityAnalysis.enneagramType}</span>
                              </span>
                            )}
                            {candidate.report.personalityAnalysis.discType && (
                              <span className="bg-white border border-slate-200 text-xs px-2 py-1 rounded-lg">
                                <span className="text-slate-400">DISC:</span>{' '}
                                <span className="font-bold text-slate-700">{candidate.report.personalityAnalysis.discType}</span>
                              </span>
                            )}
                            {candidate.report.personalityAnalysis.bigFiveType && (
                              <span className="bg-white border border-slate-200 text-xs px-2 py-1 rounded-lg">
                                <span className="text-slate-400">Big Five:</span>{' '}
                                <span className="font-bold text-slate-700">{candidate.report.personalityAnalysis.bigFiveType}</span>
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Executive Summary */}
                      {candidate.report?.header?.executiveSummary && (
                        <div>
                          <p className="text-xs font-bold text-slate-600 mb-2">الملخص التنفيذي:</p>
                          <p className="text-sm text-slate-600 bg-white p-3 rounded-lg border border-slate-200 leading-relaxed">
                            {candidate.report.header.executiveSummary.substring(0, 300)}
                            {candidate.report.header.executiveSummary.length > 300 && '...'}
                          </p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-red-50 p-3 rounded-lg">
                      <p className="text-sm font-bold text-red-700 mb-1">سبب الفشل:</p>
                      <p className="text-sm text-red-600">{candidate.error}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BatchResults;
