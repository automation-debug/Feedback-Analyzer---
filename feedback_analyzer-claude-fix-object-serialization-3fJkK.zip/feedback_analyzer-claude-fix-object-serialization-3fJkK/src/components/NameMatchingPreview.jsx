import React, { useState, useCallback, useEffect } from 'react';
import {
  ArrowLeft,
  Upload,
  FileSpreadsheet,
  Users,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Search,
  Eye,
  RefreshCcw,
  Info,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { FILE_SCHEMAS } from '../config/fileSchemas';

/**
 * NameMatchingPreview Component
 * Allows users to upload files and preview how names are matched across all files
 * Helps debug issues where review counts don't match expectations
 */
const NameMatchingPreview = ({ onBack }) => {
  // Define all expected file types with their info - names match BatchFileUpload.jsx exactly
  const FILE_SLOTS = [
    {
      id: 'leadership_assessment_dec_2025',
      shortName: 'ملف 1',
      name: 'تقييم القادة - Tally ديسمبر 2025',
      description: 'أحدث تقييم 360° للقادة من Tally - المصدر الرئيسي والأهم',
      identifierColumn: 'القائـد',
      color: 'indigo',
      bgColor: 'bg-indigo-50',
      borderColor: 'border-indigo-200',
      textColor: 'text-indigo-700',
      badgeColor: 'bg-indigo-100'
    },
    {
      id: '360_leadership_feedback',
      shortName: 'ملف 2',
      name: 'تقييم القادة 2024-2025',
      description: 'تقييم 360° شامل للقادة مع أوراق متعددة',
      identifierColumn: 'أود تقييم',
      color: 'blue',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      textColor: 'text-blue-700',
      badgeColor: 'bg-blue-100'
    },
    {
      id: 'station_checkin',
      shortName: 'ملف 3',
      name: 'تحليل المحطة - مايو 2025',
      description: 'اجتماعات المحطة الفردية مع المدير المباشر',
      identifierColumn: '*دخول المحطة ⛽️🔑*',
      color: 'green',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      textColor: 'text-green-700',
      badgeColor: 'bg-green-100'
    },
    {
      id: 'quarterly_review',
      shortName: 'ملف 4',
      name: 'تحليل تقييم الدوري - أبريل 2025',
      description: 'تقييم الأداء الربعي مع نظام الدروب',
      identifierColumn: 'اسم الموظف',
      color: 'amber',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200',
      textColor: 'text-amber-700',
      badgeColor: 'bg-amber-100',
      hasMultiRowHeader: true,
      headerRowIndex: 1  // 0-indexed, so row 2 in Excel
    },
    {
      id: 'leadership_analysis_2025',
      shortName: 'ملف 5',
      name: 'تحليل تقييم القيادة - أبريل 2025',
      description: 'تحليل نوعي شامل مع نقاط القوة والضعف والتوصيات',
      identifierColumn: '🔹 1. [اسم القائد]',
      color: 'purple',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
      textColor: 'text-purple-700',
      badgeColor: 'bg-purple-100',
      isTransposed: true
    },
    {
      id: 'periodic_evaluation_2024',
      shortName: 'ملف 6',
      name: 'التقييم الدوري - جميع الأقسام 2024',
      description: 'التقييم الدوري الشامل مع تقييم القيادة',
      identifierColumn: 'اسم الموظف',
      color: 'slate',
      bgColor: 'bg-slate-50',
      borderColor: 'border-slate-200',
      textColor: 'text-slate-700',
      badgeColor: 'bg-slate-100',
      hasMultiRowHeader: true,
      headerRowIndex: 1  // 0-indexed, so row 2 in Excel
    },
    {
      id: '360_new_full',
      shortName: 'ملف 7',
      name: 'تقرير 360 جديد - كامل',
      description: 'نموذج أبدأ/أستمر/أتوقف الشامل',
      identifierColumn: 'أود تقييم',
      color: 'teal',
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-200',
      textColor: 'text-teal-700',
      badgeColor: 'bg-teal-100'
    }
  ];

  // State for each file slot
  const [fileSlots, setFileSlots] = useState({});
  const [matchingResults, setMatchingResults] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingSlot, setProcessingSlot] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedNames, setExpandedNames] = useState({});
  const [showOnlyMismatches, setShowOnlyMismatches] = useState(false);

  // Parse Excel file and extract data
  const parseExcelFile = useCallback((file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const workbook = XLSX.read(e.target.result, { type: 'binary' });
          const allData = [];
          const sheetsInfo = [];

          // Read all sheets
          workbook.SheetNames.forEach(sheetName => {
            const worksheet = workbook.Sheets[sheetName];
            const sheetData = XLSX.utils.sheet_to_json(worksheet);

            if (sheetData.length > 0) {
              allData.push(...sheetData.map(row => ({
                ...row,
                _sourceSheet: sheetName
              })));
              sheetsInfo.push({ name: sheetName, rows: sheetData.length });
            }
          });

          resolve({
            fileName: file.name,
            data: allData,
            sheets: sheetsInfo,
            rawWorkbook: workbook
          });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('فشل في قراءة الملف'));
      reader.readAsBinaryString(file);
    });
  }, []);

  // Extract names from parsed file data based on slot schema
  const extractNamesFromFile = useCallback((parsedFile, slotInfo) => {
    const { data, rawWorkbook } = parsedFile;
    const names = new Map();
    const schema = FILE_SCHEMAS[slotInfo.id];

    // Handle transposed format (File 6)
    if (slotInfo.isTransposed || schema?.isTransposed) {
      const firstSheetName = rawWorkbook.SheetNames[0];
      const worksheet = rawWorkbook.Sheets[firstSheetName];
      const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      if (rawData.length > 0) {
        const headerRow = rawData[0];
        const leaderPattern = /^🔹\s*\d+\.\s*(.+)$/;

        headerRow.forEach(cell => {
          if (cell) {
            const match = String(cell).match(leaderPattern);
            if (match) {
              const name = match[1].trim();
              names.set(name, {
                count: 1,
                sheets: [firstSheetName],
                originalValues: [cell]
              });
            }
          }
        });
      }
    } else if (slotInfo.hasMultiRowHeader) {
      // Handle multi-row header format (e.g., periodic_evaluation_2024, quarterly_review)
      // Re-parse each sheet with merged headers from Row 1 and Row 2
      const identifierColumn = schema?.personIdentifierColumn || slotInfo.identifierColumn;
      const headerRowIndex = slotInfo.headerRowIndex || 1; // Default to row 2 (0-indexed: 1)

      rawWorkbook.SheetNames.forEach(sheetName => {
        const worksheet = rawWorkbook.Sheets[sheetName];
        const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (rawData.length > headerRowIndex + 1) {
          // Get both header rows - Row 1 has category headers, Row 2 has column names
          const categoryRow = rawData[0] || [];
          const headerRow = rawData[headerRowIndex] || [];

          // Merge headers: use Row 2 if available, otherwise fall back to Row 1
          const mergedHeaders = [];
          const maxCols = Math.max(categoryRow.length, headerRow.length);
          for (let i = 0; i < maxCols; i++) {
            const header2 = headerRow[i];
            const header1 = categoryRow[i];
            if (header2 && String(header2).trim()) {
              mergedHeaders[i] = String(header2).trim();
            } else if (header1 && String(header1).trim()) {
              mergedHeaders[i] = String(header1).trim();
            } else {
              mergedHeaders[i] = null;
            }
          }

          // Find the index of the identifier column in merged headers
          const identifierColIndex = mergedHeaders.findIndex(cell =>
            cell && cell === identifierColumn
          );

          if (identifierColIndex !== -1) {
            // Process data rows (after header row)
            for (let i = headerRowIndex + 1; i < rawData.length; i++) {
              const row = rawData[i];
              const nameValue = row[identifierColIndex];

              if (nameValue && String(nameValue).trim()) {
                const name = String(nameValue).trim();
                const existing = names.get(name) || { count: 0, sheets: new Set(), originalValues: [] };
                existing.count += 1;
                if (existing.sheets instanceof Set) {
                  existing.sheets.add(sheetName);
                } else {
                  existing.sheets = new Set([sheetName]);
                }
                existing.originalValues.push(nameValue);
                names.set(name, existing);
              }
            }
          }
        }
      });

      // Convert Set to Array for sheets
      names.forEach((value) => {
        if (value.sheets instanceof Set) {
          value.sheets = Array.from(value.sheets);
        }
      });
    } else {
      // Standard format - use personIdentifierColumn from slot or schema
      const identifierColumn = schema?.personIdentifierColumn || slotInfo.identifierColumn;

      data.forEach(row => {
        const nameValue = row[identifierColumn];
        if (nameValue && String(nameValue).trim()) {
          const name = String(nameValue).trim();
          const existing = names.get(name) || { count: 0, sheets: new Set(), originalValues: [] };
          existing.count += 1;
          if (existing.sheets instanceof Set) {
            existing.sheets.add(row._sourceSheet || 'default');
          } else {
            existing.sheets = new Set([row._sourceSheet || 'default']);
          }
          existing.originalValues.push(nameValue);
          names.set(name, existing);
        }
      });

      // Convert Set to Array for sheets
      names.forEach((value) => {
        if (value.sheets instanceof Set) {
          value.sheets = Array.from(value.sheets);
        }
      });
    }

    return {
      names: Array.from(names.entries()).map(([name, info]) => ({
        name,
        count: info.count,
        sheets: Array.isArray(info.sheets) ? info.sheets : [info.sheets],
        originalValues: info.originalValues
      })),
      error: null
    };
  }, []);

  // Handle file upload for a specific slot
  const handleFileUpload = async (slotId, e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const slotInfo = FILE_SLOTS.find(s => s.id === slotId);
    if (!slotInfo) return;

    setProcessingSlot(slotId);
    setIsProcessing(true);

    try {
      const parsed = await parseExcelFile(file);
      const extracted = extractNamesFromFile(parsed, slotInfo);

      setFileSlots(prev => ({
        ...prev,
        [slotId]: {
          fileName: file.name,
          fileSize: file.size,
          data: parsed.data,
          sheets: parsed.sheets,
          names: extracted.names,
          nameCount: extracted.names.length,
          error: extracted.error,
          rawWorkbook: parsed.rawWorkbook
        }
      }));
    } catch (err) {
      console.error('Error processing file:', err);
      setFileSlots(prev => ({
        ...prev,
        [slotId]: {
          fileName: file.name,
          error: 'فشل في قراءة الملف'
        }
      }));
    } finally {
      setIsProcessing(false);
      setProcessingSlot(null);
    }
  };

  // Remove file from a slot
  const handleRemoveFile = (slotId) => {
    setFileSlots(prev => {
      const newSlots = { ...prev };
      delete newSlots[slotId];
      return newSlots;
    });
  };

  // Normalize name for comparison
  const normalizeName = (name) => {
    return String(name)
      .trim()
      .replace(/\s+/g, ' ')
      .toLowerCase()
      .replace(/[\u064B-\u065F]/g, '');
  };

  // Calculate similarity between two names
  const calculateSimilarity = (name1, name2) => {
    const n1 = normalizeName(name1);
    const n2 = normalizeName(name2);

    if (n1 === n2) return 1;
    if (n1.includes(n2) || n2.includes(n1)) return 0.8;

    const words1 = n1.split(' ');
    const words2 = n2.split(' ');
    const commonWords = words1.filter(w => words2.includes(w)).length;
    const maxWords = Math.max(words1.length, words2.length);

    return commonWords / maxWords;
  };

  // Analyze name matching across files
  const analyzeMatching = useCallback(() => {
    const allNames = new Map();
    const uploadedSlotIds = Object.keys(fileSlots);

    if (uploadedSlotIds.length === 0) {
      setMatchingResults(null);
      return;
    }

    // Collect all names from all files
    uploadedSlotIds.forEach(slotId => {
      const slotData = fileSlots[slotId];
      if (!slotData?.names) return;

      slotData.names.forEach(({ name, count, sheets }) => {
        const normalized = normalizeName(name);
        const existing = allNames.get(normalized) || {
          originalNames: new Set(),
          files: new Map(),
          totalCount: 0
        };

        existing.originalNames.add(name);
        existing.files.set(slotId, { count, sheets, originalName: name });
        existing.totalCount += count;
        allNames.set(normalized, existing);
      });
    });

    // Find potential mismatches
    const potentialMismatches = [];
    const namesList = Array.from(allNames.keys());

    for (let i = 0; i < namesList.length; i++) {
      for (let j = i + 1; j < namesList.length; j++) {
        const similarity = calculateSimilarity(namesList[i], namesList[j]);
        if (similarity >= 0.5 && similarity < 1) {
          const name1Data = allNames.get(namesList[i]);
          const name2Data = allNames.get(namesList[j]);

          potentialMismatches.push({
            name1: Array.from(name1Data.originalNames)[0],
            name2: Array.from(name2Data.originalNames)[0],
            similarity,
            name1Files: Array.from(name1Data.files.keys()),
            name2Files: Array.from(name2Data.files.keys())
          });
        }
      }
    }

    const sortedNames = Array.from(allNames.entries())
      .map(([normalized, data]) => ({
        normalized,
        displayName: Array.from(data.originalNames)[0],
        variants: Array.from(data.originalNames),
        files: data.files,
        totalCount: data.totalCount,
        fileCount: data.files.size
      }))
      .sort((a, b) => b.totalCount - a.totalCount);

    setMatchingResults({
      names: sortedNames,
      potentialMismatches: potentialMismatches.sort((a, b) => b.similarity - a.similarity),
      totalUniqueNames: sortedNames.length,
      totalFiles: uploadedSlotIds.length
    });
  }, [fileSlots]);

  // Auto-analyze when files change
  useEffect(() => {
    analyzeMatching();
  }, [fileSlots, analyzeMatching]);

  // Toggle expanded state for a name
  const toggleExpanded = (name) => {
    setExpandedNames(prev => ({
      ...prev,
      [name]: !prev[name]
    }));
  };

  // Get uploaded slots for table headers
  const uploadedSlots = FILE_SLOTS.filter(slot => fileSlots[slot.id]);

  // Filter names based on search and mismatch filter
  const filteredNames = matchingResults?.names.filter(item => {
    const matchesSearch = !searchTerm ||
      item.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.variants.some(v => v.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesMismatchFilter = !showOnlyMismatches ||
      matchingResults.potentialMismatches.some(m =>
        m.name1 === item.displayName || m.name2 === item.displayName
      );

    return matchesSearch && matchesMismatchFilter;
  }) || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-slate-100" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-indigo-900 via-indigo-800 to-slate-900 text-white py-4 px-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <Eye className="w-6 h-6 text-indigo-300" />
            </div>
            <div>
              <h1 className="text-xl font-bold">معاينة مطابقة الأسماء</h1>
              <p className="text-indigo-300 text-xs">تحقق من مطابقة الأسماء عبر الملفات</p>
            </div>
          </div>
          <button
            onClick={onBack}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl transition-colors text-sm font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Upload Section - Grid of 7 file slots */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-6 mb-6">
          <h2 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
            <Upload className="w-5 h-5 text-indigo-600" />
            رفع الملفات للمعاينة
          </h2>
          <p className="text-sm text-slate-500 mb-6">جميع الملفات اختيارية - ارفع الملفات التي تريد التحقق منها</p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {FILE_SLOTS.map((slot) => {
              const slotData = fileSlots[slot.id];
              const isUploading = processingSlot === slot.id;

              return (
                <div
                  key={slot.id}
                  className={`relative rounded-xl border-2 transition-all ${
                    slotData
                      ? `${slot.bgColor} ${slot.borderColor}`
                      : 'border-dashed border-slate-300 hover:border-slate-400 bg-slate-50/50'
                  }`}
                >
                  {/* Header */}
                  <div className={`px-4 py-3 border-b ${slotData ? slot.borderColor : 'border-slate-200'}`}>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${slot.badgeColor} ${slot.textColor}`}>
                        {slot.shortName}
                      </span>
                      {slotData && (
                        <button
                          onClick={() => handleRemoveFile(slot.id)}
                          className="p-1 hover:bg-red-100 rounded transition-colors"
                          title="إزالة الملف"
                        >
                          <XCircle className="w-4 h-4 text-red-500" />
                        </button>
                      )}
                    </div>
                    <h3 className={`font-bold mt-1 ${slotData ? slot.textColor : 'text-slate-700'}`}>
                      {slot.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">{slot.description}</p>
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    {/* Identifier Column Info */}
                    <div className="mb-3 p-2 bg-white/60 rounded-lg border border-slate-200/50">
                      <p className="text-xs text-slate-500 mb-1">عمود تحديد الاسم:</p>
                      <code className="text-xs font-mono text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded break-all">
                        {slot.identifierColumn}
                      </code>
                    </div>

                    {slotData ? (
                      // File uploaded state
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <FileSpreadsheet className={`w-4 h-4 ${slot.textColor}`} />
                          <span className="text-sm font-medium text-slate-700 truncate" title={slotData.fileName}>
                            {slotData.fileName}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {slotData.nameCount} اسم
                          </span>
                          <span>
                            {slotData.sheets?.length || 0} صفحة
                          </span>
                        </div>
                        {slotData.error && (
                          <p className="text-xs text-red-600">{slotData.error}</p>
                        )}
                      </div>
                    ) : (
                      // Upload prompt
                      <label className="block cursor-pointer">
                        <input
                          type="file"
                          accept=".xlsx,.xls,.csv"
                          onChange={(e) => handleFileUpload(slot.id, e)}
                          className="hidden"
                          disabled={isProcessing}
                        />
                        <div className="flex flex-col items-center justify-center py-4 text-center">
                          {isUploading ? (
                            <div className="animate-spin w-6 h-6 border-2 border-slate-400 border-t-transparent rounded-full mb-2"></div>
                          ) : (
                            <Upload className="w-6 h-6 text-slate-400 mb-2" />
                          )}
                          <p className="text-xs text-slate-500">
                            {isUploading ? 'جاري الرفع...' : 'اضغط لرفع الملف'}
                          </p>
                        </div>
                      </label>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Results Section */}
        {matchingResults && uploadedSlots.length > 0 && (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white rounded-xl shadow border border-slate-200 p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-800">{matchingResults.totalFiles}</p>
                    <p className="text-sm text-slate-500">ملف</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow border border-slate-200 p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-100 rounded-lg">
                    <Users className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-800">{matchingResults.totalUniqueNames}</p>
                    <p className="text-sm text-slate-500">اسم فريد</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow border border-slate-200 p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-100 rounded-lg">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-800">{matchingResults.potentialMismatches.length}</p>
                    <p className="text-sm text-slate-500">تشابه محتمل</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow border border-slate-200 p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <CheckCircle className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-800">
                      {matchingResults.names.filter(n => n.fileCount === matchingResults.totalFiles).length}
                    </p>
                    <p className="text-sm text-slate-500">موجود في كل الملفات</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Potential Mismatches Warning */}
            {matchingResults.potentialMismatches.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-amber-800 mb-2">أسماء متشابهة قد تكون لنفس الشخص</h3>
                    <div className="space-y-2">
                      {matchingResults.potentialMismatches.slice(0, 5).map((mismatch, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm flex-wrap">
                          <span className="font-medium text-amber-900">{mismatch.name1}</span>
                          <span className="text-amber-600">↔</span>
                          <span className="font-medium text-amber-900">{mismatch.name2}</span>
                          <span className="text-xs text-amber-600 bg-amber-100 px-2 py-0.5 rounded">
                            {Math.round(mismatch.similarity * 100)}% تشابه
                          </span>
                        </div>
                      ))}
                      {matchingResults.potentialMismatches.length > 5 && (
                        <p className="text-xs text-amber-600">
                          و {matchingResults.potentialMismatches.length - 5} حالات أخرى...
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Search and Filters */}
            <div className="bg-white rounded-xl shadow border border-slate-200 p-4 mb-6">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex-1 min-w-[200px]">
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="ابحث عن اسم..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pr-10 pl-4 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showOnlyMismatches}
                    onChange={(e) => setShowOnlyMismatches(e.target.checked)}
                    className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm text-slate-600">إظهار المتشابهة فقط</span>
                </label>
                <button
                  onClick={analyzeMatching}
                  className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-sm text-slate-700 transition-colors"
                >
                  <RefreshCcw className="w-4 h-4" />
                  تحديث
                </button>
              </div>
            </div>

            {/* Names Table */}
            <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
              <div className="p-4 border-b border-slate-200">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  جدول مطابقة الأسماء
                  <span className="text-sm font-normal text-slate-500">
                    ({filteredNames.length} من {matchingResults.names.length})
                  </span>
                </h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-4 py-3 text-right text-sm font-medium text-slate-600 sticky right-0 bg-slate-50 z-10">
                        الاسم
                      </th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-slate-600">
                        إجمالي المراجعات
                      </th>
                      {uploadedSlots.map(slot => (
                        <th key={slot.id} className="px-4 py-3 text-center text-sm font-medium text-slate-600 min-w-[100px]">
                          <div className="flex flex-col items-center gap-1">
                            <span className={`text-xs px-2 py-0.5 rounded-full ${slot.badgeColor} ${slot.textColor}`}>
                              {slot.shortName}
                            </span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredNames.map((item) => {
                      const isExpanded = expandedNames[item.displayName];
                      const hasMismatch = matchingResults.potentialMismatches.some(
                        m => m.name1 === item.displayName || m.name2 === item.displayName
                      );
                      const inAllFiles = item.fileCount === matchingResults.totalFiles;

                      return (
                        <React.Fragment key={item.normalized}>
                          <tr className={`hover:bg-slate-50 ${hasMismatch ? 'bg-amber-50/50' : ''}`}>
                            <td className="px-4 py-3 sticky right-0 bg-white z-10">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => toggleExpanded(item.displayName)}
                                  className="p-1 hover:bg-slate-100 rounded"
                                >
                                  {isExpanded ? (
                                    <ChevronUp className="w-4 h-4 text-slate-400" />
                                  ) : (
                                    <ChevronDown className="w-4 h-4 text-slate-400" />
                                  )}
                                </button>
                                <div>
                                  <span className="font-medium text-slate-800">{item.displayName}</span>
                                  {hasMismatch && (
                                    <AlertTriangle className="w-4 h-4 text-amber-500 inline mr-2" />
                                  )}
                                  {inAllFiles && (
                                    <CheckCircle className="w-4 h-4 text-emerald-500 inline mr-2" />
                                  )}
                                </div>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-center">
                              <span className={`inline-flex items-center justify-center min-w-[32px] px-2 py-1 rounded-full text-sm font-bold ${
                                item.totalCount >= 6 ? 'bg-emerald-100 text-emerald-700' :
                                item.totalCount >= 3 ? 'bg-indigo-100 text-indigo-700' :
                                'bg-slate-100 text-slate-600'
                              }`}>
                                {item.totalCount}
                              </span>
                            </td>
                            {uploadedSlots.map(slot => {
                              const fileInfo = item.files.get(slot.id);
                              return (
                                <td key={slot.id} className="px-4 py-3 text-center">
                                  {fileInfo ? (
                                    <span className="inline-flex items-center justify-center min-w-[28px] px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">
                                      {fileInfo.count}
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center justify-center min-w-[28px] px-2 py-1 bg-red-100 text-red-600 rounded-full text-sm">
                                      ✗
                                    </span>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                          {isExpanded && (
                            <tr className="bg-slate-50">
                              <td colSpan={uploadedSlots.length + 2} className="px-4 py-3">
                                <div className="pr-8 space-y-2">
                                  {item.variants.length > 1 && (
                                    <div className="flex items-center gap-2 text-sm flex-wrap">
                                      <Info className="w-4 h-4 text-slate-400" />
                                      <span className="text-slate-600">صيغ مختلفة:</span>
                                      {item.variants.map((v, i) => (
                                        <span key={i} className="px-2 py-0.5 bg-white rounded border border-slate-200 text-slate-700">
                                          {v}
                                        </span>
                                      ))}
                                    </div>
                                  )}
                                  <div className="text-sm text-slate-600">
                                    <span className="font-medium">التفاصيل: </span>
                                    {Array.from(item.files.entries()).map(([slotId, info], i) => {
                                      const slot = FILE_SLOTS.find(s => s.id === slotId);
                                      return (
                                        <span key={slotId}>
                                          {i > 0 && ' • '}
                                          {slot?.shortName || slotId}: {info.count} مراجعة
                                          {info.sheets?.length > 1 && ` (${info.sheets.join(', ')})`}
                                        </span>
                                      );
                                    })}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {filteredNames.length === 0 && (
                <div className="p-8 text-center text-slate-500">
                  لا توجد نتائج مطابقة للبحث
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="mt-4 bg-white rounded-xl shadow border border-slate-200 p-4">
              <h4 className="text-sm font-medium text-slate-600 mb-3">دليل الرموز</h4>
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span className="text-slate-600">موجود في كل الملفات المرفوعة</span>
                </div>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <span className="text-slate-600">يوجد اسم مشابه</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">6+</span>
                  <span className="text-slate-600">6 مراجعات أو أكثر (تقرير موسع)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 text-red-600 rounded-full text-xs">✗</span>
                  <span className="text-slate-600">غير موجود في الملف</span>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Empty State */}
        {Object.keys(fileSlots).length === 0 && (
          <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-12 text-center">
            <FileSpreadsheet className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-700 mb-2">ارفع الملفات للبدء</h3>
            <p className="text-slate-500 max-w-md mx-auto">
              اختر أي من الملفات أعلاه لرفعها ومعاينة كيفية مطابقة الأسماء عبرها
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NameMatchingPreview;
