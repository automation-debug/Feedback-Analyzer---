import React, { useState } from 'react';
import {
  History,
  Check,
  X,
  ChevronDown,
  ChevronUp,
  Save,
  Trash2,
  AlertCircle,
  Clock,
  FileEdit,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { REPORT_SECTIONS } from '../types/reportSchema';

// Section names in Arabic
const SECTION_NAMES = {
  [REPORT_SECTIONS.HEADER]: 'المعلومات الأساسية',
  [REPORT_SECTIONS.LEADERSHIP_PATH]: 'درب القيادة',
  [REPORT_SECTIONS.MANAGER_MESSAGE]: 'رسالة المدير',
  [REPORT_SECTIONS.CORE_METRICS]: 'المؤشرات الأساسية',
  [REPORT_SECTIONS.PERSONALITY]: 'تحليل الشخصية',
  [REPORT_SECTIONS.STRENGTHS]: 'نقاط القوة',
  [REPORT_SECTIONS.WEAKNESSES]: 'نقاط الضعف',
  [REPORT_SECTIONS.FEEDBACK]: 'صوت الفريق',
  [REPORT_SECTIONS.ROADMAP]: 'خارطة الطريق',
  [REPORT_SECTIONS.DEVELOPMENT]: 'خطة التطوير'
};

/**
 * ChangeTracker Component
 * Tracks all changes made to the report and allows committing or reverting
 */
const ChangeTracker = ({
  changes,
  onCommitChanges,
  onRevertChange,
  onClearAll,
  isCommitting
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedChanges, setExpandedChanges] = useState({});

  const toggleChangeExpanded = (changeId) => {
    setExpandedChanges(prev => ({
      ...prev,
      [changeId]: !prev[changeId]
    }));
  };

  if (!changes || changes.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 z-40 w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden" dir="rtl">
      {/* Header */}
      <div
        className="bg-gradient-to-l from-amber-500 to-amber-600 px-4 py-3 flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-white" />
          <span className="font-bold text-white">التغييرات المعلقة</span>
          <span className="bg-white/20 text-white text-xs px-2 py-0.5 rounded-full font-bold">
            {changes.length}
          </span>
        </div>
        {isExpanded ? (
          <ChevronDown className="w-5 h-5 text-white" />
        ) : (
          <ChevronUp className="w-5 h-5 text-white" />
        )}
      </div>

      {/* Content */}
      {isExpanded && (
        <div className="max-h-96 overflow-y-auto">
          {/* Alert Banner */}
          <div className="bg-amber-50 px-4 py-3 border-b border-amber-100 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 leading-relaxed">
              لديك <strong>{changes.length}</strong> تغييرات لم يتم حفظها. قم بتأكيدها لتطبيقها على التقارير المستقبلية.
            </p>
          </div>

          {/* Changes List */}
          <div className="p-4 space-y-3">
            {changes.map((change, idx) => (
              <div
                key={change.id || idx}
                className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden"
              >
                {/* Change Header */}
                <div
                  className="px-3 py-2 flex items-center justify-between cursor-pointer hover:bg-slate-100 transition-colors"
                  onClick={() => toggleChangeExpanded(change.id || idx)}
                >
                  <div className="flex items-center gap-2">
                    <FileEdit className="w-4 h-4 text-indigo-600" />
                    <span className="text-sm font-medium text-slate-700">
                      {SECTION_NAMES[change.sectionId] || change.sectionId}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatTimestamp(change.timestamp)}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRevertChange(change.id || idx);
                      }}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1 rounded transition-colors"
                      title="التراجع عن هذا التغيير"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Change Details (Expandable) */}
                {expandedChanges[change.id || idx] && (
                  <div className="px-3 pb-3 border-t border-slate-200 pt-2">
                    <div className="text-xs text-slate-600 mb-2">
                      <span className="font-bold">التعديل المطلوب:</span>
                      <p className="mt-1 bg-white p-2 rounded border border-slate-200 text-slate-700">
                        "{change.instruction}"
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-2">
            <button
              onClick={onCommitChanges}
              disabled={isCommitting}
              className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-bold transition-colors ${isCommitting
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-green-600 hover:bg-green-700 text-white'
                }`}
            >
              {isCommitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  تأكيد جميع التغييرات ({changes.length})
                </>
              )}
            </button>

            <button
              onClick={onClearAll}
              disabled={isCommitting}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium text-red-600 hover:bg-red-50 transition-colors border border-red-200"
            >
              <Trash2 className="w-4 h-4" />
              تجاهل جميع التغييرات
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Format timestamp to readable format
 */
function formatTimestamp(timestamp) {
  if (!timestamp) return '';

  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);

  if (diffMins < 1) return 'الآن';
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;

  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `منذ ${diffHours} ساعة`;

  return date.toLocaleDateString('ar-EG', {
    day: 'numeric',
    month: 'short'
  });
}

export default ChangeTracker;
