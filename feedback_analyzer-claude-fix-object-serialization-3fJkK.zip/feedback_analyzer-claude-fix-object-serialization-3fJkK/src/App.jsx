import React from 'react';
import FeedbackAnalyzer from './components/FeedbackAnalyzer';
import ErrorBoundary from './components/ErrorBoundary';

function App() {
  return (
    <ErrorBoundary>
      <FeedbackAnalyzer />
    </ErrorBoundary>
  );
}

export default App;
