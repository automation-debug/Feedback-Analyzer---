/**
 * ===================================================================
 * CENTRALIZED CONFIGURATION CONSTANTS
 * ===================================================================
 *
 * This module contains ALL configurable values used throughout the
 * feedback analyzer application. Edit values here to change behavior
 * across the entire application.
 *
 * @module config/constants
 * @author Feedback Analyzer Team
 *
 * SECTIONS:
 * 1. Report Type Thresholds
 * 2. File Weights (Assessment Sources)
 * 3. Score Thresholds (5-tier color system)
 * 4. API Configuration
 * 5. Batch Processing Settings
 * 6. Character Limits (Report Fields)
 * 7. Arabic Text Configuration
 * 8. Color System (Status Colors)
 * 9. Personality Frameworks
 */

// ===================================================================
// 1. REPORT TYPE THRESHOLDS
// ===================================================================
/**
 * Thresholds that determine which report format to generate
 * based on the number of reviewers/feedback entries
 */
export const REPORT_THRESHOLDS = {
  /**
   * Minimum reviewers for Extended report (7-20 reviewers)
   * Extended reports have more detailed content: 6 strengths, 6 weaknesses, etc.
   */
  EXTENDED: 7,

  /**
   * Minimum reviewers for Gigantic report (21+ reviewers)
   * Gigantic reports have maximum content: 9 strengths, 9 weaknesses, 12 teamVoice, etc.
   */
  GIGANTIC: 21
};

/**
 * Helper function to determine report type based on reviewer count
 * @param {number} reviewerCount - Number of reviewers/feedback entries
 * @returns {'STANDARD' | 'EXTENDED' | 'GIGANTIC'} Report type
 */
export function getReportType(reviewerCount) {
  if (reviewerCount >= REPORT_THRESHOLDS.GIGANTIC) return 'GIGANTIC';
  if (reviewerCount >= REPORT_THRESHOLDS.EXTENDED) return 'EXTENDED';
  return 'STANDARD';
}

// ===================================================================
// 2. FILE WEIGHTS (Assessment Sources)
// ===================================================================
/**
 * Weight distribution for different assessment file sources
 * These weights determine how much each file contributes to the final score
 *
 * IMPORTANT: Weights should sum to 100%
 */
export const FILE_WEIGHTS = {
  /** File 1: 360° Leadership Feedback */
  '360_leadership_feedback': 10,

  /** File 2: Station Check-in (qualitative only, no numeric score) */
  'station_checkin': 8,

  /** File 3: Quarterly Review */
  'quarterly_review': 7,

  /** File 4: 360 New Full */
  '360_new_full': 4,

  /** File 5: Periodic Evaluation 2024 */
  'periodic_evaluation_2024': 5,

  /** File 6: Leadership Analysis 2025 (qualitative only) */
  'leadership_analysis_2025': 6,

  /** File 7: December 2025 Assessment - PRIMARY SOURCE (60% weight) */
  'leadership_assessment_dec_2025': 60
};

/**
 * Schemas that contain only qualitative data (no numeric scores)
 * These are excluded from weighted score calculations
 */
export const QUALITATIVE_SCHEMAS = ['station_checkin', 'leadership_analysis_2025'];

// ===================================================================
// 3. SCORE THRESHOLDS (5-tier color system)
// ===================================================================
/**
 * Score thresholds for the 5-tier leadership status system
 * Used to determine status labels and colors based on overall score
 */
export const SCORE_THRESHOLDS = {
  /** 92-100: فخر (Pride/Excellent) - Dark Green */
  PRIDE: { min: 92, max: 100, labelEn: 'Pride', labelAr: 'فخر', color: '#53815F' },

  /** 83-91: خضر (Green/Very Good) - Light Green */
  GREEN: { min: 83, max: 91, labelEn: 'Green', labelAr: 'خضر', color: '#AECF76' },

  /** 74-82: صفر (Yellow/Average) - Yellow */
  YELLOW: { min: 74, max: 82, labelEn: 'Yellow', labelAr: 'صفر', color: '#EBCB6B' },

  /** 64-73: حمر (Red/Below Average) - Orange */
  RED: { min: 64, max: 73, labelEn: 'Red', labelAr: 'حمر', color: '#D68A77' },

  /** 0-63: خطر (Danger/Critical) - Dark Red */
  DANGER: { min: 0, max: 63, labelEn: 'Danger', labelAr: 'خطر', color: '#AA392D' }
};

/**
 * Get status info based on score
 * @param {number} score - Score from 0 to 100
 * @returns {Object} Status info with labels and color
 */
export function getScoreStatus(score) {
  if (score >= SCORE_THRESHOLDS.PRIDE.min) return SCORE_THRESHOLDS.PRIDE;
  if (score >= SCORE_THRESHOLDS.GREEN.min) return SCORE_THRESHOLDS.GREEN;
  if (score >= SCORE_THRESHOLDS.YELLOW.min) return SCORE_THRESHOLDS.YELLOW;
  if (score >= SCORE_THRESHOLDS.RED.min) return SCORE_THRESHOLDS.RED;
  return SCORE_THRESHOLDS.DANGER;
}

// ===================================================================
// 4. API CONFIGURATION
// ===================================================================
/**
 * OpenRouter API configuration
 */
export const API_CONFIG = {
  /** OpenRouter API endpoint */
  URL: 'https://openrouter.ai/api/v1/chat/completions',

  /** AI model to use for report generation */
  MODEL: 'openai/gpt-4o-mini',

  /** Request timeout in milliseconds (2 minutes) */
  TIMEOUT: 120000,

  /** Max tokens by report type */
  MAX_TOKENS: {
    STANDARD: 8192,
    EXTENDED: 16000,
    GIGANTIC: 24000
  },

  /** Temperature for AI responses (0 = deterministic, 1 = creative) */
  TEMPERATURE: 0.5
};

// ===================================================================
// 5. BATCH PROCESSING SETTINGS
// ===================================================================
/**
 * Configuration for batch processing multiple candidates
 */
export const BATCH_CONFIG = {
  /** Maximum parallel API calls */
  maxConcurrent: 3,

  /** Maximum retry attempts per candidate */
  maxRetries: 4,

  /** Exponential backoff delays in milliseconds */
  retryDelays: [1000, 2000, 3000, 4000],

  /** Delay between starting new candidates (rate limiting) */
  rateLimitDelayMs: 500
};

// ===================================================================
// 6. CHARACTER LIMITS (Report Fields)
// ===================================================================
/**
 * Character/word limits for different report fields
 * These ensure content fits properly in the Figma template
 */
export const FIELD_LIMITS = {
  header: {
    employeeName: { max: 30 },
    executiveSummary: { max: 445 },
    executiveSummary2Title: { min: 20, max: 25 },
    executiveSummary2Bullet: { min: 60, max: 63 }
  },

  coreMetrics: {
    bulletPoint: { min: 80, max: 83 }
  },

  strengths: {
    title: { min: 37, max: 39 },
    description: { min: 120, max: 175 }
  },

  weaknesses: {
    title: { min: 37, max: 39 },
    description: { min: 120, max: 175 }
  },

  personalityAnalysis: {
    overview: { max: 350 },
    overview2Title: { min: 20, max: 25 },
    overview2Bullet: { min: 60, max: 63 },
    strengthWeakness: { words: { min: 8, max: 12 } }
  },

  teamVoice: {
    title: { words: { min: 1, max: 2 } },
    content: { words: { min: 25, max: 27 } }
  },

  developmentCompass: {
    item: { min: 45, max: 55 }
  },

  roadmap: {
    title: { max: 50 },
    step: {
      STANDARD: { min: 121, max: 127 },
      EXTENDED: { min: 121, max: 127 },
      GIGANTIC: { min: 165, max: 190 }
    }
  },

  developmentPlan: {
    categoryTitle: { max: 30 },
    resourceTitle: { max: 24 }
  }
};

// ===================================================================
// 7. ITEM COUNTS BY REPORT TYPE
// ===================================================================
/**
 * Number of items for each section based on report type
 */
export const ITEM_COUNTS = {
  STANDARD: {
    strengths: 3,
    weaknesses: 3,
    teamVoice: 4,
    coreMetricBullets: 3,
    developmentCompass: 5,
    roadmapSteps: 4
  },
  EXTENDED: {
    strengths: 6,
    weaknesses: 6,
    teamVoice: 5,
    coreMetricBullets: 5,
    developmentCompass: 5,
    roadmapSteps: 5
  },
  GIGANTIC: {
    strengths: 9,
    weaknesses: 9,
    teamVoice: 12,
    coreMetricBullets: 7,
    developmentCompass: 9,
    roadmapSteps: 10
  }
};

// ===================================================================
// 8. ARABIC TEXT CONFIGURATION
// ===================================================================
/**
 * Arabic hedging words to avoid in direct writing style
 */
export const HEDGING_WORDS = [
  'يلاحظ', 'يُلاحَظ', 'لوحظ', 'يبدو', 'يبدو أن', 'ربما', 'قد', 'من الممكن',
  'يُحتمل', 'على ما يبدو', 'من المحتمل', 'يُعتقد', 'يُظن', 'في الغالب',
  'على الأرجح', 'من المرجح', 'قد يكون', 'ممكن أن', 'يمكن أن يكون',
  'نوعاً ما', 'إلى حد ما', 'بشكل عام', 'في معظم الأحيان',
  'يشير', 'يشير إلى', 'يشير الى', 'تشير', 'تشير إلى', 'أشار', 'أشارت'
];

/**
 * Gender conjugations in Arabic
 */
export const ARABIC_GENDER = {
  MASCULINE: {
    examples: ['تتمتع', 'لديك', 'تمتلك', 'تميل', 'تجد', 'تواجه'],
    default: true
  },
  FEMININE: {
    examples: ['تتمتعين', 'لديكِ', 'تمتلكين', 'تميلين', 'تجدين', 'تواجهين'],
    default: false
  }
};

/**
 * Rating labels in English and Arabic
 */
export const RATING_LABELS = {
  excellent: { en: 'Excellent', ar: 'ممتاز' },
  veryGood: { en: 'Very Good', ar: 'جيد جداً' },
  average: { en: 'Average', ar: 'متوسط' },
  belowAverage: { en: 'Below Average', ar: 'ضعيف' },
  critical: { en: 'Critical', ar: 'منخفض جداً' }
};

// ===================================================================
// 9. PERSONALITY FRAMEWORKS
// ===================================================================
/**
 * Valid personality type values for validation
 */
export const PERSONALITY_TYPES = {
  MBTI: [
    'INTJ', 'INTP', 'ENTJ', 'ENTP',
    'INFJ', 'INFP', 'ENFJ', 'ENFP',
    'ISTJ', 'ISFJ', 'ESTJ', 'ESFJ',
    'ISTP', 'ISFP', 'ESTP', 'ESFP'
  ],
  ENNEAGRAM: ['Type 1', 'Type 2', 'Type 3', 'Type 4', 'Type 5', 'Type 6', 'Type 7', 'Type 8', 'Type 9'],
  DISC: ['High D', 'High I', 'High S', 'High C', 'D/I', 'I/S', 'S/C', 'C/D'],
  BIG_FIVE: [
    'High Openness',
    'High Conscientiousness',
    'High Extraversion',
    'High Agreeableness',
    'High Neuroticism'
  ]
};

// ===================================================================
// 10. LOGGING CONFIGURATION
// ===================================================================
/**
 * Logging configuration
 */
export const LOG_CONFIG = {
  /** Maximum log history entries */
  MAX_HISTORY: 500,

  /** Log levels */
  LEVELS: {
    DEBUG: 0,
    INFO: 1,
    WARN: 2,
    ERROR: 3
  },

  /** Default log level */
  DEFAULT_LEVEL: 'DEBUG'
};

// ===================================================================
// EXPORT ALL
// ===================================================================
export default {
  REPORT_THRESHOLDS,
  getReportType,
  FILE_WEIGHTS,
  QUALITATIVE_SCHEMAS,
  SCORE_THRESHOLDS,
  getScoreStatus,
  API_CONFIG,
  BATCH_CONFIG,
  FIELD_LIMITS,
  ITEM_COUNTS,
  HEDGING_WORDS,
  ARABIC_GENDER,
  RATING_LABELS,
  PERSONALITY_TYPES,
  LOG_CONFIG
};
