/**
 * File Schemas Configuration
 * Defines the structure and mapping for different assessment file types
 */

// File 1: 360° Leadership Feedback (تقييم القادة 2024 - 2025)
export const FILE_SCHEMAS = {
  '360_leadership_feedback': {
    id: '360_leadership_feedback',
    name: 'تقييم القادة 360°',
    description: 'تقييم القيادة الشامل من 360 درجة',

    // Column that identifies the person being evaluated
    personIdentifierColumn: 'أود تقييم',

    // Column that identifies the evaluator
    evaluatorColumn: 'أنا',

    // Sheet configurations with default weights
    sheets: {
      'بعد تعديل المجاملين - أغسطس 2024': {
        defaultWeight: 3,
        period: 'أغسطس 2024'
      },
      'تقييم القادة 2025 - معتمد': {
        defaultWeight: 7,
        period: '2025'
      }
    },

    // Categories with their numeric columns
    categories: {
      'الوضوح والأولويات': {
        numericColumns: [
          'يوضح لفريقه الهدف والمطلوب تحقيقه بوضوح',
          'يعطي أولوية واضحة للأعمال يسهل اتباعها',
          'يوضح لفريقه العمل ماهو متوقع منهم وكيف سيتم تقييمهم',
          'يراجع تقدم العمل بشكل مستمر ويصحح المسار عند الحاجة'
        ],
        textColumn: 'الوضوح والأولويات (لا تتردد في توضيح رأيك وسبب اختيارك)'
      },
      'طريقة العمل': {
        numericColumns: [
          'يتفق مع فريقه على طريقة العمل والقواعد والإجراءات',
          'يتخذ القرارات ويشرك فريقه في اتخاذها حسب الحاجة',
          'يكون قدوة لفريقه في سلوكه وانضباطه والتزامه',
          'يعالج المشاكل والصراعات بشكل ايجابي وفعال'
        ],
        textColumn: 'طريقة العمل (لا تتردد في توضيح رأيك وسبب اختيارك)'
      },
      'قيادة الفريق': {
        numericColumns: [
          'يعطي فريقه الثقة ويُفوّض لهم صلاحيات تتناسب مع قدراتهم',
          'يوفر بيئة آمنة نفسياً تشجع على النقاش والاختلاف والابتكار',
          'يعزز التعاون بين أعضاء فريقه ومع الفرق الأخرى',
          'يقود فريقه للنجاح من خلال التركيز على النتائج'
        ],
        textColumn: 'قيادة الفريق (لا تتردد في توضيح رأيك وسبب اختيارك)'
      },
      'الدعم والتطوير': {
        numericColumns: [
          'يقدم الدعم والمساندة لفريقه عند الحاجة',
          'يتعامل مع أعضاء فريقه باحترام ويقدر إسهاماتهم',
          'يُقدّم ملاحظات بناءة للتطوير والتحسين بشكل مستمر',
          'يهتم بتطوير فريقه مهنياً ويُمَكّنهم من القيام بذلك'
        ],
        textColumn: 'الدعم والتطوير (لا تتردد في توضيح رأيك وسبب اختيارك)'
      }
    },

    // Open-ended text fields
    openTextFields: [
      'ما هي نقاط القوة التي تراها في هذا القائد',
      'ما هي المجالات التي يمكن لهذا القائد التحسين فيها'
    ],

    // Pre-calculated average column
    averageColumn: 'متوسط التقييم',

    // Score range
    scoreRange: { min: 1, max: 10 }
  },

  // File 2: Station Check-in (تحليل المحطة - مايو 2025)
  'station_checkin': {
    id: 'station_checkin',
    name: 'تحليل المحطة',
    description: 'اجتماعات المحطة الفردية مع المدير',

    // Column that identifies the person being evaluated
    personIdentifierColumn: '*دخول المحطة ⛽️🔑*',

    // Column that identifies the manager/evaluator
    evaluatorColumn: '*مديرك المباشر 🪖*',

    // Sheet configurations with default weights
    sheets: {
      'default': {
        defaultWeight: 8,
        period: 'مايو 2025'
      }
    },

    // This format has no numeric scores - all text-based reflection
    categories: {},

    // Text-based reflection fields
    textFields: {
      'wellbeing': {
        column: '*❶ كيف الحال؟ 🤝*',
        label: 'الحالة العامة',
        type: 'self_assessment'
      },
      'past_evaluation': {
        column: '*❷ كيف التقييم الماضي؟ 🚦*',
        label: 'التقييم السابق',
        type: 'feedback'
      },
      'challenges': {
        column: '*❸ هل تواجه تحديات؟ 😣*',
        label: 'التحديات',
        type: 'challenges'
      },
      'observations': {
        column: '*❹ هل لديك مرئيات؟ 🪞*',
        label: 'المرئيات والاقتراحات',
        type: 'feedback'
      },
      'achievements': {
        column: '*❺ نحتفي بالإنجازات 🎉*',
        label: 'الإنجازات',
        type: 'achievements'
      },
      'targets': {
        column: '*❻ نحدد المستهدفات 🎯*',
        label: 'المستهدفات',
        type: 'goals'
      },
      'lessons_learned': {
        column: '*❼ نراجع ما تعلمناه 🩹 ✍*',
        label: 'الدروس المستفادة',
        type: 'learning'
      },
      'learning_plans': {
        column: '*❽ نخطط لما سنتعلم 🌱*',
        label: 'خطط التعلم',
        type: 'development'
      }
    },

    // Timestamp column
    timestampColumn: 'Submitted At',

    // No numeric scores in this format
    scoreRange: null
  },

  // File 3: Quarterly Performance Review (تحليل تقييم الدوري - أبريل 2025)
  'quarterly_review': {
    id: 'quarterly_review',
    name: 'تقييم الدوري',
    description: 'تقييم الأداء الدوري الربعي',

    // Multi-row header configuration
    // Row 1 contains category headers (المعلومات الأساسية, الدرب, تقييم القيادة, etc.)
    // Row 2 contains actual column names (اسم الموظف, القسم, الفريق, etc.)
    hasMultiRowHeader: true,
    headerRowIndex: 1, // 0-indexed, so row 2 in Excel

    // Column that identifies the person being evaluated
    personIdentifierColumn: 'اسم الموظف',

    // Column that identifies the manager/evaluator
    evaluatorColumn: 'المدير',

    // Sheet configurations with default weights
    sheets: {
      'default': {
        defaultWeight: 7,
        period: 'أبريل 2025'
      }
    },

    // No numeric categories - uses track-based assessment
    categories: {},

    // Basic employee information fields
    basicInfoFields: {
      'department': { column: 'القسم', label: 'القسم' },
      'team': { column: 'الفريق', label: 'الفريق' },
      'level': { column: 'المستوى', label: 'المستوى' },
      'title': { column: 'المسمى', label: 'المسمى الوظيفي' },
      'salary': { column: 'الراتب', label: 'الراتب' },
      'contract_end': { column: 'تاريخ انتهاء العقد', label: 'تاريخ انتهاء العقد' }
    },

    // Performance track fields
    trackFields: {
      'performance_track': {
        column: 'الدرب',
        label: 'درب الأداء',
        type: 'track',
        options: ['فخر 🎖️', 'خضر 🎉', 'أصفر ⚠️', 'أحمر 🔴']
      },
      'track_reasoning': {
        column: 'لماذا اخترت هذا الدرب؟',
        label: 'سبب اختيار الدرب',
        type: 'evaluation_text'
      },
      'leadership_evaluation': {
        column: 'تقييم القيادة',
        label: 'تقييم القيادة',
        type: 'text'
      },
      'leadership_track': {
        column: 'درب القيادة',
        label: 'درب القيادة',
        type: 'track'
      }
    },

    // Goals and targets
    goalsFields: {
      'previous_targets': {
        column: 'المستهدفات السابقة',
        label: 'المستهدفات السابقة',
        type: 'achievements'
      },
      'upcoming_targets': {
        column: 'المستهدفات القادمة',
        label: 'المستهدفات القادمة',
        type: 'goals'
      }
    },

    // Internal assessment fields (Yes/No)
    internalAssessment: {
      'future_leader': {
        column: 'هل تراه قائد المستقبل؟',
        label: 'قائد المستقبل',
        type: 'boolean'
      },
      'retention': {
        column: 'هل تتمسك به؟',
        label: 'التمسك بالموظف',
        type: 'boolean'
      },
      'loyalty': {
        column: 'ولاء الموظف',
        label: 'ولاء الموظف',
        type: 'boolean'
      },
      'special_notes': {
        column: 'ملاحظات خاصة لعلم الموارد البشرية وتنفيذي القسم',
        label: 'ملاحظات خاصة',
        type: 'internal_notes'
      }
    },

    // Additional text fields
    textFields: {
      'additional_evaluations': {
        column: 'تقييمات إضافية',
        label: 'تقييمات إضافية',
        type: 'feedback'
      }
    },

    // Track scoring interpretation
    trackScoring: {
      'فخر 🎖️': { score: 100, label: 'فخر', description: 'أداء استثنائي' },
      'خضر 🎉': { score: 80, label: 'خضر', description: 'أداء جيد' },
      'أصفر ⚠️': { score: 60, label: 'أصفر', description: 'يحتاج تحسين' },
      'أحمر 🔴': { score: 40, label: 'أحمر', description: 'أداء ضعيف' }
    },

    // No numeric scores - uses track-based scoring
    scoreRange: null
  },

  // File 4: New 360 Report (تقرير 360 جديد - كامل)
  '360_new_full': {
    id: '360_new_full',
    name: 'تقرير 360 جديد',
    description: 'تقييم 360 درجة شامل مع نموذج أبدأ/أستمر/أتوقف',

    // Column that identifies the person being evaluated
    personIdentifierColumn: 'أود تقييم',

    // Column that identifies the evaluator
    evaluatorColumn: 'أنا',

    // Sheet configurations with default weights
    sheets: {
      'default': {
        defaultWeight: 4,
        period: 'كامل'
      }
    },

    // Categories with numeric columns (1-5 scale)
    categories: {
      'التواصل': {
        numericColumns: [
          'الشفافية في التواصل بين أعضاء الفريق وفي المهام',
          'القدرة على إيضاح التوقعات ومشاركة تفاصيل المهام بوضوح',
          'إتقان العمل على تطبيق بيسكامب وإدارة المهام ومتابعتها',
          'التعامل مع النقد البنّاء والأفكار المختلفة، وإتاحة الفرصة للآخرين في إبداء رأيهم',
          'تحقيق مبدأ «قلها في وجهي»؛ والشفافية والوضوح  في إبداء الرأي ومشاركة المرئيات والنقد'
        ],
        textColumns: {
          start: '(أبدأ) العمل والمبادرة فيه (1)',
          continue: '(أستمر) عليه (1)',
          stop: '(أتوقف) عنه (1)'
        }
      },
      'الإحسان': {
        numericColumns: [
          'جودة المهام المنجزة',
          'وجود نظرة بعيدة المدى حول المهام المنجزة للفرد والفريق',
          'توليد الأفكار والحلول الإبداعية والجديدة لتحقيق غاية العمل',
          'الحرص على التعلم والالتزام بالتطوير المستمر في ما يخص العمل',
          'صنع واتخاذ القرارات لمصلحة العمل'
        ],
        textColumns: {
          start: '(أبدأ) العمل والمبادرة فيه (2)',
          continue: '(أستمر) عليه (2)',
          stop: '(أتوقف) عنه (2)'
        }
      },
      'المسؤولية': {
        numericColumns: [
          'تحديد الأولويات وتنظيم الوقت أثناء العمل، وانعكاس ذلك على سرعة الإنجاز',
          'تحقيق جملة «لا شيء هنا ليس من شأنك»؛ والمبادرة في حل ومواجهة المشاكل، والانتباه للتفاصيل حتى إن لم تكن ضمن مهام الموظف',
          'تقديم حلول عملية ومنطقية لحل ومعالجة المشكلات التي تواجهنا أثناء العمل',
          'المرونة في التعامل مع متغيرات العمل والتحدّيات الجديدة',
          'متابعة وتحديث المهام ذاتيًّا دون متابعة من أحد'
        ],
        textColumns: {
          start: '(أبدأ) العمل والمبادرة فيه (3)',
          continue: '(أستمر) عليه (3)',
          stop: '(أتوقف) عنه (3)'
        }
      },
      'التعاون': {
        numericColumns: [
          'ثقة الموظفين برأيه ومشورته',
          'تقديم يد العون وتسهيل طلب المساعدة من الآخرين بدون تردد',
          'مشاركة الأفكار والآراء لتطوير العمل حتى لو لم تكن ضمن المهام أو الأعمال الشخصية',
          'استثمار جزء من الوقت الشخصي والمجهود لمساعدة أعضاء الفريق أو تطوير قدرات',
          'التعاطف مع الآخرين وتفهّم مشاعرهم ووجهات نظرهم'
        ],
        textColumns: {
          start: '(أبدأ) العمل والمبادرة فيه (4)',
          continue: '(أستمر) عليه (4)',
          stop: '(أتوقف) عنه (4)'
        }
      },
      'القيادة': {
        numericColumns: [
          'تحديد أهداف طموحة، متوائمة مع مهارات الفرد وأهداف الفريق ومشاركتها بوضوح',
          'تأثير وتحفيز الفريق للعمل بإحسان',
          'ثقة الموظفين بقيادته للفريق والقسم، وتوجّهه',
          'قوة العلاقة مع أعضاء الفريق والتعرف على الموظف شخصيًّا',
          'المساعدة على تطوير الموظف مهنيًّا وشخصيًّا، ليكون كل فرد في فريقه أفضل ما يمكن',
          'تمكين وتحفيز استقلالية الفرد في الفريق، مما يرفع حس المسؤولية لديهم'
        ],
        textColumns: {
          start: '(أبدأ) العمل والمبادرة فيه (5)',
          continue: '(أستمر) عليه (5)',
          stop: '(أتوقف) عنه (5)'
        }
      }
    },

    // Open-ended text fields
    openTextFields: [
      'أي شيء آخر تودّ إضافته؟ (1)',
      'أي شيء آخر تودّ إضافته؟ (2)'
    ],

    // Score range (1-5 scale)
    scoreRange: { min: 1, max: 5 }
  },

  // File 5: Comprehensive Periodic Evaluation (التقييم الدوري - جميع الأقسام - 2024)
  'periodic_evaluation_2024': {
    id: 'periodic_evaluation_2024',
    name: 'التقييم الدوري 2024',
    description: 'التقييم الدوري الشامل لجميع الأقسام مع تقييم القيادة',

    // Multi-row header configuration
    // Row 1 contains category headers (المعلومات الأساسية, التقييم العام, etc.)
    // Row 2 contains actual column names (اسم الموظف, القسم, etc.)
    hasMultiRowHeader: true,
    headerRowIndex: 1, // 0-indexed, so row 2 in Excel

    // Column that identifies the person being evaluated
    personIdentifierColumn: 'اسم الموظف',

    // Column that identifies the manager/evaluator
    evaluatorColumn: 'المدير المباشر',

    // Sheet configurations with default weights
    sheets: {
      'Sheet1': {
        defaultWeight: 2,
        period: 'الربع الثالث 2024'
      },
      'Sheet2': {
        defaultWeight: 3,
        period: 'الربع الرابع 2024'
      }
    },

    // Basic employee information fields (combined from both sheets)
    basicInfoFields: {
      'department': { column: 'القسم', label: 'القسم' },
      'team': { column: 'الفريق', label: 'الفريق' },  // Sheet 2
      'level': { column: 'المستوى', label: 'المستوى' },  // Sheet 2
      'title': { column: 'المسمى الوظيفي', altColumn: 'المسمى', label: 'المسمى الوظيفي' },
      'salary': { column: 'الراتب', label: 'الراتب' },
      'contract_end': { column: 'تاريخ انتهاء العقد', label: 'تاريخ انتهاء العقد' }  // Sheet 2
    },

    // General Assessment Categories (from 80) - Text-based ratings
    generalAssessment: {
      'expectations': {
        column: 'كيف حقق التوقعات؟',
        notesColumn: 'اذكر التوقعات أو ملاحظات حولها',
        label: 'تحقيق التوقعات',
        ratings: {
          'لم ينجز أي شيء مما اتفقنا عليه': { score: 2, level: 'critical' },
          'لم يحقق كل المستهدفات كما اتفقنا': { score: 5, level: 'needs_improvement' },
          'حقق التوقعات بشكل مقبول': { score: 8, level: 'meets' },
          'حقق المستهدفات وفاق التوقعات': { score: 10, level: 'exceeds' }
        }
      },
      'quality': {
        column: 'كيف جودة المخرجات؟',
        notesColumn: 'ملاحظات',
        label: 'جودة المخرجات',
        ratings: {
          'سيئة ومرفوضة في أغلب الأحيان': { score: 2, level: 'critical' },
          'دون المأمول وفي الغالب تحتاج مراجعة وإعادة': { score: 5, level: 'needs_improvement' },
          'جيدة بما يكفي': { score: 8, level: 'meets' },
          'يغلب عليها الإحسان': { score: 10, level: 'exceeds' }
        }
      },
      'punctuality': {
        column: 'كيف الإنضباط مع الوقت؟',
        notesColumn: 'ملاحظات',
        label: 'الانضباط بالوقت',
        ratings: {
          'يتأخر عادة ولا يلتزم في أغلب المواعيد': { score: 3, level: 'needs_improvement' },
          'متساهل في المواعيد': { score: 6, level: 'developing' },
          'منضبط عادة': { score: 8, level: 'meets' },  // Sheet 2 option
          'منضبط دائمًا': { score: 10, level: 'exceeds' }
        }
      },
      'basecamp': {
        column: 'كيفه مع بيسكامب؟',
        notesColumn: 'ملاحظات',
        label: 'استخدام بيسكامب',
        ratings: {
          'لديه أميّة تقنية في استخدام المنصة': { score: 2, level: 'critical' },
          'مقبول إلى حدٍ ما لكنه يحتاج إلى ورشة تطوير': { score: 5, level: 'needs_improvement' },
          'فعّال في تواصله ويجيد استخدام المنصة': { score: 8, level: 'meets' },
          'محترف تواصل ومن أفضل من يستخدم المنصة': { score: 10, level: 'exceeds' }
        }
      },
      'initiative': {
        column: 'كيف حس المبادرة؟',
        notesColumn: 'ملاحظات',
        label: 'المبادرة',
        ratings: {
          'لا يبادر إطلاقًا ولا يهمه أي شيء خارج نطاق عمله': { score: 2, level: 'critical' },
          'يكاد لا يبادر أو يتفاعل مع طلبات الآخرين': { score: 4, level: 'needs_improvement' },
          'يبادر أحيانًا ونادرًا ما يخرج عن دائرة فريقه': { score: 7, level: 'meets' },
          'مخترع المبادرة! خدوم دائمًا وتجده في كل أرجاء ثمانية': { score: 10, level: 'exceeds' },
          'مبادر وخدوم سواء في نطاق عمله وفريقه أو خارجه': { score: 9, level: 'exceeds' }
        }
      },
      'efficiency': {
        column: 'كيف كفاءة الموظف؟',
        notesColumn: 'ملاحظات',
        label: 'كفاءة الموظف',
        ratings: {
          'أنت معنا في الشركة؟': { score: 2, level: 'critical' },
          'لا بأس، لكن لا بد من مراجعة إسناد المهام له': { score: 5, level: 'needs_improvement' },
          'جيد، يوظف وقته وطاقته على المهام الصح': { score: 8, level: 'meets' },
          'الواحد عن ثمانية موظفين': { score: 10, level: 'exceeds' }
        }
      },
      'reliability': {
        column: 'كيف تعتمد عليه؟',
        notesColumn: 'ملاحظات',
        label: 'الاعتمادية',
        ratings: {
          'يخيب ظنك في أغلب الأحيان': { score: 2, level: 'critical' },
          'دبره أحيانًا لكنه يخيب ظنك في أخرى': { score: 5, level: 'needs_improvement' },
          'كفو واعتمد عليه في أغلب الأحيان': { score: 8, level: 'meets' },
          'ساعدي الأيمن — أتكل عليه دائمًا': { score: 10, level: 'exceeds' }
        }
      },
      'development': {
        column: 'كيف تطوره المهني؟',
        notesColumn: 'ملاحظات',
        label: 'التطور المهني',
        ratings: {
          'لا يبدي أي رغبة في التطور': { score: 2, level: 'critical' },
          'بطيء التطور ويكاد لا يحرز أي تقدم يذكر': { score: 4, level: 'needs_improvement' },
          'جيد وتلمس فيه التطور المستمر': { score: 8, level: 'meets' },
          'مبهر في مدى التزامه وتطوره المستمر': { score: 10, level: 'exceeds' }
        }
      }
    },

    // Final notes for employee
    employeeNotes: 'ملاحظات آخيرة للموظف',

    // Internal assessment fields (combined from both sheets)
    internalAssessment: {
      'future_leader': {
        // Sheet 1 format
        column: 'تراه قائدًا في المستقبل:\n1. يثق الموظفين برأيه ومشورته\n2. يقدم يد العون لزملائه بدون تردد\n3. يستثمر جزء من وقته لمساعدة الفريق أو تطوير قدراتهم',
        // Sheet 2 format
        altColumn: 'هل تراه قائد المستقبل؟',
        label: 'قائد المستقبل',
        type: 'agreement_scale',
        ratings: {
          'لا': { score: 0 },
          'نعم': { score: 100 },  // Sheet 2 boolean style
          'أتفق إلى حدّ ما': { score: 50 },
          'أتفق': { score: 75 },
          'أتفق بشدة': { score: 100 }
        }
      },
      'retention': {
        column: 'هل تتمسك فيه؟',
        altColumn: 'هل تتمسك به؟',  // Sheet 2 format
        label: 'التمسك بالموظف',
        type: 'boolean'
      },
      'retention_notes': {
        column: 'ملاحظات',
        label: 'ملاحظات التمسك',
        type: 'text'
      },
      'loyalty': {
        column: 'ولاء الموظف',
        label: 'ولاء الموظف',
        type: 'text'
      }
    },

    // Goals fields (Sheet 2)
    goalsFields: {
      'previous_targets': {
        column: 'المستهدفات السابقة',
        label: 'المستهدفات السابقة',
        type: 'achievements'
      },
      'upcoming_targets': {
        column: 'مستهدفات القادمة',
        label: 'المستهدفات القادمة',
        type: 'goals'
      }
    },

    // Additional internal assessments (Sheet 2)
    additionalAssessment: {
      'additional_evaluations': {
        column: 'تقييمات إضافية للاستخدام الداخلي',
        label: 'تقييمات إضافية',
        type: 'internal'
      },
      'dept_approval': {
        column: 'اعتماد تنفيذي القسم',
        label: 'اعتماد تنفيذي القسم',
        type: 'boolean'
      },
      'hr_approval': {
        column: 'اعتماد الموارد البشرية',
        label: 'اعتماد الموارد البشرية',
        type: 'boolean'
      }
    },

    // General result columns (combined from both sheets)
    generalResult: {
      'total_score': {
        column: 'التقييم العام \nمن 80',
        altColumn: 'النتيجة الآلية \nللدرب العام',  // Sheet 2 auto-calculated
        label: 'التقييم العام',
        maxScore: 80
      },
      'manager_decision': {
        column: 'القرار العام (من المدير)',
        label: 'قرار المدير'
      },
      'result_decision': {
        column: 'القرار العام  (حسب النتيجة)',
        altColumn: 'الدرب العام وفقًا للنتيجة الآلية',  // Sheet 2
        label: 'القرار حسب النتيجة'
      },
      'track_adjustment': {
        column: 'جبر الدرب',
        label: 'جبر الدرب'
      },
      'track': {
        column: 'دربك',
        altColumn: 'الدرب',  // Sheet 2 format
        label: 'الدرب'
      },
      'track_comment': {
        column: 'اكتب تعليقك للموظف وسبب اختيارك لهذا الدرب',  // Sheet 2
        label: 'تعليق الدرب'
      }
    },

    // Leadership Assessment Categories (from 40)
    leadershipAssessment: {
      'decisions': {
        column: 'كيف يتخذ القرارات؟',
        notesColumn: 'ملاحظات',
        label: 'اتخاذ القرارات',
        ratings: {
          'قراراته مره تصيب ومره تخيب': { score: 5, level: 'needs_improvement' },
          'قراراته في الغالب صائبة': { score: 10, level: 'meets' }
        }
      },
      'team_building': {
        column: 'كيف يبني الفريق؟',
        notesColumn: 'ملاحظات',
        label: 'بناء الفريق',
        ratings: {
          'لا أجد لديه القدرة الكافية لبناء وتطوير الفريق': { score: 3, level: 'needs_improvement' },
          'لا بأس لكنه أكيد يحتاج تطوير': { score: 6, level: 'developing' },
          'جيد بما يكفي لبناء وتطوير فريقه': { score: 10, level: 'meets' }
        }
      },
      'goals': {
        column: 'كيف يبني الأهداف؟',
        notesColumn: 'ملاحظات',
        label: 'بناء الأهداف',
        ratings: {
          'يحتاج تطوير في بناء أهداف فريقه ومتابعتها': { score: 5, level: 'needs_improvement' },
          'لديه قدرة لا بأس بها في ضبط مستهدفات فريقه': { score: 8, level: 'meets' },
          'التفكير الاستراتيجي  وضبط الأهداف لعبته': { score: 10, level: 'exceeds' }
        }
      },
      'leadership': {
        column: 'كيف يقود الفريق؟',
        notesColumn: 'ملاحظات',
        label: 'قيادة الفريق',
        ratings: {
          'محبط لمعنويات الفريق ولا يصلح إطلاقًا كقائد': { score: 2, level: 'critical' },
          'يحتاج إلى تطوير في مهارات القيادة': { score: 5, level: 'needs_improvement' },
          'قائد جيد ومؤثر بما يكفي لنجاح الفريق': { score: 8, level: 'meets' },
          'قائد بالفطرة ومصدر إلهام للفريق': { score: 10, level: 'exceeds' }
        }
      }
    },

    // Manager notes
    managerNotes: 'ملاحظات آخيرة للمدير',

    // Leadership result columns (combined from both sheets)
    leadershipResult: {
      'total_score': {
        column: 'تقرير القيادة\nمن 40',
        altColumn: 'النتيجة الآلية\nلدرب القيادة',  // Sheet 2 auto-calculated
        label: 'تقييم القيادة',
        maxScore: 40
      },
      'manager_decision': {
        column: 'قرار القيادة (من المدير)',
        label: 'قرار المدير للقيادة'
      },
      'result_decision': {
        column: 'قرار القيادة (حسب النتيجة)',
        altColumn: 'درب القيادة وفقًا للنتيجة الآلية',  // Sheet 2
        label: 'قرار القيادة حسب النتيجة'
      },
      'track': {
        column: 'دربك',
        altColumn: 'درب القيادة',  // Sheet 2 format
        label: 'درب القيادة'
      },
      'track_comment': {
        column: 'اكتب تعليقك للموظف وسبب اختيارك لهذا الدرب',  // Sheet 2 (shared column name)
        label: 'تعليق درب القيادة'
      }
    },

    // HR special notes
    hrNotes: 'ملاحظات خاصة للموارد البشرية',

    // Automation/calculated columns
    calculatedColumns: {
      'email': 'عنوان البريد الإلكتروني',
      'report_link': 'رابط التقرير',
      'send_approval': 'اعتماد إرسال التقرير',
      'general_average': 'متوسط العام',
      'leadership_average': 'متوسط القيادة'
    },

    // Track definitions
    trackDefinitions: {
      'فخر 🎖️': { score: 100, label: 'فخر', color: 'gold' },
      'خضر 🎉': { score: 80, label: 'خضر', color: 'green' },
      'صفر ❶  📣': { score: 60, label: 'إشعار', color: 'yellow' },
      'حمر  ❶ 🚨': { score: 40, label: 'إنذار', color: 'red' },
      'خطر 📁': { score: 20, label: 'خطر', color: 'darkred' }
    },

    // Decision definitions
    decisionDefinitions: {
      'وسام ثمانية 🎖️': { level: 'exceptional', action: 'recognition' },
      'كفو استمر 🎉': { level: 'good', action: 'continue' },
      'خطاب إشعار ❶  📣': { level: 'warning', action: 'notice' },
      'خطاب إنذار ❶  🚨': { level: 'alert', action: 'warning' },
      'خطة تطوير اعتيادية 🔰': { level: 'development', action: 'development_plan' },
      'خطة تطوير طارئة ⛑️': { level: 'urgent', action: 'urgent_development' },
      'تغيير العقد والمستوى ✍️': { level: 'contract', action: 'contract_change' },
      'إنهاء التعاقد 📁': { level: 'termination', action: 'terminate' }
    },

    // Score ranges
    scoreRange: {
      general: { min: 0, max: 80 },
      leadership: { min: 0, max: 40 }
    }
  },

  // File 6: Leadership Analysis (تحليل تقييم القيادة - أبريل 2025)
  'leadership_analysis_2025': {
    id: 'leadership_analysis_2025',
    name: 'تحليل تقييم القيادة 2025',
    description: 'تحليل نوعي شامل للقيادات مع نقاط القوة والضعف والتوصيات',

    // TRANSPOSED FORMAT: Leaders are columns, categories are rows
    isTransposed: true,

    // Pattern to identify leader columns (e.g., "🔹 1. أسيل باعبدالله")
    leaderColumnPattern: /^🔹\s*\d+\.\s*(.+)$/,

    // Column that contains category labels (first column)
    categoryColumn: null, // First column in transposed format

    // Sheet configurations with default weights
    sheets: {
      'default': {
        defaultWeight: 6,
        period: 'أبريل 2025'
      }
    },

    // Row categories (assessment dimensions)
    rowCategories: {
      'strengths': {
        identifier: '📈 نقاط القوة',
        label: 'نقاط القوة',
        type: 'qualitative_text',
        importance: 'high'
      },
      'weaknesses': {
        identifier: '📉 نقاط الضعف',
        label: 'نقاط الضعف',
        type: 'qualitative_text',
        importance: 'high'
      },
      'recommendations': {
        identifier: '✅ التوصيات',
        label: 'التوصيات',
        type: 'qualitative_text',
        importance: 'high'
      },
      'ideal_team': {
        identifier: '👥 الفريق المثالي',
        label: 'الفريق المثالي',
        type: 'qualitative_text',
        importance: 'medium'
      },
      'action_steps': {
        identifier: '🛠️ خطوات عملية',
        label: 'خطوات عملية',
        type: 'qualitative_text',
        importance: 'high'
      },
      'comparison': {
        identifier: '📊 مقارنة',
        label: 'مقارنة',
        type: 'qualitative_text',
        importance: 'medium'
      }
    },

    // Known leaders (for reference/matching)
    knownLeaders: [
      'أسيل باعبدالله',
      'أنس الأهدل',
      'عبدالرحمن أبومالح',
      'عبدالرحمن السبيعي',
      'عبدالله الغامدي',
      'علي بوصالح',
      'فهد سندي',
      'ماجد العوفي',
      'محمد السمان',
      'محمد الصباغ',
      'محمد القحطاني',
      'ناصر الراجحي',
      'هتان خياط',
      'هشام سندي',
      'وائل الحارثي',
      'ياسين كنانة',
      'يزيد الزهراني'
    ],

    // No numeric scores - all qualitative analysis
    scoreRange: null,

    // Extraction helpers
    extractLeaderName: (columnHeader) => {
      const match = columnHeader.match(/^🔹\s*\d+\.\s*(.+)$/);
      return match ? match[1].trim() : null;
    }
  },

  // File 7: December 2025 Leadership Assessment (تقييم 2025 ديسمبر)
  'leadership_assessment_dec_2025': {
    id: 'leadership_assessment_dec_2025',
    name: 'تقييم القادة ديسمبر 2025',
    description: 'تقييم شامل للقادة من 360 درجة - ديسمبر 2025',

    // Column that identifies the person being evaluated
    personIdentifierColumn: 'القائـد',

    // Column that identifies the evaluator
    evaluatorColumn: 'أنا',

    // Sheet configurations with default weights
    sheets: {
      'default': {
        defaultWeight: 60,
        period: 'ديسمبر 2025'
      }
    },

    // Survey metadata columns
    metadataColumns: {
      'submission_id': 'Submission ID',
      'respondent_id': 'Respondent ID',
      'submitted_at': 'Submitted at'
    },

    // Consent/acknowledgment columns (for filtering valid responses)
    consentColumns: [
      'Untitled checkboxes field',
      'Untitled checkboxes field (اسمك لن يُشارك مع القائد 🔒.)',
      'Untitled checkboxes field (بمجرد الإرسال، سيتم اعتماد مرئياتك. هل أنت متأكد؟)',
      'Untitled checkboxes field (2)',
      'Untitled checkboxes field (بعض المرئيات المكتوبة ستُراجَع وتُعاد صياغتها للحفاظ على هويتك بالكامل ♻️.)',
      'Untitled checkboxes field (3)',
      'Untitled checkboxes field (تقييمك الرقمي لن يُعرض على القائد، بل سيُستخدم لتحليل الأداء؛ سنُشارك القائد المرئيات المكتوبة فقط.)'
    ],

    // Categories with their numeric columns (1-10 scale)
    categories: {
      'الوضوح والأولويات': {
        numericColumns: [
          'فعّال في توصيل المعلومة والأفكار وإيضاح المهام.',
          'يحدد الأولويات، ويعيد ترتيب المهام بوضوح عند تغيّر التوجّه.',
          'قادر على اتخاذ قرارات سريعة وواضحة تصب في مصلحة العمل والفريق.'
        ],
        textColumn: 'ما أبرز مرئياتك حول «وضوح القائد في التواصل وضبط الأولويات»؟',
        label: 'وضوح القائد في التواصل وضبط الأولويات'
      },
      'طريقة العمل': {
        numericColumns: [
          'يُمكّن ويحفّز الاستقلالية، وأشعر بثقته العالية بالفريق.',
          'متاح عند الحاجة ومتجاوب لأسئلتي أو طلبات المشورة.',
          'يظهر وعيًا وتفهّمًا لتحديات ومشاعر الفريق أثناء فترات الضغط.'
        ],
        textColumn: 'ما أبرز مرئياتك حول «طريقة عمل القائد»؟',
        label: 'طريقة عمل القائد'
      },
      'قيادة الفريق': {
        numericColumns: [
          'يخلق بيئة تشجّع على التعاون وتبادل المعرفة داخل الفريق.',
          'يبني ثقافة أداء عالية قائمة على الوضوح والمحاسبة العادلة.',
          'يُشرك الفريق ويشاورهم عند اتخاذ القرارات.'
        ],
        textColumn: 'ما أبرز مرئياتك حول «قيادة القائد للفريق»؟',
        label: 'قيادة القائد للفريق'
      },
      'التطوير والدعم': {
        numericColumns: [
          'يُقدّر  جهد الفريق ويهتم بتطور العلاقات داخل الفريق.',
          'يشاركني مرئيات بناءة تساعدني على التطور.',
          'يشجعني على المبادرة ويدعم الإبداع والأفكار المختلفة.'
        ],
        textColumn: 'ما أبرز مرئياتك حول «التطوير والدعم من القائد»؟',
        label: 'التطوير والدعم من القائد'
      }
    },

    // Open-ended text fields
    openTextFields: [
      'ما تقدّره في أسلوب قيادته للفريق؟',
      'ما الجوانب التي تتمنى أن يطوّرها في المرحلة القادمة؟',
      'هل هناك أي مرئيات إضافية ترى أنها مهمة لمشاركتها مع الموارد البشرية بخصوص أداء الفريق أو أسلوب القيادة؟'
    ],

    // Open text field labels for display
    openTextFieldLabels: {
      'ما تقدّره في أسلوب قيادته للفريق؟': 'نقاط القوة',
      'ما الجوانب التي تتمنى أن يطوّرها في المرحلة القادمة؟': 'مجالات التطوير',
      'هل هناك أي مرئيات إضافية ترى أنها مهمة لمشاركتها مع الموارد البشرية بخصوص أداء الفريق أو أسلوب القيادة؟': 'ملاحظات للموارد البشرية'
    },

    // Score range (1-10 scale)
    scoreRange: { min: 1, max: 10 }
  }
};

// Get all numeric columns for a schema
export const getNumericColumns = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema || !schema.categories) return [];

  const columns = [];
  Object.values(schema.categories).forEach(cat => {
    if (cat && Array.isArray(cat.numericColumns)) {
      columns.push(...cat.numericColumns);
    }
  });
  return columns;
};

// Get all text columns for a schema
export const getTextColumns = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema) return [];

  const columns = [];
  if (schema.categories) {
    Object.values(schema.categories).forEach(cat => {
      if (cat && cat.textColumn) columns.push(cat.textColumn);
    });
  }
  columns.push(...(schema.openTextFields || []));
  return columns;
};

// Get general assessment columns for periodic evaluation schemas
export const getGeneralAssessmentColumns = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema || !schema.generalAssessment) return [];

  return Object.values(schema.generalAssessment).map(field => field.column);
};

// Get leadership assessment columns for periodic evaluation schemas
export const getLeadershipAssessmentColumns = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema || !schema.leadershipAssessment) return [];

  return Object.values(schema.leadershipAssessment).map(field => field.column);
};

// Detect which schema matches the uploaded file based on columns
export const detectFileSchema = (columns) => {
  // First, check for transposed schemas (like leadership_analysis_2025)
  if (detectTransposedLeaderSchema(columns)) {
    return 'leadership_analysis_2025';
  }

  // Then, check for schemas with unique person identifier columns
  for (const [schemaId, schema] of Object.entries(FILE_SCHEMAS)) {
    // Skip schemas that share person identifier with others (handle them separately)
    if (schema.personIdentifierColumn === 'اسم الموظف') continue;
    // Skip transposed schemas (already checked above)
    if (schema.isTransposed) continue;

    if (columns.includes(schema.personIdentifierColumn)) {
      // For schemas with numeric categories, check for category columns
      const numericCols = getNumericColumns(schemaId);
      if (numericCols.length > 0) {
        const matchCount = numericCols.filter(col => columns.includes(col)).length;
        if (matchCount >= 4) {
          return schemaId;
        }
      } else {
        // For text-only schemas (like station_checkin), check for text field columns
        const textCols = getTextFieldColumns(schemaId);
        if (textCols.length > 0) {
          const matchCount = textCols.filter(col => columns.includes(col)).length;
          if (matchCount >= 3) {
            return schemaId;
          }
        }

        // For track-based schemas (like quarterly_review), check for track fields
        const trackCols = getTrackFieldColumns(schemaId);
        if (trackCols.length > 0) {
          const matchCount = trackCols.filter(col => columns.includes(col)).length;
          if (matchCount >= 1) {
            return schemaId;
          }
        }
      }
    }
  }

  // Handle schemas that share 'اسم الموظف' as person identifier
  if (columns.includes('اسم الموظف')) {
    // Check for periodic_evaluation_2024 first (more specific)
    const periodicAssessmentCols = getGeneralAssessmentColumns('periodic_evaluation_2024');
    if (periodicAssessmentCols.length > 0) {
      const matchCount = periodicAssessmentCols.filter(col => columns.includes(col)).length;
      if (matchCount >= 3) {
        return 'periodic_evaluation_2024';
      }
    }

    // Fall back to quarterly_review
    const trackCols = getTrackFieldColumns('quarterly_review');
    if (trackCols.length > 0) {
      const matchCount = trackCols.filter(col => columns.includes(col)).length;
      if (matchCount >= 1) {
        return 'quarterly_review';
      }
    }
  }

  return null;
};

// Get track field columns for track-based schemas
export const getTrackFieldColumns = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema || !schema.trackFields) return [];

  return Object.values(schema.trackFields).map(field => field.column);
};

// Get text field columns for text-based schemas
export const getTextFieldColumns = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema || !schema.textFields) return [];

  return Object.values(schema.textFields).map(field => field.column);
};

// Check if columns match a transposed leader format (for leadership_analysis_2025)
export const detectTransposedLeaderSchema = (columns) => {
  const schema = FILE_SCHEMAS['leadership_analysis_2025'];
  if (!schema || !schema.leaderColumnPattern) return false;

  // Count columns that match the leader pattern (🔹 followed by number and name)
  const leaderPattern = /^🔹\s*\d+\.\s*.+$/;
  const leaderColumnsCount = columns.filter(col => leaderPattern.test(col)).length;

  // If we have at least 3 leader columns, it's likely this schema
  return leaderColumnsCount >= 3;
};

// Extract leader names from transposed columns
export const extractLeadersFromColumns = (columns) => {
  const leaderPattern = /^🔹\s*\d+\.\s*(.+)$/;
  const leaders = [];

  columns.forEach(col => {
    const match = col.match(leaderPattern);
    if (match) {
      leaders.push({
        columnHeader: col,
        name: match[1].trim()
      });
    }
  });

  return leaders;
};

// Get row category identifiers for transposed schemas
export const getRowCategoryIdentifiers = (schemaId) => {
  const schema = FILE_SCHEMAS[schemaId];
  if (!schema || !schema.rowCategories) return [];

  return Object.values(schema.rowCategories).map(cat => cat.identifier);
};

// Get detected schema details
export const getSchemaDetails = (schemaId) => {
  return FILE_SCHEMAS[schemaId] || null;
};

export default FILE_SCHEMAS;
