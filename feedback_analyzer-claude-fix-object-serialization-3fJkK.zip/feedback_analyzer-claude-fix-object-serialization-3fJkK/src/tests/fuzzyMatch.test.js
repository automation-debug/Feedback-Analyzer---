/**
 * ===================================================================
 * FUZZY MATCH UTILITY TESTS
 * ===================================================================
 *
 * Tests for Arabic name matching and fuzzy search functionality
 *
 * @module tests/fuzzyMatch.test
 */

import { describe, it, expect } from 'vitest';
import {
  calculateSimilarity,
  normalizeArabicName,
  namesMatch,
  extractUniquePersons,
  findFeedbackForPerson,
  groupFeedbackBySource,
  calculateWeightedScores
} from '../utils/fuzzyMatch.js';

// ===================================================================
// CALCULATE SIMILARITY TESTS
// ===================================================================

describe('calculateSimilarity', () => {
  it('should return 100 for identical strings', () => {
    expect(calculateSimilarity('hello', 'hello')).toBe(100);
    expect(calculateSimilarity('محمد', 'محمد')).toBe(100);
  });

  it('should return 0 for null/undefined inputs', () => {
    expect(calculateSimilarity(null, 'hello')).toBe(0);
    expect(calculateSimilarity('hello', null)).toBe(0);
    expect(calculateSimilarity(null, null)).toBe(0);
  });

  it('should be case-insensitive', () => {
    expect(calculateSimilarity('Hello', 'hello')).toBe(100);
    expect(calculateSimilarity('HELLO', 'hello')).toBe(100);
  });

  it('should handle whitespace correctly', () => {
    expect(calculateSimilarity(' hello ', 'hello')).toBe(100);
  });

  it('should return lower score for different strings', () => {
    const score = calculateSimilarity('hello', 'hallo');
    expect(score).toBeLessThan(100);
    expect(score).toBeGreaterThan(50);
  });

  it('should return 0 for completely different strings', () => {
    const score = calculateSimilarity('abc', 'xyz');
    expect(score).toBeLessThan(50);
  });
});

// ===================================================================
// NORMALIZE ARABIC NAME TESTS
// ===================================================================

describe('normalizeArabicName', () => {
  it('should handle null/undefined inputs', () => {
    expect(normalizeArabicName(null)).toBe('');
    expect(normalizeArabicName(undefined)).toBe('');
    expect(normalizeArabicName('')).toBe('');
  });

  it('should normalize أ، إ، آ to ا', () => {
    expect(normalizeArabicName('أحمد')).toBe('احمد');
    expect(normalizeArabicName('إبراهيم')).toBe('ابراهيم');
    expect(normalizeArabicName('آدم')).toBe('ادم');
  });

  it('should normalize ة to ه', () => {
    expect(normalizeArabicName('فاطمة')).toBe('فاطمه');
    expect(normalizeArabicName('سارة')).toBe('ساره');
  });

  it('should normalize ى to ي', () => {
    expect(normalizeArabicName('مصطفى')).toBe('مصطفي');
    expect(normalizeArabicName('عيسى')).toBe('عيسي');
  });

  it('should remove diacritics (tashkeel)', () => {
    expect(normalizeArabicName('مُحَمَّد')).toBe('محمد');
  });

  it('should remove extra spaces', () => {
    expect(normalizeArabicName('محمد    أحمد')).toBe('محمد احمد');
  });

  it('should convert to lowercase', () => {
    expect(normalizeArabicName('Mohammed')).toBe('mohammed');
  });
});

// ===================================================================
// NAMES MATCH TESTS
// ===================================================================

describe('namesMatch', () => {
  it('should match identical names', () => {
    expect(namesMatch('محمد أحمد', 'محمد أحمد')).toBe(true);
  });

  it('should match names with different Arabic character variations', () => {
    expect(namesMatch('أحمد', 'احمد')).toBe(true);
    expect(namesMatch('فاطمة', 'فاطمه')).toBe(true);
    expect(namesMatch('مصطفى', 'مصطفي')).toBe(true);
  });

  it('should match when one name contains the other', () => {
    expect(namesMatch('محمد', 'محمد أحمد علي')).toBe(true);
    expect(namesMatch('محمد أحمد علي', 'محمد')).toBe(true);
  });

  it('should not match completely different names', () => {
    expect(namesMatch('محمد', 'علي')).toBe(false);
  });

  it('should respect custom threshold', () => {
    // Very strict threshold
    expect(namesMatch('محمد', 'محمود', 95)).toBe(false);
    // Lenient threshold
    expect(namesMatch('محمد', 'محمود', 50)).toBe(true);
  });

  it('should handle special case: البراء (male name)', () => {
    expect(namesMatch('البراء', 'البراء')).toBe(true);
    expect(namesMatch('البراء', 'البرا')).toBe(true); // With normalization
  });
});

// ===================================================================
// EXTRACT UNIQUE PERSONS TESTS
// ===================================================================

describe('extractUniquePersons', () => {
  const testData = [
    { name: 'محمد أحمد', score: 80 },
    { name: 'محمد احمد', score: 85 },  // Same person, different spelling
    { name: 'علي محمود', score: 90 },
    { name: 'فاطمة أحمد', score: 75 },
    { name: 'فاطمه احمد', score: 78 },  // Same person, different spelling
  ];

  it('should return empty array for invalid inputs', () => {
    expect(extractUniquePersons(null, 'name')).toEqual([]);
    expect(extractUniquePersons([], 'name')).toEqual([]);
    expect(extractUniquePersons(testData, null)).toEqual([]);
  });

  it('should extract unique persons consolidating name variations', () => {
    const result = extractUniquePersons(testData, 'name');

    // Should have 3 unique persons (محمد أحمد, علي محمود, فاطمة أحمد)
    expect(result.length).toBe(3);
  });

  it('should track name variations', () => {
    const result = extractUniquePersons(testData, 'name');

    // Find محمد أحمد
    const mohamed = result.find(p => p.normalizedName.includes('محمد احمد'));
    expect(mohamed.variations.length).toBeGreaterThanOrEqual(1);
  });

  it('should count occurrences correctly', () => {
    const result = extractUniquePersons(testData, 'name');

    // محمد أحمد appears twice
    const mohamed = result.find(p => p.normalizedName.includes('محمد احمد'));
    expect(mohamed.count).toBe(2);
  });

  it('should sort by count (most frequent first)', () => {
    const result = extractUniquePersons(testData, 'name');
    expect(result[0].count).toBeGreaterThanOrEqual(result[1].count);
  });
});

// ===================================================================
// FIND FEEDBACK FOR PERSON TESTS
// ===================================================================

describe('findFeedbackForPerson', () => {
  const testData = [
    { employee: 'محمد أحمد', score: 80, comment: 'جيد' },
    { employee: 'محمد احمد', score: 85, comment: 'ممتاز' },
    { employee: 'علي محمود', score: 90, comment: 'رائع' },
    { employee: 'فاطمة أحمد', score: 75, comment: 'حسن' },
  ];

  it('should return empty array for invalid inputs', () => {
    expect(findFeedbackForPerson(null, 'employee', 'محمد')).toEqual([]);
    expect(findFeedbackForPerson(testData, null, 'محمد')).toEqual([]);
    expect(findFeedbackForPerson(testData, 'employee', null)).toEqual([]);
  });

  it('should find all feedback for a person including variations', () => {
    const result = findFeedbackForPerson(testData, 'employee', 'محمد أحمد');

    // Should find both محمد أحمد and محمد احمد
    expect(result.length).toBe(2);
    expect(result.every(r => r.employee.includes('محمد'))).toBe(true);
  });

  it('should not include feedback for other people', () => {
    const result = findFeedbackForPerson(testData, 'employee', 'محمد أحمد');

    // Should not include علي or فاطمة
    expect(result.every(r => !r.employee.includes('علي'))).toBe(true);
    expect(result.every(r => !r.employee.includes('فاطمة'))).toBe(true);
  });

  it('should respect custom threshold', () => {
    // Very strict threshold - only exact matches
    const strictResult = findFeedbackForPerson(testData, 'employee', 'محمد أحمد', 100);
    expect(strictResult.length).toBeLessThanOrEqual(2);
  });
});

// ===================================================================
// GROUP FEEDBACK BY SOURCE TESTS
// ===================================================================

describe('groupFeedbackBySource', () => {
  const testData = [
    { name: 'محمد', score: 80, _sourceFile: 'file1.xlsx', _sourceSheet: 'Sheet1' },
    { name: 'علي', score: 85, _sourceFile: 'file1.xlsx', _sourceSheet: 'Sheet1' },
    { name: 'محمد', score: 90, _sourceFile: 'file2.xlsx', _sourceSheet: 'Sheet1' },
    { name: 'أحمد', score: 75, _sourceFile: 'file1.xlsx', _sourceSheet: 'Sheet2' },
  ];

  it('should group rows by source file and sheet', () => {
    const result = groupFeedbackBySource(testData);

    expect(Object.keys(result).length).toBe(3);
    expect(result['file1.xlsx::Sheet1'].rows.length).toBe(2);
    expect(result['file2.xlsx::Sheet1'].rows.length).toBe(1);
    expect(result['file1.xlsx::Sheet2'].rows.length).toBe(1);
  });

  it('should preserve file and sheet names', () => {
    const result = groupFeedbackBySource(testData);

    expect(result['file1.xlsx::Sheet1'].fileName).toBe('file1.xlsx');
    expect(result['file1.xlsx::Sheet1'].sheetName).toBe('Sheet1');
  });

  it('should handle missing source info', () => {
    const dataWithoutSource = [
      { name: 'محمد', score: 80 },
      { name: 'علي', score: 85 },
    ];

    const result = groupFeedbackBySource(dataWithoutSource);
    expect(Object.keys(result).length).toBe(1);
    expect(result['unknown::default'].rows.length).toBe(2);
  });
});

// ===================================================================
// CALCULATE WEIGHTED SCORES TESTS
// ===================================================================

describe('calculateWeightedScores', () => {
  const testData = [
    { name: 'محمد', score1: 80, score2: 70, _sourceFile: 'file1', _sourceSheet: 'Sheet1' },
    { name: 'محمد', score1: 90, score2: 85, _sourceFile: 'file1', _sourceSheet: 'Sheet1' },
    { name: 'محمد', score1: 75, score2: 65, _sourceFile: 'file2', _sourceSheet: 'Sheet1' },
  ];

  const weights = {
    'file1::Sheet1': 60,
    'file2::Sheet1': 40,
  };

  it('should calculate weighted scores across sources', () => {
    const result = calculateWeightedScores(testData, weights, ['score1', 'score2']);

    expect(result.scores.score1).toBeDefined();
    expect(result.scores.score2).toBeDefined();
    expect(result.totalWeight).toBe(100);
    expect(result.sourceCount).toBe(2);
  });

  it('should weight scores according to config', () => {
    const result = calculateWeightedScores(testData, weights, ['score1']);

    // file1 average: (80+90)/2 = 85 with weight 60
    // file2 average: 75 with weight 40
    // weighted: (85*60 + 75*40) / 100 = 81
    expect(result.scores.score1).toBeCloseTo(81, 0);
  });

  it('should ignore sources with zero weight', () => {
    const weightsWithZero = {
      'file1::Sheet1': 100,
      'file2::Sheet1': 0,
    };

    const result = calculateWeightedScores(testData, weightsWithZero, ['score1']);

    // Only file1 should be counted
    expect(result.totalWeight).toBe(100);
    expect(result.scores.score1).toBeCloseTo(85, 0); // Average of file1 only
  });

  it('should handle missing numeric values', () => {
    const dataWithMissing = [
      { name: 'محمد', score1: 80, _sourceFile: 'file1', _sourceSheet: 'Sheet1' },
      { name: 'محمد', score1: 'N/A', _sourceFile: 'file1', _sourceSheet: 'Sheet1' },
    ];

    const result = calculateWeightedScores(dataWithMissing, weights, ['score1']);

    // Should only count the valid numeric value
    expect(result.scores.score1).toBe(80);
  });
});
