/**
 * ===================================================================
 * WEIGHTED SCORE SERVICE TESTS
 * ===================================================================
 *
 * Tests for score calculation from multiple assessment sources
 *
 * @module tests/weightedScoreService.test
 */

import { describe, it, expect } from 'vitest';
import {
  FILE_WEIGHTS,
  normalizeScore,
  calculateAverage,
  calculateAdjustedWeights,
  calculateWeightedScore,
  calculateCoreMetricScores,
  aggregateHistoricalFeedback,
  getDecember2025Feedback
} from '../services/weightedScoreService.js';

// ===================================================================
// FILE_WEIGHTS TESTS
// ===================================================================

describe('FILE_WEIGHTS', () => {
  it('should have 7 file weights defined', () => {
    expect(Object.keys(FILE_WEIGHTS)).toHaveLength(7);
  });

  it('should have leadership_assessment_dec_2025 as primary (60%)', () => {
    expect(FILE_WEIGHTS['leadership_assessment_dec_2025']).toBe(60);
  });

  it('should sum to 100%', () => {
    const total = Object.values(FILE_WEIGHTS).reduce((sum, w) => sum + w, 0);
    expect(total).toBe(100);
  });

  it('should have correct individual weights', () => {
    expect(FILE_WEIGHTS['360_leadership_feedback']).toBe(10);
    expect(FILE_WEIGHTS['station_checkin']).toBe(8);
    expect(FILE_WEIGHTS['quarterly_review']).toBe(7);
    expect(FILE_WEIGHTS['360_new_full']).toBe(4);
    expect(FILE_WEIGHTS['periodic_evaluation_2024']).toBe(5);
    expect(FILE_WEIGHTS['leadership_analysis_2025']).toBe(6);
  });
});

// ===================================================================
// NORMALIZE SCORE TESTS
// ===================================================================

describe('normalizeScore', () => {
  it('should normalize score from 1-10 scale to 0-100', () => {
    expect(normalizeScore(1, 1, 10)).toBe(0);
    expect(normalizeScore(10, 1, 10)).toBe(100);
    expect(normalizeScore(5.5, 1, 10)).toBe(50);
  });

  it('should normalize score from 1-5 scale to 0-100', () => {
    expect(normalizeScore(1, 1, 5)).toBe(0);
    expect(normalizeScore(5, 1, 5)).toBe(100);
    expect(normalizeScore(3, 1, 5)).toBe(50);
  });

  it('should return null for non-numeric input', () => {
    expect(normalizeScore('not a number', 1, 10)).toBe(null);
    expect(normalizeScore(NaN, 1, 10)).toBe(null);
    expect(normalizeScore(undefined, 1, 10)).toBe(null);
  });

  it('should return 50 when min equals max (avoid division by zero)', () => {
    expect(normalizeScore(5, 5, 5)).toBe(50);
  });

  it('should round to nearest integer', () => {
    expect(normalizeScore(5.55, 1, 10)).toBe(51); // (5.55-1)/(10-1)*100 = 50.555... ≈ 51
  });
});

// ===================================================================
// CALCULATE AVERAGE TESTS
// ===================================================================

describe('calculateAverage', () => {
  it('should calculate average of numeric values', () => {
    expect(calculateAverage([10, 20, 30])).toBe(20);
    expect(calculateAverage([1, 2, 3, 4, 5])).toBe(3);
  });

  it('should ignore non-numeric values', () => {
    expect(calculateAverage([10, 'N/A', 30, null, undefined])).toBe(20);
  });

  it('should return null for empty array', () => {
    expect(calculateAverage([])).toBe(null);
  });

  it('should return null for array with only non-numeric values', () => {
    expect(calculateAverage(['a', 'b', null])).toBe(null);
  });

  it('should handle single value', () => {
    expect(calculateAverage([42])).toBe(42);
  });
});

// ===================================================================
// CALCULATE ADJUSTED WEIGHTS TESTS
// ===================================================================

describe('calculateAdjustedWeights', () => {
  it('should return original weights when all sources available', () => {
    const availableSources = {
      '360_leadership_feedback': true,
      'station_checkin': true,
      'quarterly_review': true,
      '360_new_full': true,
      'periodic_evaluation_2024': true,
      'leadership_analysis_2025': true,
      'leadership_assessment_dec_2025': true
    };

    const result = calculateAdjustedWeights(availableSources);

    // Weights should remain proportional (sum to ~100)
    const totalAdjusted = Object.values(result.adjustedWeights).reduce((sum, w) => sum + w, 0);
    expect(totalAdjusted).toBeCloseTo(100, 0);
    expect(result.coveragePercentage).toBe(100);
  });

  it('should adjust weights when some sources missing', () => {
    const availableSources = {
      '360_leadership_feedback': false,
      'station_checkin': false,
      'quarterly_review': false,
      '360_new_full': false,
      'periodic_evaluation_2024': false,
      'leadership_analysis_2025': false,
      'leadership_assessment_dec_2025': true  // Only File 7 available
    };

    const result = calculateAdjustedWeights(availableSources);

    // Only File 7 available, so it should get 100% weight
    expect(result.adjustedWeights['leadership_assessment_dec_2025']).toBe(100);
    expect(result.adjustedWeights['360_leadership_feedback']).toBe(0);
    expect(result.coveragePercentage).toBe(60);
  });

  it('should handle multiple sources available', () => {
    const availableSources = {
      '360_leadership_feedback': true,  // 10%
      'station_checkin': false,
      'quarterly_review': false,
      '360_new_full': false,
      'periodic_evaluation_2024': false,
      'leadership_analysis_2025': false,
      'leadership_assessment_dec_2025': true  // 60%
    };

    const result = calculateAdjustedWeights(availableSources);

    // Available: 10 + 60 = 70%
    // File 1 adjusted: 10/70 * 100 ≈ 14.3%
    // File 7 adjusted: 60/70 * 100 ≈ 85.7%
    expect(result.adjustedWeights['360_leadership_feedback']).toBeCloseTo(14.3, 0);
    expect(result.adjustedWeights['leadership_assessment_dec_2025']).toBeCloseTo(85.7, 0);
    expect(result.coveragePercentage).toBe(70);
  });

  it('should return zero weights when no sources available', () => {
    const availableSources = {
      '360_leadership_feedback': false,
      'station_checkin': false,
      'quarterly_review': false,
      '360_new_full': false,
      'periodic_evaluation_2024': false,
      'leadership_analysis_2025': false,
      'leadership_assessment_dec_2025': false
    };

    const result = calculateAdjustedWeights(availableSources);

    expect(result.totalAvailableWeight).toBe(0);
    expect(result.coveragePercentage).toBe(0);
  });
});

// ===================================================================
// CALCULATE WEIGHTED SCORE TESTS
// ===================================================================

describe('calculateWeightedScore', () => {
  it('should calculate weighted score from multiple sources', () => {
    const sourceScores = {
      '360_leadership_feedback': { available: true, score: 80 },
      'leadership_assessment_dec_2025': { available: true, score: 90 }
    };

    const adjustedWeights = {
      '360_leadership_feedback': 14.3,
      'station_checkin': 0,
      'quarterly_review': 0,
      '360_new_full': 0,
      'periodic_evaluation_2024': 0,
      'leadership_analysis_2025': 0,
      'leadership_assessment_dec_2025': 85.7
    };

    const result = calculateWeightedScore(sourceScores, adjustedWeights);

    // (80 * 14.3 + 90 * 85.7) / (14.3 + 85.7) ≈ 88.6
    expect(result).toBeCloseTo(89, 0);
  });

  it('should skip qualitative-only sources', () => {
    const sourceScores = {
      'station_checkin': { available: true, score: 70 },  // qualitative
      'leadership_analysis_2025': { available: true, score: 75 },  // qualitative
      'leadership_assessment_dec_2025': { available: true, score: 90 }
    };

    const adjustedWeights = {
      'station_checkin': 10,
      'leadership_analysis_2025': 10,
      'leadership_assessment_dec_2025': 80
    };

    const result = calculateWeightedScore(sourceScores, adjustedWeights);

    // Should only count File 7 (qualitative sources excluded)
    expect(result).toBe(90);
  });

  it('should return null when no numeric sources available', () => {
    const sourceScores = {
      'station_checkin': { available: true, score: 70 },
      'leadership_analysis_2025': { available: true, score: 75 }
    };

    const adjustedWeights = {
      'station_checkin': 50,
      'leadership_analysis_2025': 50
    };

    const result = calculateWeightedScore(sourceScores, adjustedWeights);
    expect(result).toBe(null);
  });

  it('should handle sources with null scores', () => {
    const sourceScores = {
      '360_leadership_feedback': { available: true, score: null },
      'leadership_assessment_dec_2025': { available: true, score: 85 }
    };

    const adjustedWeights = {
      '360_leadership_feedback': 15,
      'leadership_assessment_dec_2025': 85
    };

    const result = calculateWeightedScore(sourceScores, adjustedWeights);
    expect(result).toBe(85);
  });
});

// ===================================================================
// CALCULATE CORE METRIC SCORES TESTS
// ===================================================================

describe('calculateCoreMetricScores', () => {
  it('should use File 7 category scores when available', () => {
    const sourceScores = {
      'leadership_assessment_dec_2025': {
        available: true,
        score: 85,
        categoryScores: {
          clarity: 80,
          efficiency: 85,
          safety: 90,
          empowerment: 75
        }
      }
    };

    const adjustedWeights = {};

    const result = calculateCoreMetricScores(sourceScores, adjustedWeights);

    expect(result.clarity).toBe(80);
    expect(result.efficiency).toBe(85);
    expect(result.safety).toBe(90);
    expect(result.empowerment).toBe(75);
  });

  it('should fall back to overall score when category scores missing', () => {
    const sourceScores = {
      'leadership_assessment_dec_2025': {
        available: true,
        score: 85,
        categoryScores: {}
      }
    };

    const adjustedWeights = {};

    const result = calculateCoreMetricScores(sourceScores, adjustedWeights);

    expect(result.clarity).toBe(85);
    expect(result.efficiency).toBe(85);
    expect(result.safety).toBe(85);
    expect(result.empowerment).toBe(85);
  });

  it('should fall back to weighted overall when File 7 not available', () => {
    const sourceScores = {
      '360_leadership_feedback': { available: true, score: 80 }
    };

    const adjustedWeights = {
      '360_leadership_feedback': 100
    };

    const result = calculateCoreMetricScores(sourceScores, adjustedWeights);

    expect(result.clarity).toBe(80);
    expect(result.efficiency).toBe(80);
    expect(result.safety).toBe(80);
    expect(result.empowerment).toBe(80);
  });
});

// ===================================================================
// AGGREGATE HISTORICAL FEEDBACK TESTS
// ===================================================================

describe('aggregateHistoricalFeedback', () => {
  it('should aggregate qualitative data from sources', () => {
    const sourceScores = {
      'station_checkin': {
        available: true,
        qualitativeData: { field1: ['feedback 1', 'feedback 2'] },
        reviewerCount: 2
      },
      'leadership_analysis_2025': {
        available: true,
        qualitativeData: { strengths: 'Strong leadership' },
        reviewerCount: 1
      },
      'leadership_assessment_dec_2025': {
        available: true,
        score: 85
      }
    };

    const result = aggregateHistoricalFeedback(sourceScores);

    expect(result['station_checkin']).toBeDefined();
    expect(result['station_checkin'].type).toBe('qualitative');
    expect(result['leadership_analysis_2025']).toBeDefined();
    // File 7 should be excluded (handled separately)
    expect(result['leadership_assessment_dec_2025']).toBeUndefined();
  });

  it('should aggregate numeric data with category scores', () => {
    const sourceScores = {
      '360_leadership_feedback': {
        available: true,
        score: 80,
        categoryScores: { clarity: 85, efficiency: 75 },
        reviewerCount: 3
      }
    };

    const result = aggregateHistoricalFeedback(sourceScores);

    expect(result['360_leadership_feedback']).toBeDefined();
    expect(result['360_leadership_feedback'].type).toBe('numeric');
    expect(result['360_leadership_feedback'].categoryScores.clarity).toBe(85);
  });

  it('should skip unavailable sources', () => {
    const sourceScores = {
      'station_checkin': {
        available: false,
        qualitativeData: { field1: ['feedback'] }
      }
    };

    const result = aggregateHistoricalFeedback(sourceScores);

    expect(result['station_checkin']).toBeUndefined();
  });
});

// ===================================================================
// GET DECEMBER 2025 FEEDBACK TESTS
// ===================================================================

describe('getDecember2025Feedback', () => {
  it('should extract text feedback from File 7', () => {
    const sourceScores = {
      'leadership_assessment_dec_2025': {
        available: true,
        textFeedback: {
          strengths: ['Excellent communicator', 'Strong leader'],
          developmentAreas: ['Time management'],
          hrNotes: ['Promoted last year']
        },
        reviewerCount: 5
      }
    };

    const result = getDecember2025Feedback(sourceScores);

    expect(result.strengths).toHaveLength(2);
    expect(result.developmentAreas).toHaveLength(1);
    expect(result.hrNotes).toHaveLength(1);
    expect(result.reviewerCount).toBe(5);
  });

  it('should return null when File 7 not available', () => {
    const sourceScores = {
      'leadership_assessment_dec_2025': {
        available: false
      }
    };

    const result = getDecember2025Feedback(sourceScores);
    expect(result).toBe(null);
  });

  it('should return null when textFeedback missing', () => {
    const sourceScores = {
      'leadership_assessment_dec_2025': {
        available: true,
        score: 85
        // no textFeedback
      }
    };

    const result = getDecember2025Feedback(sourceScores);
    expect(result).toBe(null);
  });

  it('should handle empty arrays in textFeedback', () => {
    const sourceScores = {
      'leadership_assessment_dec_2025': {
        available: true,
        textFeedback: {
          strengths: [],
          developmentAreas: [],
          hrNotes: []
        },
        reviewerCount: 0
      }
    };

    const result = getDecember2025Feedback(sourceScores);

    expect(result.strengths).toHaveLength(0);
    expect(result.developmentAreas).toHaveLength(0);
    expect(result.hrNotes).toHaveLength(0);
  });
});
