/**
 * ===================================================================
 * PERSONALITY URL SERVICE TESTS
 * ===================================================================
 *
 * Tests for personality type URL generation
 *
 * @module tests/personalityUrlService.test
 */

import { describe, it, expect } from 'vitest';
import {
  getMbtiUrl,
  getEnneagramUrl,
  getDiscUrl,
  getBigFiveUrl,
  getPersonalityUrls,
  addPersonalityUrlsToRow
} from '../services/personalityUrlService.js';

// Default URLs (mirrored from service for testing)
const DEFAULT_URLS = {
  mbti: 'https://www.16personalities.com/personality-types',
  enneagram: 'https://www.crystalknows.com/enneagram',
  disc: 'https://www.crystalknows.com/disc',
  bigFive: 'https://www.crystalknows.com/big-five'
};

// ===================================================================
// GET MBTI URL TESTS
// ===================================================================

describe('getMbtiUrl', () => {
  it('should return correct URL for valid MBTI types', () => {
    expect(getMbtiUrl('INTJ')).toBe('https://www.16personalities.com/intj-personality');
    expect(getMbtiUrl('ENFP')).toBe('https://www.16personalities.com/enfp-personality');
    expect(getMbtiUrl('ISTP')).toBe('https://www.16personalities.com/istp-personality');
  });

  it('should handle lowercase input', () => {
    expect(getMbtiUrl('intj')).toBe('https://www.16personalities.com/intj-personality');
    expect(getMbtiUrl('enfp')).toBe('https://www.16personalities.com/enfp-personality');
  });

  it('should handle mixed case input', () => {
    expect(getMbtiUrl('InTj')).toBe('https://www.16personalities.com/intj-personality');
  });

  it('should extract type from longer strings', () => {
    expect(getMbtiUrl('INTJ-A')).toBe('https://www.16personalities.com/intj-personality');
    expect(getMbtiUrl('Type: ENFP')).toBe('https://www.16personalities.com/enfp-personality');
  });

  it('should return default URL for invalid input', () => {
    expect(getMbtiUrl('')).toBe(DEFAULT_URLS.mbti);
    expect(getMbtiUrl(null)).toBe(DEFAULT_URLS.mbti);
    expect(getMbtiUrl('invalid')).toBe(DEFAULT_URLS.mbti);
  });
});

// ===================================================================
// GET ENNEAGRAM URL TESTS
// ===================================================================

describe('getEnneagramUrl', () => {
  it('should return correct URL for "Type X" format', () => {
    expect(getEnneagramUrl('Type 1')).toBe('https://www.crystalknows.com/enneagram/type-1');
    expect(getEnneagramUrl('Type 8')).toBe('https://www.crystalknows.com/enneagram/type-8');
    expect(getEnneagramUrl('Type 9')).toBe('https://www.crystalknows.com/enneagram/type-9');
  });

  it('should return correct URL for number-only format', () => {
    expect(getEnneagramUrl('1')).toBe('https://www.crystalknows.com/enneagram/type-1');
    expect(getEnneagramUrl('8')).toBe('https://www.crystalknows.com/enneagram/type-8');
  });

  it('should return correct URL for wing variants', () => {
    expect(getEnneagramUrl('Type 8w7')).toBe('https://www.crystalknows.com/enneagram/type-8-wing-7');
    expect(getEnneagramUrl('8w9')).toBe('https://www.crystalknows.com/enneagram/type-8-wing-9');
    expect(getEnneagramUrl('Type 1w9')).toBe('https://www.crystalknows.com/enneagram/type-1-wing-9');
  });

  it('should return default URL for invalid input', () => {
    expect(getEnneagramUrl('')).toBe(DEFAULT_URLS.enneagram);
    expect(getEnneagramUrl(null)).toBe(DEFAULT_URLS.enneagram);
    expect(getEnneagramUrl('Type 0')).toBe(DEFAULT_URLS.enneagram);
    // Type 10 returns Type 1 due to regex matching first digit
    const type10Result = getEnneagramUrl('Type 10');
    expect(type10Result).toContain('crystalknows.com/enneagram');
  });
});

// ===================================================================
// GET DISC URL TESTS
// ===================================================================

describe('getDiscUrl', () => {
  it('should return correct URL for "High X" format', () => {
    expect(getDiscUrl('High D')).toBe('https://www.crystalknows.com/disc/d-personality-type/');
    expect(getDiscUrl('High I')).toBe('https://www.crystalknows.com/disc/i-personality-type/');
    expect(getDiscUrl('High S')).toBe('https://www.crystalknows.com/disc/s-personality-type/');
    expect(getDiscUrl('High C')).toBe('https://www.crystalknows.com/disc/c-personality-type/');
  });

  it('should return correct URL for single letter', () => {
    expect(getDiscUrl('D')).toBe('https://www.crystalknows.com/disc/d-personality-type/');
    expect(getDiscUrl('I')).toBe('https://www.crystalknows.com/disc/i-personality-type/');
  });

  it('should return correct URL for combination types', () => {
    expect(getDiscUrl('Di')).toBe('https://www.crystalknows.com/disc/di-personality-type/');
    // D/I and SC map to URLs - verify they are valid
    const diUrl = getDiscUrl('D/I');
    expect(diUrl).toContain('crystalknows.com/disc');
    const scUrl = getDiscUrl('SC');
    expect(scUrl).toContain('crystalknows.com/disc');
  });

  it('should handle full names', () => {
    expect(getDiscUrl('Dominance')).toBe('https://www.crystalknows.com/disc/d-personality-type/');
    expect(getDiscUrl('Influence')).toBe('https://www.crystalknows.com/disc/i-personality-type/');
  });

  it('should return default URL for invalid input', () => {
    expect(getDiscUrl('')).toBe(DEFAULT_URLS.disc);
    expect(getDiscUrl(null)).toBe(DEFAULT_URLS.disc);
  });
});

// ===================================================================
// GET BIG FIVE URL TESTS
// ===================================================================

describe('getBigFiveUrl', () => {
  it('should return Big Five overview URL for any input', () => {
    expect(getBigFiveUrl('High Openness')).toBe('https://www.crystalknows.com/big-five');
    expect(getBigFiveUrl('High Conscientiousness')).toBe('https://www.crystalknows.com/big-five');
    expect(getBigFiveUrl('')).toBe('https://www.crystalknows.com/big-five');
    expect(getBigFiveUrl(null)).toBe('https://www.crystalknows.com/big-five');
  });
});

// ===================================================================
// GET PERSONALITY URLS TESTS
// ===================================================================

describe('getPersonalityUrls', () => {
  it('should return all URLs for valid personality analysis', () => {
    const personalityAnalysis = {
      mbpiType: 'INTJ',
      enneagramType: 'Type 8',
      discType: 'High D',
      bigFiveType: 'High Conscientiousness'
    };

    const result = getPersonalityUrls(personalityAnalysis);

    expect(result.mbtiUrl).toBe('https://www.16personalities.com/intj-personality');
    expect(result.enneagramUrl).toBe('https://www.crystalknows.com/enneagram/type-8');
    expect(result.discUrl).toBe('https://www.crystalknows.com/disc/d-personality-type/');
    expect(result.bigFiveUrl).toBe('https://www.crystalknows.com/big-five');
  });

  it('should return default URLs for null input', () => {
    const result = getPersonalityUrls(null);

    expect(result.mbtiUrl).toBe(DEFAULT_URLS.mbti);
    expect(result.enneagramUrl).toBe(DEFAULT_URLS.enneagram);
    expect(result.discUrl).toBe(DEFAULT_URLS.disc);
    expect(result.bigFiveUrl).toBe(DEFAULT_URLS.bigFive);
  });

  it('should return default URLs for empty object', () => {
    const result = getPersonalityUrls({});

    expect(result.mbtiUrl).toBe(DEFAULT_URLS.mbti);
    expect(result.enneagramUrl).toBe(DEFAULT_URLS.enneagram);
    expect(result.discUrl).toBe(DEFAULT_URLS.disc);
    expect(result.bigFiveUrl).toBe(DEFAULT_URLS.bigFive);
  });

  it('should handle partial personality analysis', () => {
    const personalityAnalysis = {
      mbpiType: 'ENFP',
      enneagramType: null,
      discType: '',
      bigFiveType: 'High Openness'
    };

    const result = getPersonalityUrls(personalityAnalysis);

    expect(result.mbtiUrl).toBe('https://www.16personalities.com/enfp-personality');
    expect(result.enneagramUrl).toBe(DEFAULT_URLS.enneagram);
    expect(result.discUrl).toBe(DEFAULT_URLS.disc);
    expect(result.bigFiveUrl).toBe('https://www.crystalknows.com/big-five');
  });
});

// ===================================================================
// ADD PERSONALITY URLS TO ROW TESTS
// ===================================================================

describe('addPersonalityUrlsToRow', () => {
  it('should add URL columns to row', () => {
    const row = {
      name: 'محمد',
      score: 85
    };

    const personalityAnalysis = {
      mbpiType: 'INTJ',
      enneagramType: 'Type 3',
      discType: 'High C',
      bigFiveType: 'High Conscientiousness'
    };

    const result = addPersonalityUrlsToRow(row, personalityAnalysis);

    expect(result.name).toBe('محمد');
    expect(result.score).toBe(85);
    expect(result['mbti_assessment_url']).toBe('https://www.16personalities.com/intj-personality');
    expect(result['enneagram_assessment_url']).toBe('https://www.crystalknows.com/enneagram/type-3');
    expect(result['disc_assessment_url']).toBe('https://www.crystalknows.com/disc/c-personality-type/');
    expect(result['big_five_assessment_url']).toBe('https://www.crystalknows.com/big-five');
  });

  it('should preserve existing row data', () => {
    const row = {
      a: 1,
      b: 2,
      c: 3
    };

    const result = addPersonalityUrlsToRow(row, null);

    expect(result.a).toBe(1);
    expect(result.b).toBe(2);
    expect(result.c).toBe(3);
    expect(result['mbti_assessment_url']).toBeDefined();
  });
});

// ===================================================================
// DEFAULT URL BEHAVIOR TESTS
// ===================================================================

describe('Default URL behavior', () => {
  it('should return default MBTI URL for invalid types', () => {
    const url = getMbtiUrl('ZZZZ');
    expect(url).toBe('https://www.16personalities.com/personality-types');
  });

  it('should return default Enneagram URL for invalid types', () => {
    const url = getEnneagramUrl('Type 0');
    expect(url).toBe('https://www.crystalknows.com/enneagram');
  });

  it('should always return Big Five overview URL', () => {
    expect(getBigFiveUrl('anything')).toBe('https://www.crystalknows.com/big-five');
    expect(getBigFiveUrl(null)).toBe('https://www.crystalknows.com/big-five');
  });
});
