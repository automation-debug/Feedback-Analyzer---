/**
 * ===================================================================
 * REPORT SCHEMAS TESTS
 * ===================================================================
 *
 * Tests for report JSON schemas and validation
 *
 * @module tests/reportSchemas.test
 */

import { describe, it, expect } from 'vitest';
import {
  REPORT_SCHEMAS,
  STANDARD_REPORT_SCHEMA,
  EXTENDED_REPORT_SCHEMA,
  GIGANTIC_REPORT_SCHEMA,
  getSchemaForReportType,
  getSchemaByReviewerCount,
  validateReportStructure
} from '../services/report/schemas/index.js';

// ===================================================================
// SCHEMA EXISTENCE TESTS
// ===================================================================

describe('Report Schemas', () => {
  it('should export all three report schemas', () => {
    expect(STANDARD_REPORT_SCHEMA).toBeDefined();
    expect(EXTENDED_REPORT_SCHEMA).toBeDefined();
    expect(GIGANTIC_REPORT_SCHEMA).toBeDefined();
  });

  it('should have REPORT_SCHEMAS map', () => {
    expect(REPORT_SCHEMAS.STANDARD).toBe(STANDARD_REPORT_SCHEMA);
    expect(REPORT_SCHEMAS.EXTENDED).toBe(EXTENDED_REPORT_SCHEMA);
    expect(REPORT_SCHEMAS.GIGANTIC).toBe(GIGANTIC_REPORT_SCHEMA);
  });
});

// ===================================================================
// STANDARD SCHEMA TESTS
// ===================================================================

describe('STANDARD_REPORT_SCHEMA', () => {
  it('should have correct required fields', () => {
    const required = STANDARD_REPORT_SCHEMA.required;
    expect(required).toContain('header');
    expect(required).toContain('leadershipPath');
    expect(required).toContain('coreMetrics');
    expect(required).toContain('strengths');
    expect(required).toContain('weaknesses');
    expect(required).toContain('personalityAnalysis');
    expect(required).toContain('teamVoice');
    expect(required).toContain('roadmap');
    expect(required).toContain('developmentPlan');
  });

  it('should require 3 strengths', () => {
    const strengthsSchema = STANDARD_REPORT_SCHEMA.properties.strengths;
    expect(strengthsSchema.minItems).toBe(3);
    expect(strengthsSchema.maxItems).toBe(3);
  });

  it('should require 3 weaknesses', () => {
    const weaknessesSchema = STANDARD_REPORT_SCHEMA.properties.weaknesses;
    expect(weaknessesSchema.minItems).toBe(3);
    expect(weaknessesSchema.maxItems).toBe(3);
  });

  it('should require 4 teamVoice items', () => {
    const teamVoiceSchema = STANDARD_REPORT_SCHEMA.properties.teamVoice;
    expect(teamVoiceSchema.minItems).toBe(4);
    expect(teamVoiceSchema.maxItems).toBe(4);
  });

  it('should require 3 bullet points per core metric', () => {
    const bulletSchema = STANDARD_REPORT_SCHEMA.properties.coreMetrics.items.properties.bulletPoints;
    expect(bulletSchema.minItems).toBe(3);
    expect(bulletSchema.maxItems).toBe(3);
  });

  it('should NOT require executiveSummary3', () => {
    const headerRequired = STANDARD_REPORT_SCHEMA.properties.header.required;
    expect(headerRequired).not.toContain('executiveSummary3');
  });
});

// ===================================================================
// EXTENDED SCHEMA TESTS
// ===================================================================

describe('EXTENDED_REPORT_SCHEMA', () => {
  it('should require 6 strengths', () => {
    const strengthsSchema = EXTENDED_REPORT_SCHEMA.properties.strengths;
    expect(strengthsSchema.minItems).toBe(6);
    expect(strengthsSchema.maxItems).toBe(6);
  });

  it('should require 6 weaknesses', () => {
    const weaknessesSchema = EXTENDED_REPORT_SCHEMA.properties.weaknesses;
    expect(weaknessesSchema.minItems).toBe(6);
    expect(weaknessesSchema.maxItems).toBe(6);
  });

  it('should require 5 teamVoice items', () => {
    const teamVoiceSchema = EXTENDED_REPORT_SCHEMA.properties.teamVoice;
    expect(teamVoiceSchema.minItems).toBe(5);
    expect(teamVoiceSchema.maxItems).toBe(5);
  });

  it('should require 5 bullet points per core metric', () => {
    const bulletSchema = EXTENDED_REPORT_SCHEMA.properties.coreMetrics.items.properties.bulletPoints;
    expect(bulletSchema.minItems).toBe(5);
    expect(bulletSchema.maxItems).toBe(5);
  });
});

// ===================================================================
// GIGANTIC SCHEMA TESTS
// ===================================================================

describe('GIGANTIC_REPORT_SCHEMA', () => {
  it('should require 9 strengths', () => {
    const strengthsSchema = GIGANTIC_REPORT_SCHEMA.properties.strengths;
    expect(strengthsSchema.minItems).toBe(9);
    expect(strengthsSchema.maxItems).toBe(9);
  });

  it('should require 9 weaknesses', () => {
    const weaknessesSchema = GIGANTIC_REPORT_SCHEMA.properties.weaknesses;
    expect(weaknessesSchema.minItems).toBe(9);
    expect(weaknessesSchema.maxItems).toBe(9);
  });

  it('should require 12 teamVoice items', () => {
    const teamVoiceSchema = GIGANTIC_REPORT_SCHEMA.properties.teamVoice;
    expect(teamVoiceSchema.minItems).toBe(12);
    expect(teamVoiceSchema.maxItems).toBe(12);
  });

  it('should require 7 bullet points per core metric', () => {
    const bulletSchema = GIGANTIC_REPORT_SCHEMA.properties.coreMetrics.items.properties.bulletPoints;
    expect(bulletSchema.minItems).toBe(7);
    expect(bulletSchema.maxItems).toBe(7);
  });

  it('should require executiveSummary3 in header', () => {
    const headerRequired = GIGANTIC_REPORT_SCHEMA.properties.header.required;
    expect(headerRequired).toContain('executiveSummary3');
  });

  it('should require overview3 in personalityAnalysis', () => {
    const personalityRequired = GIGANTIC_REPORT_SCHEMA.properties.personalityAnalysis.required;
    expect(personalityRequired).toContain('overview3');
  });

  it('should require 9 developmentCompass items', () => {
    const devCompassSchema = GIGANTIC_REPORT_SCHEMA.properties.developmentCompass;
    expect(devCompassSchema.minItems).toBe(9);
    expect(devCompassSchema.maxItems).toBe(9);
  });

  it('should require 10 roadmap steps', () => {
    const stepsSchema = GIGANTIC_REPORT_SCHEMA.properties.roadmap.items.properties.steps;
    expect(stepsSchema.minItems).toBe(10);
    expect(stepsSchema.maxItems).toBe(10);
  });
});

// ===================================================================
// GET SCHEMA FOR REPORT TYPE TESTS
// ===================================================================

describe('getSchemaForReportType', () => {
  it('should return correct schema for each type', () => {
    expect(getSchemaForReportType('STANDARD')).toBe(STANDARD_REPORT_SCHEMA);
    expect(getSchemaForReportType('EXTENDED')).toBe(EXTENDED_REPORT_SCHEMA);
    expect(getSchemaForReportType('GIGANTIC')).toBe(GIGANTIC_REPORT_SCHEMA);
  });

  it('should throw error for invalid type', () => {
    expect(() => getSchemaForReportType('INVALID')).toThrow();
    expect(() => getSchemaForReportType('')).toThrow();
    expect(() => getSchemaForReportType(null)).toThrow();
  });
});

// ===================================================================
// GET SCHEMA BY REVIEWER COUNT TESTS
// ===================================================================

describe('getSchemaByReviewerCount', () => {
  it('should return STANDARD for 0-6 reviewers', () => {
    expect(getSchemaByReviewerCount(0).reportType).toBe('STANDARD');
    expect(getSchemaByReviewerCount(1).reportType).toBe('STANDARD');
    expect(getSchemaByReviewerCount(6).reportType).toBe('STANDARD');
  });

  it('should return EXTENDED for 7-20 reviewers', () => {
    expect(getSchemaByReviewerCount(7).reportType).toBe('EXTENDED');
    expect(getSchemaByReviewerCount(15).reportType).toBe('EXTENDED');
    expect(getSchemaByReviewerCount(20).reportType).toBe('EXTENDED');
  });

  it('should return GIGANTIC for 21+ reviewers', () => {
    expect(getSchemaByReviewerCount(21).reportType).toBe('GIGANTIC');
    expect(getSchemaByReviewerCount(50).reportType).toBe('GIGANTIC');
    expect(getSchemaByReviewerCount(100).reportType).toBe('GIGANTIC');
  });

  it('should return schema with result', () => {
    const result = getSchemaByReviewerCount(10);
    expect(result.schema).toBe(EXTENDED_REPORT_SCHEMA);
    expect(result.reportType).toBe('EXTENDED');
    expect(result.thresholds).toBeDefined();
  });
});

// ===================================================================
// VALIDATE REPORT STRUCTURE TESTS
// ===================================================================

describe('validateReportStructure', () => {
  const createMockReport = (overrides = {}) => ({
    header: { employeeName: 'Test', executiveSummary: 'Summary', executiveSummary2: {} },
    leadershipPath: { score: 85, statusLabelAr: 'خضر' },
    coreMetrics: [
      { id: 'clarity', score: 80, bulletPoints: ['1', '2', '3'] },
      { id: 'efficiency', score: 85, bulletPoints: ['1', '2', '3'] },
      { id: 'safety', score: 90, bulletPoints: ['1', '2', '3'] },
      { id: 'empowerment', score: 75, bulletPoints: ['1', '2', '3'] }
    ],
    strengths: [{ title: 't', description: 'd' }, { title: 't', description: 'd' }, { title: 't', description: 'd' }],
    weaknesses: [{ title: 't', description: 'd' }, { title: 't', description: 'd' }, { title: 't', description: 'd' }],
    personalityAnalysis: { overview: 'o', overview2: {}, mbpiType: 'INTJ', enneagramType: 'Type 8', discType: 'High D', bigFiveType: 'High C', strengths: ['1', '2', '3', '4', '5'], weaknesses: ['1', '2', '3', '4', '5'] },
    teamVoice: [{ title: 't', content: 'c' }, { title: 't', content: 'c' }, { title: 't', content: 'c' }, { title: 't', content: 'c' }],
    developmentCompass: ['1', '2', '3', '4', '5'],
    roadmap: [{ title: 't', priorityAr: 'p', steps: ['1', '2', '3', '4'] }, { title: 't', priorityAr: 'p', steps: ['1', '2', '3', '4'] }, { title: 't', priorityAr: 'p', steps: ['1', '2', '3', '4'] }],
    developmentPlan: [{ categoryTitle: 'c', resources: [{}, {}, {}, {}, {}] }, { categoryTitle: 'c', resources: [{}, {}, {}, {}, {}] }, { categoryTitle: 'c', resources: [{}, {}, {}, {}, {}] }, { categoryTitle: 'c', resources: [{}, {}, {}, {}, {}] }],
    ...overrides
  });

  it('should validate a correct STANDARD report', () => {
    const report = createMockReport();
    const result = validateReportStructure(report, 'STANDARD');
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should detect missing required fields', () => {
    const report = createMockReport();
    delete report.strengths;

    const result = validateReportStructure(report, 'STANDARD');
    expect(result.valid).toBe(false);
    expect(result.errors.some(e => e.includes('strengths'))).toBe(true);
  });

  it('should detect insufficient strengths', () => {
    const report = createMockReport({
      strengths: [{ title: 't', description: 'd' }]  // Only 1, need 3
    });

    const result = validateReportStructure(report, 'STANDARD');
    expect(result.valid).toBe(false);
    expect(result.errors.some(e => e.includes('strengths'))).toBe(true);
  });

  it('should detect missing executiveSummary3 for gigantic', () => {
    const giganticReport = createMockReport({
      strengths: Array(9).fill({ title: 't', description: 'd' }),
      weaknesses: Array(9).fill({ title: 't', description: 'd' }),
      teamVoice: Array(12).fill({ title: 't', content: 'c' }),
      developmentCompass: Array(9).fill('item'),
      coreMetrics: [
        { id: 'clarity', score: 80, bulletPoints: Array(7).fill('b') },
        { id: 'efficiency', score: 85, bulletPoints: Array(7).fill('b') },
        { id: 'safety', score: 90, bulletPoints: Array(7).fill('b') },
        { id: 'empowerment', score: 75, bulletPoints: Array(7).fill('b') }
      ],
      header: { employeeName: 'Test', executiveSummary: 'Summary', executiveSummary2: {} }
      // Missing executiveSummary3
    });

    const result = validateReportStructure(giganticReport, 'GIGANTIC');
    expect(result.valid).toBe(false);
    expect(result.errors.some(e => e.includes('executiveSummary3'))).toBe(true);
  });
});
