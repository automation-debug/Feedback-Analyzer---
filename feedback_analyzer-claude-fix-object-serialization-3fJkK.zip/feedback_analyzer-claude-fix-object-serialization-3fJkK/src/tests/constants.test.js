/**
 * ===================================================================
 * CONSTANTS MODULE TESTS
 * ===================================================================
 *
 * Tests for the centralized configuration constants
 *
 * @module tests/constants.test
 */

import { describe, it, expect } from 'vitest';
import {
  REPORT_THRESHOLDS,
  getReportType,
  FILE_WEIGHTS,
  QUALITATIVE_SCHEMAS,
  SCORE_THRESHOLDS,
  getScoreStatus,
  API_CONFIG,
  BATCH_CONFIG,
  FIELD_LIMITS,
  ITEM_COUNTS,
  PERSONALITY_TYPES,
  LOG_CONFIG
} from '../config/constants/index.js';

// ===================================================================
// REPORT THRESHOLDS TESTS
// ===================================================================

describe('REPORT_THRESHOLDS', () => {
  it('should have EXTENDED threshold of 7', () => {
    expect(REPORT_THRESHOLDS.EXTENDED).toBe(7);
  });

  it('should have GIGANTIC threshold of 21', () => {
    expect(REPORT_THRESHOLDS.GIGANTIC).toBe(21);
  });
});

describe('getReportType', () => {
  it('should return STANDARD for 0-6 reviewers', () => {
    expect(getReportType(0)).toBe('STANDARD');
    expect(getReportType(1)).toBe('STANDARD');
    expect(getReportType(6)).toBe('STANDARD');
  });

  it('should return EXTENDED for 7-20 reviewers', () => {
    expect(getReportType(7)).toBe('EXTENDED');
    expect(getReportType(15)).toBe('EXTENDED');
    expect(getReportType(20)).toBe('EXTENDED');
  });

  it('should return GIGANTIC for 21+ reviewers', () => {
    expect(getReportType(21)).toBe('GIGANTIC');
    expect(getReportType(50)).toBe('GIGANTIC');
    expect(getReportType(100)).toBe('GIGANTIC');
  });
});

// ===================================================================
// FILE WEIGHTS TESTS
// ===================================================================

describe('FILE_WEIGHTS', () => {
  it('should have all 7 file weights defined', () => {
    expect(Object.keys(FILE_WEIGHTS)).toHaveLength(7);
  });

  it('should have leadership_assessment_dec_2025 as primary (60%)', () => {
    expect(FILE_WEIGHTS['leadership_assessment_dec_2025']).toBe(60);
  });

  it('should sum to 100%', () => {
    const total = Object.values(FILE_WEIGHTS).reduce((sum, w) => sum + w, 0);
    expect(total).toBe(100);
  });
});

describe('QUALITATIVE_SCHEMAS', () => {
  it('should include station_checkin and leadership_analysis_2025', () => {
    expect(QUALITATIVE_SCHEMAS).toContain('station_checkin');
    expect(QUALITATIVE_SCHEMAS).toContain('leadership_analysis_2025');
  });

  it('should have exactly 2 qualitative schemas', () => {
    expect(QUALITATIVE_SCHEMAS).toHaveLength(2);
  });
});

// ===================================================================
// SCORE THRESHOLDS TESTS
// ===================================================================

describe('SCORE_THRESHOLDS', () => {
  it('should have 5 tiers', () => {
    expect(Object.keys(SCORE_THRESHOLDS)).toHaveLength(5);
  });

  it('should have correct Arabic labels', () => {
    expect(SCORE_THRESHOLDS.PRIDE.labelAr).toBe('فخر');
    expect(SCORE_THRESHOLDS.GREEN.labelAr).toBe('خضر');
    expect(SCORE_THRESHOLDS.YELLOW.labelAr).toBe('صفر');
    expect(SCORE_THRESHOLDS.RED.labelAr).toBe('حمر');
    expect(SCORE_THRESHOLDS.DANGER.labelAr).toBe('خطر');
  });

  it('should have correct threshold ranges', () => {
    expect(SCORE_THRESHOLDS.PRIDE.min).toBe(92);
    expect(SCORE_THRESHOLDS.GREEN.min).toBe(83);
    expect(SCORE_THRESHOLDS.YELLOW.min).toBe(74);
    expect(SCORE_THRESHOLDS.RED.min).toBe(64);
    expect(SCORE_THRESHOLDS.DANGER.min).toBe(0);
  });
});

describe('getScoreStatus', () => {
  it('should return PRIDE for scores 92-100', () => {
    expect(getScoreStatus(92).labelAr).toBe('فخر');
    expect(getScoreStatus(100).labelAr).toBe('فخر');
  });

  it('should return GREEN for scores 83-91', () => {
    expect(getScoreStatus(83).labelAr).toBe('خضر');
    expect(getScoreStatus(91).labelAr).toBe('خضر');
  });

  it('should return YELLOW for scores 74-82', () => {
    expect(getScoreStatus(74).labelAr).toBe('صفر');
    expect(getScoreStatus(82).labelAr).toBe('صفر');
  });

  it('should return RED for scores 64-73', () => {
    expect(getScoreStatus(64).labelAr).toBe('حمر');
    expect(getScoreStatus(73).labelAr).toBe('حمر');
  });

  it('should return DANGER for scores 0-63', () => {
    expect(getScoreStatus(0).labelAr).toBe('خطر');
    expect(getScoreStatus(63).labelAr).toBe('خطر');
  });
});

// ===================================================================
// API CONFIG TESTS
// ===================================================================

describe('API_CONFIG', () => {
  it('should have correct URL', () => {
    expect(API_CONFIG.URL).toBe('https://openrouter.ai/api/v1/chat/completions');
  });

  it('should have correct model', () => {
    expect(API_CONFIG.MODEL).toBe('openai/gpt-4o-mini');
  });

  it('should have 2-minute timeout', () => {
    expect(API_CONFIG.TIMEOUT).toBe(120000);
  });

  it('should have max tokens for each report type', () => {
    expect(API_CONFIG.MAX_TOKENS.STANDARD).toBe(8192);
    expect(API_CONFIG.MAX_TOKENS.EXTENDED).toBe(16000);
    expect(API_CONFIG.MAX_TOKENS.GIGANTIC).toBe(24000);
  });
});

// ===================================================================
// BATCH CONFIG TESTS
// ===================================================================

describe('BATCH_CONFIG', () => {
  it('should have max 3 concurrent requests', () => {
    expect(BATCH_CONFIG.maxConcurrent).toBe(3);
  });

  it('should have 4 retry attempts', () => {
    expect(BATCH_CONFIG.maxRetries).toBe(4);
  });

  it('should have exponential backoff delays', () => {
    expect(BATCH_CONFIG.retryDelays).toEqual([1000, 2000, 3000, 4000]);
  });
});

// ===================================================================
// FIELD LIMITS TESTS
// ===================================================================

describe('FIELD_LIMITS', () => {
  it('should have header limits', () => {
    expect(FIELD_LIMITS.header.employeeName.max).toBe(30);
    expect(FIELD_LIMITS.header.executiveSummary.max).toBe(445);
  });

  it('should have strength/weakness limits', () => {
    expect(FIELD_LIMITS.strengths.title.min).toBe(37);
    expect(FIELD_LIMITS.strengths.title.max).toBe(39);
    expect(FIELD_LIMITS.strengths.description.min).toBe(120);
    expect(FIELD_LIMITS.strengths.description.max).toBe(175);
  });

  it('should have core metric bullet limits', () => {
    expect(FIELD_LIMITS.coreMetrics.bulletPoint.min).toBe(80);
    expect(FIELD_LIMITS.coreMetrics.bulletPoint.max).toBe(83);
  });

  it('should have team voice word limits', () => {
    expect(FIELD_LIMITS.teamVoice.content.words.min).toBe(25);
    expect(FIELD_LIMITS.teamVoice.content.words.max).toBe(27);
  });
});

// ===================================================================
// ITEM COUNTS TESTS
// ===================================================================

describe('ITEM_COUNTS', () => {
  it('should have correct STANDARD counts', () => {
    expect(ITEM_COUNTS.STANDARD.strengths).toBe(3);
    expect(ITEM_COUNTS.STANDARD.weaknesses).toBe(3);
    expect(ITEM_COUNTS.STANDARD.teamVoice).toBe(4);
  });

  it('should have correct EXTENDED counts', () => {
    expect(ITEM_COUNTS.EXTENDED.strengths).toBe(6);
    expect(ITEM_COUNTS.EXTENDED.weaknesses).toBe(6);
    expect(ITEM_COUNTS.EXTENDED.teamVoice).toBe(5);
  });

  it('should have correct GIGANTIC counts', () => {
    expect(ITEM_COUNTS.GIGANTIC.strengths).toBe(9);
    expect(ITEM_COUNTS.GIGANTIC.weaknesses).toBe(9);
    expect(ITEM_COUNTS.GIGANTIC.teamVoice).toBe(12);
  });
});

// ===================================================================
// PERSONALITY TYPES TESTS
// ===================================================================

describe('PERSONALITY_TYPES', () => {
  it('should have 16 MBTI types', () => {
    expect(PERSONALITY_TYPES.MBTI).toHaveLength(16);
    expect(PERSONALITY_TYPES.MBTI).toContain('INTJ');
    expect(PERSONALITY_TYPES.MBTI).toContain('ENFP');
  });

  it('should have 9 Enneagram types', () => {
    expect(PERSONALITY_TYPES.ENNEAGRAM).toHaveLength(9);
    expect(PERSONALITY_TYPES.ENNEAGRAM).toContain('Type 1');
    expect(PERSONALITY_TYPES.ENNEAGRAM).toContain('Type 9');
  });

  it('should have DISC types', () => {
    expect(PERSONALITY_TYPES.DISC).toContain('High D');
    expect(PERSONALITY_TYPES.DISC).toContain('High I');
    expect(PERSONALITY_TYPES.DISC).toContain('High S');
    expect(PERSONALITY_TYPES.DISC).toContain('High C');
  });

  it('should have 5 Big Five types', () => {
    expect(PERSONALITY_TYPES.BIG_FIVE).toHaveLength(5);
    expect(PERSONALITY_TYPES.BIG_FIVE).toContain('High Openness');
    expect(PERSONALITY_TYPES.BIG_FIVE).toContain('High Conscientiousness');
  });
});

// ===================================================================
// LOG CONFIG TESTS
// ===================================================================

describe('LOG_CONFIG', () => {
  it('should have max history of 500', () => {
    expect(LOG_CONFIG.MAX_HISTORY).toBe(500);
  });

  it('should have 4 log levels', () => {
    expect(Object.keys(LOG_CONFIG.LEVELS)).toHaveLength(4);
    expect(LOG_CONFIG.LEVELS.DEBUG).toBe(0);
    expect(LOG_CONFIG.LEVELS.ERROR).toBe(3);
  });

  it('should default to DEBUG level', () => {
    expect(LOG_CONFIG.DEFAULT_LEVEL).toBe('DEBUG');
  });
});
