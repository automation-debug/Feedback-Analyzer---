/**
 * Leadership Report Data Schema
 * This file defines the complete structure for generating leadership scorecards
 */

/**
 * @typedef {Object} HeaderInfo
 * @property {string} employeeName - Name of the employee being evaluated
 * @property {string} jobTitle - Employee's job title/position
 * @property {number} reviewerCount - Number of people who provided feedback
 * @property {string} date - Report generation date
 * @property {string} executiveSummary - Brief summary of key findings
 */

/**
 * @typedef {Object} LeadershipPathMetric
 * @property {number} score - Overall leadership score (0-100)
 * @property {string} statusLabel - e.g., "Critical Risk", "Caution", "Stable", "Strong", "Excellent"
 * @property {string} statusLabelAr - Arabic version of status label
 * @property {string} description - Brief description of the current state
 */

/**
 * @typedef {Object} ManagerMessage
 * @property {string} summary - Blunt, honest paragraph about the leader's trade-offs
 * @property {Array<{title: string, description: string}>} containmentStrategy - 3 actionable steps
 * @property {Array<{title: string, description: string}>} redLines - 3 non-negotiable behaviors
 * @property {string} fitRecommendation - Where they fit best in the org
 * @property {string} idealTeamRecommendation - What type of subordinates they should lead
 */

/**
 * @typedef {Object} CoreMetric
 * @property {string} id - Unique identifier (clarity, efficiency, safety, empowerment)
 * @property {string} nameAr - Arabic name for the metric
 * @property {string} nameEn - English name for the metric
 * @property {number} score - Percentage score (0-100)
 * @property {string} rating - Rating label (Excellent, Very Good, Average, Low, Critical)
 * @property {string} ratingAr - Arabic rating label
 * @property {string} color - Color code based on score
 * @property {Array<string>} bulletPoints - 2 bullet points explaining the score
 */

/**
 * @typedef {Object} PersonalityAssessment
 * @property {string} framework - Name of the framework (16 Personalities, DiSC, Enneagram, Big Five)
 * @property {string} typeName - The specific type (e.g., "INTJ (The Architect)")
 * @property {string} typeNameAr - Arabic description/name
 * @property {string} link - Valid URL to type definition
 * @property {string} badgeColor - Color for the type badge
 * @property {Array<string>} strengths - 3 strength bullet points
 * @property {Array<string>} weaknesses - 3 weakness bullet points
 */

/**
 * @typedef {Object} StrengthWeakness
 * @property {string} title - Title of the strength/weakness
 * @property {string} description - Detailed description
 * @property {string} icon - Icon name from lucide-react
 */

/**
 * @typedef {Object} EmployeeFeedback
 * @property {string} theme - Theme name (Trust, Meetings, Environment, Vision)
 * @property {string} themeAr - Arabic theme name
 * @property {'negative'|'mild'|'positive'} sentiment - Feedback sentiment
 * @property {string} quote - Synthesized quote representing team feedback
 */

/**
 * @typedef {Object} RoadmapAction
 * @property {string} title - Action title
 * @property {string} priority - 'critical' | 'urgent' | 'continuous'
 * @property {string} priorityAr - Arabic priority label
 * @property {string} icon - Icon name
 * @property {string} color - Color theme
 * @property {Array<string>} checklist - 3 checklist items
 */

/**
 * @typedef {Object} DevelopmentResource
 * @property {string} title - Resource title
 * @property {string} author - Author or source
 * @property {'book'|'article'|'podcast'|'video'} type - Resource type
 * @property {string} typeAr - Arabic type label
 * @property {string} link - Valid URL to resource
 */

/**
 * @typedef {Object} DevelopmentPlan
 * @property {string} categoryId - Category identifier
 * @property {string} categoryTitle - Category title in Arabic
 * @property {string} icon - Icon name
 * @property {string} color - Color theme
 * @property {Array<DevelopmentResource>} resources - 5 resources per category
 */

/**
 * @typedef {Object} LeadershipReport
 * @property {HeaderInfo} header - Header and meta information
 * @property {LeadershipPathMetric} leadershipPath - Overall leadership score visualization
 * @property {ManagerMessage} managerMessage - Message to direct manager
 * @property {Array<CoreMetric>} coreMetrics - 4 core metric cards
 * @property {Array<PersonalityAssessment>} personalityAnalysis - 4 personality frameworks
 * @property {Array<StrengthWeakness>} strengths - 3-4 key strengths
 * @property {Array<StrengthWeakness>} weaknesses - 3-4 key weaknesses
 * @property {Array<EmployeeFeedback>} employeeFeedback - 4 feedback themes
 * @property {Array<RoadmapAction>} roadmap - 3 roadmap actions
 * @property {Array<DevelopmentPlan>} developmentPlan - 4 development categories
 */

// Color mapping based on scores
export const SCORE_COLORS = {
  excellent: '#53815F',    // 92-100 (فخر)
  good: '#AECF76',         // 83-91 (خضر)
  average: '#EBCB6B',      // 74-82 (صفر)
  below: '#D68A77',        // 64-73 (حمر)
  critical: '#AA392D'      // 0-63 (خطر)
};

// Rating labels mapping
export const RATING_LABELS = {
  excellent: { en: 'Excellent', ar: 'ممتاز' },
  good: { en: 'Very Good', ar: 'جيد جداً' },
  average: { en: 'Average', ar: 'متوسط' },
  below: { en: 'Below Average', ar: 'ضعيف' },
  critical: { en: 'Critical', ar: 'منخفض جداً' }
};

// Status labels for leadership path gauge
export const STATUS_LABELS = {
  excellent: { en: 'Pride', ar: 'فخر' },
  good: { en: 'Green', ar: 'خضر' },
  average: { en: 'Yellow', ar: 'صفر' },
  below: { en: 'Red', ar: 'حمر' },
  critical: { en: 'Danger', ar: 'خطر' }
};

/**
 * Get color based on score
 * Thresholds: 92-100 فخر, 83-91 خضر, 74-82 صفر, 64-73 حمر, 0-63 خطر
 * @param {number} score
 * @returns {string} Color hex code
 */
export function getScoreColor(score) {
  if (score >= 92) return SCORE_COLORS.excellent;
  if (score >= 83) return SCORE_COLORS.good;
  if (score >= 74) return SCORE_COLORS.average;
  if (score >= 64) return SCORE_COLORS.below;
  return SCORE_COLORS.critical;
}

/**
 * Get rating based on score
 * @param {number} score
 * @returns {{en: string, ar: string}} Rating labels
 */
export function getScoreRating(score) {
  if (score >= 92) return RATING_LABELS.excellent;
  if (score >= 83) return RATING_LABELS.good;
  if (score >= 74) return RATING_LABELS.average;
  if (score >= 64) return RATING_LABELS.below;
  return RATING_LABELS.critical;
}

/**
 * Get status label based on score
 * Thresholds: 92-100 فخر, 83-91 خضر, 74-82 صفر, 64-73 حمر, 0-63 خطر
 * @param {number} score
 * @returns {{en: string, ar: string}} Status labels
 */
export function getStatusLabel(score) {
  if (score >= 92) return STATUS_LABELS.excellent;
  if (score >= 83) return STATUS_LABELS.good;
  if (score >= 74) return STATUS_LABELS.average;
  if (score >= 64) return STATUS_LABELS.below;
  return STATUS_LABELS.critical;
}

/**
 * Empty report template for initialization
 * @returns {LeadershipReport}
 */
export function createEmptyReport() {
  return {
    header: {
      employeeName: '',
      jobTitle: '',
      reviewerCount: 0,
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      executiveSummary: ''
    },
    leadershipPath: {
      score: 50,
      statusLabel: 'Stable',
      statusLabelAr: 'مستقر',
      description: ''
    },
    managerMessage: {
      summary: '',
      containmentStrategy: [],
      redLines: [],
      fitRecommendation: '',
      idealTeamRecommendation: ''
    },
    coreMetrics: [
      { id: 'clarity', nameAr: 'الوضوح والهيكلة', nameEn: 'Clarity & Structure', score: 0, rating: '', ratingAr: '', color: '', bulletPoints: [] },
      { id: 'efficiency', nameAr: 'الكفاءة التشغيلية', nameEn: 'Operational Efficiency', score: 0, rating: '', ratingAr: '', color: '', bulletPoints: [] },
      { id: 'safety', nameAr: 'الأمان النفسي', nameEn: 'Psychological Safety', score: 0, rating: '', ratingAr: '', color: '', bulletPoints: [] },
      { id: 'empowerment', nameAr: 'تمكين الفريق', nameEn: 'Team Empowerment', score: 0, rating: '', ratingAr: '', color: '', bulletPoints: [] }
    ],
    personalityAnalysis: [],
    strengths: [],
    weaknesses: [],
    employeeFeedback: [],
    roadmap: [],
    developmentPlan: []
  };
}

// Section identifiers for editing
export const REPORT_SECTIONS = {
  HEADER: 'header',
  LEADERSHIP_PATH: 'leadershipPath',
  MANAGER_MESSAGE: 'managerMessage',
  CORE_METRICS: 'coreMetrics',
  PERSONALITY: 'personalityAnalysis',
  STRENGTHS: 'strengths',
  WEAKNESSES: 'weaknesses',
  FEEDBACK: 'employeeFeedback',
  ROADMAP: 'roadmap',
  DEVELOPMENT: 'developmentPlan'
};

export default {
  SCORE_COLORS,
  RATING_LABELS,
  STATUS_LABELS,
  getScoreColor,
  getScoreRating,
  getStatusLabel,
  createEmptyReport,
  REPORT_SECTIONS
};
