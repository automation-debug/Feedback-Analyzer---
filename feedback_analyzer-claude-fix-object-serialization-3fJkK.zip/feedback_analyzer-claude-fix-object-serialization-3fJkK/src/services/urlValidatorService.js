/**
 * URL Validator Service
 * Validates resource URLs and replaces broken ones via Gemini API
 * Designed for post-generation validation with parallel processing
 */

import { createLogger } from '../utils/logger';

const logger = createLogger('URLValidator');

// Cache for validated URLs to avoid redundant checks
const validatedUrlCache = new Map();
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

// Configuration
const CONFIG = {
  maxRetries: 3,
  parallelBatchSize: 5,
  requestTimeout: 10000, // 10 seconds
  retryDelay: 1000, // 1 second between retries
};

// URL patterns for known platforms
const URL_PATTERNS = {
  amazon: {
    regex: /amazon\.com.*\/(?:dp|product|gp\/product)\/([A-Z0-9]{10})/i,
    validIdLength: 10,
    searchFallback: (title) => `https://www.amazon.com/s?k=${encodeURIComponent(title)}`,
  },
  youtube: {
    regex: /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    validIdLength: 11,
    searchFallback: (title) => `https://www.youtube.com/results?search_query=${encodeURIComponent(title)}`,
  },
  coursera: {
    regex: /coursera\.org\/learn\/([a-z0-9-]+)/i,
    searchFallback: (title) => `https://www.coursera.org/search?query=${encodeURIComponent(title)}`,
  },
  linkedin: {
    regex: /linkedin\.com\/learning\/([a-z0-9-]+)/i,
    searchFallback: (title) => `https://www.linkedin.com/learning/search?keywords=${encodeURIComponent(title)}`,
  },
  goodreads: {
    regex: /goodreads\.com\/book\/show\/(\d+)/,
    searchFallback: (title) => `https://www.goodreads.com/search?q=${encodeURIComponent(title)}`,
  },
};

/**
 * Validation result structure
 * @typedef {Object} ValidationResult
 * @property {string} originalUrl - The original URL
 * @property {string} validatedUrl - The validated/replaced URL
 * @property {boolean} isValid - Whether the URL is valid
 * @property {string} status - 'valid', 'replaced', 'fallback', 'failed'
 * @property {string|null} error - Error message if any
 * @property {number} retryCount - Number of retries attempted
 */

/**
 * Check if URL is in cache and still valid
 * @param {string} url - URL to check
 * @returns {ValidationResult|null}
 */
function checkCache(url) {
  const cached = validatedUrlCache.get(url);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    logger.debug('Cache hit for URL', { url });
    return cached.result;
  }
  return null;
}

/**
 * Add URL to cache
 * @param {string} url - Original URL
 * @param {ValidationResult} result - Validation result
 */
function addToCache(url, result) {
  validatedUrlCache.set(url, {
    result,
    timestamp: Date.now(),
  });
}

/**
 * Validate URL pattern without HTTP request
 * @param {string} url - URL to validate
 * @returns {{isValid: boolean, platform: string|null, id: string|null}}
 */
export function validateUrlPattern(url) {
  if (!url || typeof url !== 'string') {
    return { isValid: false, platform: null, id: null, error: 'Invalid URL format' };
  }

  // Basic URL format check
  try {
    new URL(url);
  } catch {
    return { isValid: false, platform: null, id: null, error: 'Malformed URL' };
  }

  // Check against known patterns
  for (const [platform, config] of Object.entries(URL_PATTERNS)) {
    const match = url.match(config.regex);
    if (match) {
      const id = match[1];
      // Validate ID length if specified
      if (config.validIdLength && id.length !== config.validIdLength) {
        return { isValid: false, platform, id, error: `Invalid ${platform} ID length` };
      }
      return { isValid: true, platform, id, error: null };
    }
  }

  // Unknown platform - consider valid if it's a proper URL
  return { isValid: true, platform: 'unknown', id: null, error: null };
}

/**
 * Validate URL via server-side API route
 * @param {string} url - URL to validate
 * @returns {Promise<{isValid: boolean, status: number, error: string|null}>}
 */
async function validateUrlViaApi(url) {
  try {
    logger.debug('Validating URL via API', { url });

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), CONFIG.requestTimeout);

    const response = await fetch('/api/validate-url', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      logger.warn('API validation failed', { url, status: response.status, error: errorData });
      return { isValid: false, status: response.status, error: errorData.error || 'API error' };
    }

    const result = await response.json();
    logger.debug('API validation result', { url, result });
    return result;
  } catch (error) {
    if (error.name === 'AbortError') {
      logger.warn('URL validation timeout', { url });
      return { isValid: false, status: 0, error: 'Request timeout' };
    }
    logger.error('URL validation error', { url, error: error.message });
    return { isValid: false, status: 0, error: error.message };
  }
}

/**
 * Request Gemini to provide a replacement URL
 * @param {string} originalUrl - The broken URL
 * @param {string} resourceTitle - Title of the resource
 * @param {string} category - Category context (e.g., "بناء الثقة")
 * @param {string} apiKey - Gemini API key
 * @returns {Promise<string|null>} - New URL or null
 */
async function requestReplacementUrl(originalUrl, resourceTitle, category, apiKey) {
  logger.info('Requesting replacement URL from Gemini', { originalUrl, resourceTitle, category });

  const prompt = `You are helping fix a broken resource URL in a leadership development plan.

BROKEN URL: ${originalUrl}
RESOURCE TITLE: ${resourceTitle}
CATEGORY: ${category}

Please provide a SINGLE working, verified URL for this resource or a similar high-quality alternative.

Requirements:
1. The URL must be from a reputable source: Amazon, Goodreads, YouTube, Coursera, LinkedIn Learning, or official publisher sites
2. The URL must be a direct link to the resource (not a search page)
3. For books, prefer Amazon product pages with valid ASINs
4. For videos, prefer YouTube with valid video IDs
5. For courses, prefer Coursera or LinkedIn Learning direct course links

RESPOND WITH ONLY THE URL - no explanation, no markdown, just the raw URL.`;

  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer': window.location.origin,
        'X-Title': 'Leadership Feedback Analyzer',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.0-flash-001',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 200,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      logger.error('Gemini API error for URL replacement', { status: response.status });
      return null;
    }

    const data = await response.json();
    const newUrl = data.choices?.[0]?.message?.content?.trim();

    if (newUrl && newUrl.startsWith('http')) {
      logger.info('Received replacement URL', { originalUrl, newUrl });
      return newUrl;
    }

    logger.warn('Invalid replacement URL received', { originalUrl, received: newUrl });
    return null;
  } catch (error) {
    logger.error('Error requesting replacement URL', { error: error.message });
    return null;
  }
}

/**
 * Get fallback search URL for a platform
 * @param {string} url - Original URL
 * @param {string} title - Resource title
 * @returns {string} - Search URL
 */
function getFallbackUrl(url, title) {
  for (const [platform, config] of Object.entries(URL_PATTERNS)) {
    if (url.includes(platform) || url.includes(platform.replace('.com', ''))) {
      return config.searchFallback(title);
    }
  }
  // Default to Google search
  return `https://www.google.com/search?q=${encodeURIComponent(title)}`;
}

/**
 * Validate a single URL with retry logic
 * @param {Object} resource - Resource object with title and link
 * @param {string} category - Category context
 * @param {string} apiKey - API key for Gemini
 * @returns {Promise<ValidationResult>}
 */
async function validateSingleUrl(resource, category, apiKey) {
  const { title, link: originalUrl } = resource;
  let currentUrl = originalUrl;
  let retryCount = 0;

  logger.info('Starting URL validation', { title, originalUrl });

  // Check cache first
  const cached = checkCache(originalUrl);
  if (cached) {
    return cached;
  }

  // Step 1: Pattern validation
  const patternResult = validateUrlPattern(currentUrl);
  if (!patternResult.isValid) {
    logger.warn('URL failed pattern validation', { url: currentUrl, error: patternResult.error });
    // Skip to replacement
    currentUrl = null;
  }

  // Step 2: Server-side validation (if pattern is valid)
  if (currentUrl) {
    const apiResult = await validateUrlViaApi(currentUrl);
    if (apiResult.isValid) {
      const result = {
        originalUrl,
        validatedUrl: currentUrl,
        isValid: true,
        status: 'valid',
        error: null,
        retryCount: 0,
      };
      addToCache(originalUrl, result);
      logger.info('URL validated successfully', { url: currentUrl });
      return result;
    }
    logger.warn('URL failed API validation', { url: currentUrl, error: apiResult.error });
  }

  // Step 3: Request replacement URLs with retries
  while (retryCount < CONFIG.maxRetries) {
    retryCount++;
    logger.info(`Attempting URL replacement (retry ${retryCount}/${CONFIG.maxRetries})`, { originalUrl });

    const newUrl = await requestReplacementUrl(originalUrl, title, category, apiKey);

    if (newUrl) {
      // Validate the new URL
      const newPatternResult = validateUrlPattern(newUrl);
      if (newPatternResult.isValid) {
        const newApiResult = await validateUrlViaApi(newUrl);
        if (newApiResult.isValid) {
          const result = {
            originalUrl,
            validatedUrl: newUrl,
            isValid: true,
            status: 'replaced',
            error: null,
            retryCount,
          };
          addToCache(originalUrl, result);
          logger.info('URL replaced successfully', { originalUrl, newUrl, retryCount });
          return result;
        }
      }
    }

    // Wait before retry
    if (retryCount < CONFIG.maxRetries) {
      await new Promise(resolve => setTimeout(resolve, CONFIG.retryDelay));
    }
  }

  // Step 4: Use fallback search URL
  const fallbackUrl = getFallbackUrl(originalUrl, title);
  const result = {
    originalUrl,
    validatedUrl: fallbackUrl,
    isValid: true,
    status: 'fallback',
    error: 'All replacement attempts failed, using search fallback',
    retryCount,
  };
  addToCache(originalUrl, result);
  logger.warn('Using fallback URL', { originalUrl, fallbackUrl });
  return result;
}

/**
 * Process URLs in parallel batches
 * @param {Array} items - Array of {resource, category} objects
 * @param {string} apiKey - API key
 * @returns {Promise<Array<ValidationResult>>}
 */
async function processInParallel(items, apiKey) {
  const results = [];

  for (let i = 0; i < items.length; i += CONFIG.parallelBatchSize) {
    const batch = items.slice(i, i + CONFIG.parallelBatchSize);
    logger.info(`Processing batch ${Math.floor(i / CONFIG.parallelBatchSize) + 1}`, {
      batchSize: batch.length,
      totalProcessed: i,
      totalItems: items.length,
    });

    const batchResults = await Promise.all(
      batch.map(({ resource, category }) => validateSingleUrl(resource, category, apiKey))
    );

    results.push(...batchResults);
  }

  return results;
}

/**
 * Validate all URLs in a report's development plan
 * @param {Object} report - Full report object
 * @param {string} apiKey - API key for Gemini
 * @param {Function} onProgress - Progress callback (processed, total, current)
 * @returns {Promise<Object>} - Updated report with validated URLs
 */
export async function validateReportUrls(report, apiKey, onProgress = null) {
  if (!report?.developmentPlan || !Array.isArray(report.developmentPlan)) {
    logger.warn('No development plan found in report');
    return report;
  }

  logger.info('Starting report URL validation', {
    categories: report.developmentPlan.length,
  });

  const startTime = Date.now();

  // Collect all URLs with their context
  const urlItems = [];
  report.developmentPlan.forEach((category) => {
    if (category.resources && Array.isArray(category.resources)) {
      category.resources.forEach((resource) => {
        if (resource.link) {
          urlItems.push({
            resource,
            category: category.categoryTitle,
          });
        }
      });
    }
  });

  logger.info('Collected URLs for validation', { totalUrls: urlItems.length });

  if (urlItems.length === 0) {
    return report;
  }

  // Create a map to track progress
  let processed = 0;
  const total = urlItems.length;

  // Process with progress tracking
  const results = [];
  for (let i = 0; i < urlItems.length; i += CONFIG.parallelBatchSize) {
    const batch = urlItems.slice(i, i + CONFIG.parallelBatchSize);

    const batchResults = await Promise.all(
      batch.map(async ({ resource, category }) => {
        const result = await validateSingleUrl(resource, category, apiKey);
        processed++;
        if (onProgress) {
          onProgress(processed, total, resource.title);
        }
        return { resource, result };
      })
    );

    results.push(...batchResults);
  }

  // Update report with validated URLs
  const updatedReport = JSON.parse(JSON.stringify(report)); // Deep clone

  results.forEach(({ resource, result }) => {
    // Find and update the resource in the cloned report
    updatedReport.developmentPlan.forEach((category) => {
      if (category.resources) {
        category.resources.forEach((res) => {
          if (res.link === resource.link) {
            res.link = result.validatedUrl;
            res._validationStatus = result.status;
            res._originalUrl = result.originalUrl;
          }
        });
      }
    });
  });

  const duration = Date.now() - startTime;
  const stats = {
    total: results.length,
    valid: results.filter(r => r.result.status === 'valid').length,
    replaced: results.filter(r => r.result.status === 'replaced').length,
    fallback: results.filter(r => r.result.status === 'fallback').length,
    failed: results.filter(r => r.result.status === 'failed').length,
    duration,
  };

  logger.info('URL validation complete', stats);

  // Add validation metadata to report
  updatedReport._urlValidation = {
    validated: true,
    timestamp: new Date().toISOString(),
    stats,
  };

  return updatedReport;
}

/**
 * Validate URLs for multiple reports (batch processing)
 * @param {Array<Object>} reports - Array of report objects
 * @param {string} apiKey - API key
 * @param {Function} onProgress - Progress callback (reportIndex, totalReports, urlProgress)
 * @returns {Promise<Array<Object>>} - Updated reports
 */
export async function validateBatchReportUrls(reports, apiKey, onProgress = null) {
  logger.info('Starting batch URL validation', { totalReports: reports.length });

  const validatedReports = [];

  for (let i = 0; i < reports.length; i++) {
    const report = reports[i];
    logger.info(`Validating report ${i + 1}/${reports.length}`, {
      candidateName: report.header?.employeeName,
    });

    const validatedReport = await validateReportUrls(
      report,
      apiKey,
      (processed, total, current) => {
        if (onProgress) {
          onProgress(i, reports.length, { processed, total, current });
        }
      }
    );

    validatedReports.push(validatedReport);
  }

  logger.info('Batch URL validation complete', { totalReports: validatedReports.length });
  return validatedReports;
}

/**
 * Clear the URL validation cache
 */
export function clearUrlCache() {
  validatedUrlCache.clear();
  logger.info('URL validation cache cleared');
}

/**
 * Get cache statistics
 * @returns {Object} - Cache stats
 */
export function getCacheStats() {
  return {
    size: validatedUrlCache.size,
    entries: Array.from(validatedUrlCache.entries()).map(([url, data]) => ({
      url,
      status: data.result.status,
      age: Date.now() - data.timestamp,
    })),
  };
}

export default {
  validateUrlPattern,
  validateReportUrls,
  validateBatchReportUrls,
  clearUrlCache,
  getCacheStats,
};
