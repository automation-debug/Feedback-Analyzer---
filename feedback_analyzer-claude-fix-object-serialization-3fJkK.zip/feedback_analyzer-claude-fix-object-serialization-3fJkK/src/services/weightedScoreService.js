/**
 * ===================================================================
 * WEIGHTED SCORE CALCULATION SERVICE
 * ===================================================================
 *
 * Handles deterministic score calculation from multiple assessment sources.
 * All scores are calculated client-side (no AI randomness) for consistency.
 *
 * @module services/weightedScoreService
 *
 * SCORING SYSTEM:
 * - 7 assessment sources with different weights (total = 100%)
 * - Primary source: leadership_assessment_dec_2025 (60% weight)
 * - Some sources are qualitative-only (no numeric scores)
 *
 * MAIN FUNCTIONS:
 * - calculateCandidateScores(): Full score calculation for a candidate
 * - normalizeScore(): Convert any scale to 0-100
 * - calculateAdjustedWeights(): Rebalance weights when sources are missing
 * - calculateWeightedScore(): Compute weighted average
 * - calculateCoreMetricScores(): Get scores per metric (clarity, efficiency, etc.)
 *
 * CONFIGURATION:
 * - FILE_WEIGHTS: Imported from '../config/constants/' (single source of truth)
 * - QUALITATIVE_SCHEMAS: Sources excluded from numeric scoring
 */

import FILE_SCHEMAS from '../config/fileSchemas.js';
import { createLogger } from '../utils/logger.js';

// Import centralized configuration (single source of truth)
import {
  FILE_WEIGHTS as WEIGHTS,
  QUALITATIVE_SCHEMAS as QUAL_SCHEMAS
} from '../config/constants/index.js';

const logger = createLogger('WeightedScoreService');

// Re-export for backward compatibility with existing imports
export const FILE_WEIGHTS = WEIGHTS;

// Re-export qualitative schemas for internal use
const QUALITATIVE_SCHEMAS = QUAL_SCHEMAS;

/**
 * Normalize a score to 0-100 scale
 * @param {number} score - Raw score
 * @param {number} min - Minimum possible score
 * @param {number} max - Maximum possible score
 * @returns {number} Normalized score (0-100)
 */
export function normalizeScore(score, min, max) {
  if (typeof score !== 'number' || isNaN(score)) return null;
  if (max === min) return 50; // Avoid division by zero
  return Math.round(((score - min) / (max - min)) * 100);
}

/**
 * Calculate average of numeric values, ignoring non-numeric
 * @param {Array} values - Array of values
 * @returns {number|null} Average or null if no valid values
 */
export function calculateAverage(values) {
  const numericValues = values.filter(v => typeof v === 'number' && !isNaN(v));
  if (numericValues.length === 0) return null;
  return numericValues.reduce((sum, v) => sum + v, 0) / numericValues.length;
}

/**
 * Extract score from File 1 (360° Leadership Feedback)
 * @param {Array} feedbackRows - Rows of feedback for this candidate
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted scores and metadata
 */
function extractScoresFile1(feedbackRows, schema) {
  if (!feedbackRows || !Array.isArray(feedbackRows) || feedbackRows.length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  const categoryScores = {};
  const allScores = [];

  // Process each category
  Object.entries(schema.categories).forEach(([categoryName, categoryConfig]) => {
    const categoryValues = [];

    feedbackRows.forEach(row => {
      categoryConfig.numericColumns.forEach(col => {
        const value = parseFloat(row[col]);
        if (!isNaN(value)) {
          categoryValues.push(value);
          allScores.push(value);
        }
      });
    });

    if (categoryValues.length > 0) {
      categoryScores[categoryName] = calculateAverage(categoryValues);
    }
  });

  // Also check for pre-calculated average column
  let overallAvg = null;
  if (schema.averageColumn) {
    const avgValues = feedbackRows
      .map(row => parseFloat(row[schema.averageColumn]))
      .filter(v => !isNaN(v));
    if (avgValues.length > 0) {
      overallAvg = calculateAverage(avgValues);
    }
  }

  // Fallback to calculated average
  if (overallAvg === null && allScores.length > 0) {
    overallAvg = calculateAverage(allScores);
  }

  // Normalize to 0-100
  const scoreRange = schema.scoreRange || { min: 1, max: 10 };
  const normalizedScore = overallAvg !== null
    ? normalizeScore(overallAvg, scoreRange.min, scoreRange.max)
    : null;

  return {
    available: normalizedScore !== null,
    score: normalizedScore,
    rawScore: overallAvg,
    categoryScores,
    reviewerCount: feedbackRows.length,
    scoreRange
  };
}

/**
 * Extract score from File 3 (Quarterly Review) - Track-based
 * @param {Array} feedbackRows - Rows of feedback for this candidate
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted scores and metadata
 */
function extractScoresFile3(feedbackRows, schema) {
  if (!feedbackRows || !Array.isArray(feedbackRows) || feedbackRows.length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  const trackScoring = schema.trackScoring || {};
  const trackScores = [];
  const unmatchedValues = [];

  // Helper to normalize track value (strip emojis and extra whitespace)
  const normalizeTrackValue = (value) => {
    if (!value) return '';
    // Remove emojis and special characters, keep Arabic text
    return String(value)
      .replace(/[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]|[\u{1F600}-\u{1F64F}]|[\u{1F680}-\u{1F6FF}]/gu, '')
      .trim();
  };

  // Build normalized lookup map for fallback matching
  const normalizedScoring = {};
  Object.entries(trackScoring).forEach(([key, value]) => {
    const normalizedKey = normalizeTrackValue(key);
    normalizedScoring[normalizedKey] = value;
  });

  feedbackRows.forEach(row => {
    const trackField = schema.trackFields?.performance_track;
    if (trackField) {
      const trackValue = row[trackField.column];
      if (trackValue) {
        // Try exact match first
        if (trackScoring[trackValue]) {
          trackScores.push(trackScoring[trackValue].score);
        } else {
          // Fallback: try normalized match (without emojis)
          const normalizedValue = normalizeTrackValue(trackValue);
          if (normalizedScoring[normalizedValue]) {
            trackScores.push(normalizedScoring[normalizedValue].score);
            logger.debug('Track value matched via normalization', {
              original: trackValue,
              normalized: normalizedValue
            });
          } else {
            unmatchedValues.push(trackValue);
          }
        }
      }
    }
  });

  // Log warning if there were unmatched track values
  if (unmatchedValues.length > 0) {
    logger.warn('Unmatched track values in quarterly_review', {
      unmatchedValues,
      expectedValues: Object.keys(trackScoring)
    });
  }

  const avgScore = trackScores.length > 0 ? calculateAverage(trackScores) : null;

  return {
    available: avgScore !== null,
    score: avgScore,
    reviewerCount: feedbackRows.length,
    trackBased: true,
    unmatchedCount: unmatchedValues.length
  };
}

/**
 * Extract score from File 4 (360 New Full) - 1-5 scale
 * @param {Array} feedbackRows - Rows of feedback for this candidate
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted scores and metadata
 */
function extractScoresFile4(feedbackRows, schema) {
  if (!feedbackRows || !Array.isArray(feedbackRows) || feedbackRows.length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  const categoryScores = {};
  const allScores = [];

  Object.entries(schema.categories).forEach(([categoryName, categoryConfig]) => {
    const categoryValues = [];

    feedbackRows.forEach(row => {
      categoryConfig.numericColumns.forEach(col => {
        const value = parseFloat(row[col]);
        if (!isNaN(value)) {
          categoryValues.push(value);
          allScores.push(value);
        }
      });
    });

    if (categoryValues.length > 0) {
      categoryScores[categoryName] = calculateAverage(categoryValues);
    }
  });

  const overallAvg = allScores.length > 0 ? calculateAverage(allScores) : null;
  const scoreRange = schema.scoreRange || { min: 1, max: 5 };
  const normalizedScore = overallAvg !== null
    ? normalizeScore(overallAvg, scoreRange.min, scoreRange.max)
    : null;

  return {
    available: normalizedScore !== null,
    score: normalizedScore,
    rawScore: overallAvg,
    categoryScores,
    reviewerCount: feedbackRows.length,
    scoreRange
  };
}

/**
 * Extract score from File 5 (Periodic Evaluation 2024) - Text-to-score ratings
 * @param {Array} feedbackRows - Rows of feedback for this candidate
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted scores and metadata
 */
function extractScoresFile5(feedbackRows, schema) {
  if (!feedbackRows || !Array.isArray(feedbackRows) || feedbackRows.length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  let generalScores = [];
  let leadershipScores = [];

  feedbackRows.forEach(row => {
    // Extract general assessment scores
    if (schema.generalAssessment) {
      Object.values(schema.generalAssessment).forEach(field => {
        const value = row[field.column] || row[field.altColumn];
        if (value && field.ratings && field.ratings[value]) {
          generalScores.push(field.ratings[value].score);
        }
      });
    }

    // Extract leadership assessment scores
    if (schema.leadershipAssessment) {
      Object.values(schema.leadershipAssessment).forEach(field => {
        const value = row[field.column];
        if (value && field.ratings && field.ratings[value]) {
          leadershipScores.push(field.ratings[value].score);
        }
      });
    }

    // Also check for pre-calculated totals
    const generalTotal = schema.generalResult?.total_score;
    if (generalTotal) {
      const totalValue = parseFloat(row[generalTotal.column] || row[generalTotal.altColumn]);
      if (!isNaN(totalValue)) {
        // Normalize from 80-point scale
        generalScores.push(normalizeScore(totalValue, 0, 80));
      }
    }
  });

  const generalAvg = generalScores.length > 0 ? calculateAverage(generalScores) : null;
  const leadershipAvg = leadershipScores.length > 0 ? calculateAverage(leadershipScores) : null;

  // Combined score (weighted: 80 pts general, 40 pts leadership = 66.7% / 33.3%)
  let combinedScore = null;
  if (generalAvg !== null && leadershipAvg !== null) {
    combinedScore = Math.round((generalAvg * 0.667) + (leadershipAvg * 0.333));
  } else if (generalAvg !== null) {
    combinedScore = generalAvg;
  } else if (leadershipAvg !== null) {
    combinedScore = leadershipAvg;
  }

  return {
    available: combinedScore !== null,
    score: combinedScore,
    generalScore: generalAvg,
    leadershipScore: leadershipAvg,
    reviewerCount: feedbackRows.length
  };
}

/**
 * Extract score from File 7 (December 2025 Assessment) - 1-10 scale
 * @param {Array} feedbackRows - Rows of feedback for this candidate
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted scores and metadata
 */
function extractScoresFile7(feedbackRows, schema) {
  if (!feedbackRows || !Array.isArray(feedbackRows) || feedbackRows.length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  const categoryScores = {};
  const allScores = [];

  // Map our core metrics to the file categories
  const categoryMapping = {
    'الوضوح والأولويات': 'clarity',
    'طريقة العمل': 'efficiency',
    'قيادة الفريق': 'safety',
    'التطوير والدعم': 'empowerment'
  };

  Object.entries(schema.categories).forEach(([categoryName, categoryConfig]) => {
    const categoryValues = [];

    feedbackRows.forEach(row => {
      categoryConfig.numericColumns.forEach(col => {
        const value = parseFloat(row[col]);
        if (!isNaN(value)) {
          categoryValues.push(value);
          allScores.push(value);
        }
      });
    });

    if (categoryValues.length > 0) {
      const avgScore = calculateAverage(categoryValues);
      categoryScores[categoryName] = avgScore;

      // Map to core metric ID
      const metricId = categoryMapping[categoryName];
      if (metricId) {
        categoryScores[metricId] = normalizeScore(avgScore, 1, 10);
      }
    }
  });

  const overallAvg = allScores.length > 0 ? calculateAverage(allScores) : null;
  const normalizedScore = overallAvg !== null ? normalizeScore(overallAvg, 1, 10) : null;

  // Extract text feedback for paraphrasing
  const textFeedback = {
    strengths: [],
    developmentAreas: [],
    hrNotes: []
  };

  feedbackRows.forEach(row => {
    const strengthField = schema.openTextFields?.[0];
    const developmentField = schema.openTextFields?.[1];
    const hrField = schema.openTextFields?.[2];

    if (strengthField && row[strengthField]) {
      textFeedback.strengths.push(row[strengthField]);
    }
    if (developmentField && row[developmentField]) {
      textFeedback.developmentAreas.push(row[developmentField]);
    }
    if (hrField && row[hrField]) {
      textFeedback.hrNotes.push(row[hrField]);
    }

    // Also collect category text feedback
    Object.values(schema.categories).forEach(cat => {
      if (cat.textColumn && row[cat.textColumn]) {
        textFeedback.developmentAreas.push(row[cat.textColumn]);
      }
    });
  });

  return {
    available: normalizedScore !== null,
    score: normalizedScore,
    rawScore: overallAvg,
    categoryScores,
    reviewerCount: feedbackRows.length,
    textFeedback,
    scoreRange: { min: 1, max: 10 }
  };
}

/**
 * Extract qualitative data from File 2 (Station Check-in)
 * @param {Array} feedbackRows - Rows of feedback for this candidate
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted qualitative data
 */
function extractQualitativeFile2(feedbackRows, schema) {
  if (!feedbackRows || !Array.isArray(feedbackRows) || feedbackRows.length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  const qualitativeData = {};

  Object.entries(schema.textFields || {}).forEach(([fieldId, fieldConfig]) => {
    const values = feedbackRows
      .map(row => row[fieldConfig.column])
      .filter(v => v && v.trim());

    if (values.length > 0) {
      qualitativeData[fieldId] = values;
    }
  });

  return {
    available: Object.keys(qualitativeData).length > 0,
    qualitativeData,
    reviewerCount: feedbackRows.length,
    isQualitative: true
  };
}

/**
 * Extract qualitative data from File 6 (Leadership Analysis - Transposed)
 * @param {Object} transposedData - Data for this candidate from transposed format
 * @param {Object} schema - The schema configuration
 * @returns {Object} Extracted qualitative data
 */
function extractQualitativeFile6(transposedData, schema) {
  if (!transposedData || Object.keys(transposedData).length === 0) {
    return { available: false, reviewerCount: 0 };
  }

  const qualitativeData = {};

  Object.entries(schema.rowCategories || {}).forEach(([categoryId, categoryConfig]) => {
    const value = transposedData[categoryConfig.identifier];
    if (value && value.trim()) {
      qualitativeData[categoryId] = value;
    }
  });

  return {
    available: Object.keys(qualitativeData).length > 0,
    qualitativeData,
    reviewerCount: 1, // Transposed format is typically one consolidated entry
    isQualitative: true
  };
}

/**
 * Calculate adjusted weights when some sources are missing
 * @param {Object} availableSources - Object with source availability
 * @returns {Object} Adjusted weights that sum to 100
 */
export function calculateAdjustedWeights(availableSources) {
  let totalAvailableWeight = 0;
  const adjustedWeights = {};

  // Sum up weights of available sources
  Object.entries(FILE_WEIGHTS).forEach(([schemaId, weight]) => {
    if (availableSources[schemaId]) {
      totalAvailableWeight += weight;
    }
  });

  // Calculate adjusted weights (proportional to available)
  if (totalAvailableWeight > 0) {
    Object.entries(FILE_WEIGHTS).forEach(([schemaId, weight]) => {
      if (availableSources[schemaId]) {
        adjustedWeights[schemaId] = Math.round((weight / totalAvailableWeight) * 100 * 10) / 10;
      } else {
        adjustedWeights[schemaId] = 0;
      }
    });
  }

  return {
    adjustedWeights,
    totalAvailableWeight,
    coveragePercentage: totalAvailableWeight
  };
}

/**
 * Calculate weighted overall score from all available sources
 * @param {Object} sourceScores - Scores from each source
 * @param {Object} adjustedWeights - Adjusted weights for each source
 * @returns {number} Weighted overall score (0-100)
 */
export function calculateWeightedScore(sourceScores, adjustedWeights) {
  let weightedSum = 0;
  let totalWeight = 0;

  Object.entries(sourceScores).forEach(([schemaId, scoreData]) => {
    // Skip qualitative-only sources for numeric calculation
    if (QUALITATIVE_SCHEMAS.includes(schemaId)) return;

    if (scoreData.available && scoreData.score !== null && adjustedWeights[schemaId] > 0) {
      weightedSum += scoreData.score * adjustedWeights[schemaId];
      totalWeight += adjustedWeights[schemaId];
    }
  });

  if (totalWeight === 0) return null;
  return Math.round(weightedSum / totalWeight);
}

/**
 * Calculate category-level weighted scores for core metrics
 * @param {Object} sourceScores - Scores from each source
 * @param {Object} adjustedWeights - Adjusted weights for each source
 * @returns {Object} Core metric scores
 */
export function calculateCoreMetricScores(sourceScores, adjustedWeights) {
  // Use File 7 as primary source since it has 60% weight and clear category mapping
  const file7Data = sourceScores['leadership_assessment_dec_2025'];

  if (file7Data?.available && file7Data.categoryScores) {
    return {
      clarity: file7Data.categoryScores.clarity || file7Data.score,
      efficiency: file7Data.categoryScores.efficiency || file7Data.score,
      safety: file7Data.categoryScores.safety || file7Data.score,
      empowerment: file7Data.categoryScores.empowerment || file7Data.score
    };
  }

  // Fallback to overall score for all metrics
  const overallScore = calculateWeightedScore(sourceScores, adjustedWeights);
  return {
    clarity: overallScore,
    efficiency: overallScore,
    safety: overallScore,
    empowerment: overallScore
  };
}

/**
 * Main function to calculate all scores for a candidate
 * @param {string} candidateName - Name of the candidate
 * @param {Object} allFileData - Data from all uploaded files, keyed by schema ID
 * @returns {Object} Complete score calculation result
 */
export function calculateCandidateScores(candidateName, allFileData) {
  const operation = logger.startOperation('calculateCandidateScores', { candidateName });

  // Validate inputs
  if (!FILE_SCHEMAS) {
    const error = 'FILE_SCHEMAS is undefined - configuration error';
    logger.error(error);
    operation.fail(error);
    throw new Error(error);
  }

  if (!allFileData || typeof allFileData !== 'object') {
    const error = 'allFileData is invalid or undefined';
    logger.error(error, { allFileData: typeof allFileData });
    operation.fail(error);
    throw new Error(error);
  }

  logger.debug('Input validation passed', {
    candidateName,
    availableSchemas: Object.keys(allFileData),
    totalSchemas: Object.keys(FILE_SCHEMAS).length
  });

  const sourceScores = {};
  const availableSources = {};
  let totalReviewerCount = 0;
  const missingSources = [];

  // Extract scores from each file type
  Object.entries(FILE_SCHEMAS).forEach(([schemaId, schema]) => {
    if (!schema) {
      logger.warn(`Schema ${schemaId} is undefined, skipping`);
      return;
    }

    const fileData = allFileData[schemaId];
    let result;

    logger.debug(`Processing schema: ${schemaId}`, {
      hasData: !!fileData,
      dataLength: Array.isArray(fileData) ? fileData.length : 0
    });

    try {
      switch (schemaId) {
        case '360_leadership_feedback':
          result = extractScoresFile1(fileData, schema);
          break;
        case 'station_checkin':
          result = extractQualitativeFile2(fileData, schema);
          break;
        case 'quarterly_review':
          result = extractScoresFile3(fileData, schema);
          break;
        case '360_new_full':
          result = extractScoresFile4(fileData, schema);
          break;
        case 'periodic_evaluation_2024':
          result = extractScoresFile5(fileData, schema);
          break;
        case 'leadership_analysis_2025':
          result = extractQualitativeFile6(fileData, schema);
          break;
        case 'leadership_assessment_dec_2025':
          result = extractScoresFile7(fileData, schema);
          break;
        default:
          result = { available: false, reviewerCount: 0 };
      }
    } catch (err) {
      logger.error(`Error extracting scores for ${schemaId}`, { error: err.message });
      result = { available: false, reviewerCount: 0, error: err.message };
    }

    sourceScores[schemaId] = result;
    availableSources[schemaId] = result.available;

    // CRITICAL: Count reviewers regardless of whether scores were extracted
    // The reviewer count is based on how many feedback rows exist, not whether numeric scores matched
    // This ensures extended reports trigger correctly even if column names don't exactly match
    if (result.reviewerCount > 0) {
      totalReviewerCount += result.reviewerCount;
      logger.debug(`Schema ${schemaId} has ${result.reviewerCount} reviewers`, {
        reviewerCount: result.reviewerCount,
        scoresAvailable: result.available,
        normalizedScore: result.score
      });
    }

    if (!result.available) {
      missingSources.push({
        id: schemaId,
        name: schema.name || schemaId,
        weight: FILE_WEIGHTS[schemaId] || 0
      });
    }
  });

  // Calculate adjusted weights
  const { adjustedWeights, coveragePercentage } = calculateAdjustedWeights(availableSources);

  // Calculate overall weighted score
  const overallScore = calculateWeightedScore(sourceScores, adjustedWeights);

  // Calculate core metric scores
  const coreMetricScores = calculateCoreMetricScores(sourceScores, adjustedWeights);

  // Determine status label based on score (5-tier color system)
  // Thresholds: 92-100 فخر, 83-91 خضر, 74-82 صفر, 64-73 حمر, 0-63 خطر
  let statusLabel, statusLabelAr;
  if (overallScore >= 92) {
    statusLabel = 'Pride';
    statusLabelAr = 'فخر';
  } else if (overallScore >= 83) {
    statusLabel = 'Green';
    statusLabelAr = 'خضر';
  } else if (overallScore >= 74) {
    statusLabel = 'Yellow';
    statusLabelAr = 'صفر';
  } else if (overallScore >= 64) {
    statusLabel = 'Red';
    statusLabelAr = 'حمر';
  } else {
    statusLabel = 'Danger';
    statusLabelAr = 'خطر';
  }

  const result = {
    candidateName,
    overallScore,
    statusLabel,
    statusLabelAr,
    coreMetricScores,
    sourceScores,
    availableSources,
    adjustedWeights,
    originalWeights: FILE_WEIGHTS,
    coveragePercentage,
    totalReviewerCount,
    missingSources,
    hasLowCoverage: coveragePercentage < 70,
    timestamp: new Date().toISOString()
  };

  logger.info('Score calculation complete', {
    candidateName,
    overallScore,
    statusLabel,
    coveragePercentage,
    totalReviewerCount,
    missingSourcesCount: missingSources.length
  });

  operation.end({ overallScore, coveragePercentage });
  return result;
}

/**
 * Aggregate text feedback for the prompt (from all sources except File 7)
 * @param {Object} sourceScores - Scores from each source with qualitative data
 * @returns {Object} Aggregated text feedback by source
 */
export function aggregateHistoricalFeedback(sourceScores) {
  const aggregated = {};

  Object.entries(sourceScores).forEach(([schemaId, data]) => {
    // Skip File 7 - handled separately for paraphrasing
    if (schemaId === 'leadership_assessment_dec_2025') return;

    if (data.available) {
      if (data.qualitativeData) {
        aggregated[schemaId] = {
          type: 'qualitative',
          data: data.qualitativeData,
          reviewerCount: data.reviewerCount
        };
      } else if (data.categoryScores) {
        aggregated[schemaId] = {
          type: 'numeric',
          categoryScores: data.categoryScores,
          overallScore: data.score,
          reviewerCount: data.reviewerCount
        };
      }
    }
  });

  return aggregated;
}

/**
 * Get December 2025 feedback for paraphrasing
 * @param {Object} sourceScores - Scores from each source
 * @returns {Object} File 7 text feedback ready for paraphrasing
 */
export function getDecember2025Feedback(sourceScores) {
  const file7Data = sourceScores['leadership_assessment_dec_2025'];

  if (!file7Data?.available || !file7Data.textFeedback) {
    return null;
  }

  return {
    strengths: file7Data.textFeedback.strengths || [],
    developmentAreas: file7Data.textFeedback.developmentAreas || [],
    hrNotes: file7Data.textFeedback.hrNotes || [],
    reviewerCount: file7Data.reviewerCount
  };
}

export default {
  FILE_WEIGHTS,
  calculateCandidateScores,
  calculateAdjustedWeights,
  calculateWeightedScore,
  calculateCoreMetricScores,
  aggregateHistoricalFeedback,
  getDecember2025Feedback,
  normalizeScore,
  calculateAverage
};
