/**
 * Export Service
 * Handles exporting batch and single candidate results to Excel and PDF formats
 */

import * as XLSX from 'xlsx';
import { getPersonalityUrls } from './personalityUrlService';

/**
 * Safely extract a string value from a potentially nested object
 * This handles cases where AI returns {text: "..."} or {value: "..."} instead of plain strings
 * @param {any} value - The value to convert to string
 * @returns {string} The extracted string value
 */
function safeString(value) {
  // Handle null/undefined
  if (value === null || value === undefined) {
    return '';
  }

  // Handle primitive types
  if (typeof value === 'string') {
    return value;
  }
  if (typeof value === 'number' || typeof value === 'boolean') {
    return String(value);
  }

  // Handle objects - try to extract meaningful text
  if (typeof value === 'object') {
    // Check for common text properties
    if (value.text) return String(value.text);
    if (value.value) return String(value.value);
    if (value.content) return String(value.content);
    if (value.title) return String(value.title);
    if (value.name) return String(value.name);
    if (value.description) return String(value.description);

    // For arrays, join the string-converted elements
    if (Array.isArray(value)) {
      return value.map(item => safeString(item)).filter(Boolean).join(' | ');
    }

    // Last resort: return empty string instead of [object Object]
    return '';
  }

  return String(value);
}

/**
 * Convert a single report to the same flattened row format used in batch export
 * This ensures consistency between single and batch exports
 * English column names optimized for Figma template mapping
 * @param {Object} report - Full report object
 * @param {Object} scoreData - Optional score data
 * @returns {Object} Flattened row object
 */
export function convertSingleReportToRow(report, scoreData = null) {
  // Get personality assessment URLs
  const personalityUrls = getPersonalityUrls(report?.personalityAnalysis);

  // Determine if this is an extended/gigantic report - use multiple sources
  const reviewCount = scoreData?.totalReviewerCount
    || report?._metadata?.scoreData?.totalReviewerCount
    || report?.header?.reviewerCount
    || report?._meta?.reviewCount
    || 0;
  const isGigantic = report?._metadata?.isGigantic || (reviewCount >= 21);
  const isExtended = report?._metadata?.isExtended || (!isGigantic && reviewCount >= 7);
  const reportFormat = report?._metadata?.reportFormat || (isGigantic ? 'GIGANTIC' : (isExtended ? 'EXTENDED' : 'STANDARD'));

  return {
    // ===== METADATA (3 columns) =====
    'is_extended_report': isExtended ? 'نعم' : 'لا',
    'is_gigantic_report': isGigantic ? 'نعم' : 'لا',
    'total_reviewer_count': reviewCount ?? 0,

    // ===== HEADER (11 columns - includes extended executiveSummary2 with title + 5 bullets) =====
    'employee_name_for_header_greeting': safeString(report?.header?.employeeName),
    'leadership_path_status_badge_text': safeString(report?.leadershipPath?.statusLabelAr),
    'executive_summary_intro_paragraph': safeString(report?.header?.executiveSummary),
    'executive_summary_2_title': safeString(report?.header?.executiveSummary2?.title),
    'executive_summary_2_bullet_1': safeString(report?.header?.executiveSummary2?.bulletPoints?.[0]),
    'executive_summary_2_bullet_2': safeString(report?.header?.executiveSummary2?.bulletPoints?.[1]),
    'executive_summary_2_bullet_3': safeString(report?.header?.executiveSummary2?.bulletPoints?.[2]),
    'executive_summary_2_bullet_4': safeString(report?.header?.executiveSummary2?.bulletPoints?.[3]),
    'executive_summary_2_bullet_5': safeString(report?.header?.executiveSummary2?.bulletPoints?.[4]),
    // GIGANTIC: executiveSummary3
    'executive_summary_3_title_gigantic': safeString(report?.header?.executiveSummary3?.title),
    'executive_summary_3_bullet_1_gigantic': safeString(report?.header?.executiveSummary3?.bulletPoints?.[0]),
    'executive_summary_3_bullet_2_gigantic': safeString(report?.header?.executiveSummary3?.bulletPoints?.[1]),
    'executive_summary_3_bullet_3_gigantic': safeString(report?.header?.executiveSummary3?.bulletPoints?.[2]),
    'executive_summary_3_bullet_4_gigantic': safeString(report?.header?.executiveSummary3?.bulletPoints?.[3]),
    'executive_summary_3_bullet_5_gigantic': safeString(report?.header?.executiveSummary3?.bulletPoints?.[4]),
    'number_of_reviews_analyzed': report?.header?.reviewerCount || report?._meta?.reviewCount || 0,

    // ===== CORE METRICS (24 columns - includes extended bullet point 5 for each) =====
    'clarity_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.score, 0),
    'clarity_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[0]),
    'clarity_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[1]),
    'clarity_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[2]),
    'clarity_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[3]),
    'clarity_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[4]),
    'clarity_metric_bullet_point_6_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[5]),
    'clarity_metric_bullet_point_7_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[6]),
    'efficiency_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.score, 0),
    'efficiency_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[0]),
    'efficiency_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[1]),
    'efficiency_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[2]),
    'efficiency_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[3]),
    'efficiency_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[4]),
    'efficiency_metric_bullet_point_6_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[5]),
    'efficiency_metric_bullet_point_7_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[6]),
    'psychological_safety_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.score, 0),
    'psychological_safety_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[0]),
    'psychological_safety_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[1]),
    'psychological_safety_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[2]),
    'psychological_safety_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[3]),
    'psychological_safety_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[4]),
    'psychological_safety_metric_bullet_point_6_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[5]),
    'psychological_safety_metric_bullet_point_7_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[6]),
    'empowerment_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.score, 0),
    'empowerment_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[0]),
    'empowerment_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[1]),
    'empowerment_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[2]),
    'empowerment_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[3]),
    'empowerment_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[4]),
    'empowerment_metric_bullet_point_6_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[5]),
    'empowerment_metric_bullet_point_7_gigantic': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[6]),

    // ===== STRENGTHS (18 columns - includes extended 4, 5, 6 and gigantic 7, 8, 9) =====
    'strength_1_title_in_assessment_section': safeString(report?.strengths?.[0]?.title),
    'strength_1_description_in_assessment_section': safeString(report?.strengths?.[0]?.description),
    'strength_2_title_in_assessment_section': safeString(report?.strengths?.[1]?.title),
    'strength_2_description_in_assessment_section': safeString(report?.strengths?.[1]?.description),
    'strength_3_title_in_assessment_section': safeString(report?.strengths?.[2]?.title),
    'strength_3_description_in_assessment_section': safeString(report?.strengths?.[2]?.description),
    'strength_4_title_extended': safeString(report?.strengths?.[3]?.title),
    'strength_4_description_extended': safeString(report?.strengths?.[3]?.description),
    'strength_5_title_extended': safeString(report?.strengths?.[4]?.title),
    'strength_5_description_extended': safeString(report?.strengths?.[4]?.description),
    'strength_6_title_extended': safeString(report?.strengths?.[5]?.title),
    'strength_6_description_extended': safeString(report?.strengths?.[5]?.description),
    // GIGANTIC: strengths 7, 8, 9
    'strength_7_title_gigantic': safeString(report?.strengths?.[6]?.title),
    'strength_7_description_gigantic': safeString(report?.strengths?.[6]?.description),
    'strength_8_title_gigantic': safeString(report?.strengths?.[7]?.title),
    'strength_8_description_gigantic': safeString(report?.strengths?.[7]?.description),
    'strength_9_title_gigantic': safeString(report?.strengths?.[8]?.title),
    'strength_9_description_gigantic': safeString(report?.strengths?.[8]?.description),

    // ===== WEAKNESSES (18 columns - includes extended 4, 5, 6 and gigantic 7, 8, 9) =====
    'weakness_1_title_in_improvement_section': safeString(report?.weaknesses?.[0]?.title),
    'weakness_1_description_in_improvement_section': safeString(report?.weaknesses?.[0]?.description),
    'weakness_2_title_in_improvement_section': safeString(report?.weaknesses?.[1]?.title),
    'weakness_2_description_in_improvement_section': safeString(report?.weaknesses?.[1]?.description),
    'weakness_3_title_in_improvement_section': safeString(report?.weaknesses?.[2]?.title),
    'weakness_3_description_in_improvement_section': safeString(report?.weaknesses?.[2]?.description),
    'weakness_4_title_extended': safeString(report?.weaknesses?.[3]?.title),
    'weakness_4_description_extended': safeString(report?.weaknesses?.[3]?.description),
    'weakness_5_title_extended': safeString(report?.weaknesses?.[4]?.title),
    'weakness_5_description_extended': safeString(report?.weaknesses?.[4]?.description),
    'weakness_6_title_extended': safeString(report?.weaknesses?.[5]?.title),
    'weakness_6_description_extended': safeString(report?.weaknesses?.[5]?.description),
    // GIGANTIC: weaknesses 7, 8, 9
    'weakness_7_title_gigantic': safeString(report?.weaknesses?.[6]?.title),
    'weakness_7_description_gigantic': safeString(report?.weaknesses?.[6]?.description),
    'weakness_8_title_gigantic': safeString(report?.weaknesses?.[7]?.title),
    'weakness_8_description_gigantic': safeString(report?.weaknesses?.[7]?.description),
    'weakness_9_title_gigantic': safeString(report?.weaknesses?.[8]?.title),
    'weakness_9_description_gigantic': safeString(report?.weaknesses?.[8]?.description),

    // ===== PERSONALITY ANALYSIS (28 columns - includes extended overview2 and gigantic overview3) =====
    'personality_analysis_overview_paragraph': safeString(report?.personalityAnalysis?.overview),
    'personality_overview_2_title': safeString(report?.personalityAnalysis?.overview2?.title),
    'personality_overview_2_bullet_1': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[0]),
    'personality_overview_2_bullet_2': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[1]),
    'personality_overview_2_bullet_3': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[2]),
    'personality_overview_2_bullet_4': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[3]),
    'personality_overview_2_bullet_5': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[4]),
    // GIGANTIC: overview3
    'personality_overview_3_title_gigantic': safeString(report?.personalityAnalysis?.overview3?.title),
    'personality_overview_3_bullet_1_gigantic': safeString(report?.personalityAnalysis?.overview3?.bulletPoints?.[0]),
    'personality_overview_3_bullet_2_gigantic': safeString(report?.personalityAnalysis?.overview3?.bulletPoints?.[1]),
    'personality_overview_3_bullet_3_gigantic': safeString(report?.personalityAnalysis?.overview3?.bulletPoints?.[2]),
    'personality_overview_3_bullet_4_gigantic': safeString(report?.personalityAnalysis?.overview3?.bulletPoints?.[3]),
    'personality_overview_3_bullet_5_gigantic': safeString(report?.personalityAnalysis?.overview3?.bulletPoints?.[4]),
    'mbti_personality_type_badge_code': safeString(report?.personalityAnalysis?.mbpiType),
    'enneagram_personality_type_badge_code': safeString(report?.personalityAnalysis?.enneagramType),
    'disc_behavioral_style_badge_code': safeString(report?.personalityAnalysis?.discType),
    'big_five_trait_badge_code': safeString(report?.personalityAnalysis?.bigFiveType),
    'personality_strength_bullet_1': safeString(report?.personalityAnalysis?.strengths?.[0]),
    'personality_strength_bullet_2': safeString(report?.personalityAnalysis?.strengths?.[1]),
    'personality_strength_bullet_3': safeString(report?.personalityAnalysis?.strengths?.[2]),
    'personality_strength_bullet_4': safeString(report?.personalityAnalysis?.strengths?.[3]),
    'personality_strength_bullet_5': safeString(report?.personalityAnalysis?.strengths?.[4]),
    'personality_weakness_bullet_1': safeString(report?.personalityAnalysis?.weaknesses?.[0]),
    'personality_weakness_bullet_2': safeString(report?.personalityAnalysis?.weaknesses?.[1]),
    'personality_weakness_bullet_3': safeString(report?.personalityAnalysis?.weaknesses?.[2]),
    'personality_weakness_bullet_4': safeString(report?.personalityAnalysis?.weaknesses?.[3]),
    'personality_weakness_bullet_5': safeString(report?.personalityAnalysis?.weaknesses?.[4]),

    // ===== PERSONALITY ASSESSMENT URLS (4 columns) =====
    'mbti_assessment_url': safeString(personalityUrls.mbtiUrl),
    'enneagram_assessment_url': safeString(personalityUrls.enneagramUrl),
    'disc_assessment_url': safeString(personalityUrls.discUrl),
    'big_five_assessment_url': safeString(personalityUrls.bigFiveUrl),

    // ===== TEAM VOICE (10 columns - includes extended box 5) =====
    'team_voice_feedback_box_1_title': safeString(report?.teamVoice?.[0]?.title),
    'team_voice_feedback_box_1_content': safeString(report?.teamVoice?.[0]?.content),
    'team_voice_feedback_box_2_title': safeString(report?.teamVoice?.[1]?.title),
    'team_voice_feedback_box_2_content': safeString(report?.teamVoice?.[1]?.content),
    'team_voice_feedback_box_3_title': safeString(report?.teamVoice?.[2]?.title),
    'team_voice_feedback_box_3_content': safeString(report?.teamVoice?.[2]?.content),
    'team_voice_feedback_box_4_title': safeString(report?.teamVoice?.[3]?.title),
    'team_voice_feedback_box_4_content': safeString(report?.teamVoice?.[3]?.content),
    'team_voice_feedback_box_5_title_extended': safeString(report?.teamVoice?.[4]?.title),
    'team_voice_feedback_box_5_content_extended': safeString(report?.teamVoice?.[4]?.content),
    // GIGANTIC: teamVoice 6-12
    'team_voice_feedback_box_6_title_gigantic': safeString(report?.teamVoice?.[5]?.title),
    'team_voice_feedback_box_6_content_gigantic': safeString(report?.teamVoice?.[5]?.content),
    'team_voice_feedback_box_7_title_gigantic': safeString(report?.teamVoice?.[6]?.title),
    'team_voice_feedback_box_7_content_gigantic': safeString(report?.teamVoice?.[6]?.content),
    'team_voice_feedback_box_8_title_gigantic': safeString(report?.teamVoice?.[7]?.title),
    'team_voice_feedback_box_8_content_gigantic': safeString(report?.teamVoice?.[7]?.content),
    'team_voice_feedback_box_9_title_gigantic': safeString(report?.teamVoice?.[8]?.title),
    'team_voice_feedback_box_9_content_gigantic': safeString(report?.teamVoice?.[8]?.content),
    'team_voice_feedback_box_10_title_gigantic': safeString(report?.teamVoice?.[9]?.title),
    'team_voice_feedback_box_10_content_gigantic': safeString(report?.teamVoice?.[9]?.content),
    'team_voice_feedback_box_11_title_gigantic': safeString(report?.teamVoice?.[10]?.title),
    'team_voice_feedback_box_11_content_gigantic': safeString(report?.teamVoice?.[10]?.content),
    'team_voice_feedback_box_12_title_gigantic': safeString(report?.teamVoice?.[11]?.title),
    'team_voice_feedback_box_12_content_gigantic': safeString(report?.teamVoice?.[11]?.content),

    // ===== DEVELOPMENT COMPASS / بوصلة التطوير (9 columns for gigantic) =====
    'development_compass_1': safeString(report?.developmentCompass?.[0]),
    'development_compass_2': safeString(report?.developmentCompass?.[1]),
    'development_compass_3': safeString(report?.developmentCompass?.[2]),
    'development_compass_4': safeString(report?.developmentCompass?.[3]),
    'development_compass_5': safeString(report?.developmentCompass?.[4]),
    // GIGANTIC: developmentCompass 6-9
    'development_compass_6_gigantic': safeString(report?.developmentCompass?.[5]),
    'development_compass_7_gigantic': safeString(report?.developmentCompass?.[6]),
    'development_compass_8_gigantic': safeString(report?.developmentCompass?.[7]),
    'development_compass_9_gigantic': safeString(report?.developmentCompass?.[8]),

    // ===== ROADMAP (36 columns - includes extended step 5 and gigantic steps 6-10) =====
    'roadmap_priority_1_highest_action_title': safeString(report?.roadmap?.[0]?.title),
    'roadmap_priority_1_highest_badge_label': safeString(report?.roadmap?.[0]?.priorityAr),
    'roadmap_priority_1_highest_step_1': safeString(report?.roadmap?.[0]?.steps?.[0]),
    'roadmap_priority_1_highest_step_2': safeString(report?.roadmap?.[0]?.steps?.[1]),
    'roadmap_priority_1_highest_step_3': safeString(report?.roadmap?.[0]?.steps?.[2]),
    'roadmap_priority_1_highest_step_4': safeString(report?.roadmap?.[0]?.steps?.[3]),
    'roadmap_priority_1_highest_step_5_extended': safeString(report?.roadmap?.[0]?.steps?.[4]),
    // GIGANTIC: roadmap priority 1 steps 6-10
    'roadmap_priority_1_highest_step_6_gigantic': safeString(report?.roadmap?.[0]?.steps?.[5]),
    'roadmap_priority_1_highest_step_7_gigantic': safeString(report?.roadmap?.[0]?.steps?.[6]),
    'roadmap_priority_1_highest_step_8_gigantic': safeString(report?.roadmap?.[0]?.steps?.[7]),
    'roadmap_priority_1_highest_step_9_gigantic': safeString(report?.roadmap?.[0]?.steps?.[8]),
    'roadmap_priority_1_highest_step_10_gigantic': safeString(report?.roadmap?.[0]?.steps?.[9]),
    'roadmap_priority_2_urgent_action_title': safeString(report?.roadmap?.[1]?.title),
    'roadmap_priority_2_urgent_badge_label': safeString(report?.roadmap?.[1]?.priorityAr),
    'roadmap_priority_2_urgent_step_1': safeString(report?.roadmap?.[1]?.steps?.[0]),
    'roadmap_priority_2_urgent_step_2': safeString(report?.roadmap?.[1]?.steps?.[1]),
    'roadmap_priority_2_urgent_step_3': safeString(report?.roadmap?.[1]?.steps?.[2]),
    'roadmap_priority_2_urgent_step_4': safeString(report?.roadmap?.[1]?.steps?.[3]),
    'roadmap_priority_2_urgent_step_5_extended': safeString(report?.roadmap?.[1]?.steps?.[4]),
    // GIGANTIC: roadmap priority 2 steps 6-10
    'roadmap_priority_2_urgent_step_6_gigantic': safeString(report?.roadmap?.[1]?.steps?.[5]),
    'roadmap_priority_2_urgent_step_7_gigantic': safeString(report?.roadmap?.[1]?.steps?.[6]),
    'roadmap_priority_2_urgent_step_8_gigantic': safeString(report?.roadmap?.[1]?.steps?.[7]),
    'roadmap_priority_2_urgent_step_9_gigantic': safeString(report?.roadmap?.[1]?.steps?.[8]),
    'roadmap_priority_2_urgent_step_10_gigantic': safeString(report?.roadmap?.[1]?.steps?.[9]),
    'roadmap_priority_3_ongoing_action_title': safeString(report?.roadmap?.[2]?.title),
    'roadmap_priority_3_ongoing_badge_label': safeString(report?.roadmap?.[2]?.priorityAr),
    'roadmap_priority_3_ongoing_step_1': safeString(report?.roadmap?.[2]?.steps?.[0]),
    'roadmap_priority_3_ongoing_step_2': safeString(report?.roadmap?.[2]?.steps?.[1]),
    'roadmap_priority_3_ongoing_step_3': safeString(report?.roadmap?.[2]?.steps?.[2]),
    'roadmap_priority_3_ongoing_step_4': safeString(report?.roadmap?.[2]?.steps?.[3]),
    'roadmap_priority_3_ongoing_step_5_extended': safeString(report?.roadmap?.[2]?.steps?.[4]),
    // GIGANTIC: roadmap priority 3 steps 6-10
    'roadmap_priority_3_ongoing_step_6_gigantic': safeString(report?.roadmap?.[2]?.steps?.[5]),
    'roadmap_priority_3_ongoing_step_7_gigantic': safeString(report?.roadmap?.[2]?.steps?.[6]),
    'roadmap_priority_3_ongoing_step_8_gigantic': safeString(report?.roadmap?.[2]?.steps?.[7]),
    'roadmap_priority_3_ongoing_step_9_gigantic': safeString(report?.roadmap?.[2]?.steps?.[8]),
    'roadmap_priority_3_ongoing_step_10_gigantic': safeString(report?.roadmap?.[2]?.steps?.[9]),

    // ===== DEVELOPMENT PLAN (44 columns) =====
    'dev_plan_track_1_category_title': safeString(report?.developmentPlan?.[0]?.categoryTitle),
    'dev_plan_track_1_resource_1_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[0]?.title),
    'dev_plan_track_1_resource_1_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[0]?.link),
    'dev_plan_track_1_resource_2_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[1]?.title),
    'dev_plan_track_1_resource_2_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[1]?.link),
    'dev_plan_track_1_resource_3_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[2]?.title),
    'dev_plan_track_1_resource_3_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[2]?.link),
    'dev_plan_track_1_resource_4_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[3]?.title),
    'dev_plan_track_1_resource_4_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[3]?.link),
    'dev_plan_track_1_resource_5_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[4]?.title),
    'dev_plan_track_1_resource_5_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[4]?.link),
    'dev_plan_track_2_category_title': safeString(report?.developmentPlan?.[1]?.categoryTitle),
    'dev_plan_track_2_resource_1_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[0]?.title),
    'dev_plan_track_2_resource_1_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[0]?.link),
    'dev_plan_track_2_resource_2_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[1]?.title),
    'dev_plan_track_2_resource_2_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[1]?.link),
    'dev_plan_track_2_resource_3_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[2]?.title),
    'dev_plan_track_2_resource_3_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[2]?.link),
    'dev_plan_track_2_resource_4_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[3]?.title),
    'dev_plan_track_2_resource_4_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[3]?.link),
    'dev_plan_track_2_resource_5_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[4]?.title),
    'dev_plan_track_2_resource_5_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[4]?.link),
    'dev_plan_track_3_category_title': safeString(report?.developmentPlan?.[2]?.categoryTitle),
    'dev_plan_track_3_resource_1_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[0]?.title),
    'dev_plan_track_3_resource_1_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[0]?.link),
    'dev_plan_track_3_resource_2_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[1]?.title),
    'dev_plan_track_3_resource_2_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[1]?.link),
    'dev_plan_track_3_resource_3_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[2]?.title),
    'dev_plan_track_3_resource_3_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[2]?.link),
    'dev_plan_track_3_resource_4_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[3]?.title),
    'dev_plan_track_3_resource_4_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[3]?.link),
    'dev_plan_track_3_resource_5_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[4]?.title),
    'dev_plan_track_3_resource_5_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[4]?.link),
    'dev_plan_track_4_category_title': safeString(report?.developmentPlan?.[3]?.categoryTitle),
    'dev_plan_track_4_resource_1_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[0]?.title),
    'dev_plan_track_4_resource_1_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[0]?.link),
    'dev_plan_track_4_resource_2_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[1]?.title),
    'dev_plan_track_4_resource_2_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[1]?.link),
    'dev_plan_track_4_resource_3_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[2]?.title),
    'dev_plan_track_4_resource_3_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[2]?.link),
    'dev_plan_track_4_resource_4_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[3]?.title),
    'dev_plan_track_4_resource_4_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[3]?.link),
    'dev_plan_track_4_resource_5_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[4]?.title),
    'dev_plan_track_4_resource_5_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[4]?.link),
  };
}

/**
 * Export single report to Excel (same format as batch for consistency)
 * @param {Object} report - Full report object
 * @param {string} filename - Filename without extension
 */
export function exportSingleReportToExcel(report, filename = 'leadership_report') {
  if (!report) {
    throw new Error('لا توجد بيانات للتصدير');
  }

  const row = convertSingleReportToRow(report);
  const data = [row];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(data);
  ws['!dir'] = 'rtl';

  // Auto-size columns
  const colWidths = Object.keys(row).map(key => ({
    wch: Math.max(key.length, 15)
  }));
  ws['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(wb, ws, 'التقرير');

  const timestamp = new Date().toISOString().split('T')[0];
  const employeeName = report.header?.employeeName?.replace(/\s+/g, '_') || 'report';
  XLSX.writeFile(wb, `${filename}_${employeeName}_${timestamp}.xlsx`);
}

/**
 * Export batch results to Excel file (dynamic columns based on data)
 * @param {Array<Object>} data - Array of row objects from convertToExcelFormat
 * @param {string} filename - Filename without extension
 * @returns {void} Downloads the file
 */
export function exportToExcel(data, filename = 'leadership_assessment_results') {
  if (!data || data.length === 0) {
    throw new Error('لا توجد بيانات للتصدير');
  }

  // Create workbook and worksheet
  const wb = XLSX.utils.book_new();

  // Main results sheet - let XLSX auto-detect columns from data
  const ws = XLSX.utils.json_to_sheet(data);

  // Auto-size columns based on first row keys
  const firstRow = data[0];
  if (firstRow) {
    const colWidths = Object.keys(firstRow).map(key => ({
      wch: Math.min(Math.max(key.length, 12), 50)
    }));
    ws['!cols'] = colWidths;
  }

  // Set RTL direction for Arabic
  ws['!dir'] = 'rtl';

  XLSX.utils.book_append_sheet(wb, ws, 'التقييمات');

  // Create summary sheet
  const successCount = data.filter(d => d['حالة إنشاء التقرير'] === 'ناجح').length;
  const failCount = data.filter(d => d['حالة إنشاء التقرير'] === 'فشل').length;
  const avgScore = data
    .filter(d => d['الدرجة الإجمالية للأداء القيادي'])
    .reduce((sum, d) => sum + (d['الدرجة الإجمالية للأداء القيادي'] || 0), 0) / (successCount || 1);

  const summaryData = [
    { 'البند': 'إجمالي المرشحين', 'القيمة': data.length },
    { 'البند': 'التقارير الناجحة', 'القيمة': successCount },
    { 'البند': 'التقارير الفاشلة', 'القيمة': failCount },
    { 'البند': 'متوسط الدرجات', 'القيمة': Math.round(avgScore) },
    { 'البند': 'تاريخ التصدير', 'القيمة': new Date().toLocaleDateString('ar-SA') }
  ];

  const summaryWs = XLSX.utils.json_to_sheet(summaryData);
  summaryWs['!cols'] = [{ wch: 20 }, { wch: 15 }];
  summaryWs['!dir'] = 'rtl';
  XLSX.utils.book_append_sheet(wb, summaryWs, 'الملخص');

  // Download file
  const timestamp = new Date().toISOString().split('T')[0];
  XLSX.writeFile(wb, `${filename}_${timestamp}.xlsx`);
}

/**
 * Export detailed reports to Excel with multiple sheets
 * @param {Object} batchResults - Full batch results with reports
 * @param {string} filename - Filename without extension
 */
export function exportDetailedReportsToExcel(batchResults, filename = 'leadership_detailed_reports') {
  // Ensure successful and failed are arrays
  const successful = Array.isArray(batchResults?.successful) ? batchResults.successful : [];
  const failed = Array.isArray(batchResults?.failed) ? batchResults.failed : [];

  if (!batchResults || (successful.length === 0 && failed.length === 0)) {
    throw new Error('لا توجد بيانات للتصدير');
  }

  const wb = XLSX.utils.book_new();

  // Sheet 1: Summary
  const summaryData = [
    { 'البند': 'إجمالي المرشحين', 'القيمة': batchResults.total },
    { 'البند': 'التقارير الناجحة', 'القيمة': successful.length },
    { 'البند': 'التقارير الفاشلة', 'القيمة': failed.length },
    { 'البند': 'وقت البدء', 'القيمة': batchResults.startTime },
    { 'البند': 'وقت الانتهاء', 'القيمة': batchResults.endTime },
    { 'البند': 'المدة (ثانية)', 'القيمة': Math.round((batchResults.duration || 0) / 1000) }
  ];
  const summaryWs = XLSX.utils.json_to_sheet(summaryData);
  summaryWs['!dir'] = 'rtl';
  XLSX.utils.book_append_sheet(wb, summaryWs, 'الملخص');

  // Sheet 2: All Scores
  const scoresData = successful.map(result => ({
    'الاسم': result.candidateName,
    'المسمى': result.jobTitle,
    'الدرجة الإجمالية': result.scoreData?.overallScore,
    'الحالة': result.report?.leadershipPath?.statusLabelAr,
    'الوضوح': result.scoreData?.coreMetricScores?.clarity,
    'الكفاءة': result.scoreData?.coreMetricScores?.efficiency,
    'الأمان': result.scoreData?.coreMetricScores?.safety,
    'التمكين': result.scoreData?.coreMetricScores?.empowerment,
    'عدد المقيّمين': result.scoreData?.totalReviewerCount,
    'نسبة التغطية': `${result.scoreData?.coveragePercentage || 100}%`
  }));

  if (scoresData.length > 0) {
    const scoresWs = XLSX.utils.json_to_sheet(scoresData);
    scoresWs['!dir'] = 'rtl';
    XLSX.utils.book_append_sheet(wb, scoresWs, 'الدرجات');
  }

  // Sheet 3: Strengths
  const strengthsData = [];
  successful.forEach(result => {
    const strengths = result.report?.strengths || [];
    strengths.forEach((s, idx) => {
      strengthsData.push({
        'الاسم': result.candidateName,
        'رقم': idx + 1,
        'نقطة القوة': s.title,
        'الوصف': s.description
      });
    });
  });

  if (strengthsData.length > 0) {
    const strengthsWs = XLSX.utils.json_to_sheet(strengthsData);
    strengthsWs['!dir'] = 'rtl';
    XLSX.utils.book_append_sheet(wb, strengthsWs, 'نقاط القوة');
  }

  // Sheet 4: Weaknesses
  const weaknessesData = [];
  successful.forEach(result => {
    const weaknesses = result.report?.weaknesses || [];
    weaknesses.forEach((w, idx) => {
      weaknessesData.push({
        'الاسم': result.candidateName,
        'رقم': idx + 1,
        'نقطة الضعف': w.title,
        'الوصف': w.description
      });
    });
  });

  if (weaknessesData.length > 0) {
    const weaknessesWs = XLSX.utils.json_to_sheet(weaknessesData);
    weaknessesWs['!dir'] = 'rtl';
    XLSX.utils.book_append_sheet(wb, weaknessesWs, 'نقاط الضعف');
  }

  // Sheet 5: Personality Analysis (updated for new object structure)
  const personalityData = successful.map(result => {
    const p = result.report?.personalityAnalysis || {};
    return {
      'الاسم': result.candidateName,
      'النظرة العامة': p.overview,
      'MBTI': p.mbpiType,
      'Enneagram': p.enneagramType,
      'DISC': p.discType,
      'Big Five': p.bigFiveType,
      'نقاط القوة': (p.strengths || []).join(' | '),
      'نقاط الضعف': (p.weaknesses || []).join(' | ')
    };
  });

  if (personalityData.length > 0) {
    const personalityWs = XLSX.utils.json_to_sheet(personalityData);
    personalityWs['!dir'] = 'rtl';
    XLSX.utils.book_append_sheet(wb, personalityWs, 'تحليل الشخصية');
  }

  // Sheet 6: Roadmap Actions (updated to use steps instead of checklist)
  const roadmapData = [];
  successful.forEach(result => {
    const roadmap = result.report?.roadmap || [];
    roadmap.forEach(r => {
      roadmapData.push({
        'الاسم': result.candidateName,
        'الأولوية': r.priorityAr,
        'الإجراء': r.title,
        'الخطوات': (r.steps || []).join(' | ')
      });
    });
  });

  if (roadmapData.length > 0) {
    const roadmapWs = XLSX.utils.json_to_sheet(roadmapData);
    roadmapWs['!dir'] = 'rtl';
    XLSX.utils.book_append_sheet(wb, roadmapWs, 'خارطة الطريق');
  }

  // Sheet 7: Failed Reports
  if (failed.length > 0) {
    const failedData = failed.map(f => ({
      'الاسم': f.candidateName,
      'المسمى': f.jobTitle || 'غير محدد',
      'سبب الفشل': f.error
    }));
    const failedWs = XLSX.utils.json_to_sheet(failedData);
    failedWs['!dir'] = 'rtl';
    XLSX.utils.book_append_sheet(wb, failedWs, 'التقارير الفاشلة');
  }

  // Download
  const timestamp = new Date().toISOString().split('T')[0];
  XLSX.writeFile(wb, `${filename}_${timestamp}.xlsx`);
}

/**
 * Generate CSV format for simple export
 * @param {Array<Object>} data - Row data
 * @param {string} filename - Filename without extension
 */
export function exportToCSV(data, filename = 'leadership_results') {
  if (!data || data.length === 0) {
    throw new Error('لا توجد بيانات للتصدير');
  }

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, 'Data');

  const timestamp = new Date().toISOString().split('T')[0];
  XLSX.writeFile(wb, `${filename}_${timestamp}.csv`, { bookType: 'csv' });
}

/**
 * Generate JSON export of full results
 * @param {Object} batchResults - Full batch results
 * @param {string} filename - Filename without extension
 */
export function exportToJSON(batchResults, filename = 'leadership_full_results') {
  const blob = new Blob([JSON.stringify(batchResults, null, 2)], {
    type: 'application/json'
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}_${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Generate a printable HTML report for a single candidate
 * @param {Object} report - Full report object
 * @returns {string} HTML string
 */
export function generatePrintableHTML(report) {
  const getStatusColor = (score) => {
    if (score >= 90) return '#53815F';
    if (score >= 75) return '#AECF76';
    if (score >= 60) return '#EBCB6B';
    if (score >= 40) return '#D68A77';
    return '#AA392D';
  };

  const score = report.leadershipPath?.score || 0;

  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تقرير القيادة - ${report.header?.employeeName}</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, sans-serif;
      direction: rtl;
      padding: 20px;
      max-width: 900px;
      margin: 0 auto;
      background: #f5f5f5;
    }
    .report-container {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .header {
      text-align: center;
      border-bottom: 2px solid #eee;
      padding-bottom: 20px;
      margin-bottom: 20px;
    }
    .header h1 {
      color: #333;
      margin: 0;
    }
    .header .subtitle {
      color: #666;
      font-size: 1.1em;
    }
    .score-badge {
      display: inline-block;
      padding: 10px 30px;
      border-radius: 20px;
      color: white;
      font-size: 1.5em;
      font-weight: bold;
      margin: 15px 0;
      background: ${getStatusColor(score)};
    }
    .section {
      margin: 25px 0;
    }
    .section h2 {
      color: #444;
      border-bottom: 1px solid #ddd;
      padding-bottom: 10px;
    }
    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
    }
    .metric-card {
      background: #f9f9f9;
      padding: 15px;
      border-radius: 8px;
      border-right: 4px solid;
    }
    .metric-card .label {
      font-weight: bold;
      color: #555;
    }
    .metric-card .value {
      font-size: 1.5em;
      font-weight: bold;
    }
    .bullet-list {
      list-style-type: disc;
      padding-right: 20px;
    }
    .bullet-list li {
      margin: 8px 0;
      line-height: 1.6;
    }
    .summary-text {
      background: #f0f7ff;
      padding: 15px;
      border-radius: 8px;
      line-height: 1.8;
    }
    @media print {
      body { background: white; }
      .report-container { box-shadow: none; }
    }
  </style>
</head>
<body>
  <div class="report-container">
    <div class="header">
      <h1>${report.header?.employeeName || 'غير محدد'}</h1>
      <div class="subtitle">${report.header?.jobTitle || ''}</div>
      <div class="score-badge">${score}/100 - ${report.leadershipPath?.statusLabelAr}</div>
      <div style="color: #888; font-size: 0.9em;">
        ${report.header?.date} | عدد المقيّمين: ${report.header?.reviewerCount}
      </div>
    </div>

    <div class="section">
      <h2>الملخص التنفيذي</h2>
      <div class="summary-text">${report.header?.executiveSummary || ''}</div>
    </div>

    <div class="section">
      <h2>المؤشرات الأساسية</h2>
      <div class="metrics-grid">
        ${(report.coreMetrics || []).map(m => `
          <div class="metric-card" style="border-color: ${m.color || '#ccc'}">
            <div class="label">${m.nameAr}</div>
            <div class="value" style="color: ${m.color || '#333'}">${m.score}/100</div>
            <div style="color: #666; font-size: 0.9em;">${m.ratingAr}</div>
          </div>
        `).join('')}
      </div>
    </div>

    <div class="section">
      <h2>نقاط القوة</h2>
      <ul class="bullet-list">
        ${(report.strengths || []).map(s => `
          <li><strong>${s.title}</strong>: ${s.description}</li>
        `).join('')}
      </ul>
    </div>

    <div class="section">
      <h2>مجالات التطوير</h2>
      <ul class="bullet-list">
        ${(report.weaknesses || []).map(w => `
          <li><strong>${w.title}</strong>: ${w.description}</li>
        `).join('')}
      </ul>
    </div>
  </div>
</body>
</html>
`;
}

/**
 * Open printable report in new window
 * @param {Object} report - Full report object
 */
export function printReport(report) {
  const html = generatePrintableHTML(report);
  const printWindow = window.open('', '_blank');
  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.print();
}

export default {
  exportToExcel,
  exportDetailedReportsToExcel,
  exportSingleReportToExcel,
  convertSingleReportToRow,
  exportToCSV,
  exportToJSON,
  generatePrintableHTML,
  printReport
};
