/**
 * ===================================================================
 * OPENROUTER AI SERVICE
 * ===================================================================
 *
 * Handles communication with OpenRouter's API for AI-powered report generation.
 * Supports weighted multi-source assessment with deterministic scoring.
 *
 * @module services/geminiService
 *
 * ARCHITECTURE:
 * - Schemas: Imported from './report/schemas/' (STANDARD, EXTENDED, GIGANTIC)
 * - Constants: Imported from '../config/constants/' (REPORT_THRESHOLDS)
 * - Scoring: Uses weightedScoreService.js for deterministic calculations
 *
 * REPORT TYPES (by reviewer count):
 * - STANDARD: < 7 reviewers (3 strengths, 3 weaknesses, 4 teamVoice)
 * - EXTENDED: 7-20 reviewers (6 strengths, 6 weaknesses, 5 teamVoice)
 * - GIGANTIC: 21+ reviewers (9 strengths, 9 weaknesses, 12 teamVoice)
 *
 * MAIN FUNCTIONS:
 * - generateReportFromFeedback(): Generate report for a single candidate
 * - processBatch(): Process multiple candidates in parallel
 *
 * PROMPT BUILDING:
 * - buildStandardOutputRequirements()
 * - buildExtendedOutputRequirements()
 * - buildGiganticOutputRequirements()
 */

import {
  calculateCandidateScores,
  aggregateHistoricalFeedback,
  getDecember2025Feedback,
  FILE_WEIGHTS
} from './weightedScoreService.js';

import FILE_SCHEMAS from '../config/fileSchemas.js';
import { createLogger } from '../utils/logger.js';
import { getPersonalityUrls } from './personalityUrlService.js';
import { getResourceListForPrompt, mapDevelopmentPlanToUrls } from './resourceRepository.js';

// Import centralized schemas and constants (removes ~700 lines of duplicated code)
import {
  STANDARD_REPORT_SCHEMA,
  EXTENDED_REPORT_SCHEMA,
  GIGANTIC_REPORT_SCHEMA,
  getSchemaByReviewerCount
} from './report/schemas/index.js';
import { REPORT_THRESHOLDS, getReportType } from '../config/constants/index.js';
// Hedging words to avoid in direct writing style
const HEDGING_WORDS_TO_AVOID = [
  'يلاحظ', 'يُلاحَظ', 'لوحظ', 'يبدو', 'يبدو أن', 'ربما', 'قد', 'من الممكن',
  'يُحتمل', 'على ما يبدو', 'من المحتمل', 'يُعتقد', 'يُظن', 'في الغالب',
  'على الأرجح', 'من المرجح', 'قد يكون', 'ممكن أن', 'يمكن أن يكون',
  'نوعاً ما', 'إلى حد ما', 'بشكل عام', 'في معظم الأحيان',
  'يشير', 'يشير إلى', 'يشير الى', 'تشير', 'تشير إلى', 'أشار', 'أشارت'
];

// Varied intro phrases for strengths descriptions - MUST rotate through these
const STRENGTH_INTRO_PHRASES = [
  'تتميز ب', 'لديك قدرة', 'تُظهر مهارة', 'تمتلك', 'تبرع في', 'تُجيد',
  'تتفوق في', 'لديك موهبة', 'تُثبت قدرتك', 'أنت ماهر في', 'تُبدي'
];

// Varied intro phrases for weaknesses/development areas - MUST NOT always use "تحتاج إلى"
const WEAKNESS_INTRO_PHRASES = [
  'يمكنك تطوير', 'لديك فرصة ل', 'مجال للنمو في', 'فرصة لتعزيز',
  'يمكنك تحسين', 'هناك مساحة لتطوير', 'تستطيع تقوية', 'مجال للتحسين في',
  'لديك إمكانية تطوير', 'فرصتك للنمو في', 'يمكنك الارتقاء ب'
];

// Varied intro phrases for teamVoice - Direct advice style, NOT "الفريق" style
const TEAM_VOICE_INTRO_PHRASES = [
  // Positive (use 1-2 per report):
  'تتميز في', 'لديك قدرة على', 'تُظهر مهارة في', 'تمتلك', 'تبرع في',
  // Improvement (use for the rest):
  'يمكنك تعزيز', 'ركّز على تطوير', 'اعمل على تحسين', 'طوّر قدرتك في',
  'حاول تحسين', 'استثمر في تطوير', 'عزّز من', 'ضع تركيزاً أكبر على'
];

// Create contextualized logger
const serviceLogger = createLogger('GeminiService');

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
// API key from environment variable (set in Vercel) or fallback
const API_KEY = import.meta.env.VITE_OPENROUTER_API_KEY || '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';
// Using OpenAI GPT-4o Mini
const MODEL = 'openai/gpt-4o-mini';

// Request timeout in milliseconds (2 minutes)
const REQUEST_TIMEOUT = 120000;

// Batch processing configuration
const BATCH_CONFIG = {
  maxConcurrent: 3,        // Max parallel API calls (3 at a time)
  maxRetries: 4,           // Max retry attempts per candidate
  retryDelays: [1000, 2000, 3000, 4000], // Exponential backoff: 1s, 2s, 3s, 4s
  rateLimitDelayMs: 500    // Small delay between starting new candidates
};

// ===================================================================
// SCHEMAS - Now imported from centralized location
// ===================================================================
// Schemas are imported from './report/schemas/index.js':
// - STANDARD_REPORT_SCHEMA (< 7 reviewers)
// - EXTENDED_REPORT_SCHEMA (7-20 reviewers)
// - GIGANTIC_REPORT_SCHEMA (21+ reviewers)
//
// Alias for backward compatibility with existing code
const REPORT_SCHEMA = STANDARD_REPORT_SCHEMA;

// EXTENDED_REPORT_SCHEMA - imported from './report/schemas/index.js'

// GIGANTIC_REPORT_SCHEMA - imported from './report/schemas/index.js'

// ===================================================================
// THRESHOLDS - Now imported from centralized constants
// ===================================================================
// REPORT_THRESHOLDS.EXTENDED = 7  (7-20 reviews)
// REPORT_THRESHOLDS.GIGANTIC = 21 (21+ reviews)
//
// Aliases for backward compatibility with existing code
const EXTENDED_REPORT_THRESHOLD = REPORT_THRESHOLDS.EXTENDED;
const GIGANTIC_REPORT_THRESHOLD = REPORT_THRESHOLDS.GIGANTIC;

/**
 * Build standard output requirements (for < 6 reviews)
 */
function buildStandardOutputRequirements(employeeName, scoreData) {
  return `================================================================================
SECTION 4: OUTPUT REQUIREMENTS - STANDARD FORMAT (< 6 REVIEWS)
================================================================================

Generate a JSON report. 🚨 ALL TEXT MUST BE IN ARABIC (العربية) - absolutely NO English except personality codes.

🚨🚨🚨 CRITICAL: BULLET POINT LENGTH = EXACTLY 80-83 CHARACTERS 🚨🚨🚨
⛔ REJECTED if bullet < 80 chars - TOO SHORT
⛔ REJECTED if bullet > 83 chars - TOO LONG
✅ ACCEPTED only if bullet is 80, 81, 82, or 83 characters
COUNT EVERY CHARACTER before writing!

HEADER:
- employeeName: Use "${employeeName}" exactly (max 30 chars)
- executiveSummary: Write a comprehensive Arabic summary (max 445 chars) - USE THE FULL LIMIT
  CRITICAL: Use 2ND PERSON (أنت/تُظهر/لديك) - address the person DIRECTLY
  Example: "تُظهر قدرات استثنائية في بناء فرق العمل..." NOT "يُظهر خالد قدرات..."

LEADERSHIP PATH:
- score: Use ${scoreData.overallScore} exactly
- statusLabelAr: Use "${scoreData.statusLabelAr}" exactly (max 15 chars)

CORE METRICS (4 items - use exact scores):
- 🚨 CRITICAL: Each bulletPoint EXACTLY 80-83 characters - COUNT THEM!
- Use 2ND PERSON (أنت/تفعل) - address the person directly in friendly, constructive tone
- 🎯 IMPROVEMENT FOCUS: Write as areas for growth, NOT positive praise
  ❌ WRONG: "تُظهر قدرتك على إدارة الوقت بشكل فعال" (positive praise)
  ✅ RIGHT: "يمكنك تحسين إدارة وقتك لتحقيق نتائج أفضل مع الفريق" (improvement advice)
- 🚫 VARY SENTENCE STARTERS - each bullet MUST start differently:
  ✅ Use: يمكنك تحسين، ركّز على تطوير، اعمل على تعزيز، طوّر قدرتك في، حاول تحسين، استثمر في، عزّز من، ضع تركيزاً على

STRENGTHS (exactly 3 items):
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
  ❌ WRONG: Title "قدرتك على تعزيز الشفافية" → Desc "تُظهر مهاراتك في تعزيز الشفافية..." (repeats title)
  ✅ RIGHT: Title "قدرتك على تعزيز الشفافية" → Desc "تحرص على مشاركة المعلومات بوضوح مع الفريق وبناء بيئة من الثقة المتبادلة تدعم اتخاذ القرارات الصحيحة"
- 🚫 VARY STARTERS - each item MUST start differently:
  ✅ Mix: تحرص على، تسعى دائماً إلى، تعمل باستمرار على، تبذل جهداً في، تولي اهتماماً كبيراً لـ

DEVELOPMENT AREAS (exactly 3 items) - USE CONSTRUCTIVE LANGUAGE:
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
  ❌ WRONG: Title "تحتاج إلى تحسين التفويض" → Desc "يمكنك تطوير مهارات التفويض..." (repeats title)
  ✅ RIGHT: Title "تحتاج إلى تحسين التفويض" → Desc "ركّز على منح فريقك مزيداً من الصلاحيات والثقة لاتخاذ قراراتهم بشكل مستقل مما يعزز إنتاجيتهم وثقتهم بأنفسهم"
- 🚫 VARY STARTERS - each item MUST start differently:
  ✅ Mix: ركّز على، اعمل على تطوير، حاول تعزيز، استثمر وقتاً في، ضع أولوية لـ

PERSONALITY ANALYSIS (consolidated object, NOT array):
CRITICAL: You MUST ALWAYS provide personality types. NEVER use "غير متوفر" or "N/A".
Infer the most likely personality type from behavioral patterns in the feedback data.
Even with limited data, make your best professional inference based on:
- Communication style, decision-making patterns, team interactions
- Leadership approach, conflict handling, delegation tendencies
- Work style, attention to detail, strategic vs tactical focus

- overview: Max 350 characters - comprehensive Arabic personality summary, USE FULL LIMIT
  CRITICAL: Use 2ND PERSON - address the person DIRECTLY like "تجمع بين الحزم والتعاطف..." NOT "يجمع خالد..."
- mbpiType: MANDATORY - Infer from 16 types: INTJ, INTP, ENTJ, ENTP, INFJ, INFP, ENFJ, ENFP, ISTJ, ISFJ, ESTJ, ESFJ, ISTP, ISFP, ESTP, ESFP
- enneagramType: MANDATORY - Infer from: Type 1-9 (e.g., "Type 8", "Type 3")
- discType: MANDATORY - Infer from: High D, High I, High S, High C, or combinations like "D/I", "S/C"
- bigFiveType: MANDATORY - CHOOSE ONLY ONE IN ENGLISH: High Openness, High Conscientiousness, High Extraversion, High Agreeableness, or High Neuroticism (NOT ALL, JUST ONE)
- strengths: 5 items in ARABIC, 8-12 words each
  👤 GENDER: Detect from name. DEFAULT TO MASCULINE (تتمتع، لديك، تمتلك) - only use feminine (تتمتعين، لديكِ) for clearly female names
  ⛔ CRITICAL: ALL 5 ITEMS MUST START WITH COMPLETELY DIFFERENT WORDS - RANDOMIZE!
  ❌ WRONG: "تتميز بالتواصل..." + "تتميز بالقيادة..." (same word تتميز repeated)
  ✅ RIGHT: Each item starts with a unique verb - be creative and varied!
- weaknesses: 5 items in ARABIC, 8-12 words each - DIRECT OBSERVATION STYLE
  👤 GENDER: Detect from name. DEFAULT TO MASCULINE (تميل، تجد، تواجه) - only use feminine for clearly female names
  ⛔ CRITICAL: ALL 5 ITEMS MUST START WITH COMPLETELY DIFFERENT WORDS - RANDOMIZE!
  ❌ WRONG: "يمكنك تطوير..." + "يمكنك تحسين..." (same word يمكنك repeated)
  ✅ RIGHT: Each item starts with a unique verb/phrase - be creative!
  USE DIRECT OBSERVATIONS - describe behavioral tendencies, NOT "يمكنك" style
  ❌ AVOID: "يمكنك تطوير" or "لديك فرصة" - use direct observation instead

TEAM VOICE (4 items) - QUOTE FROM ACTUAL FEEDBACK:
- ⚠️ STRICT: Each title: 1-2 WORDS ONLY about the main topic (e.g., التواصل، القيادة، التفويض، الدعم)
- ⚠️ STRICT: Each content: 25-27 words (min 25, max 27) - MUST be in range
- 🎯 BALANCE: 1 positive item + 3 improvement items
- 📝 QUOTE ACTUAL FEEDBACK: Extract real feedback from employees and REPHRASE to hide identity
  ✅ Take actual comments/themes from the feedback data provided
  ✅ Paraphrase to anonymize - never copy word-for-word
  ✅ Combine similar feedback points from multiple reviewers into one statement
  ❌ NEVER mention names or identifiable details
- ⛔ ALL 4 ITEMS MUST START WITH DIFFERENT WORDS - RANDOMIZE!
- 🚨 ZERO DUPLICATES: Each teamVoice item MUST be about a DIFFERENT topic

ROADMAP (3 items with FIXED priorities):
- Item 1: priorityAr = "الأولوية القصوى"
- Item 2: priorityAr = "عاجل"
- Item 3: priorityAr = "مستمر"
- title: Max 50 characters in Arabic
- ⚠️ STRICT: Each step: 133-140 characters in Arabic (min 121, max 127) - MUST be in range
- Use 2ND PERSON - address the person directly
- 👤 GENDER-AWARE: Determine gender from person's name. For FEMALES, use feminine verb forms:
  ✅ Female: افعلي، تستطيعين، طوّري، حسّني، ركّزي، ابدئي، اعملي، قومي
  ✅ Male: افعل، تستطيع، طوّر، حسّن، ركّز، ابدأ، اعمل، قم

DEVELOPMENT PLAN (4 tracks, 5 resources each) - SELECT FROM PROVIDED LIST ONLY:
- categoryTitle: Max 30 characters in Arabic - customize based on person's needs
- CRITICAL: You MUST select resources ONLY from the AVAILABLE_RESOURCES list below
- For each resource, provide the exact "id" from the list
- Choose resources that are RELEVANT to this specific person's weaknesses and development areas
- DIVERSIFY selections - do NOT pick the same resources for everyone
- Mix books and TED talks for variety

${getResourceListForPrompt()}`;
}

/**
 * Build extended output requirements (for 6+ reviews)
 */
function buildExtendedOutputRequirements(employeeName, scoreData) {
  return `================================================================================
SECTION 4: OUTPUT REQUIREMENTS - EXTENDED FORMAT (6+ REVIEWS)
================================================================================

⚠️ IMPORTANT: This candidate has 6+ reviews, so generate an EXTENDED report with MORE content.

Generate a JSON report. 🚨 ALL TEXT MUST BE IN ARABIC (العربية) - absolutely NO English except personality codes. IMPORTANT: Use the FULL character limits for richer, more detailed content.

HEADER (EXTENDED):
- employeeName: Use "${employeeName}" exactly (max 30 chars)
- executiveSummary: First comprehensive Arabic summary paragraph (max 445 chars)
  CRITICAL: Use 2ND PERSON (أنت/تُظهر/لديك) - address the person DIRECTLY
- executiveSummary2: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
  ⚠️ MUST be UNIQUE content not covered elsewhere in report
  🎯 FOCUS ON IMPROVEMENT TIPS: This section MUST focus on areas for growth and actionable improvement suggestions, NOT positive qualities

LEADERSHIP PATH:
- score: Use ${scoreData.overallScore} exactly
- statusLabelAr: Use "${scoreData.statusLabelAr}" exactly (max 15 chars)

CORE METRICS (4 items - use exact scores - EXTENDED: 5 bullet points each):
- ⚠️ STRICT: Each bulletPoint: 80-83 characters in Arabic (min 80, max 83) - MUST be in range
- Use 2ND PERSON (أنت/تفعل) - address the person directly in friendly, constructive tone
- 🎯 IMPROVEMENT FOCUS: Write as areas for growth, NOT positive praise
  ❌ WRONG: "تُظهر قدرتك على إدارة الوقت بشكل فعال" (positive praise)
  ✅ RIGHT: "يمكنك تحسين إدارة وقتك لتحقيق نتائج أفضل مع الفريق" (improvement advice)
- 🚫 VARY SENTENCE STARTERS - each bullet MUST start differently:
  ✅ Use: يمكنك تحسين، ركّز على تطوير، اعمل على تعزيز، طوّر قدرتك في، حاول تحسين، استثمر في، عزّز من، ضع تركيزاً على

STRENGTHS (EXTENDED: exactly 6 items):
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
  ❌ WRONG: Title "قدرتك على تعزيز الشفافية" → Desc "تُظهر مهاراتك في تعزيز الشفافية..." (repeats title)
  ✅ RIGHT: Title "قدرتك على تعزيز الشفافية" → Desc "تحرص على مشاركة المعلومات بوضوح مع الفريق وبناء بيئة من الثقة المتبادلة تدعم اتخاذ القرارات الصحيحة"
- 🎯 VARY STARTERS - each of 6 items MUST start differently:
  ✅ Mix: تحرص على، تسعى دائماً إلى، تعمل باستمرار على، تبذل جهداً في، تولي اهتماماً كبيراً لـ، تتقن فن

DEVELOPMENT AREAS (EXTENDED: exactly 6 items) - USE CONSTRUCTIVE LANGUAGE:
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
  ❌ WRONG: Title "تحتاج إلى تحسين التفويض" → Desc "يمكنك تطوير مهارات التفويض..." (repeats title)
  ✅ RIGHT: Title "تحتاج إلى تحسين التفويض" → Desc "ركّز على منح فريقك مزيداً من الصلاحيات والثقة لاتخاذ قراراتهم بشكل مستقل مما يعزز إنتاجيتهم وثقتهم بأنفسهم"
- 🎯 VARY STARTERS - each of 6 items MUST start differently:
  ✅ Mix: ركّز على، اعمل على تطوير، حاول تعزيز، استثمر وقتاً في، ضع أولوية لـ، خصص جهداً أكبر لـ

PERSONALITY ANALYSIS (EXTENDED):
CRITICAL: You MUST ALWAYS provide personality types. NEVER use "غير متوفر" or "N/A".
Infer the most likely personality type from behavioral patterns in the feedback data.

- overview: First personality overview paragraph (max 350 chars)
  CRITICAL: Use 2ND PERSON - address the person DIRECTLY
  Focus ONLY on personality TYPES analysis (MBTI, Enneagram, DISC, Big Five)
- overview2: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
  ⚠️ MUST be UNIQUE content - focus on personality type characteristics, NOT personal strengths
  🎯 FOCUS ON IMPROVEMENT TIPS: This section MUST focus on areas for growth based on personality type, actionable improvement suggestions, NOT positive qualities
- mbpiType: MANDATORY - Infer from 16 types
- enneagramType: MANDATORY - Infer from: Type 1-9
- discType: MANDATORY - Infer from: High D, High I, High S, High C
- bigFiveType: MANDATORY - CHOOSE ONLY ONE IN ENGLISH: High Openness, High Conscientiousness, High Extraversion, High Agreeableness, or High Neuroticism (NOT ALL, JUST ONE)
- strengths: 5 items in ARABIC, 8-12 words each
  👤 GENDER: DEFAULT TO MASCULINE (تتمتع، لديك) - only feminine for clearly female names
  ⛔ ALL 5 MUST START WITH DIFFERENT WORDS - RANDOMIZE!
- weaknesses: 5 items in ARABIC, 8-12 words each - DIRECT OBSERVATION STYLE
  👤 GENDER: DEFAULT TO MASCULINE (تميل، تجد) - only feminine for clearly female names
  ⛔ ALL 5 MUST START WITH DIFFERENT WORDS - RANDOMIZE!
  ❌ AVOID "يمكنك تطوير" - use direct observations

TEAM VOICE (EXTENDED: 5 items) - QUOTE FROM ACTUAL FEEDBACK:
- ⚠️ STRICT: Each title: 1-2 WORDS ONLY about the main topic (e.g., التواصل، القيادة، التفويض، الدعم)
- ⚠️ STRICT: Each content: 25-27 words (min 25, max 27) - MUST be in range
- 🎯 BALANCE: 1-2 positive items + 3-4 improvement items
- 📝 QUOTE ACTUAL FEEDBACK: Extract real feedback from employees and REPHRASE to hide identity
  ✅ Take actual comments/themes from the feedback data provided
  ✅ Paraphrase to anonymize - never copy word-for-word
  ✅ Combine similar feedback points from multiple reviewers into one statement
  ❌ NEVER mention names or identifiable details
- ⛔ ALL 5 ITEMS MUST START WITH DIFFERENT WORDS - RANDOMIZE!
- 🚨 ZERO DUPLICATES: Each teamVoice item MUST be about a DIFFERENT topic
  ⛔ NO overlapping themes between items

ROADMAP (3 items with FIXED priorities - EXTENDED: 5 steps each):
- Item 1: priorityAr = "الأولوية القصوى"
- Item 2: priorityAr = "عاجل"
- Item 3: priorityAr = "مستمر"
- title: Max 50 characters in Arabic
- ⚠️ STRICT: Each step: 133-140 characters in Arabic (min 121, max 127) - MUST be in range
- Use 2ND PERSON - address the person directly
- 👤 GENDER-AWARE: Determine gender from person's name. For FEMALES, use feminine verb forms:
  ✅ Female: افعلي، تستطيعين، طوّري، حسّني، ركّزي، ابدئي، اعملي، قومي
  ✅ Male: افعل، تستطيع، طوّر، حسّن، ركّز، ابدأ، اعمل، قم

DEVELOPMENT PLAN (4 tracks, 5 resources each) - SELECT FROM PROVIDED LIST ONLY:
- categoryTitle: Max 30 characters in Arabic - customize based on person's needs
- CRITICAL: You MUST select resources ONLY from the AVAILABLE_RESOURCES list below

${getResourceListForPrompt()}`;
}

/**
 * Build gigantic output requirements (for 16+ reviews)
 */
function buildGiganticOutputRequirements(employeeName, scoreData) {
  return `================================================================================
SECTION 4: OUTPUT REQUIREMENTS - GIGANTIC FORMAT (16+ REVIEWS)
================================================================================

⚠️ IMPORTANT: This candidate has 16+ reviews, so generate a GIGANTIC report with MAXIMUM content.

Generate a JSON report. 🚨 ALL TEXT MUST BE IN ARABIC (العربية) - absolutely NO English except personality codes. IMPORTANT: Use the FULL character limits for richer, more detailed content.

HEADER (GIGANTIC):
- employeeName: Use "${employeeName}" exactly (max 30 chars)
- executiveSummary: First comprehensive Arabic summary paragraph (max 445 chars)
  CRITICAL: Use 2ND PERSON (أنت/تُظهر/لديك) - address the person DIRECTLY
- executiveSummary2: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
  ⚠️ MUST be UNIQUE content not covered elsewhere in report
  🎯 FOCUS ON IMPROVEMENT TIPS: This section MUST focus on areas for growth and actionable improvement suggestions, NOT positive qualities
- executiveSummary3: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
  ⚠️ MUST be UNIQUE strategic perspective - DIFFERENT from executiveSummary2

LEADERSHIP PATH:
- score: Use ${scoreData.overallScore} exactly
- statusLabelAr: Use "${scoreData.statusLabelAr}" exactly (max 15 chars)

CORE METRICS (4 items - use exact scores - GIGANTIC: 7 bullet points each):
- ⚠️ STRICT: Each bulletPoint: 80-83 characters in Arabic (min 80, max 83) - MUST be in range
- Use 2ND PERSON (أنت/تفعل) - address the person directly in friendly, constructive tone
- 🎯 IMPROVEMENT FOCUS: Write as areas for growth, NOT positive praise
  ❌ WRONG: "تُظهر قدرتك على إدارة الوقت بشكل فعال" (positive praise)
  ✅ RIGHT: "يمكنك تحسين إدارة وقتك لتحقيق نتائج أفضل مع الفريق" (improvement advice)
- 🚫 VARY SENTENCE STARTERS - each of 7 bullets MUST start differently:
  ✅ Use: يمكنك تحسين، ركّز على تطوير، اعمل على تعزيز، طوّر قدرتك في، حاول تحسين، استثمر في، عزّز من، ضع تركيزاً على

STRENGTHS (GIGANTIC: exactly 9 items):
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
  ❌ WRONG: Title "قدرتك على تعزيز الشفافية" → Desc "تُظهر مهاراتك في تعزيز الشفافية..." (repeats title)
  ✅ RIGHT: Title "قدرتك على تعزيز الشفافية" → Desc "تحرص على مشاركة المعلومات بوضوح مع الفريق وبناء بيئة من الثقة المتبادلة تدعم اتخاذ القرارات الصحيحة"
- 🎯 VARY STARTERS - each of 9 items MUST start differently:
  ✅ Mix: تحرص على، تسعى دائماً إلى، تعمل باستمرار على، تبذل جهداً في، تولي اهتماماً كبيراً لـ، تتقن فن، تُجيد، تبرع في، تمتلك قدرة على

DEVELOPMENT AREAS (GIGANTIC: exactly 9 items) - USE CONSTRUCTIVE LANGUAGE:
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
  ❌ WRONG: Title "تحتاج إلى تحسين التفويض" → Desc "يمكنك تطوير مهارات التفويض..." (repeats title)
  ✅ RIGHT: Title "تحتاج إلى تحسين التفويض" → Desc "ركّز على منح فريقك مزيداً من الصلاحيات والثقة لاتخاذ قراراتهم بشكل مستقل مما يعزز إنتاجيتهم وثقتهم بأنفسهم"
- 🎯 VARY STARTERS - each of 9 items MUST start differently:
  ✅ Mix: ركّز على، اعمل على تطوير، حاول تعزيز، استثمر وقتاً في، ضع أولوية لـ، خصص جهداً أكبر لـ، طوّر قدرتك على، وجّه اهتمامك نحو، ابدأ بتحسين

PERSONALITY ANALYSIS (GIGANTIC):
CRITICAL: You MUST ALWAYS provide personality types. NEVER use "غير متوفر" or "N/A".
Infer the most likely personality type from behavioral patterns in the feedback data.

- overview: First personality overview paragraph (max 350 chars)
  CRITICAL: Use 2ND PERSON - address the person DIRECTLY
  Focus ONLY on personality TYPES analysis (MBTI, Enneagram, DISC, Big Five)
- overview2: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
  ⚠️ MUST be UNIQUE content - focus on personality type characteristics, NOT personal strengths
  🎯 FOCUS ON IMPROVEMENT TIPS: This section MUST focus on areas for growth based on personality type, actionable improvement suggestions, NOT positive qualities
- overview3: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
  ⚠️ MUST be UNIQUE - deeper behavioral insights DIFFERENT from overview2
- mbpiType: MANDATORY - Infer from 16 types
- enneagramType: MANDATORY - Infer from: Type 1-9
- discType: MANDATORY - Infer from: High D, High I, High S, High C
- bigFiveType: MANDATORY - CHOOSE ONLY ONE IN ENGLISH: High Openness, High Conscientiousness, High Extraversion, High Agreeableness, or High Neuroticism (NOT ALL, JUST ONE)
- strengths: 5 items in ARABIC, 8-12 words each
  👤 GENDER: DEFAULT TO MASCULINE (تتمتع، لديك) - only feminine for clearly female names
  ⛔ ALL 5 MUST START WITH DIFFERENT WORDS - RANDOMIZE!
- weaknesses: 5 items in ARABIC, 8-12 words each - DIRECT OBSERVATION STYLE
  👤 GENDER: DEFAULT TO MASCULINE (تميل، تجد) - only feminine for clearly female names
  ⛔ ALL 5 MUST START WITH DIFFERENT WORDS - RANDOMIZE!
  ❌ AVOID "يمكنك تطوير" - use direct observations

TEAM VOICE (GIGANTIC: 12 items) - QUOTE FROM ACTUAL FEEDBACK:
- ⚠️ STRICT: Each title: 1-2 WORDS ONLY about the main topic (e.g., التواصل، القيادة، التفويض، الدعم)
- ⚠️ STRICT: Each content: 25-27 words (min 25, max 27) - MUST be in range
- 🎯 BALANCE: 2-3 positive items + 9-10 improvement items
- 📝 QUOTE ACTUAL FEEDBACK: Extract real feedback from employees and REPHRASE to hide identity
  ✅ Take actual comments/themes from the feedback data provided
  ✅ Paraphrase to anonymize - never copy word-for-word
  ✅ Combine similar feedback points from multiple reviewers into one statement
  ❌ NEVER mention names or identifiable details
- ⛔ ALL 12 ITEMS MUST START WITH DIFFERENT WORDS - RANDOMIZE!
- 🚨 ZERO DUPLICATES: Each teamVoice item MUST be about a DIFFERENT topic

DEVELOPMENT COMPASS / بوصلة التطوير (GIGANTIC: 9 items):
- Each item: 45-55 characters in Arabic
- Focus on soft skills based on challenges faced
- MUST be COMPLETELY UNIQUE - cannot overlap with strengths, weaknesses, roadmap

ROADMAP (3 items with FIXED priorities - GIGANTIC: 10 steps each):
- Item 1: priorityAr = "الأولوية القصوى"
- Item 2: priorityAr = "عاجل"
- Item 3: priorityAr = "مستمر"
- title: Max 50 characters in Arabic
- 🚨 CRITICAL: Each step MUST be 165-190 characters
  ❌ REJECTED if step < 165 chars - TOO SHORT
  ❌ REJECTED if step > 190 chars - TOO LONG
- Use 2ND PERSON - address the person directly
- 👤 GENDER-AWARE: Determine gender from person's name. For FEMALES, use feminine verb forms:
  ✅ Female: افعلي، تستطيعين، طوّري، حسّني، ركّزي، ابدئي، اعملي، قومي
  ✅ Male: افعل، تستطيع، طوّر، حسّن، ركّز، ابدأ، اعمل، قم

DEVELOPMENT PLAN (4 tracks, 5 resources each) - SELECT FROM PROVIDED LIST ONLY:
- categoryTitle: Max 30 characters in Arabic - customize based on person's needs
- CRITICAL: You MUST select resources ONLY from the AVAILABLE_RESOURCES list below

${getResourceListForPrompt()}`;
}

/**
 * Build standard JSON template (for < 6 reviews)
 */
function buildStandardJsonTemplate(employeeName, scoreData) {
  // Ensure scores have valid values (null is valid JSON, undefined is not)
  const overallScore = scoreData.overallScore ?? 0;
  const statusLabelAr = scoreData.statusLabelAr || 'غير محدد';
  const clarity = scoreData.coreMetricScores?.clarity ?? overallScore;
  const efficiency = scoreData.coreMetricScores?.efficiency ?? overallScore;
  const safety = scoreData.coreMetricScores?.safety ?? overallScore;
  const empowerment = scoreData.coreMetricScores?.empowerment ?? overallScore;

  return `================================================================================
SECTION 5: JSON TEMPLATE - STANDARD FORMAT (EXACT STRUCTURE REQUIRED)
================================================================================

{
  "header": {
    "employeeName": "${employeeName}",
    "executiveSummary": "تُظهر قدرات استثنائية في بناء فرق عمل متماسكة وتحقيق نتائج ملموسة من خلال التواصل الفعال والرؤية الاستراتيجية الواضحة. تتميز بقدرتك على اتخاذ قرارات سريعة ومدروسة مع الحفاظ على بيئة عمل إيجابية تشجع على الإبداع والابتكار. لديك فرص للنمو في مجالات التفويض الفعال وتمكين أعضاء الفريق من تحمل مسؤوليات أكبر، بالإضافة إلى تعزيز التواصل الاستباقي مع فريقك حول الأولويات والتوقعات المتغيرة."
  },
  "leadershipPath": {
    "score": ${overallScore},
    "statusLabelAr": "${statusLabelAr}"
  },
  "coreMetrics": [
    {"id": "clarity", "score": ${clarity}, "bulletPoints": ["[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]"]},
    {"id": "efficiency", "score": ${efficiency}, "bulletPoints": ["[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]"]},
    {"id": "safety", "score": ${safety}, "bulletPoints": ["[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]"]},
    {"id": "empowerment", "score": ${empowerment}, "bulletPoints": ["[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]", "[80-83 chars, 2nd person أنت]"]}
  ],
  "strengths": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "weaknesses": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "personalityAnalysis": {
    "overview": "تجمع بين الحزم والتعاطف في أسلوبك القيادي، مما يخلق توازناً فريداً بين تحقيق النتائج وبناء العلاقات. تتميز بقدرتك على التفكير الاستراتيجي مع الاهتمام بالتفاصيل التشغيلية. شخصيتك تجمع بين الانضباط الذاتي والانفتاح على الأفكار الجديدة، مع ميل طبيعي نحو القيادة والتأثير الإيجابي في الآخرين.",
    "mbpiType": "INTJ",
    "enneagramType": "Type 8",
    "discType": "High D",
    "bigFiveType": "High Conscientiousness",
    "strengths": ["تتمتعين بقدرة عالية على التواصل الفعال مع الآخرين", "لديكِ مهارة في تحفيز الفريق وبث روح التعاون", "تتحلّين بوعي ذاتي واضح أثناء تفاعلاتك مع من حولك", "تمتلكين تفكيرًا نقديًا يساعدك على تحليل المشكلات", "لديكِ قدرة جيدة على بناء العلاقات والحفاظ عليها"],
    "weaknesses": ["تميلين أحيانًا إلى تجنّب الصراع في بعض المواقف", "تجدين صعوبة في قول لا للآخرين عند الحاجة", "قد تفرطين أحيانًا في الاهتمام بالآخرين على حساب نفسك", "تحتاجين إلى تطوير مهارات التفاوض لديكِ", "تسعين إلى تحسين أسلوب تواصلك ليكون أكثر حزمًا"]
  },
  "teamVoice": [
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"}
  ],
  "developmentCompass": [
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]"
  ],
  "roadmap": [
    {"title": "", "priorityAr": "الأولوية القصوى", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]},
    {"title": "", "priorityAr": "عاجل", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]},
    {"title": "", "priorityAr": "مستمر", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]}
  ],
  "developmentPlan": [
    {"categoryTitle": "بناء الثقة", "resources": [
      {"id": "speed-of-trust", "title": "سرعة الثقة"},
      {"id": "dare-to-lead", "title": "تجرأ على القيادة"},
      {"id": "fearless-organization", "title": "المؤسسة التي لا تهاب"},
      {"id": "frei-trust", "title": "كيف تبني الثقة وتستعيدها"},
      {"id": "five-dysfunctions", "title": "خلل العمل الجماعي الخمسة"}
    ]},
    {"categoryTitle": "التواصل الفعال", "resources": [
      {"id": "crucial-conversations", "title": "محادثات حاسمة"},
      {"id": "radical-candor", "title": "الصراحة المطلقة"},
      {"id": "nonviolent-communication", "title": "التواصل غير العنيف"},
      {"id": "difficult-conversations", "title": "محادثات صعبة"},
      {"id": "treasure-speak", "title": "كيف تتحدث لكي يرغب الناس في الاستماع إليك"}
    ]},
    {"categoryTitle": "التفويض والتمكين", "resources": [
      {"id": "turn-ship-around", "title": "اقلب السفينة"},
      {"id": "multipliers", "title": "المضاعفون"},
      {"id": "one-minute-manager", "title": "مدير الدقيقة الواحدة"},
      {"id": "coaching-habit", "title": "عادة التدريب"},
      {"id": "pink-motivation", "title": "لغز التحفيز"}
    ]},
    {"categoryTitle": "الذكاء العاطفي", "resources": [
      {"id": "emotional-intelligence", "title": "الذكاء العاطفي"},
      {"id": "primal-leadership", "title": "القيادة البدائية"},
      {"id": "brown-vulnerability", "title": "قوة الضعف"},
      {"id": "eq-edge", "title": "حافة الذكاء العاطفي"},
      {"id": "mindset", "title": "طريقة التفكير"}
    ]}
  ]
}

⚠️ STANDARD REPORT VALIDATION CHECKLIST - VERIFY BEFORE SUBMITTING:
□ strengths has 3 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ weaknesses has 3 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ All text uses 2ND PERSON (أنت/تُظهر/لديك) - NO 3rd person or names!
□ bigFiveType is EXACTLY ONE of: High Openness, High Conscientiousness, High Extraversion, High Agreeableness, High Neuroticism
□ Each roadmap step is 133-140 chars and uses 2nd person (أنت) - STRICT
□ coreMetrics has exactly 4 items (clarity, efficiency, safety, empowerment) with 3 bullets each
□ Each teamVoice: title 1-2 words (topic only), content 21-22 words - STRICT
□ developmentPlan has 4 categories with 5 resources each
□ Each core metric bullet point is 80-83 chars - STRICT`;
}

/**
 * Build extended JSON template (for 6+ reviews)
 */
function buildExtendedJsonTemplate(employeeName, scoreData) {
  // Ensure scores have valid values (null is valid JSON, undefined is not)
  const overallScore = scoreData.overallScore ?? 0;
  const statusLabelAr = scoreData.statusLabelAr || 'غير محدد';
  const clarity = scoreData.coreMetricScores?.clarity ?? overallScore;
  const efficiency = scoreData.coreMetricScores?.efficiency ?? overallScore;
  const safety = scoreData.coreMetricScores?.safety ?? overallScore;
  const empowerment = scoreData.coreMetricScores?.empowerment ?? overallScore;

  return `================================================================================
SECTION 5: JSON TEMPLATE - EXTENDED FORMAT (6+ REVIEWS - EXACT STRUCTURE REQUIRED)
================================================================================

{
  "header": {
    "employeeName": "${employeeName}",
    "executiveSummary": "تُظهر قدرات استثنائية في بناء فرق عمل متماسكة وتحقيق نتائج ملموسة من خلال التواصل الفعال والرؤية الاستراتيجية الواضحة. تتميز بقدرتك على اتخاذ قرارات سريعة ومدروسة مع الحفاظ على بيئة عمل إيجابية تشجع على الإبداع والابتكار.",
    "executiveSummary2": "لديك فرص واعدة للنمو في مجالات التفويض الفعال وتمكين أعضاء الفريق من تحمل مسؤوليات أكبر. يمكنك تعزيز التواصل الاستباقي مع فريقك حول الأولويات والتوقعات المتغيرة لتحقيق تأثير أكبر على المدى الطويل."
  },
  "leadershipPath": {
    "score": ${overallScore},
    "statusLabelAr": "${statusLabelAr}"
  },
  "coreMetrics": [
    {"id": "clarity", "score": ${clarity}, "bulletPoints": ["يمكنك تحسين وضوح الأولويات عند مشاركتها مع فريقك بشكل أفضل", "ركّز على تقديم توجيهات أوضح للمهام والتوقعات المطلوبة من الفريق", "اعمل على وضع أهداف أكثر قابلية للقياس ومتابعة التقدم بانتظام", "طوّر طريقة تقديم الملاحظات البناءة لمساعدة الفريق على التحسن", "استثمر في تعزيز التواصل الاستباقي مع أعضاء فريقك باستمرار"]},
    {"id": "efficiency", "score": ${efficiency}, "bulletPoints": ["يمكنك تحسين إدارة الوقت والموارد المتاحة بشكل أكثر فعالية", "ركّز على إنجاز المهام ضمن الجداول الزمنية المحددة بدقة أكبر", "اعمل على تحسين العمليات باستمرار لزيادة الإنتاجية والكفاءة", "طوّر قدرتك على التوازن بين الجودة والسرعة في تنفيذ المشاريع", "حاول تحسين تفويض المهام وتوزيع المسؤوليات بشكل أفضل"]},
    {"id": "safety", "score": ${safety}, "bulletPoints": ["يمكنك تعزيز بيئة العمل لتكون أكثر دعماً وتحفيزاً للإبداع", "ركّز على الاستماع لآراء الفريق باهتمام أكبر واحترام وجهات نظرهم", "اعمل على التعامل مع الأخطاء كفرص للتعلم بدلاً من اللوم", "طوّر ثقافة الحوار المفتوح والنقاشات البناءة مع الفريق", "استثمر في تعزيز ثقافة التغذية الراجعة المتبادلة باستمرار"]},
    {"id": "empowerment", "score": ${empowerment}, "bulletPoints": ["يمكنك منح فريقك مزيداً من الصلاحيات والاستقلالية في القرارات", "ركّز على دعم نمو أعضاء الفريق مهنياً والمساهمة في تطورهم", "اعمل على توفير المزيد من فرص التدريب والتطوير للفريق", "طوّر ثقتك في قدرات فريقك وامنحهم مساحة أكبر للإبداع", "حاول زيادة مشاركة الفريق في القرارات الاستراتيجية المهمة"]}
  ],
  "strengths": [
    {"title": "قيادة استراتيجية متميزة", "description": "تمتلك رؤية واضحة للمستقبل وتستطيع ترجمتها إلى خطط عمل قابلة للتنفيذ مع إشراك الفريق"},
    {"title": "بناء علاقات مهنية قوية", "description": "تتميز بقدرتك على بناء جسور الثقة مع أعضاء الفريق وأصحاب المصلحة"},
    {"title": "اتخاذ قرارات فعالة", "description": "تتخذ قرارات مدروسة في الوقت المناسب مع مراعاة مختلف وجهات النظر"},
    {"title": "إدارة الوقت والأولويات", "description": "تنظم العمل بكفاءة وتحدد الأولويات بشكل يضمن تحقيق الأهداف في الوقت المحدد"},
    {"title": "التواصل الفعال", "description": "تتميز بقدرتك على إيصال الأفكار بوضوح وتستمع باهتمام لآراء الآخرين"},
    {"title": "حل المشكلات", "description": "تتعامل مع التحديات بمنهجية وتجد حلولاً إبداعية للمشكلات المعقدة"}
  ],
  "weaknesses": [
    {"title": "فرصة لتطوير التفويض", "description": "يمكنك تعزيز قدرات الفريق من خلال منحهم مزيداً من المسؤوليات والصلاحيات"},
    {"title": "مجال لتحسين المرونة", "description": "لديك فرصة لتطوير قدرتك على التكيف مع المتغيرات السريعة وتعديل الخطط"},
    {"title": "تطوير التواصل الاستباقي", "description": "يمكنك تعزيز التواصل المسبق مع الفريق حول التغييرات والأولويات"},
    {"title": "تعزيز ثقافة التغذية الراجعة", "description": "لديك فرصة لزيادة وتيرة تقديم الملاحظات البناءة لأعضاء الفريق"},
    {"title": "تطوير مهارات التدريب", "description": "يمكنك تخصيص وقت أكبر لتوجيه وتطوير أعضاء الفريق بشكل فردي"},
    {"title": "موازنة العمل والتفاصيل", "description": "لديك فرصة للموازنة بين الرؤية الاستراتيجية والاهتمام بالتفاصيل التشغيلية"}
  ],
  "personalityAnalysis": {
    "overview": "تجمع بين الحزم والتعاطف في أسلوبك القيادي، مما يخلق توازناً فريداً بين تحقيق النتائج وبناء العلاقات. تتميز بقدرتك على التفكير الاستراتيجي مع الاهتمام بالتفاصيل التشغيلية.",
    "overview2": "شخصيتك تجمع بين الانضباط الذاتي والانفتاح على الأفكار الجديدة، مع ميل طبيعي نحو القيادة والتأثير الإيجابي في الآخرين. تتميز بالقدرة على تحفيز الفريق وإلهامهم لتحقيق الأهداف.",
    "mbpiType": "INTJ",
    "enneagramType": "Type 8",
    "discType": "High D",
    "bigFiveType": "High Conscientiousness",
    "strengths": ["لديك قدرة عالية على التواصل الفعال والمؤثر", "تتميز بالحزم والوضوح في اتخاذ القرارات", "لديك مهارة متميزة في بناء العلاقات المهنية", "تمتلك رؤية استراتيجية واضحة وملهمة", "لديك التزام عالٍ بالمعايير والجودة"],
    "weaknesses": ["يمكنك تطوير أسلوب التفويض وتمكين الآخرين", "لديك فرصة لتعزيز المرونة القيادية والتكيف", "يمكنك تحسين سرعة اتخاذ القرارات الروتينية", "لديك مجال لتمكين الفريق من المبادرة أكثر", "يمكنك موازنة الدقة مع الكفاءة والسرعة"]
  },
  "teamVoice": [
    {"title": "وضوح الرؤية والتوجيه", "content": "يُشيد أعضاء الفريق بوضوح الرؤية الاستراتيجية والقدرة على توصيل الأهداف بشكل مفهوم"},
    {"title": "بيئة العمل والدعم", "content": "يُقدّر الفريق البيئة الإيجابية والدعم المتاح مع اقتراحات لتعزيز التطوير المهني"},
    {"title": "التواصل والتفاعل", "content": "يُثني الفريق على سهولة التواصل والاستماع الفعال مع رغبة في المزيد من الاجتماعات"},
    {"title": "التمكين والثقة", "content": "يُعبّر الفريق عن تقديره للثقة الممنوحة مع اقتراحات لتوسيع نطاق الصلاحيات"},
    {"title": "التطوير المهني", "content": "يُقدّر الفريق الاهتمام بنموهم المهني مع اقتراحات لمزيد من فرص التدريب والتوجيه"}
  ],
  "developmentCompass": [
    "قدرتك على تحفيز الآخرين بفعالية",
    "مهاراتك في التواصل وبناء العلاقات",
    "قدرتك على فهم احتياجات الفريق",
    "التزامك بتطوير الأفراد وتحفيزهم",
    "قدرتك على التكيف مع التغيرات السريعة"
  ],
  "roadmap": [
    {"title": "استعادة الأمان النفسي", "priorityAr": "الأولوية القصوى", "steps": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4", "خطوة 5"]},
    {"title": "تطوير التفويض", "priorityAr": "عاجل", "steps": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4", "خطوة 5"]},
    {"title": "تحسين التواصل", "priorityAr": "مستمر", "steps": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4", "خطوة 5"]}
  ],
  "developmentPlan": [
    {"categoryTitle": "بناء الثقة", "resources": [
      {"id": "speed-of-trust", "title": "سرعة الثقة"},
      {"id": "dare-to-lead", "title": "تجرأ على القيادة"},
      {"id": "fearless-organization", "title": "المؤسسة التي لا تهاب"},
      {"id": "frei-trust", "title": "كيف تبني الثقة وتستعيدها"},
      {"id": "five-dysfunctions", "title": "خلل العمل الجماعي الخمسة"}
    ]},
    {"categoryTitle": "التواصل الفعال", "resources": [
      {"id": "crucial-conversations", "title": "محادثات حاسمة"},
      {"id": "radical-candor", "title": "الصراحة المطلقة"},
      {"id": "nonviolent-communication", "title": "التواصل غير العنيف"},
      {"id": "difficult-conversations", "title": "محادثات صعبة"},
      {"id": "treasure-speak", "title": "كيف تتحدث لكي يرغب الناس في الاستماع إليك"}
    ]},
    {"categoryTitle": "التفويض والتمكين", "resources": [
      {"id": "turn-ship-around", "title": "اقلب السفينة"},
      {"id": "multipliers", "title": "المضاعفون"},
      {"id": "one-minute-manager", "title": "مدير الدقيقة الواحدة"},
      {"id": "coaching-habit", "title": "عادة التدريب"},
      {"id": "pink-motivation", "title": "لغز التحفيز"}
    ]},
    {"categoryTitle": "الذكاء العاطفي", "resources": [
      {"id": "emotional-intelligence", "title": "الذكاء العاطفي"},
      {"id": "primal-leadership", "title": "القيادة البدائية"},
      {"id": "brown-vulnerability", "title": "قوة الضعف"},
      {"id": "eq-edge", "title": "حافة الذكاء العاطفي"},
      {"id": "mindset", "title": "طريقة التفكير"}
    ]}
  ]
}`;
}

/**
 * Build gigantic JSON template (for 16+ reviews)
 */
function buildGiganticJsonTemplate(employeeName, scoreData) {
  // Ensure scores have valid values (null is valid JSON, undefined is not)
  const overallScore = scoreData.overallScore ?? 0;
  const statusLabelAr = scoreData.statusLabelAr || 'غير محدد';
  const clarity = scoreData.coreMetricScores?.clarity ?? overallScore;
  const efficiency = scoreData.coreMetricScores?.efficiency ?? overallScore;
  const safety = scoreData.coreMetricScores?.safety ?? overallScore;
  const empowerment = scoreData.coreMetricScores?.empowerment ?? overallScore;

  return `================================================================================
SECTION 5: JSON TEMPLATE - GIGANTIC FORMAT (16+ REVIEWS - EXACT STRUCTURE REQUIRED)
================================================================================

{
  "header": {
    "employeeName": "${employeeName}",
    "executiveSummary": "تُظهر قدرات استثنائية في بناء فرق عمل متماسكة وتحقيق نتائج ملموسة من خلال التواصل الفعال والرؤية الاستراتيجية الواضحة. تتميز بقدرتك على اتخاذ قرارات سريعة ومدروسة مع الحفاظ على بيئة عمل إيجابية تشجع على الإبداع والابتكار.",
    "executiveSummary2": {
      "title": "[20-25 chars - UNIQUE]",
      "bulletPoints": ["[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"]
    },
    "executiveSummary3": {
      "title": "[20-25 chars - UNIQUE strategic]",
      "bulletPoints": ["[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"]
    }
  },
  "leadershipPath": {
    "score": ${overallScore},
    "statusLabelAr": "${statusLabelAr}"
  },
  "coreMetrics": [
    {"id": "clarity", "score": ${clarity}, "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]},
    {"id": "efficiency", "score": ${efficiency}, "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]},
    {"id": "safety", "score": ${safety}, "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]},
    {"id": "empowerment", "score": ${empowerment}, "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]}
  ],
  "strengths": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "weaknesses": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "personalityAnalysis": {
    "overview": "[max 350 chars - personality types focus]",
    "overview2": {
      "title": "[20-25 chars - UNIQUE]",
      "bulletPoints": ["[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"]
    },
    "overview3": {
      "title": "[20-25 chars - UNIQUE behavioral]",
      "bulletPoints": ["[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"]
    },
    "mbpiType": "INTJ",
    "enneagramType": "Type 8",
    "discType": "High D",
    "bigFiveType": "High Conscientiousness",
    "strengths": ["[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]"],
    "weaknesses": ["[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]"]
  },
  "teamVoice": [
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"},
    {"title": "[1-2 words]", "content": "[21-22 words]"}
  ],
  "developmentCompass": [
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]",
    "[45-55 chars - UNIQUE soft skill]"
  ],
  "roadmap": [
    {"title": "[max 50 chars]", "priorityAr": "الأولوية القصوى", "steps": ["[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]"]},
    {"title": "[max 50 chars]", "priorityAr": "عاجل", "steps": ["[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]"]},
    {"title": "[max 50 chars]", "priorityAr": "مستمر", "steps": ["[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]", "[165-190 chars]"]}
  ],
  "developmentPlan": [
    {"categoryTitle": "بناء الثقة", "resources": [
      {"id": "speed-of-trust", "title": "سرعة الثقة"},
      {"id": "dare-to-lead", "title": "تجرأ على القيادة"},
      {"id": "fearless-organization", "title": "المؤسسة التي لا تهاب"},
      {"id": "frei-trust", "title": "كيف تبني الثقة وتستعيدها"},
      {"id": "five-dysfunctions", "title": "خلل العمل الجماعي الخمسة"}
    ]},
    {"categoryTitle": "التواصل الفعال", "resources": [
      {"id": "crucial-conversations", "title": "محادثات حاسمة"},
      {"id": "radical-candor", "title": "الصراحة المطلقة"},
      {"id": "nonviolent-communication", "title": "التواصل غير العنيف"},
      {"id": "difficult-conversations", "title": "محادثات صعبة"},
      {"id": "treasure-speak", "title": "كيف تتحدث لكي يرغب الناس في الاستماع إليك"}
    ]},
    {"categoryTitle": "التفويض والتمكين", "resources": [
      {"id": "turn-ship-around", "title": "اقلب السفينة"},
      {"id": "multipliers", "title": "المضاعفون"},
      {"id": "one-minute-manager", "title": "مدير الدقيقة الواحدة"},
      {"id": "coaching-habit", "title": "عادة التدريب"},
      {"id": "pink-motivation", "title": "لغز التحفيز"}
    ]},
    {"categoryTitle": "الذكاء العاطفي", "resources": [
      {"id": "emotional-intelligence", "title": "الذكاء العاطفي"},
      {"id": "primal-leadership", "title": "القيادة البدائية"},
      {"id": "brown-vulnerability", "title": "قوة الضعف"},
      {"id": "eq-edge", "title": "حافة الذكاء العاطفي"},
      {"id": "mindset", "title": "طريقة التفكير"}
    ]}
  ]
}

⚠️ GIGANTIC REPORT VALIDATION CHECKLIST - VERIFY BEFORE SUBMITTING:
□ strengths has 9 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ weaknesses has 9 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ teamVoice has 12 items - each UNIQUE topic, no duplicates
□ developmentCompass has 9 items - 45-55 chars each, UNIQUE from all sections
□ Each roadmap priority has 10 steps (165-190 chars each)
□ executiveSummary3 exists with title + 5 bulletPoints
□ overview3 exists with title + 5 bulletPoints
□ All coreMetrics have 7 bullet points each
□ All text uses 2ND PERSON (أنت/تُظهر/لديك) - NO 3rd person!
□ bigFiveType is ONE OF: High Openness, High Conscientiousness, High Extraversion, High Agreeableness, High Neuroticism`;
}

/**
 * Logger utility for consistent logging
 */
const logger = {
  info: (message, data = null) => {
    console.log(`[INFO] ${new Date().toISOString()} - ${message}`, data ? data : '');
  },
  error: (message, error = null) => {
    console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, error ? error : '');
  },
  debug: (message, data = null) => {
    console.log(`[DEBUG] ${new Date().toISOString()} - ${message}`, data ? data : '');
  }
};

/**
 * Fetch with timeout support
 */
async function fetchWithTimeout(url, options, timeout = REQUEST_TIMEOUT) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    if (error.name === 'AbortError') {
      throw new Error('انتهت مهلة الاتصال. يرجى المحاولة مرة أخرى.');
    }
    throw error;
  }
}

/**
 * Safely parse JSON with error handling
 * Handles markdown code blocks that AI might return
 */
function safeJSONParse(content, context = 'response') {
  // Handle empty or null content
  if (!content || typeof content !== 'string') {
    logger.error(`Empty or invalid content in ${context}`, {
      contentType: typeof content,
      contentLength: content?.length || 0
    });
    throw new Error(`استجابة فارغة من الذكاء الاصطناعي. الرجاء المحاولة مرة أخرى.`);
  }

  try {
    // First, try to parse directly
    return JSON.parse(content);
  } catch (firstError) {
    // If direct parse fails, try to extract JSON from markdown code blocks
    try {
      let cleanedContent = content;

      // Remove markdown code blocks (```json ... ``` or ``` ... ```)
      const codeBlockMatch = content.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (codeBlockMatch) {
        cleanedContent = codeBlockMatch[1].trim();
      }

      // Also try to find JSON object/array in the content
      if (!codeBlockMatch) {
        const jsonMatch = content.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
        if (jsonMatch) {
          cleanedContent = jsonMatch[1].trim();
        }
      }

      return JSON.parse(cleanedContent);
    } catch (secondError) {
      // Log more details to help debug
      const preview = content.substring(0, 500);
      const ending = content.length > 500 ? content.substring(content.length - 200) : '';
      logger.error(`Failed to parse JSON in ${context}`, {
        error: secondError.message,
        parseError: firstError.message,
        contentLength: content.length,
        contentPreview: preview,
        contentEnding: ending,
        startsWithBrace: content.trim().startsWith('{'),
        endsWithBrace: content.trim().endsWith('}')
      });

      // Provide more helpful error message
      if (content.includes('error') || content.includes('Error')) {
        throw new Error(`خطأ من الذكاء الاصطناعي: ${content.substring(0, 200)}`);
      }
      throw new Error(`فشل في تحليل استجابة الذكاء الاصطناعي. الرجاء المحاولة مرة أخرى.`);
    }
  }
}

/**
 * Validate required fields in feedback data
 */
function validateFeedbackData(feedbackData) {
  if (!feedbackData) {
    throw new Error('بيانات التغذية الراجعة مطلوبة.');
  }
  if (!Array.isArray(feedbackData)) {
    throw new Error('بيانات التغذية الراجعة يجب أن تكون في شكل قائمة.');
  }
  if (feedbackData.length === 0) {
    throw new Error('ملف البيانات فارغ. يرجى رفع ملف يحتوي على تقييمات.');
  }
  // Check if all rows are empty objects
  const nonEmptyRows = feedbackData.filter(row => Object.keys(row).length > 0);
  if (nonEmptyRows.length === 0) {
    throw new Error('جميع صفوف البيانات فارغة. يرجى التحقق من الملف.');
  }
  return nonEmptyRows;
}

/**
 * Generate leadership report from feedback data using OpenRouter
 * @param {Array<Object>} feedbackData - Parsed feedback from CSV/Excel
 * @param {string} employeeName - Name of the employee
 * @param {string} jobTitle - Job title of the employee
 * @returns {Promise<Object>} Generated report data
 */
export async function generateReportFromFeedback(feedbackData, employeeName, jobTitle, leaderAssessment = null, periodicEvaluation = null, writingStyle = 'standard') {
  console.log(`\n${'='.repeat(80)}`);
  console.log(`[SOLO REPORT] Starting generation for: ${employeeName}`);
  console.log(`[SOLO REPORT] Writing style: ${writingStyle}`);
  console.log(`${'='.repeat(80)}`);

  // Validate inputs
  const validatedData = validateFeedbackData(feedbackData);

  if (!employeeName || employeeName.trim() === '') {
    throw new Error('اسم الموظف مطلوب.');
  }
  if (!jobTitle || jobTitle.trim() === '') {
    throw new Error('المسمى الوظيفي مطلوب.');
  }

  // CRITICAL: Determine report type based on feedback count (3 types)
  const reviewerCount = validatedData?.length || 0;
  const isGiganticMode = reviewerCount >= GIGANTIC_REPORT_THRESHOLD;
  const isExtendedMode = !isGiganticMode && reviewerCount >= EXTENDED_REPORT_THRESHOLD;
  const reportType = isGiganticMode ? 'GIGANTIC' : (isExtendedMode ? 'EXTENDED' : 'STANDARD');

  console.log(`[SOLO REPORT] Reviewer count: ${reviewerCount}`);
  console.log(`[SOLO REPORT] Thresholds: Extended=${EXTENDED_REPORT_THRESHOLD}, Gigantic=${GIGANTIC_REPORT_THRESHOLD}`);
  console.log(`[SOLO REPORT] Mode: ${reportType} ✓`);
  console.log(`[SOLO REPORT] Writing style: ${writingStyle}`);

  // Build prompts based on mode and writing style
  let prompts;
  if (isGiganticMode) {
    prompts = buildGiganticSoloPrompts(validatedData, employeeName.trim(), jobTitle.trim(), leaderAssessment, periodicEvaluation, writingStyle);
  } else if (isExtendedMode) {
    prompts = buildExtendedSoloPrompts(validatedData, employeeName.trim(), jobTitle.trim(), leaderAssessment, periodicEvaluation, writingStyle);
  } else {
    prompts = buildStandardSoloPrompts(validatedData, employeeName.trim(), jobTitle.trim(), leaderAssessment, periodicEvaluation, writingStyle);
  }
  const { systemPrompt, userPrompt } = prompts;

  console.log(`[SOLO REPORT] System prompt length: ${systemPrompt.length} chars`);
  console.log(`[SOLO REPORT] User prompt length: ${userPrompt.length} chars`);

  // Determine max tokens based on report type
  const maxTokens = isGiganticMode ? 24000 : (isExtendedMode ? 16000 : 8192);

  try {
    const response = await fetchWithTimeout(OPENROUTER_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000',
        'X-Title': 'Leadership Feedback Analyzer'
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.5,
        max_tokens: maxTokens
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (response.status === 401) {
        throw new Error('مفتاح API غير صالح. يرجى التحقق من الإعدادات.');
      } else if (response.status === 429) {
        throw new Error('تم تجاوز حد الطلبات. يرجى الانتظار قليلاً والمحاولة مرة أخرى.');
      } else if (response.status === 500) {
        throw new Error('خطأ في خادم الذكاء الاصطناعي. يرجى المحاولة لاحقاً.');
      }
      throw new Error(`خطأ: ${errorData.error?.message || JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('لم يتم استلام رد من خدمة الذكاء الاصطناعي.');
    }

    console.log(`[SOLO REPORT] AI response length: ${content.length} chars`);

    const report = safeJSONParse(content, 'report generation');

    // Validate and log structure
    const validation = {
      hasExecutiveSummary2: !!report.header?.executiveSummary2,
      hasOverview2: !!report.personalityAnalysis?.overview2,
      strengthsCount: Array.isArray(report.strengths) ? report.strengths.length : 0,
      weaknessesCount: Array.isArray(report.weaknesses) ? report.weaknesses.length : 0,
      teamVoiceCount: Array.isArray(report.teamVoice) ? report.teamVoice.length : 0,
      bulletPointCounts: Array.isArray(report.coreMetrics) ? report.coreMetrics.map(m => Array.isArray(m.bulletPoints) ? m.bulletPoints.length : 0) : [],
      roadmapStepCounts: Array.isArray(report.roadmap) ? report.roadmap.map(r => Array.isArray(r.steps) ? r.steps.length : 0) : []
    };

    console.log(`[SOLO REPORT] Validation:`, validation);

    if (isGiganticMode) {
      const issues = [];
      if (!validation.hasExecutiveSummary2) issues.push('Missing executiveSummary2');
      if (!report.header?.executiveSummary3) issues.push('Missing executiveSummary3');
      if (!validation.hasOverview2) issues.push('Missing overview2');
      if (!report.personalityAnalysis?.overview3) issues.push('Missing overview3');
      if (validation.strengthsCount < 9) issues.push(`Strengths: ${validation.strengthsCount}/9`);
      if (validation.weaknessesCount < 9) issues.push(`Weaknesses: ${validation.weaknessesCount}/9`);
      if (validation.teamVoiceCount < 12) issues.push(`TeamVoice: ${validation.teamVoiceCount}/12`);
      if ((report.developmentCompass?.length || 0) < 9) issues.push(`DevCompass: ${report.developmentCompass?.length || 0}/9`);

      if (issues.length > 0) {
        console.error(`[SOLO GIGANTIC VALIDATION FAILED]`, issues);
      } else {
        console.log(`[SOLO GIGANTIC VALIDATION PASSED] ✓ All gigantic fields present`);
      }
    } else if (isExtendedMode) {
      const issues = [];
      if (!validation.hasExecutiveSummary2) issues.push('Missing executiveSummary2');
      if (!validation.hasOverview2) issues.push('Missing overview2');
      if (validation.strengthsCount < 6) issues.push(`Strengths: ${validation.strengthsCount}/6`);
      if (validation.weaknessesCount < 6) issues.push(`Weaknesses: ${validation.weaknessesCount}/6`);
      if (validation.teamVoiceCount < 5) issues.push(`TeamVoice: ${validation.teamVoiceCount}/5`);

      if (issues.length > 0) {
        console.error(`[SOLO EXTENDED VALIDATION FAILED]`, issues);
      } else {
        console.log(`[SOLO EXTENDED VALIDATION PASSED] ✓ All extended fields present`);
      }
    }

    // Add colors to core metrics
    if (report.coreMetrics && Array.isArray(report.coreMetrics)) {
      report.coreMetrics = report.coreMetrics.map(metric => ({
        ...metric,
        color: getColorForScore(metric.score)
      }));
    }

    // Map development plan resources
    if (report.developmentPlan && Array.isArray(report.developmentPlan)) {
      report.developmentPlan = mapDevelopmentPlanToUrls(report.developmentPlan);
    }

    // Add metadata
    if (report.header) {
      report.header.reviewerCount = reviewerCount;
    }

    report._metadata = {
      scoreData: {
        totalReviewerCount: reviewerCount,
        overallScore: report.leadershipPath?.score || 0
      },
      isExtended: isExtendedMode,
      isGigantic: isGiganticMode,
      reportFormat: reportType,
      generatedAt: new Date().toISOString(),
      reportType: 'single'
    };

    console.log(`[SOLO REPORT COMPLETE] Generated ${reportType} report for ${employeeName}`);
    console.log(`${'='.repeat(80)}\n`);

    return report;
  } catch (error) {
    console.error(`[SOLO REPORT FAILED] ${employeeName}:`, error.message);
    throw error;
  }
}

/**
 * Build STANDARD prompts for solo report (< 6 reviewers)
 */
function buildStandardSoloPrompts(feedbackData, employeeName, jobTitle, leaderAssessment, periodicEvaluation, writingStyle = 'standard') {
  const feedbackSummary = feedbackData.map((item, idx) =>
    `Feedback ${idx + 1}: ${Object.entries(item).slice(0, 5).map(([k, v]) => `${k}: ${v}`).join(', ')}`
  ).join('\n');

  // Build writing style instructions for direct mode
  const directStyleInstructions = writingStyle === 'direct' ? `
🎯 DIRECT WRITING STYLE (أسلوب مباشر) - MANDATORY:

🚫 AVOID HEDGING WORDS - Be DIRECT and ASSERTIVE:
DO NOT USE these words/phrases: ${HEDGING_WORDS_TO_AVOID.join('، ')}

Instead of hedging, state observations directly:
❌ "يلاحظ أن لديك قدرة..." → ✅ "لديك قدرة..."
❌ "يبدو أنك تتميز..." → ✅ "تتميز..."
❌ "ربما تحتاج إلى..." → ✅ "تحتاج إلى..."
❌ "قد تكون قادراً على..." → ✅ "أنت قادر على..."

👤 GENDER-AWARE WRITING (مراعاة الجنس):
The candidate's name is "${employeeName}". Based on this Arabic name, determine if the person is male or female, then use the correct grammatical forms throughout the report:
- For MALE: Use masculine verb conjugations (تتميز، لديكَ، تحتاج، تعمل، تقود)
- For FEMALE: Use feminine verb conjugations (تتميزين، لديكِ، تحتاجين، تعملين، تقودين)

Examples:
- Male: "لديكَ قدرة عالية على التواصل" / "تتميز بمهاراتك القيادية"
- Female: "لديكِ قدرة عالية على التواصل" / "تتميزين بمهاراتكِ القيادية"
` : '';

  const systemPrompt = `You are an expert HR analyst. Generate a leadership report in Arabic.

RULES:
1. 🚨 ALL OUTPUT MUST BE IN ARABIC (العربية) - NO ENGLISH TEXT ALLOWED except personality type codes (INTJ, Type 8, High D, etc.)
2. Use 2nd person (أنت) to address the person directly
3. Output ONLY valid JSON - no markdown, no explanation
${directStyleInstructions}
STANDARD FORMAT:
- strengths: EXACTLY 3 items - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في) - DO NOT repeat title words - 120-175 chars
- weaknesses: EXACTLY 3 items - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل، مجال للنمو) - DO NOT always use "تحتاج إلى"
- coreMetrics bulletPoints: EXACTLY 3 per metric
- teamVoice: EXACTLY 4 items (1 positive + 3 improvement) - 📝 Quote actual feedback, rephrase to anonymize, ALL DIFFERENT starters
- developmentCompass: EXACTLY 5 soft skills (45-55 chars each) - based on challenges faced, MUST be unique from ALL other sections
- roadmap steps: EXACTLY 4 per priority
- executiveSummary2: Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
- overview2: Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type

🚨 بوصلة التطوير (developmentCompass) - CRITICAL RULES 🚨
- 5 soft skills the person should directly work on
- Based on their specific challenges and problems from feedback
- Each skill must be 45-55 characters in Arabic
- MUST be COMPLETELY UNIQUE - cannot overlap with strengths, weaknesses, roadmap, or any other section
- Focus on actionable soft skills: communication, emotional intelligence, conflict resolution, time management, etc.

🚨🚨🚨 CRITICAL UNIQUENESS RULE FOR executiveSummary2 & overview2 🚨🚨🚨

⛔ ZERO REPETITION ALLOWED:
  - NO paraphrasing of content from other sections
  - NO similar ideas with different words
  - NO overlapping themes or concepts
  - The MEANING must be completely different, not just the wording

✅ WHAT MAKES CONTENT TRULY UNIQUE:
  - If you removed executiveSummary2/overview2, the report would be MISSING important insights
  - Each bullet reveals something NOT deducible from other sections
  - A reader should learn NEW information, not recognize rephrased content

🔍 SELF-CHECK BEFORE OUTPUT:
  For each bullet in executiveSummary2/overview2, ask:
  "Is this exact insight already covered in strengths, weaknesses, coreMetrics, teamVoice, or roadmap?"
  If YES → DELETE IT and write something completely different

🚨🚨🚨 CRITICAL: BULLET POINT LENGTHS - STRICT ENFORCEMENT 🚨🚨🚨

📌 coreMetrics bulletPoints: EXACTLY 80-83 chars
   ⛔ REJECTED if < 80 or > 83 chars

📌 executiveSummary2 bulletPoints: EXACTLY 60-63 chars
   ⛔ REJECTED if < 60 or > 63 chars

📌 overview2 bulletPoints: EXACTLY 60-63 chars
   ⛔ REJECTED if < 60 or > 63 chars

COUNT EVERY CHARACTER before writing!

⚠️ OTHER LENGTH REQUIREMENTS:
- executiveSummary2/overview2 title: 20-25 chars
- Strengths/Weaknesses title: 37-39 chars
- Strengths/Weaknesses description: ONE FLUID SENTENCE (120-175 chars)
- Team Voice title: 1-2 words (topic only)
- Team Voice content: 21-22 words
- Roadmap steps: 133-140 chars
- developmentCompass items: 45-55 chars each`;

  const userPrompt = `Generate a STANDARD leadership report for ${employeeName} (${jobTitle}).
${writingStyle === 'direct' ? `\n⚠️ IMPORTANT: Use DIRECT writing style - no hedging words, be assertive. Determine gender from the name "${employeeName}" and use correct Arabic verb conjugations.` : ''}

FEEDBACK DATA (${feedbackData.length} reviewers):
${feedbackSummary}
${leaderAssessment ? `\nLEADER ASSESSMENT:\n${leaderAssessment}` : ''}
${periodicEvaluation ? `\nPERIODIC EVALUATION:\n${JSON.stringify(periodicEvaluation)}` : ''}

REQUIRED JSON STRUCTURE:
{
  "header": {
    "employeeName": "${employeeName}",
    "executiveSummary": "[Arabic, 2nd person أنت, max 445 chars]",
    "executiveSummary2": {
      "title": "[UNIQUE Arabic title 20-25 chars, e.g., 'الوضوح والهيكلة']",
      "bulletPoints": ["[60-63 chars - UNIQUE insight]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"]
    }
  },
  "leadershipPath": {"score": [0-100], "statusLabelAr": "[فخر/خضر/صفر/حمر/خطر]"},
  "coreMetrics": [
    {"id": "clarity", "score": [0-100], "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]},
    {"id": "efficiency", "score": [0-100], "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]},
    {"id": "safety", "score": [0-100], "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]},
    {"id": "empowerment", "score": [0-100], "bulletPoints": ["[80-83 chars]", "[80-83 chars]", "[80-83 chars]"]}
  ],
  "strengths": [{"title": "[37-39 chars]", "description": "[120-175 chars, one sentence]"}, {"title": "[37-39 chars]", "description": "[120-175 chars, one sentence]"}, {"title": "[37-39 chars]", "description": "[120-175 chars, one sentence]"}],
  "weaknesses": [{"title": "[37-39 chars]", "description": "[120-175 chars, one sentence]"}, {"title": "[37-39 chars]", "description": "[120-175 chars, one sentence]"}, {"title": "[37-39 chars]", "description": "[120-175 chars, one sentence]"}],
  "personalityAnalysis": {
    "overview": "[Arabic, max 350 chars]",
    "overview2": {
      "title": "[UNIQUE Arabic title 20-25 chars, e.g., 'الوضوح والهيكلة']",
      "bulletPoints": ["[60-63 chars - UNIQUE insight]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"]
    },
    "mbpiType": "[INTJ/etc]", "enneagramType": "[Type 1-9]", "discType": "[High D/I/S/C]", "bigFiveType": "[CHOOSE ONLY ONE: High Openness OR High Conscientiousness OR High Extraversion OR High Agreeableness OR High Neuroticism]",
    "strengths": ["[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]"],
    "weaknesses": ["[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]"]
  },
  "teamVoice": [{"title": "[1-2 words]", "content": "[21-22 words]"}, {"title": "[1-2 words]", "content": "[21-22 words]"}, {"title": "[1-2 words]", "content": "[21-22 words]"}, {"title": "[1-2 words]", "content": "[21-22 words]"}],
  "developmentCompass": ["[45-55 chars - soft skill UNIQUE]", "[45-55 chars]", "[45-55 chars]", "[45-55 chars]", "[45-55 chars]"],
  "roadmap": [
    {"title": "", "priorityAr": "الأولوية القصوى", "steps": ["[133-140 chars, 2nd person]", "[133-140 chars]", "[133-140 chars]", "[133-140 chars]"]},
    {"title": "", "priorityAr": "عاجل", "steps": ["[133-140 chars]", "[133-140 chars]", "[133-140 chars]", "[133-140 chars]"]},
    {"title": "", "priorityAr": "مستمر", "steps": ["[133-140 chars]", "[133-140 chars]", "[133-140 chars]", "[133-140 chars]"]}
  ],
  "developmentPlan": [${buildDevelopmentPlanTemplate()}]
}

${getResourceListForPrompt()}

Output ONLY the JSON.`;

  return { systemPrompt, userPrompt };
}

/**
 * Build EXTENDED prompts for solo report (6+ reviewers)
 */
function buildExtendedSoloPrompts(feedbackData, employeeName, jobTitle, leaderAssessment, periodicEvaluation, writingStyle = 'standard') {
  const feedbackSummary = feedbackData.map((item, idx) =>
    `Feedback ${idx + 1}: ${Object.entries(item).slice(0, 5).map(([k, v]) => `${k}: ${v}`).join(', ')}`
  ).join('\n');

  // Build writing style instructions for direct mode
  const directStyleInstructions = writingStyle === 'direct' ? `
🎯 DIRECT WRITING STYLE (أسلوب مباشر) - MANDATORY:

🚫 AVOID HEDGING WORDS - Be DIRECT and ASSERTIVE:
DO NOT USE these words/phrases: ${HEDGING_WORDS_TO_AVOID.join('، ')}

Instead of hedging, state observations directly:
❌ "يلاحظ أن لديك قدرة..." → ✅ "لديك قدرة..."
❌ "يبدو أنك تتميز..." → ✅ "تتميز..."
❌ "ربما تحتاج إلى..." → ✅ "تحتاج إلى..."
❌ "قد تكون قادراً على..." → ✅ "أنت قادر على..."

👤 GENDER-AWARE WRITING (مراعاة الجنس):
The candidate's name is "${employeeName}". Based on this Arabic name, determine if the person is male or female, then use the correct grammatical forms throughout the report:
- For MALE: Use masculine verb conjugations (تتميز، لديكَ، تحتاج، تعمل، تقود)
- For FEMALE: Use feminine verb conjugations (تتميزين، لديكِ، تحتاجين، تعملين، تقودين)

Examples:
- Male: "لديكَ قدرة عالية على التواصل" / "تتميز بمهاراتك القيادية"
- Female: "لديكِ قدرة عالية على التواصل" / "تتميزين بمهاراتكِ القيادية"
` : '';

  const systemPrompt = `You are an expert HR analyst generating an EXTENDED leadership report.

⚠️ CRITICAL: THIS IS AN EXTENDED REPORT ⚠️
${directStyleInstructions}
MANDATORY EXTENDED REQUIREMENTS:
✓ header.executiveSummary2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
✓ personalityAnalysis.overview2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type
✓ strengths array - EXACTLY 6 items (NOT 3) - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في) - DO NOT repeat title words - 120-175 chars
✓ weaknesses array - EXACTLY 6 items (NOT 3) - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل) - DO NOT always use "تحتاج إلى"
✓ coreMetrics bulletPoints - EXACTLY 5 per metric (NOT 3)
✓ teamVoice array - EXACTLY 5 items (NOT 4) - 🎯 VARY intros - negative feedback as improvement guidance NOT criticism
✓ roadmap steps - EXACTLY 5 per priority (NOT 4)

🚨🚨🚨 CRITICAL UNIQUENESS RULE FOR executiveSummary2 & overview2 🚨🚨🚨

⛔ ZERO REPETITION ALLOWED:
  - NO paraphrasing of content from other sections
  - NO similar ideas with different words
  - NO overlapping themes or concepts
  - The MEANING must be completely different, not just the wording

✅ WHAT MAKES CONTENT TRULY UNIQUE:
  - If you removed executiveSummary2/overview2, the report would be MISSING important insights
  - Each bullet reveals something NOT deducible from other sections
  - A reader should learn NEW information, not recognize rephrased content

🔍 SELF-CHECK BEFORE OUTPUT:
  For each bullet in executiveSummary2/overview2, ask:
  "Is this exact insight already covered in strengths, weaknesses, coreMetrics, teamVoice, or roadmap?"
  If YES → DELETE IT and write something completely different

🚨 CRITICAL - 2ND PERSON ADDRESSING (أنت) - ENTIRE REPORT 🚨
ALL text MUST address the person DIRECTLY using 2nd person (أنت):
- executiveSummary: "تتميز بقدرتك على..." NOT "يتميز بقدرته على..."
- strengths/weaknesses descriptions: "لديك قدرة..." NOT "لديه قدرة..."
- personalityAnalysis overview: "أنت شخص..." NOT "هو شخص..."
- coreMetrics bulletPoints: "تُظهر مهارتك في..." NOT "يُظهر مهارته في..."
- roadmap steps: "حدد المهام التي يمكنك..." NOT "يجب تحديد المهام..."

⚠️ CRITICAL CONTENT RULES:
1. strengths/weaknesses: MUST be derived from ACTUAL FEEDBACK DATA provided - not generic
2. personalityAnalysis.overview/overview2: MUST focus ONLY on analyzing the personality TYPES (MBTI, Enneagram, DISC, Big Five) - NOT personal strengths/weaknesses. Explain what these personality types mean, how they manifest, their characteristics - NOT the person's job performance
3. personalityAnalysis.strengths/weaknesses: MUST be derived from the assigned personality types (MBTI, Enneagram, DISC, Big Five) - specific traits of those personality frameworks, NOT overlapping with main strengths/weaknesses
4. ⛔ ZERO OVERLAP: personalityAnalysis sections must be COMPLETELY DIFFERENT from main strengths/weaknesses - if content appears in one, it CANNOT appear in the other
5. teamVoice: Quote ACTUAL FEEDBACK from employees, rephrase to anonymize, ALL items must start with DIFFERENT words
6. executiveSummary: Make it 42% LONGER than usual - comprehensive and detailed

RULES:
1. 🚨 ALL OUTPUT MUST BE IN ARABIC (العربية) - NO ENGLISH TEXT ALLOWED except personality type codes (INTJ, Type 8, High D, etc.)
2. ⚠️ MANDATORY: Use 2nd person (أنت) EVERYWHERE - address the person DIRECTLY in ALL sections
3. Output ONLY valid JSON`;

  const userPrompt = `Generate an EXTENDED leadership report for ${employeeName} (${jobTitle}).
This candidate has ${feedbackData.length} reviewers (≥6), so use EXTENDED format.
${writingStyle === 'direct' ? `\n⚠️ IMPORTANT: Use DIRECT writing style - no hedging words (يلاحظ، يبدو، ربما، قد), be assertive and clear. Determine gender from the name "${employeeName}" and use correct Arabic verb conjugations.` : ''}

FEEDBACK DATA:
${feedbackSummary}
${leaderAssessment ? `\nLEADER ASSESSMENT:\n${leaderAssessment}` : ''}
${periodicEvaluation ? `\nPERIODIC EVALUATION:\n${JSON.stringify(periodicEvaluation)}` : ''}

🚨 CRITICAL: 2ND PERSON (أنت) ADDRESSING - ENTIRE REPORT 🚨
You MUST write the ENTIRE report addressing the person DIRECTLY:
✓ "أنت تتميز بـ..." ✓ "لديك القدرة على..." ✓ "تُظهر مهاراتك..."
✗ "هو يتميز بـ..." ✗ "لديه القدرة على..." ✗ "يُظهر مهاراته..."

⚠️ CONTENT GENERATION RULES:

1. EXECUTIVE SUMMARY (42% LONGER than usual):
   - Address the person DIRECTLY using أنت
   - Make it comprehensive and detailed
   - ⚠️ STRICTLY ENFORCE: Must be exactly 42% longer - no shorter, no longer
   - Example: "تتميز بقدرتك الاستثنائية على قيادة فريقك..."

2. STRENGTHS/WEAKNESSES (6 each):
   - Extract DIRECTLY from the feedback data above
   - Address using 2nd person: "لديك قدرة على..." NOT "لديه قدرة على..."
   - ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
   - 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars)
   - ✅ Keep it brief, direct, and impactful - single sentence only
   - ❌ NO multi-line descriptions, NO lengthy explanations
   - Each must reference specific observations from reviewers
   - NOT generic leadership traits

3. PERSONALITY ANALYSIS (overview, strengths, weaknesses):
   - ⚠️ STRICT: overview: 11% LONGER than usual - MUST be exactly 11% longer
   - ⚠️ STRICT: overview2: 21% LONGER than usual - MUST be exactly 21% longer
   - Address directly: "أنت شخص يتميز بـ..." NOT "هو شخص يتميز بـ..."
   - After determining MBTI, Enneagram, DISC, Big Five types
   - ⚠️ STRICT: personality strengths/weaknesses: 7-10 words each (min 7, max 10), feminine verbs, direct observation style for weaknesses
   - These personality strengths/weaknesses must be SPECIFIC to those personality types

4. CORE METRICS BULLET POINTS (5 each):
   - ⚠️ STRICT: Each bullet: 80-83 characters (min 80, max 83) - MUST be in range
   - 🎯 IMPROVEMENT FOCUS: "يمكنك تحسين..." "ركّز على تطوير..." NOT positive praise
   - Vary starters: يمكنك تحسين، ركّز على، اعمل على، طوّر، حاول، استثمر في

5. TEAM VOICE (5 items):
   ⛔ NEVER USE NAMES - COMPLETE ANONYMITY REQUIRED
   ✓ Quote ACTUAL FEEDBACK, rephrase to anonymize, ALL items start with DIFFERENT words
   ✗ Never: "محمد قال...", "أحمد يرى...", "[أي اسم]:"
   - ⚠️ STRICT: Each title: 1-2 WORDS ONLY about the main topic (e.g., التواصل، القيادة، التفويض، الدعم)
   - ⚠️ STRICT: Each content: 25-27 words (min 25, max 27) - MUST be in range
   - Aggregate similar feedback into general statements
   - Protect evaluator confidentiality completely

6. ROADMAP STEPS (5 per priority):
   - Use 2ND PERSON (أنت) - address the person DIRECTLY
   - Example: "حدد المهام التي يمكنك تفويضها" NOT "يجب تحديد المهام"
   - ⚠️ STRICT: Each step: 133-140 characters in Arabic (min 121, max 127) - MUST be in range

⚠️ EXTENDED JSON STRUCTURE (follow EXACTLY):
{
  "header": {
    "employeeName": "${employeeName}",
    "executiveSummary": "[First Arabic paragraph - comprehensive overview, max 445 chars]",
    "executiveSummary2": {
      "title": "[UNIQUE Arabic title 20-25 chars, e.g., 'الوضوح والهيكلة']",
      "bulletPoints": [
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]"
      ]
    }
  },
  "leadershipPath": {"score": [0-100], "statusLabelAr": "[فخر/خضر/صفر/حمر/خطر]"},
  "coreMetrics": [
    {"id": "clarity", "score": [0-100], "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]},
    {"id": "efficiency", "score": [0-100], "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]},
    {"id": "safety", "score": [0-100], "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]},
    {"id": "empowerment", "score": [0-100], "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]}
  ],
  "strengths": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "weaknesses": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "personalityAnalysis": {
    "overview": "[First Arabic paragraph - max 350 chars]",
    "overview2": {
      "title": "[UNIQUE Arabic title 20-25 chars, e.g., 'الوضوح والهيكلة']",
      "bulletPoints": [
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]"
      ]
    },
    "mbpiType": "[ENFJ/INTJ/etc]",
    "enneagramType": "[Type 1-9]",
    "discType": "[High D/I/S/C]",
    "bigFiveType": "[CHOOSE ONLY ONE IN ENGLISH: High Openness OR High Conscientiousness OR High Extraversion OR High Agreeableness OR High Neuroticism]",
    "strengths": ["[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]"],
    "weaknesses": ["[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]"]
  },
  "teamVoice": [
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"}
  ],
  "developmentCompass": [
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]"
  ],
  "roadmap": [
    {"title": "", "priorityAr": "الأولوية القصوى", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]},
    {"title": "", "priorityAr": "عاجل", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]},
    {"title": "", "priorityAr": "مستمر", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]}
  ],
  "developmentPlan": [${buildDevelopmentPlanTemplate()}]
}

${getResourceListForPrompt()}

FINAL VERIFICATION:
□ executiveSummary2 has UNIQUE title + 5 bullet points (NOT repeated elsewhere)
□ overview2 has UNIQUE title + 5 bullet points (NOT repeated elsewhere)
□ strengths has 6 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ weaknesses has 6 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ personality strengths/weaknesses derived from personality types
□ teamVoice has 5 items with NO NAMES
□ Each roadmap step is 133-140 chars and uses 2nd person (أنت) - STRICT
□ ENTIRE REPORT uses 2nd person (أنت) - addressing directly, NOT talking about them
□ executiveSummary is comprehensive (max 445 chars)
□ executiveSummary2 has UNIQUE title + 5 UNIQUE bullet points
□ overview (personality) is comprehensive (max 350 chars)
□ overview2 has UNIQUE title + 5 UNIQUE bullet points
□ Each teamVoice: title 1-2 words (topic only), content 21-22 words - STRICT
□ Each core metric bullet point is 80-83 chars - STRICT
□ Each personality strength/weakness is 7-10 words, feminine verbs, direct observation for weaknesses

Output ONLY the JSON.`;

  return { systemPrompt, userPrompt };
}

/**
 * Build GIGANTIC prompts for solo report (16+ reviewers)
 */
function buildGiganticSoloPrompts(feedbackData, employeeName, jobTitle, leaderAssessment, periodicEvaluation, writingStyle = 'standard') {
  const feedbackSummary = feedbackData.map((item, idx) =>
    `Feedback ${idx + 1}: ${Object.entries(item).slice(0, 5).map(([k, v]) => `${k}: ${v}`).join(', ')}`
  ).join('\n');

  // Build writing style instructions for direct mode
  const directStyleInstructions = writingStyle === 'direct' ? `
🎯 DIRECT WRITING STYLE (أسلوب مباشر) - MANDATORY:

🚫 AVOID HEDGING WORDS - Be DIRECT and ASSERTIVE:
DO NOT USE these words/phrases: ${HEDGING_WORDS_TO_AVOID.join('، ')}

Instead of hedging, state observations directly:
❌ "يلاحظ أن لديك قدرة..." → ✅ "لديك قدرة..."
❌ "يبدو أنك تتميز..." → ✅ "تتميز..."
❌ "ربما تحتاج إلى..." → ✅ "تحتاج إلى..."
❌ "قد تكون قادراً على..." → ✅ "أنت قادر على..."

👤 GENDER-AWARE WRITING (مراعاة الجنس):
The candidate's name is "${employeeName}". Based on this Arabic name, determine if the person is male or female, then use the correct grammatical forms throughout the report:
- For MALE: Use masculine verb conjugations (تتميز، لديكَ، تحتاج، تعمل، تقود)
- For FEMALE: Use feminine verb conjugations (تتميزين، لديكِ، تحتاجين، تعملين، تقودين)

Examples:
- Male: "لديكَ قدرة عالية على التواصل" / "تتميز بمهاراتك القيادية"
- Female: "لديكِ قدرة عالية على التواصل" / "تتميزين بمهاراتكِ القيادية"
` : '';

  const systemPrompt = `You are an expert HR analyst generating a GIGANTIC leadership report.

⚠️ CRITICAL: THIS IS A GIGANTIC REPORT (16+ REVIEWS) ⚠️
${directStyleInstructions}
MANDATORY GIGANTIC REQUIREMENTS:
✓ header.executiveSummary2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
✓ header.executiveSummary3 - Object with UNIQUE strategic title + 5 bullet points (DIFFERENT from executiveSummary2) - 🎯 IMPROVEMENT TIPS
✓ personalityAnalysis.overview2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type
✓ personalityAnalysis.overview3 - Object with UNIQUE behavioral title + 5 bullet points (DIFFERENT from overview2) - 🎯 IMPROVEMENT TIPS
✓ strengths array - EXACTLY 9 items (NOT 6, NOT 3) - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في، تولي اهتماماً لـ) - DO NOT repeat title words - 120-175 chars
✓ weaknesses array - EXACTLY 9 items (NOT 6, NOT 3) - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل، مجال للنمو) - DO NOT always use "تحتاج إلى"
✓ coreMetrics bulletPoints - EXACTLY 7 per metric
✓ teamVoice array - EXACTLY 12 items (each UNIQUE topic - ZERO DUPLICATES) - 🎯 VARY intros - negative feedback as improvement guidance
✓ developmentCompass - EXACTLY 9 items (soft skills, 45-55 chars each)
✓ roadmap steps - EXACTLY 10 per priority (165-190 chars each)

🚨🚨🚨 CRITICAL UNIQUENESS RULES 🚨🚨🚨

⛔ ZERO REPETITION ALLOWED:
  - NO paraphrasing of content from other sections
  - NO similar ideas with different words
  - NO overlapping themes or concepts
  - executiveSummary2, executiveSummary3, overview2, overview3 MUST each be COMPLETELY UNIQUE

🔍 SELF-CHECK BEFORE OUTPUT:
  For each section, ask: "Is this insight already covered elsewhere?"
  If YES → DELETE IT and write something completely different

🚨 CRITICAL - 2ND PERSON ADDRESSING (أنت) - ENTIRE REPORT 🚨
ALL text MUST address the person DIRECTLY using 2nd person (أنت):
- executiveSummary: "تتميز بقدرتك على..." NOT "يتميز بقدرته على..."
- strengths/weaknesses descriptions: "لديك قدرة..." NOT "لديه قدرة..."
- personalityAnalysis overview: "أنت شخص..." NOT "هو شخص..."

⚠️ CRITICAL CONTENT RULES:
1. strengths/weaknesses: 9 each, MUST be derived from ACTUAL FEEDBACK DATA - not generic
2. personalityAnalysis: Focus ONLY on personality TYPES (MBTI, Enneagram, DISC, Big Five)
3. teamVoice: 12 items, EACH about a DIFFERENT topic - ABSOLUTE ANONYMITY
4. developmentCompass: 9 soft skills based on challenges, COMPLETELY UNIQUE from other sections
5. roadmap steps: 10 per priority, 165-190 chars each

RULES:
1. 🚨 ALL OUTPUT MUST BE IN ARABIC (العربية) - NO ENGLISH TEXT ALLOWED except personality type codes
2. ⚠️ MANDATORY: Use 2nd person (أنت) EVERYWHERE
3. Output ONLY valid JSON`;

  const userPrompt = `Generate a GIGANTIC leadership report for ${employeeName} (${jobTitle}).
This candidate has ${feedbackData.length} reviewers (≥16), so use GIGANTIC format with MAXIMUM content.
${writingStyle === 'direct' ? `\n⚠️ IMPORTANT: Use DIRECT writing style - no hedging words, be assertive and clear.` : ''}

FEEDBACK DATA:
${feedbackSummary}
${leaderAssessment ? `\nLEADER ASSESSMENT:\n${leaderAssessment}` : ''}
${periodicEvaluation ? `\nPERIODIC EVALUATION:\n${JSON.stringify(periodicEvaluation)}` : ''}

🚨 CRITICAL: 2ND PERSON (أنت) ADDRESSING - ENTIRE REPORT 🚨
You MUST write the ENTIRE report addressing the person DIRECTLY.

⚠️ GIGANTIC CONTENT GENERATION RULES:

1. STRENGTHS/WEAKNESSES (9 each):
   - ⚠️ STRICT: Each title: 37-39 characters
   - 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars)

2. TEAM VOICE (12 items):
   ⛔ NEVER USE NAMES - COMPLETE ANONYMITY
   ✓ Quote ACTUAL FEEDBACK, rephrase to anonymize, ALL items start with DIFFERENT words
   - ⚠️ Each item MUST be about a DIFFERENT topic - ZERO DUPLICATES
   - ⚠️ STRICT: Each title: 1-2 WORDS ONLY (e.g., التواصل، القيادة)
   - ⚠️ STRICT: Each content: 21-22 words

3. DEVELOPMENT COMPASS (9 items):
   - Each: 45-55 characters in Arabic
   - Soft skills based on challenges faced
   - MUST be COMPLETELY UNIQUE from strengths/weaknesses/roadmap

4. CORE METRICS (7 bullet points each):
   - ⚠️ STRICT: Each bullet: 80-83 characters

5. ROADMAP STEPS (10 per priority):
   - 🚨 CRITICAL: Each step MUST be 165-190 characters
   - Use 2ND PERSON (أنت)

6. EXECUTIVE SUMMARY 3 & OVERVIEW 3:
   - executiveSummary3: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
   - overview3: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
   - MUST be COMPLETELY DIFFERENT from executiveSummary2/overview2

⚠️ GIGANTIC VALIDATION CHECKLIST - VERIFY BEFORE SUBMITTING:
□ strengths has 9 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars)
□ weaknesses has 9 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars)
□ teamVoice has 12 items - each UNIQUE topic, no duplicates
□ developmentCompass has 9 items - 45-55 chars each, UNIQUE from all sections
□ Each roadmap priority has 10 steps (165-190 chars each)
□ executiveSummary3 exists with title + 5 bulletPoints
□ overview3 exists with title + 5 bulletPoints
□ All coreMetrics have 7 bullet points each (80-83 chars)
□ All text uses 2ND PERSON (أنت/تُظهر/لديك)

Output ONLY the JSON.`;

  return { systemPrompt, userPrompt };
}

/**
 * Edit a specific section of the report using AI
 * @param {string} sectionId - Which section to edit
 * @param {Object} currentContent - Current content of the section
 * @param {string} editInstruction - User's edit instruction
 * @param {Object} fullReport - The complete report for context
 * @returns {Promise<Object>} Updated section content
 */
export async function editReportSection(sectionId, currentContent, editInstruction, fullReport) {
  logger.info('Starting section edit', { sectionId, instructionLength: editInstruction?.length });

  // Validate inputs
  if (!sectionId) {
    throw new Error('معرف القسم مطلوب.');
  }
  if (!editInstruction || editInstruction.trim() === '') {
    throw new Error('تعليمات التعديل مطلوبة.');
  }
  if (!currentContent) {
    throw new Error('المحتوى الحالي مطلوب.');
  }
  if (!fullReport) {
    throw new Error('التقرير الكامل مطلوب للسياق.');
  }

  const prompt = buildSectionEditPrompt(sectionId, currentContent, editInstruction.trim(), fullReport);

  // Get the schema for the specific section
  const sectionSchema = REPORT_SCHEMA.properties[sectionId];

  if (!sectionSchema) {
    logger.error('Unknown section ID', { sectionId, availableSections: Object.keys(REPORT_SCHEMA.properties) });
    throw new Error('قسم غير معروف للتعديل.');
  }

  try {
    const response = await fetchWithTimeout(OPENROUTER_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000',
        'X-Title': 'Leadership Feedback Analyzer'
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          {
            role: 'system',
            content: `You are an expert HR analyst helping to refine a leadership report. Modify the section according to the user's instruction. Keep all Arabic text in Arabic. Maintain the exact structure.

IMPORTANT: You must respond with ONLY a valid JSON object matching the original structure. No markdown, no code blocks, no explanations - just the raw JSON.`
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        response_format: {
          type: 'json_object'
        },
        temperature: 0.7,
        max_tokens: 4096
      })
    });

    logger.debug('Received edit response from OpenRouter', {
      status: response.status,
      ok: response.ok
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      logger.error('OpenRouter API error during edit', {
        status: response.status,
        error: errorData
      });
      throw new Error(errorData.error?.message || 'فشل في تعديل القسم. يرجى المحاولة مرة أخرى.');
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      logger.error('Empty content in edit response', { data });
      throw new Error('لم يتم استلام رد من خدمة الذكاء الاصطناعي.');
    }

    const updatedSection = safeJSONParse(content, 'section edit');

    // Add colors if it's core metrics
    if (sectionId === 'coreMetrics' && Array.isArray(updatedSection)) {
      logger.info('Section edit successful', { sectionId });
      return updatedSection.map(metric => ({
        ...metric,
        color: getColorForScore(metric.score)
      }));
    }

    logger.info('Section edit successful', { sectionId });
    return updatedSection;
  } catch (error) {
    logger.error('Section edit failed', {
      sectionId,
      error: error.message
    });
    throw error;
  }
}

/**
 * Build the prompt for generating a complete report with weighted scores (Figma-optimized)
 * Supports both standard and extended report formats based on reviewer count
 * @param {Object} scoreData - Pre-calculated scores from weightedScoreService
 * @param {Object} historicalFeedback - Aggregated feedback from sources 1-6
 * @param {Object} december2025Feedback - Feedback from File 7 for paraphrasing
 * @param {string} employeeName - Name of the employee
 * @param {string} jobTitle - Job title of the employee
 * @param {Object|null} periodicEvaluationData - Optional periodic evaluation data
 */
function buildReportGenerationPrompt(scoreData, historicalFeedback, december2025Feedback, employeeName, jobTitle, periodicEvaluationData = null) {
  // Ensure scores have valid values (null is valid JSON, undefined is not)
  const safeScoreData = {
    overallScore: scoreData.overallScore ?? 0,
    statusLabelAr: scoreData.statusLabelAr || 'غير محدد',
    totalReviewerCount: scoreData.totalReviewerCount ?? 0,
    coveragePercentage: scoreData.coveragePercentage ?? 0,
    coreMetricScores: {
      clarity: scoreData.coreMetricScores?.clarity ?? scoreData.overallScore ?? 0,
      efficiency: scoreData.coreMetricScores?.efficiency ?? scoreData.overallScore ?? 0,
      safety: scoreData.coreMetricScores?.safety ?? scoreData.overallScore ?? 0,
      empowerment: scoreData.coreMetricScores?.empowerment ?? scoreData.overallScore ?? 0
    }
  };

  // Determine report format based on review count (3 types)
  const isGigantic = safeScoreData.totalReviewerCount >= GIGANTIC_REPORT_THRESHOLD;
  const isExtended = !isGigantic && safeScoreData.totalReviewerCount >= EXTENDED_REPORT_THRESHOLD;
  const reportFormat = isGigantic ? 'GIGANTIC' : (isExtended ? 'EXTENDED' : 'STANDARD');

  // Build historical feedback summary
  let historicalSummary = '';
  Object.entries(historicalFeedback || {}).forEach(([schemaId, data]) => {
    if (data.type === 'numeric' && data.categoryScores) {
      historicalSummary += `\n--- ${schemaId} (${data.reviewerCount} reviewers) ---\n`;
      historicalSummary += `Overall Score: ${data.overallScore}/100\n`;
      historicalSummary += `Categories: ${JSON.stringify(data.categoryScores)}\n`;
    } else if (data.type === 'qualitative') {
      historicalSummary += `\n--- ${schemaId} (${data.reviewerCount} entries) ---\n`;
      historicalSummary += `Themes: ${JSON.stringify(data.data)}\n`;
    }
  });

  // Build December 2025 feedback for paraphrasing
  let dec2025Section = 'No December 2025 feedback available.';
  if (december2025Feedback) {
    const strengthsList = Array.isArray(december2025Feedback.strengths)
      ? december2025Feedback.strengths.map((s, i) => `${i + 1}. ${s}`).join('\n')
      : 'None provided';
    const devAreasList = Array.isArray(december2025Feedback.developmentAreas)
      ? december2025Feedback.developmentAreas.map((d, i) => `${i + 1}. ${d}`).join('\n')
      : 'None provided';
    const hrNotesList = Array.isArray(december2025Feedback.hrNotes)
      ? december2025Feedback.hrNotes.map((n, i) => `${i + 1}. ${n}`).join('\n')
      : 'None provided';

    dec2025Section = `
--- December 2025 Assessment (${december2025Feedback.reviewerCount || 0} reviewers) ---

STRENGTHS MENTIONED BY REVIEWERS:
${strengthsList}

DEVELOPMENT AREAS MENTIONED BY REVIEWERS:
${devAreasList}

HR NOTES (INTERNAL):
${hrNotesList}
`;
  }

  // Build periodic evaluation section if provided
  let periodicSection = '';
  if (periodicEvaluationData && Object.keys(periodicEvaluationData).length > 0) {
    const periodicDataStr = Object.entries(periodicEvaluationData)
      .map(([key, value]) => `  ${key}: ${value}`)
      .join('\n');

    periodicSection = `
================================================================================
PERIODIC EVALUATION DATA (التقييم الدوري - مارس 2025)
WEIGHT: 10% OF FINAL ASSESSMENT
================================================================================

${periodicDataStr}

NOTE: Use this periodic evaluation data as supporting context (10% weight) alongside
the main 360° feedback data. Look for performance trends and consistency with
peer feedback.
`;
  }

  // Build format-specific output requirements
  console.log(`[PROMPT BUILD] Format: ${reportFormat}, ReviewerCount: ${safeScoreData.totalReviewerCount}`);
  console.log(`[PROMPT BUILD] Thresholds: Extended=${EXTENDED_REPORT_THRESHOLD}, Gigantic=${GIGANTIC_REPORT_THRESHOLD}`);

  let outputRequirements;
  let jsonTemplate;

  if (isGigantic) {
    outputRequirements = buildGiganticOutputRequirements(employeeName, scoreData);
    jsonTemplate = buildGiganticJsonTemplate(employeeName, scoreData);
  } else if (isExtended) {
    outputRequirements = buildExtendedOutputRequirements(employeeName, scoreData);
    jsonTemplate = buildExtendedJsonTemplate(employeeName, scoreData);
  } else {
    outputRequirements = buildStandardOutputRequirements(employeeName, scoreData);
    jsonTemplate = buildStandardJsonTemplate(employeeName, scoreData);
  }

  console.log(`[PROMPT BUILD] Using ${reportFormat} template for ${employeeName}`);

  // Add critical warning for extended/gigantic format at the very beginning
  let formatWarning = '';
  if (isGigantic) {
    formatWarning = `
⚠️⚠️⚠️ CRITICAL: GIGANTIC REPORT FORMAT REQUIRED ⚠️⚠️⚠️

This candidate has ${safeScoreData.totalReviewerCount} reviews (≥16), so you MUST generate a GIGANTIC report.

MANDATORY GIGANTIC REQUIREMENTS - FAILURE TO COMPLY WILL RESULT IN REJECTION:
✓ header.executiveSummary2 - MUST include (title + 5 bulletPoints) - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
✓ header.executiveSummary3 - MUST include (title + 5 bulletPoints) - UNIQUE from executiveSummary2 - 🎯 IMPROVEMENT TIPS
✓ coreMetrics - MUST have exactly 7 bulletPoints per metric
✓ strengths - MUST have exactly 9 items - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في) - DO NOT repeat title words - 120-175 chars
✓ weaknesses - MUST have exactly 9 items - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل) - DO NOT always use "تحتاج إلى"
✓ personalityAnalysis.overview2 - MUST include (title + 5 bulletPoints) - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type
✓ personalityAnalysis.overview3 - MUST include (title + 5 bulletPoints) - UNIQUE from overview2 - 🎯 IMPROVEMENT TIPS
✓ teamVoice - MUST have exactly 12 items (each UNIQUE topic) - 🎯 VARY intros - negative feedback as improvement guidance
✓ developmentCompass - MUST have exactly 9 items
✓ roadmap steps - MUST have exactly 10 steps per priority (165-190 chars each)

DO NOT generate an extended or standard report. COUNT YOUR OUTPUT!

`;
  } else if (isExtended) {
    formatWarning = `
⚠️⚠️⚠️ CRITICAL: EXTENDED REPORT FORMAT REQUIRED ⚠️⚠️⚠️

This candidate has ${safeScoreData.totalReviewerCount} reviews (≥6), so you MUST generate an EXTENDED report.

MANDATORY EXTENDED REQUIREMENTS - FAILURE TO COMPLY WILL RESULT IN REJECTION:
✓ header.executiveSummary2 - MUST include second paragraph (NOT OPTIONAL) - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
✓ coreMetrics - MUST have exactly 5 bulletPoints per metric (NOT 3 or 4)
✓ strengths - MUST have exactly 6 items (NOT 3) - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في) - DO NOT repeat title words - 120-175 chars
✓ weaknesses - MUST have exactly 6 items (NOT 3) - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل) - DO NOT always use "تحتاج إلى"
✓ personalityAnalysis.overview2 - MUST include second paragraph (NOT OPTIONAL) - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type
✓ teamVoice - MUST have exactly 5 items (NOT 4) - 🎯 VARY intros - negative feedback as improvement guidance NOT criticism
✓ roadmap steps - MUST have exactly 5 steps per priority (NOT 4)

DO NOT generate a standard report with fewer items. COUNT YOUR OUTPUT!

`;
  }

  return `${formatWarning}
================================================================================
LEADERSHIP ASSESSMENT REPORT GENERATION (FIGMA-OPTIMIZED FORMAT)
================================================================================

You are an expert HR analyst generating a leadership assessment report optimized for Figma template mapping.
ALL OUTPUT TEXT MUST BE IN ARABIC (العربية). Only JSON keys remain in English.

CRITICAL TONE GUIDELINES:
- Use CONSTRUCTIVE and DEVELOPMENTAL language throughout
- Frame weaknesses as "growth opportunities" or "areas for development"
- Focus on potential and improvement, NOT criticism or blame
- Use encouraging phrases like "يمكنك تطوير", "فرصة للنمو", "مجال للتحسين"
- Avoid harsh or judgmental language
- Every weakness should imply a path to improvement

================================================================================
SECTION 1: CANDIDATE INFORMATION
================================================================================

Name: ${employeeName}
Total Reviewers: ${safeScoreData.totalReviewerCount}
Data Coverage: ${safeScoreData.coveragePercentage}%

================================================================================
SECTION 2: PRE-CALCULATED SCORES (USE EXACTLY AS PROVIDED)
================================================================================

IMPORTANT: These scores are calculated deterministically. You MUST use these exact values.

OVERALL WEIGHTED SCORE: ${safeScoreData.overallScore}/100
STATUS (Arabic only): ${safeScoreData.statusLabelAr}

CORE METRIC SCORES (use these exact values):
- Clarity (الوضوح والهيكلة): ${safeScoreData.coreMetricScores.clarity}/100
- Efficiency (الكفاءة التشغيلية): ${safeScoreData.coreMetricScores.efficiency}/100
- Safety (الأمان النفسي): ${safeScoreData.coreMetricScores.safety}/100
- Empowerment (تمكين الفريق): ${safeScoreData.coreMetricScores.empowerment}/100

================================================================================
SECTION 3: FEEDBACK DATA (FOR CONTEXT)
================================================================================

Historical Feedback:
${historicalSummary || 'No historical feedback available.'}

December 2025 Feedback (can be paraphrased):
${dec2025Section}
${periodicSection}
${outputRequirements}

${jsonTemplate}

================================================================================
SECTION 6: ANONYMIZATION REQUIREMENTS FOR teamVoice SECTION
================================================================================

For the "صوت الفريق" (teamVoice) section, you MUST follow these rules:
1. ALL statements must be ANONYMOUS - NO NAMES ever
2. NEVER use direct quotes from any evaluator
3. ADDRESS THE PERSON DIRECTLY with advice - NOT "الفريق يقدر" style:
   - POSITIVE (1-2 items): "تتميز في..." "لديك قدرة على..." "تُظهر مهارة في..."
   - IMPROVEMENT (rest): "يمكنك تعزيز..." "ركّز على تطوير..." "اعمل على تحسين..."
4. Aggregate similar feedback into one general statement
5. Protect evaluator confidentiality completely
6. 🎯 BALANCE: Mostly improvement feedback (3-4 items), only 1-2 positive items
${isExtended ? `
================================================================================
⚠️ FINAL CHECK: EXTENDED FORMAT VERIFICATION ⚠️
================================================================================

BEFORE SUBMITTING, VERIFY YOUR JSON HAS:
□ header.executiveSummary2 field with content (NOT empty)
□ Each coreMetric has 5 bulletPoints (count them!)
□ strengths array has 6 items (count them!)
□ weaknesses array has 6 items (count them!)
□ personalityAnalysis.overview2 field with content (NOT empty)
□ teamVoice array has 5 items (count them!)
□ Each roadmap item has 5 steps (count them!)

If any of these are missing, ADD THEM NOW before responding.
` : ''}
================================================================================
RESPOND WITH VALID JSON ONLY - NO MARKDOWN, NO EXPLANATION, NO CODE BLOCKS
================================================================================
`;
}

/**
 * Legacy prompt builder for backward compatibility (single file mode) - Figma-optimized
 * @param {Array} feedbackData - 360 feedback data
 * @param {string} employeeName - Employee name
 * @param {string} jobTitle - Job title
 * @param {string|null} leaderAssessment - Optional leader assessment text
 * @param {Object|null} periodicEvaluation - Optional periodic evaluation data (التقييم الدوري)
 *
 * Weighting Logic:
 * - Leader + Periodic: 50% Leader + 10% Periodic + 40% 360°
 * - Leader only: 60% Leader + 40% 360°
 * - Periodic only: 10% Periodic + 90% 360°
 * - Neither: 100% 360°
 */
function buildLegacyReportPrompt(feedbackData, employeeName, jobTitle, leaderAssessment = null, periodicEvaluation = null) {
  const feedbackSummary = feedbackData.map((item, idx) =>
    `Feedback ${idx + 1}:\n${Object.entries(item).map(([k, v]) => `  ${k}: ${v}`).join('\n')}`
  ).join('\n\n');

  // Calculate weights based on what's provided
  const hasLeader = !!leaderAssessment;
  const hasPeriodic = !!periodicEvaluation;

  let leaderWeight = 0;
  let periodicWeight = 0;
  let feedback360Weight = 100;

  if (hasLeader && hasPeriodic) {
    leaderWeight = 50;
    periodicWeight = 10;
    feedback360Weight = 40;
  } else if (hasLeader) {
    leaderWeight = 60;
    feedback360Weight = 40;
  } else if (hasPeriodic) {
    periodicWeight = 10;
    feedback360Weight = 90;
  }

  // Build leader assessment section if provided
  const leaderAssessmentSection = hasLeader ? `
================================================================================
DIRECT MANAGER ASSESSMENT (التقييم الدوري من المدير المباشر)
WEIGHT: ${leaderWeight}% OF FINAL ASSESSMENT
================================================================================

${leaderAssessment}

` : '';

  // Build periodic evaluation section if provided
  let periodicEvaluationSection = '';
  if (hasPeriodic) {
    const periodicDataStr = Object.entries(periodicEvaluation)
      .map(([key, value]) => `  ${key}: ${value}`)
      .join('\n');

    periodicEvaluationSection = `
================================================================================
PERIODIC EVALUATION DATA (التقييم الدوري - مارس 2025)
WEIGHT: ${periodicWeight}% OF FINAL ASSESSMENT
================================================================================

${periodicDataStr}

`;
  }

  // Build weighting instructions based on what's included
  let weightingInstructions = '';
  if (hasLeader || hasPeriodic) {
    weightingInstructions = `
================================================================================
WEIGHTING INSTRUCTIONS
================================================================================

IMPORTANT: This report includes multiple data sources. Apply the following weighting:
${hasLeader ? `- Direct Manager Assessment: ${leaderWeight}% weight` : ''}
${hasPeriodic ? `- Periodic Evaluation (التقييم الدوري): ${periodicWeight}% weight` : ''}
- 360° Feedback Data: ${feedback360Weight}% weight

When calculating scores and generating insights:
${hasLeader ? `1. ${hasPeriodic ? 'Give PRIMARY weight to' : 'Prioritize'} the manager's assessment - their direct observations carry more weight` : ''}
${hasPeriodic ? `${hasLeader ? '2' : '1'}. Use the periodic evaluation data (الدرب, المستهدفات, etc.) as supporting context for performance trends` : ''}
${hasLeader || hasPeriodic ? `${hasLeader && hasPeriodic ? '3' : '2'}. Use 360° feedback to SUPPLEMENT and validate the other assessments` : ''}
${hasLeader ? `${hasLeader && hasPeriodic ? '4' : '3'}. If there are contradictions, lean toward the manager's assessment but note the discrepancy` : ''}

`;
  }

  // Build assessment type description
  let assessmentType = '360° Feedback Only (100%)';
  if (hasLeader && hasPeriodic) {
    assessmentType = `COMBINED (Manager ${leaderWeight}% + Periodic ${periodicWeight}% + 360° ${feedback360Weight}%)`;
  } else if (hasLeader) {
    assessmentType = `COMBINED (Manager ${leaderWeight}% + 360° ${feedback360Weight}%)`;
  } else if (hasPeriodic) {
    assessmentType = `COMBINED (Periodic ${periodicWeight}% + 360° ${feedback360Weight}%)`;
  }

  // Build header warning
  let headerWarning = '';
  if (hasLeader && hasPeriodic) {
    headerWarning = `\n⚠️ THIS REPORT USES 50/10/40 WEIGHTING: Manager (50%) + Periodic (10%) + 360° Feedback (40%)\n`;
  } else if (hasLeader) {
    headerWarning = `\n⚠️ THIS REPORT USES 60/40 WEIGHTING: Manager Assessment (60%) + 360° Feedback (40%)\n`;
  } else if (hasPeriodic) {
    headerWarning = `\n⚠️ THIS REPORT USES 10/90 WEIGHTING: Periodic Evaluation (10%) + 360° Feedback (90%)\n`;
  }

  return `
================================================================================
LEADERSHIP ASSESSMENT REPORT GENERATION (FIGMA-OPTIMIZED FORMAT)
================================================================================

You are an expert HR analyst generating a leadership assessment report optimized for Figma template mapping.
ALL OUTPUT TEXT MUST BE IN ARABIC (العربية). Only JSON keys remain in English.

CRITICAL TONE GUIDELINES:
- Use CONSTRUCTIVE and DEVELOPMENTAL language throughout
- Frame weaknesses as "growth opportunities" or "areas for development"
- Focus on potential and improvement, NOT criticism or blame
- Use encouraging phrases like "يمكنك تطوير", "فرصة للنمو", "مجال للتحسين"
- Avoid harsh or judgmental language
- Every weakness should imply a path to improvement
${headerWarning}
================================================================================
CANDIDATE INFORMATION
================================================================================

Name: ${employeeName}
Number of Reviewers: ${feedbackData.length}
Assessment Type: ${assessmentType}
${leaderAssessmentSection}${periodicEvaluationSection}${weightingInstructions}
================================================================================
360° FEEDBACK DATA (WEIGHT: ${feedback360Weight}%)
================================================================================

${feedbackSummary}

================================================================================
OUTPUT REQUIREMENTS - STRICT LENGTH ENFORCEMENT
================================================================================

Generate a JSON report. 🚨 ALL TEXT MUST BE IN ARABIC (العربية) - absolutely NO English except personality codes.

🚨🚨🚨 CRITICAL: BULLET POINT LENGTH = EXACTLY 80-83 CHARACTERS 🚨🚨🚨
⛔ REJECTED if bullet < 80 chars - TOO SHORT
⛔ REJECTED if bullet > 83 chars - TOO LONG
✅ ACCEPTED only if bullet is 80, 81, 82, or 83 characters
COUNT EVERY CHARACTER before writing!

HEADER:
- employeeName: Use "${employeeName}" exactly (max 30 chars)
- executiveSummary: Write a comprehensive Arabic summary (max 445 chars) - USE THE FULL LIMIT
  CRITICAL: Use 2ND PERSON (أنت/تُظهر/لديك) - address the person DIRECTLY
  Example: "تُظهر قدرات استثنائية في بناء فرق العمل..." NOT "يُظهر خالد قدرات..."

LEADERSHIP PATH:
- score: Calculate based on feedback (0-100)
- statusLabelAr: Arabic label only: فخر (92+), خضر (83-91), صفر (74-82), حمر (64-73), خطر (<64)

CORE METRICS (4 items):
- 🚨 CRITICAL: Each bulletPoint EXACTLY 80-83 characters - COUNT THEM!
- CRITICAL: Use 2ND PERSON (أنت/تفعل) - address the person DIRECTLY

STRENGTHS (exactly 3 items):
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
- 🚫 VARY STARTERS: تحرص على، تسعى دائماً إلى، تعمل باستمرار على

DEVELOPMENT AREAS (exactly 3 items) - USE CONSTRUCTIVE LANGUAGE:
- ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
- 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars) - LONGER and DETAILED
- ⛔ DO NOT REPEAT TITLE WORDS in description - expand with NEW information
- 🚫 VARY STARTERS: ركّز على، اعمل على تطوير، حاول تعزيز

PERSONALITY ANALYSIS (consolidated object, NOT array):
CRITICAL: You MUST ALWAYS provide personality types. NEVER use "غير متوفر" or "N/A".
Infer the most likely personality type from behavioral patterns in the feedback data.
Even with limited data, make your best professional inference based on:
- Communication style, decision-making patterns, team interactions
- Leadership approach, conflict handling, delegation tendencies
- Work style, attention to detail, strategic vs tactical focus

- overview: Max 350 characters - comprehensive Arabic personality summary, USE FULL LIMIT
  CRITICAL: Use 2ND PERSON - address the person DIRECTLY like "تجمع بين الحزم والتعاطف..." NOT "يجمع خالد..."
- mbpiType: MANDATORY - Infer from 16 types: INTJ, INTP, ENTJ, ENTP, INFJ, INFP, ENFJ, ENFP, ISTJ, ISFJ, ESTJ, ESFJ, ISTP, ISFP, ESTP, ESFP
- enneagramType: MANDATORY - Infer from: Type 1-9 (e.g., "Type 8", "Type 3")
- discType: MANDATORY - Infer from: High D, High I, High S, High C, or combinations like "D/I", "S/C"
- bigFiveType: MANDATORY - CHOOSE ONLY ONE IN ENGLISH: High Openness, High Conscientiousness, High Extraversion, High Agreeableness, or High Neuroticism (NOT ALL, JUST ONE)
- strengths: 5 items in ARABIC, 8-12 words each
  👤 GENDER: Detect from name. DEFAULT TO MASCULINE (تتمتع، لديك، تمتلك) - only use feminine (تتمتعين، لديكِ) for clearly female names
  ⛔ CRITICAL: ALL 5 ITEMS MUST START WITH COMPLETELY DIFFERENT WORDS - RANDOMIZE!
  ❌ WRONG: "تتميز بالتواصل..." + "تتميز بالقيادة..." (same word تتميز repeated)
  ✅ RIGHT: Each item starts with a unique verb - be creative and varied!
- weaknesses: 5 items in ARABIC, 8-12 words each - DIRECT OBSERVATION STYLE
  👤 GENDER: Detect from name. DEFAULT TO MASCULINE (تميل، تجد، تواجه) - only use feminine for clearly female names
  ⛔ CRITICAL: ALL 5 ITEMS MUST START WITH COMPLETELY DIFFERENT WORDS - RANDOMIZE!
  ❌ WRONG: "يمكنك تطوير..." + "يمكنك تحسين..." (same word يمكنك repeated)
  ✅ RIGHT: Each item starts with a unique verb/phrase - be creative!
  USE DIRECT OBSERVATIONS - describe behavioral tendencies, NOT "يمكنك" style
  ❌ AVOID: "يمكنك تطوير" or "لديك فرصة" - use direct observation instead

TEAM VOICE (4 items) - QUOTE FROM ACTUAL FEEDBACK:
- ⚠️ STRICT: Each title: 1-2 WORDS ONLY about the main topic (e.g., التواصل، القيادة، التفويض، الدعم)
- ⚠️ STRICT: Each content: 25-27 words (min 25, max 27) - MUST be in range
- 🎯 BALANCE: 1 positive item + 3 improvement items
- 📝 QUOTE ACTUAL FEEDBACK: Extract real feedback from employees and REPHRASE to hide identity
  ✅ Take actual comments/themes from the feedback data provided
  ✅ Paraphrase to anonymize - never copy word-for-word
  ✅ Combine similar feedback points from multiple reviewers into one statement
  ❌ NEVER mention names or identifiable details
- ⛔ ALL 4 ITEMS MUST START WITH DIFFERENT WORDS - RANDOMIZE!
- 🚨 ZERO DUPLICATES: Each teamVoice item MUST be about a DIFFERENT topic

ROADMAP (3 items with FIXED priorities):
- Item 1: priorityAr = "الأولوية القصوى"
- Item 2: priorityAr = "عاجل"
- Item 3: priorityAr = "مستمر"
- title: Max 50 characters in Arabic
- ⚠️ STRICT: Each step: 133-140 characters in Arabic (min 121, max 127) - MUST be in range
- Use 2ND PERSON (أنت) - address the person directly

DEVELOPMENT PLAN (4 tracks, 5 resources each) - SELECT FROM PROVIDED LIST ONLY:
- categoryTitle: Max 30 characters in Arabic - customize based on person's needs
- CRITICAL: Select resources ONLY from the provided AVAILABLE_RESOURCES list
- Use resource "id" field, diversify selections based on person's specific needs

${getResourceListForPrompt()}

================================================================================
JSON TEMPLATE (EXACT STRUCTURE REQUIRED)
================================================================================

{
  "header": {
    "employeeName": "${employeeName}",
    "executiveSummary": "تُظهر قدرات قيادية متميزة في إدارة فريقك وتحقيق الأهداف. تتميز بالتواصل الفعال والرؤية الواضحة..."
  },
  "leadershipPath": {
    "score": 85,
    "statusLabelAr": "خضر"
  },
  "coreMetrics": [
    {"id": "clarity", "score": 80, "bulletPoints": ["يمكنك تحسين وضوح الأولويات عند مشاركتها مع الفريق", "ركّز على تقديم توجيهات أوضح للمهام والتوقعات", "اعمل على تعزيز التواصل الاستباقي مع أعضاء الفريق"]},
    {"id": "efficiency", "score": 70, "bulletPoints": ["يمكنك تحسين إدارة الوقت والموارد بشكل أكثر فعالية", "ركّز على إنجاز المهام ضمن الجداول الزمنية بدقة", "طوّر قدرتك على تفويض المهام وتوزيع المسؤوليات"]},
    {"id": "safety", "score": 65, "bulletPoints": ["يمكنك تعزيز بيئة العمل لتكون أكثر دعماً وتحفيزاً", "ركّز على الاستماع لآراء الفريق باهتمام أكبر", "اعمل على تعزيز الحوار المفتوح والنقاشات البناءة"]},
    {"id": "empowerment", "score": 75, "bulletPoints": ["يمكنك منح الفريق مزيداً من الصلاحيات والاستقلالية", "ركّز على دعم نمو أعضاء الفريق مهنياً وتطورهم", "طوّر مشاركة الفريق في القرارات الاستراتيجية"]}
  ],
  "strengths": [
    {"title": "عنوان قصير", "description": "وصف موجز"},
    {"title": "عنوان قصير", "description": "وصف موجز"},
    {"title": "عنوان قصير", "description": "وصف موجز"}
  ],
  "weaknesses": [
    {"title": "فرصة للتفويض", "description": "يمكنك تعزيز نموك بتوسيع نطاق التفويض للفريق"},
    {"title": "مجال التواصل", "description": "لديك إمكانية تطوير التواصل الاستباقي مع الفريق"},
    {"title": "تطوير المرونة", "description": "فرصة لتعزيز التكيف مع التغييرات السريعة"}
  ],
  "personalityAnalysis": {
    "overview": "تجمع بين الحزم والتعاطف في أسلوبك القيادي. تتميز بالتفكير الاستراتيجي والانفتاح على الأفكار الجديدة...",
    "mbpiType": "INTJ",
    "enneagramType": "Type 8",
    "discType": "High D",
    "bigFiveType": "High Conscientiousness",
    "strengths": ["لديك قدرة عالية على التواصل", "تتميزين بالحزم والوضوح", "لديك مهارة بناء العلاقات", "تمتلكين رؤية استراتيجية واضحة", "لديك التزام عالٍ بالمعايير"],
    "weaknesses": ["يمكنك تطوير أسلوب التفويض", "لديك فرصة لتعزيز المرونة", "يمكنك تسريع اتخاذ القرارات", "فرصة لتوسيع نطاق التمكين", "يمكنك موازنة الدقة بالسرعة"]
  },
  "teamVoice": [
    {"title": "وضوح الرؤية", "content": "ملاحظة مجمعة..."},
    {"title": "بيئة العمل", "content": "ملاحظة مجمعة..."},
    {"title": "التواصل", "content": "ملاحظة مجمعة..."},
    {"title": "التمكين", "content": "ملاحظة مجمعة..."}
  ],
  "developmentCompass": [
    "قدرتك على تحفيز الآخرين بفعالية",
    "مهاراتك في التواصل وبناء العلاقات",
    "قدرتك على فهم احتياجات الفريق",
    "التزامك بتطوير الأفراد وتحفيزهم",
    "قدرتك على التكيف مع التغيرات السريعة"
  ],
  "roadmap": [
    {"title": "إجراء عاجل", "priorityAr": "الأولوية القصوى", "steps": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4"]},
    {"title": "إجراء مهم", "priorityAr": "عاجل", "steps": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4"]},
    {"title": "إجراء مستمر", "priorityAr": "مستمر", "steps": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4"]}
  ],
  "developmentPlan": [
    {"categoryTitle": "بناء الثقة", "resources": [
      {"id": "speed-of-trust", "title": "سرعة الثقة"},
      {"id": "dare-to-lead", "title": "تجرأ على القيادة"},
      {"id": "fearless-organization", "title": "المؤسسة التي لا تهاب"},
      {"id": "frei-trust", "title": "كيف تبني الثقة وتستعيدها"},
      {"id": "five-dysfunctions", "title": "خلل العمل الجماعي الخمسة"}
    ]},
    {"categoryTitle": "التواصل الفعال", "resources": [
      {"id": "crucial-conversations", "title": "محادثات حاسمة"},
      {"id": "nonviolent-communication", "title": "التواصل اللاعنفي"},
      {"id": "difficult-conversations", "title": "المحادثات الصعبة"},
      {"id": "treasure-talk", "title": "قوة المحادثات"},
      {"id": "sinek-why", "title": "ابدأ بلماذا"}
    ]},
    {"categoryTitle": "التفويض والتمكين", "resources": [
      {"id": "turn-the-ship-around", "title": "اقلب السفينة"},
      {"id": "leaders-eat-last", "title": "القادة يأكلون أخيراً"},
      {"id": "multipliers", "title": "المضاعفون"},
      {"id": "radical-candor", "title": "الصراحة الجذرية"},
      {"id": "drive", "title": "الدافع"}
    ]},
    {"categoryTitle": "الذكاء العاطفي", "resources": [
      {"id": "emotional-intelligence-2", "title": "الذكاء العاطفي 2.0"},
      {"id": "primal-leadership", "title": "القيادة البدائية"},
      {"id": "power-of-vulnerability", "title": "قوة الضعف"},
      {"id": "cuddy-presence", "title": "الحضور"},
      {"id": "permission-to-feel", "title": "الإذن بالشعور"}
    ]}
  ]
}

RESPOND WITH VALID JSON ONLY - NO MARKDOWN, NO EXPLANATION, NO CODE BLOCKS`;
}

/**
 * Build prompt for editing a specific section
 */
function buildSectionEditPrompt(sectionId, currentContent, editInstruction, fullReport) {
  return `أنت تقوم بتعديل قسم من تقرير قيادي.

سياق التقرير:
- الموظف: ${fullReport.header?.employeeName || 'غير محدد'}
- المنصب: ${fullReport.header?.jobTitle || 'غير محدد'}
- الدرجة الإجمالية: ${fullReport.leadershipPath?.score || 'غير محددة'}

القسم المطلوب تعديله: ${sectionId}

المحتوى الحالي:
${JSON.stringify(currentContent, null, 2)}

تعليمات التعديل من المستخدم:
"${editInstruction}"

قم بتعديل المحتوى وفقاً للتعليمات مع الحفاظ على:
- نفس البنية والهيكل
- اللغة العربية الاحترافية
- الاتساق مع باقي التقرير`;
}

/**
 * Get color hex code based on score
 */
function getColorForScore(score) {
  if (typeof score !== 'number' || isNaN(score)) {
    return '#EBCB6B'; // Default to average color
  }
  if (score >= 90) return '#53815F';
  if (score >= 75) return '#AECF76';
  if (score >= 60) return '#EBCB6B';
  if (score >= 40) return '#D68A77';
  return '#AA392D';
}

/**
 * Sleep utility for rate limiting
 * @param {number} ms - Milliseconds to sleep
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Generate report for a single candidate with weighted scores
 * REFACTORED: Uses separate internal functions for standard vs extended reports
 * @param {string} candidateName - Name of the candidate
 * @param {string} jobTitle - Job title
 * @param {Object} allFileData - Data from all files for this candidate
 * @param {number} retryCount - Current retry attempt
 * @param {Object|null} periodicEvaluationData - Optional periodic evaluation data for this candidate
 * @returns {Promise<Object>} Generated report with metadata
 */
export async function generateWeightedReport(candidateName, jobTitle, allFileData, retryCount = 0, periodicEvaluationData = null) {
  console.log(`\n${'='.repeat(80)}`);
  console.log(`[REPORT START] Generating report for: ${candidateName}`);
  console.log(`${'='.repeat(80)}`);

  try {
    // Step 1: Calculate deterministic scores
    console.log(`[STEP 1] Calculating scores for ${candidateName}...`);
    const scoreData = calculateCandidateScores(candidateName, allFileData);

    if (scoreData.overallScore === null) {
      throw new Error(`لا توجد بيانات كافية لتقييم ${candidateName}`);
    }

    console.log(`[STEP 1 RESULT] Scores calculated:`, {
      overallScore: scoreData.overallScore,
      totalReviewerCount: scoreData.totalReviewerCount,
      coreMetrics: scoreData.coreMetricScores
    });

    // Step 2: Determine report type (3 types)
    const isGiganticMode = scoreData.totalReviewerCount >= GIGANTIC_REPORT_THRESHOLD;
    const isExtendedMode = !isGiganticMode && scoreData.totalReviewerCount >= EXTENDED_REPORT_THRESHOLD;
    const reportFormat = isGiganticMode ? 'GIGANTIC' : (isExtendedMode ? 'EXTENDED' : 'STANDARD');

    console.log(`\n[STEP 2] REPORT TYPE DETERMINATION:`);
    console.log(`  - Total Reviewers: ${scoreData.totalReviewerCount}`);
    console.log(`  - Thresholds: Extended=${EXTENDED_REPORT_THRESHOLD}, Gigantic=${GIGANTIC_REPORT_THRESHOLD}`);
    console.log(`  - Report Format: ${reportFormat} ✓`);

    // Step 3: Generate report using the appropriate internal function
    console.log(`\n[STEP 3] Calling ${reportFormat} report generator...`);

    let result;
    if (isGiganticMode) {
      result = await generateGiganticReportInternal(candidateName, jobTitle, scoreData, allFileData, periodicEvaluationData, retryCount);
    } else if (isExtendedMode) {
      result = await generateExtendedReportInternal(candidateName, jobTitle, scoreData, allFileData, periodicEvaluationData, retryCount);
    } else {
      result = await generateStandardReportInternal(candidateName, jobTitle, scoreData, allFileData, periodicEvaluationData, retryCount);
    }

    if (!result.success) {
      return result;
    }

    const report = result.report;

    // Step 4: Add colors to core metrics
    if (report.coreMetrics && Array.isArray(report.coreMetrics)) {
      report.coreMetrics = report.coreMetrics.map(metric => ({
        ...metric,
        color: getColorForScore(metric.score)
      }));
    }

    // Step 5: Add metadata
    if (report.header) {
      report.header.reviewerCount = scoreData.totalReviewerCount;
    }

    report._metadata = {
      scoreData: {
        overallScore: scoreData.overallScore,
        coveragePercentage: scoreData.coveragePercentage,
        totalReviewerCount: scoreData.totalReviewerCount,
        missingSources: scoreData.missingSources,
        adjustedWeights: scoreData.adjustedWeights
      },
      isExtended: isExtendedMode,
      isGigantic: isGiganticMode,
      reportFormat: reportFormat,
      generatedAt: new Date().toISOString(),
      candidateName,
      jobTitle
    };

    console.log(`\n[REPORT COMPLETE] Successfully generated ${reportFormat} report for ${candidateName}`);
    console.log(`${'='.repeat(80)}\n`);

    return {
      success: true,
      report,
      scoreData,
      candidateName,
      jobTitle
    };

  } catch (error) {
    // Retry on transient errors
    if (retryCount < BATCH_CONFIG.maxRetries &&
        (error.message.includes('timeout') || error.message.includes('network') || error.message.includes('fetch'))) {
      const delay = BATCH_CONFIG.retryDelays[retryCount] || 4000;
      console.log(`[RETRY] Error occurred, retrying in ${delay}ms...`, { error: error.message });
      await sleep(delay);
      return generateWeightedReport(candidateName, jobTitle, allFileData, retryCount + 1, periodicEvaluationData);
    }

    console.error(`[REPORT FAILED] ${candidateName}:`, error.message);

    return {
      success: false,
      error: error.message,
      candidateName,
      jobTitle
    };
  }
}

/**
 * Internal function to generate STANDARD report (< 6 reviewers)
 * Uses a focused, simple prompt for 3 strengths, 3 weaknesses, 3 bullet points, etc.
 */
async function generateStandardReportInternal(candidateName, jobTitle, scoreData, allFileData, periodicEvaluationData, retryCount) {
  console.log(`\n[STANDARD REPORT] Generating for ${candidateName}`);

  const historicalFeedback = aggregateHistoricalFeedback(scoreData.sourceScores);
  const december2025Feedback = getDecember2025Feedback(scoreData.sourceScores);

  // Build focused data context
  const dataContext = buildDataContext(scoreData, historicalFeedback, december2025Feedback, candidateName, periodicEvaluationData);

  // STANDARD SYSTEM PROMPT - Simple and focused
  const systemPrompt = `You are an expert HR analyst. Generate a leadership report in Arabic.

RULES:
1. 🚨 ALL OUTPUT MUST BE IN ARABIC (العربية) - NO ENGLISH TEXT ALLOWED except personality type codes (INTJ, Type 8, High D, etc.)
2. Use 2nd person (أنت) to address the person directly
3. Output ONLY valid JSON - no markdown, no explanation
4. Use the exact scores provided - do not change them

STANDARD FORMAT REQUIREMENTS:
- strengths: EXACTLY 3 items
- weaknesses: EXACTLY 3 items
- coreMetrics bulletPoints: EXACTLY 3 per metric
- teamVoice: EXACTLY 4 items
- developmentCompass: EXACTLY 5 soft skills (45-55 chars each) - based on challenges faced, MUST be unique from ALL other sections
- roadmap steps: EXACTLY 4 per priority

🚨 بوصلة التطوير (developmentCompass) - CRITICAL RULES 🚨
- 5 soft skills the person should directly work on
- Based on their specific challenges and problems from feedback
- MUST be COMPLETELY UNIQUE - cannot overlap with any other section`;

  // STANDARD USER PROMPT - Focused
  const userPrompt = `Generate a STANDARD leadership report for ${candidateName}.

SCORES (use exactly):
- Overall: ${scoreData.overallScore}/100
- Status: ${scoreData.statusLabelAr}
- Clarity: ${scoreData.coreMetricScores.clarity}
- Efficiency: ${scoreData.coreMetricScores.efficiency}
- Safety: ${scoreData.coreMetricScores.safety}
- Empowerment: ${scoreData.coreMetricScores.empowerment}

FEEDBACK DATA:
${dataContext}

REQUIRED JSON STRUCTURE:
{
  "header": {
    "employeeName": "${candidateName}",
    "executiveSummary": "[Arabic summary, 2nd person, max 445 chars]"
  },
  "leadershipPath": {
    "score": ${scoreData.overallScore},
    "statusLabelAr": "${scoreData.statusLabelAr}"
  },
  "coreMetrics": [
    {"id": "clarity", "score": ${scoreData.coreMetricScores.clarity}, "bulletPoints": ["[3 Arabic points]"]},
    {"id": "efficiency", "score": ${scoreData.coreMetricScores.efficiency}, "bulletPoints": ["[3 Arabic points]"]},
    {"id": "safety", "score": ${scoreData.coreMetricScores.safety}, "bulletPoints": ["[3 Arabic points]"]},
    {"id": "empowerment", "score": ${scoreData.coreMetricScores.empowerment}, "bulletPoints": ["[3 Arabic points]"]}
  ],
  "strengths": [{"title": "", "description": ""}, {"title": "", "description": ""}, {"title": "", "description": ""}],
  "weaknesses": [{"title": "", "description": ""}, {"title": "", "description": ""}, {"title": "", "description": ""}],
  "personalityAnalysis": {
    "overview": "[Arabic overview]",
    "mbpiType": "[INTJ/ENFP/etc]",
    "enneagramType": "[Type 1-9]",
    "discType": "[High D/I/S/C]",
    "bigFiveType": "[High Trait]",
    "strengths": ["[5 items]"],
    "weaknesses": ["[5 items]"]
  },
  "teamVoice": [{"title": "", "content": ""}, {"title": "", "content": ""}, {"title": "", "content": ""}, {"title": "", "content": ""}],
  "developmentCompass": ["[45-55 chars]", "[45-55 chars]", "[45-55 chars]", "[45-55 chars]", "[45-55 chars]"],
  "roadmap": [
    {"title": "", "priorityAr": "الأولوية القصوى", "steps": ["[4 steps]"]},
    {"title": "", "priorityAr": "عاجل", "steps": ["[4 steps]"]},
    {"title": "", "priorityAr": "مستمر", "steps": ["[4 steps]"]}
  ],
  "developmentPlan": [${buildDevelopmentPlanTemplate()}]
}

${getResourceListForPrompt()}

Output ONLY the JSON object.`;

  console.log(`[STANDARD] Sending API request...`);
  console.log(`[STANDARD] System prompt length: ${systemPrompt.length} chars`);
  console.log(`[STANDARD] User prompt length: ${userPrompt.length} chars`);

  return await callAIAndParse(systemPrompt, userPrompt, candidateName, false, retryCount);
}

/**
 * Internal function to generate EXTENDED report (6+ reviewers)
 * Uses a focused prompt with explicit extended requirements
 */
async function generateExtendedReportInternal(candidateName, jobTitle, scoreData, allFileData, periodicEvaluationData, retryCount) {
  console.log(`\n[EXTENDED REPORT] Generating for ${candidateName} (${scoreData.totalReviewerCount} reviewers)`);

  const historicalFeedback = aggregateHistoricalFeedback(scoreData.sourceScores);
  const december2025Feedback = getDecember2025Feedback(scoreData.sourceScores);

  // Build focused data context
  const dataContext = buildDataContext(scoreData, historicalFeedback, december2025Feedback, candidateName, periodicEvaluationData);

  // EXTENDED SYSTEM PROMPT - Emphasizes extended requirements
  const systemPrompt = `You are an expert HR analyst generating an EXTENDED leadership report.

⚠️ CRITICAL: THIS IS AN EXTENDED REPORT ⚠️

MANDATORY EXTENDED REQUIREMENTS (MUST follow exactly):
✓ header.executiveSummary2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
✓ personalityAnalysis.overview2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type
✓ strengths array - EXACTLY 6 items (NOT 3) - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في) - DO NOT repeat title words - 120-175 chars
✓ weaknesses array - EXACTLY 6 items (NOT 3) - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل) - DO NOT always use "تحتاج إلى"
✓ coreMetrics bulletPoints - EXACTLY 5 per metric (NOT 3)
✓ teamVoice array - EXACTLY 5 items (NOT 4) - 🎯 VARY intros - negative feedback as improvement guidance NOT criticism
✓ roadmap steps - EXACTLY 5 per priority (NOT 4)

🚨🚨🚨 CRITICAL UNIQUENESS RULE FOR executiveSummary2 & overview2 🚨🚨🚨

⛔ ZERO REPETITION ALLOWED:
  - NO paraphrasing of content from other sections
  - NO similar ideas with different words
  - NO overlapping themes or concepts
  - The MEANING must be completely different, not just the wording

✅ WHAT MAKES CONTENT TRULY UNIQUE:
  - If you removed executiveSummary2/overview2, the report would be MISSING important insights
  - Each bullet reveals something NOT deducible from other sections
  - A reader should learn NEW information, not recognize rephrased content

🔍 SELF-CHECK BEFORE OUTPUT:
  For each bullet in executiveSummary2/overview2, ask:
  "Is this exact insight already covered in strengths, weaknesses, coreMetrics, teamVoice, or roadmap?"
  If YES → DELETE IT and write something completely different

🚨 CRITICAL - 2ND PERSON ADDRESSING (أنت) - ENTIRE REPORT 🚨
ALL text MUST address the person DIRECTLY using 2nd person (أنت):
- executiveSummary: "تتميز بقدرتك على..." NOT "يتميز بقدرته على..."
- strengths/weaknesses descriptions: "لديك قدرة..." NOT "لديه قدرة..."
- personalityAnalysis overview: "أنت شخص..." NOT "هو شخص..."
- coreMetrics bulletPoints: "تُظهر مهارتك في..." NOT "يُظهر مهارته في..."
- roadmap steps: "حدد المهام التي يمكنك..." NOT "يجب تحديد المهام..."

⚠️ CRITICAL CONTENT RULES:
1. strengths/weaknesses: MUST be derived from ACTUAL FEEDBACK DATA provided - not generic
2. personalityAnalysis.overview/overview2: MUST focus ONLY on analyzing the personality TYPES (MBTI, Enneagram, DISC, Big Five) - NOT personal strengths/weaknesses. Explain what these personality types mean, how they manifest, their characteristics - NOT the person's job performance
3. personalityAnalysis.strengths/weaknesses: MUST be derived from the assigned personality types (MBTI, Enneagram, DISC, Big Five) - specific traits of those personality frameworks, NOT overlapping with main strengths/weaknesses
4. ⛔ ZERO OVERLAP: personalityAnalysis sections must be COMPLETELY DIFFERENT from main strengths/weaknesses - if content appears in one, it CANNOT appear in the other
5. teamVoice: Quote ACTUAL FEEDBACK from employees, rephrase to anonymize, ALL items must start with DIFFERENT words
6. executiveSummary: Make it comprehensive and detailed

RULES:
1. 🚨 ALL OUTPUT MUST BE IN ARABIC (العربية) - NO ENGLISH TEXT ALLOWED except personality type codes (INTJ, Type 8, High D, etc.)
2. ⚠️ MANDATORY: Use 2nd person (أنت) EVERYWHERE - address the person DIRECTLY in ALL sections
3. Output ONLY valid JSON - no markdown, no explanation
4. Use the exact scores provided`;

  // EXTENDED USER PROMPT - Very explicit about extended structure
  const userPrompt = `Generate an EXTENDED leadership report for ${candidateName}.
This candidate has ${scoreData.totalReviewerCount} reviewers (≥6), so use EXTENDED format.

SCORES (use exactly):
- Overall: ${scoreData.overallScore}/100
- Status: ${scoreData.statusLabelAr}
- Clarity: ${scoreData.coreMetricScores.clarity}
- Efficiency: ${scoreData.coreMetricScores.efficiency}
- Safety: ${scoreData.coreMetricScores.safety}
- Empowerment: ${scoreData.coreMetricScores.empowerment}

FEEDBACK DATA:
${dataContext}

🚨 CRITICAL: 2ND PERSON (أنت) ADDRESSING - ENTIRE REPORT 🚨
You MUST write the ENTIRE report addressing the person DIRECTLY:
✓ "أنت تتميز بـ..." ✓ "لديك القدرة على..." ✓ "تُظهر مهاراتك..."
✗ "هو يتميز بـ..." ✗ "لديه القدرة على..." ✗ "يُظهر مهاراته..."

⚠️ CONTENT GENERATION RULES:

1. EXECUTIVE SUMMARY (42% LONGER than usual):
   - Address the person DIRECTLY using أنت
   - Make it comprehensive and detailed
   - ⚠️ STRICTLY ENFORCE: Must be exactly 42% longer - no shorter, no longer
   - Example: "تتميز بقدرتك الاستثنائية على قيادة فريقك..."

2. STRENGTHS/WEAKNESSES (6 each):
   - Extract DIRECTLY from the feedback data above
   - Address using 2nd person: "لديك قدرة على..." NOT "لديه قدرة على..."
   - ⚠️ STRICT: Each title: 37-39 characters (min 37, max 39) - MUST be in range
   - 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars)
   - ✅ Keep it brief, direct, and impactful - single sentence only
   - ❌ NO multi-line descriptions, NO lengthy explanations
   - Each must reference specific observations from reviewers
   - NOT generic leadership traits

3. PERSONALITY ANALYSIS (overview, strengths, weaknesses):
   - ⚠️ STRICT: overview: 11% LONGER than usual - MUST be exactly 11% longer
   - ⚠️ STRICT: overview2: 21% LONGER than usual - MUST be exactly 21% longer
   - Address directly: "أنت شخص يتميز بـ..." NOT "هو شخص يتميز بـ..."
   - After determining MBTI, Enneagram, DISC, Big Five types
   - ⚠️ STRICT: personality strengths/weaknesses: 7-10 words each (min 7, max 10), feminine verbs, direct observation style for weaknesses
   - These personality strengths/weaknesses must be SPECIFIC to those personality types

4. CORE METRICS BULLET POINTS (5 each):
   - ⚠️ STRICT: Each bullet: 80-83 characters (min 80, max 83) - MUST be in range
   - 🎯 IMPROVEMENT FOCUS: "يمكنك تحسين..." "ركّز على تطوير..." NOT positive praise
   - Vary starters: يمكنك تحسين، ركّز على، اعمل على، طوّر، حاول، استثمر في

5. TEAM VOICE (5 items):
   ⛔ NEVER USE NAMES - COMPLETE ANONYMITY REQUIRED
   ✓ Quote ACTUAL FEEDBACK, rephrase to anonymize, ALL items start with DIFFERENT words
   ✗ Never: "محمد قال...", "أحمد يرى...", "[أي اسم]:"
   - ⚠️ STRICT: Each title: 1-2 WORDS ONLY about the main topic (e.g., التواصل، القيادة، التفويض، الدعم)
   - ⚠️ STRICT: Each content: 25-27 words (min 25, max 27) - MUST be in range
   - Aggregate similar feedback into general statements
   - Protect evaluator confidentiality completely

6. ROADMAP STEPS (5 per priority):
   - Use 2ND PERSON (أنت) - address the person DIRECTLY
   - Example: "حدد المهام التي يمكنك تفويضها" NOT "يجب تحديد المهام"
   - ⚠️ STRICT: Each step: 133-140 characters in Arabic (min 121, max 127) - MUST be in range

⚠️ EXTENDED JSON STRUCTURE (follow EXACTLY):
{
  "header": {
    "employeeName": "${candidateName}",
    "executiveSummary": "[First Arabic paragraph - comprehensive overview, max 445 chars]",
    "executiveSummary2": {
      "title": "[UNIQUE Arabic title 20-25 chars, e.g., 'الوضوح والهيكلة']",
      "bulletPoints": [
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE insight NOT mentioned elsewhere]"
      ]
    }
  },
  "leadershipPath": {
    "score": ${scoreData.overallScore},
    "statusLabelAr": "${scoreData.statusLabelAr}"
  },
  "coreMetrics": [
    {"id": "clarity", "score": ${scoreData.coreMetricScores.clarity}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]},
    {"id": "efficiency", "score": ${scoreData.coreMetricScores.efficiency}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]},
    {"id": "safety", "score": ${scoreData.coreMetricScores.safety}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]},
    {"id": "empowerment", "score": ${scoreData.coreMetricScores.empowerment}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5"]}
  ],
  "strengths": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "weaknesses": [
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"},
    {"title": "[37-39 chars]", "description": "[120-175 chars, ONE sentence]"}
  ],
  "personalityAnalysis": {
    "overview": "[First Arabic paragraph - max 350 chars]",
    "overview2": {
      "title": "[UNIQUE Arabic title 20-25 chars, e.g., 'الوضوح والهيكلة']",
      "bulletPoints": [
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]",
        "[60-63 chars - UNIQUE personality insight NOT mentioned elsewhere]"
      ]
    },
    "mbpiType": "[ENFJ/INTJ/etc]",
    "enneagramType": "[Type 1-9]",
    "discType": "[High D/I/S/C]",
    "bigFiveType": "[CHOOSE ONLY ONE IN ENGLISH: High Openness OR High Conscientiousness OR High Extraversion OR High Agreeableness OR High Neuroticism]",
    "strengths": ["[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]", "[7-10 words, feminine]"],
    "weaknesses": ["[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]", "[7-10 words, direct observation]"]
  },
  "teamVoice": [
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"},
    {"title": "[1-2 words, topic only]", "content": "[21-22 words, anonymous]"}
  ],
  "developmentCompass": [
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]",
    "[45-55 chars - soft skill based on challenges, UNIQUE]"
  ],
  "roadmap": [
    {"title": "", "priorityAr": "الأولوية القصوى", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]},
    {"title": "", "priorityAr": "عاجل", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]},
    {"title": "", "priorityAr": "مستمر", "steps": ["[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]", "[133-140 chars, 2nd person أنت]"]}
  ],
  "developmentPlan": [${buildDevelopmentPlanTemplate()}]
}

${getResourceListForPrompt()}

FINAL VERIFICATION:
□ executiveSummary2 has UNIQUE title + 5 bullet points (NOT repeated elsewhere)
□ overview2 has UNIQUE title + 5 bullet points (NOT repeated elsewhere)
□ strengths has 6 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ weaknesses has 6 items: title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars) - COUNT CHARACTERS!
□ personality strengths/weaknesses derived from personality types
□ teamVoice has 5 items with NO NAMES
□ Each roadmap step is 133-140 chars and uses 2nd person (أنت) - STRICT
□ ENTIRE REPORT uses 2nd person (أنت) - addressing directly, NOT talking about them
□ executiveSummary is comprehensive (max 445 chars)
□ executiveSummary2 has UNIQUE title + 5 UNIQUE bullet points
□ overview (personality) is comprehensive (max 350 chars)
□ overview2 has UNIQUE title + 5 UNIQUE bullet points
□ Each teamVoice: title 1-2 words (topic only), content 21-22 words - STRICT
□ Each core metric bullet point is 80-83 chars - STRICT
□ Each personality strength/weakness is 7-10 words, feminine verbs, direct observation for weaknesses

Output ONLY the JSON object.`;

  console.log(`[EXTENDED] Sending API request...`);
  console.log(`[EXTENDED] System prompt length: ${systemPrompt.length} chars`);
  console.log(`[EXTENDED] User prompt length: ${userPrompt.length} chars`);

  return await callAIAndParse(systemPrompt, userPrompt, candidateName, true, retryCount);
}

/**
 * Internal function to generate GIGANTIC report (16+ reviewers)
 * Uses a focused prompt with explicit gigantic requirements
 */
async function generateGiganticReportInternal(candidateName, jobTitle, scoreData, allFileData, periodicEvaluationData, retryCount) {
  console.log(`\n[GIGANTIC REPORT] Generating for ${candidateName} (${scoreData.totalReviewerCount} reviewers)`);

  const historicalFeedback = aggregateHistoricalFeedback(scoreData.sourceScores);
  const december2025Feedback = getDecember2025Feedback(scoreData.sourceScores);

  // Build focused data context
  const dataContext = buildDataContext(scoreData, historicalFeedback, december2025Feedback, candidateName, periodicEvaluationData);

  // GIGANTIC SYSTEM PROMPT
  const systemPrompt = `You are an expert HR analyst generating a GIGANTIC leadership report.

⚠️ CRITICAL: THIS IS A GIGANTIC REPORT (16+ REVIEWS) ⚠️

MANDATORY GIGANTIC REQUIREMENTS (MUST follow exactly):
✓ header.executiveSummary2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS, NOT positive qualities
✓ header.executiveSummary3 - Object with UNIQUE strategic title + 5 bullet points (DIFFERENT from executiveSummary2) - 🎯 IMPROVEMENT TIPS
✓ personalityAnalysis.overview2 - Object with UNIQUE title + 5 bullet points - 🎯 FOCUS ON IMPROVEMENT TIPS based on personality type
✓ personalityAnalysis.overview3 - Object with UNIQUE behavioral title + 5 bullet points (DIFFERENT from overview2) - 🎯 IMPROVEMENT TIPS
✓ strengths array - EXACTLY 9 items - 🎯 VARY intros (تحرص على، تسعى إلى، تعمل على، تبذل جهداً في) - DO NOT repeat title words - 120-175 chars
✓ weaknesses array - EXACTLY 9 items - 🎯 VARY intros (يمكنك تطوير، لديك فرصة ل) - DO NOT always use "تحتاج إلى"
✓ coreMetrics bulletPoints - EXACTLY 7 per metric
✓ teamVoice array - EXACTLY 12 items (each UNIQUE topic - ZERO DUPLICATES) - 🎯 VARY intros - negative feedback as improvement guidance
✓ developmentCompass - EXACTLY 9 items (soft skills, 45-55 chars each)
✓ roadmap steps - EXACTLY 10 per priority (165-190 chars each)

🚨🚨🚨 CRITICAL UNIQUENESS RULES 🚨🚨🚨

⛔ ZERO REPETITION ALLOWED:
  - NO paraphrasing of content from other sections
  - NO similar ideas with different words
  - executiveSummary2, executiveSummary3, overview2, overview3 MUST each be COMPLETELY UNIQUE

🚨 CRITICAL - 2ND PERSON ADDRESSING (أنت) - ENTIRE REPORT 🚨
ALL text MUST address the person DIRECTLY using 2nd person (أنت)

⚠️ CRITICAL CONTENT RULES:
1. strengths/weaknesses: 9 each, derived from ACTUAL FEEDBACK DATA
2. personalityAnalysis: Focus ONLY on personality TYPES
3. teamVoice: 12 items, EACH about a DIFFERENT topic - ABSOLUTE ANONYMITY
4. developmentCompass: 9 soft skills based on challenges, COMPLETELY UNIQUE
5. roadmap steps: 10 per priority, 165-190 chars each

RULES:
1. 🚨 ALL OUTPUT MUST BE IN ARABIC (العربية) - NO ENGLISH TEXT except personality codes
2. ⚠️ MANDATORY: Use 2nd person (أنت) EVERYWHERE
3. Output ONLY valid JSON
4. Use the exact scores provided`;

  // GIGANTIC USER PROMPT
  const userPrompt = `Generate a GIGANTIC leadership report for ${candidateName}.
This candidate has ${scoreData.totalReviewerCount} reviewers (≥16), so use GIGANTIC format with MAXIMUM content.

SCORES (use exactly):
- Overall: ${scoreData.overallScore}/100
- Status: ${scoreData.statusLabelAr}
- Clarity: ${scoreData.coreMetricScores.clarity}
- Efficiency: ${scoreData.coreMetricScores.efficiency}
- Safety: ${scoreData.coreMetricScores.safety}
- Empowerment: ${scoreData.coreMetricScores.empowerment}

FEEDBACK DATA:
${dataContext}

⚠️ GIGANTIC CONTENT GENERATION RULES:

1. STRENGTHS/WEAKNESSES (9 each):
   - ⚠️ STRICT: Each title: 37-39 characters
   - 🚨 CRITICAL: Each description MUST be ONE FLUID SENTENCE (120-175 chars)

2. TEAM VOICE (12 items):
   ⛔ NEVER USE NAMES - COMPLETE ANONYMITY
   ✓ Quote ACTUAL FEEDBACK, rephrase to anonymize, ALL items start with DIFFERENT words
   - ⚠️ Each item MUST be about a DIFFERENT topic - ZERO DUPLICATES
   - ⚠️ STRICT: Each title: 1-2 WORDS ONLY (e.g., التواصل، القيادة)
   - ⚠️ STRICT: Each content: 21-22 words

3. DEVELOPMENT COMPASS (9 items):
   - Each: 45-55 characters in Arabic
   - Soft skills based on challenges faced
   - MUST be COMPLETELY UNIQUE from strengths/weaknesses/roadmap

4. CORE METRICS (7 bullet points each):
   - ⚠️ STRICT: Each bullet: 80-83 characters

5. ROADMAP STEPS (10 per priority):
   - 🚨 CRITICAL: Each step MUST be 165-190 characters
   - Use 2ND PERSON (أنت)

6. EXECUTIVE SUMMARY 3 & OVERVIEW 3:
   - executiveSummary3: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
   - overview3: Object with title (20-25 chars) + 5 bulletPoints (60-63 chars each)
   - MUST be COMPLETELY DIFFERENT from executiveSummary2/overview2

⚠️ GIGANTIC JSON STRUCTURE (follow EXACTLY):
{
  "header": {
    "employeeName": "${candidateName}",
    "executiveSummary": "[max 445 chars]",
    "executiveSummary2": { "title": "[20-25 chars]", "bulletPoints": ["[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"] },
    "executiveSummary3": { "title": "[20-25 chars - UNIQUE]", "bulletPoints": ["[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]", "[60-63 chars]"] }
  },
  "leadershipPath": { "score": ${scoreData.overallScore}, "statusLabelAr": "${scoreData.statusLabelAr}" },
  "coreMetrics": [
    {"id": "clarity", "score": ${scoreData.coreMetricScores.clarity}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5", "p6", "p7"]},
    {"id": "efficiency", "score": ${scoreData.coreMetricScores.efficiency}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5", "p6", "p7"]},
    {"id": "safety", "score": ${scoreData.coreMetricScores.safety}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5", "p6", "p7"]},
    {"id": "empowerment", "score": ${scoreData.coreMetricScores.empowerment}, "bulletPoints": ["p1", "p2", "p3", "p4", "p5", "p6", "p7"]}
  ],
  "strengths": [9 items, each with title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars)],
  "weaknesses": [9 items, each with title 37-39 chars, description ONE FLUID SENTENCE (120-175 chars)],
  "personalityAnalysis": {
    "overview": "[max 350 chars]",
    "overview2": { "title": "[20-25 chars]", "bulletPoints": [...] },
    "overview3": { "title": "[20-25 chars - UNIQUE]", "bulletPoints": [...] },
    "mbpiType": "...", "enneagramType": "...", "discType": "...", "bigFiveType": "...",
    "strengths": [5 items, 7-10 words each, feminine verbs],
    "weaknesses": [5 items, 7-10 words each, direct observation style]
  },
  "teamVoice": [12 items, each UNIQUE topic, title 1-2 words, content 21-22 words],
  "developmentCompass": [9 items, 45-55 chars each, UNIQUE soft skills],
  "roadmap": [
    {"title": "[max 50 chars]", "priorityAr": "الأولوية القصوى", "steps": [10 items, 165-190 chars each]},
    {"title": "[max 50 chars]", "priorityAr": "عاجل", "steps": [10 items, 165-190 chars each]},
    {"title": "[max 50 chars]", "priorityAr": "مستمر", "steps": [10 items, 165-190 chars each]}
  ],
  "developmentPlan": [4 categories with 5 resources each]
}

${getResourceListForPrompt()}

FINAL VERIFICATION:
□ strengths has 9 items, weaknesses has 9 items
□ teamVoice has 12 items - each UNIQUE topic
□ developmentCompass has 9 items - UNIQUE soft skills
□ Each roadmap priority has 10 steps (165-190 chars each)
□ executiveSummary3 and overview3 exist with UNIQUE content
□ All coreMetrics have 7 bullet points each
□ All text uses 2ND PERSON (أنت)

Output ONLY the JSON object.`;

  console.log(`[GIGANTIC] Sending API request...`);
  console.log(`[GIGANTIC] System prompt length: ${systemPrompt.length} chars`);
  console.log(`[GIGANTIC] User prompt length: ${userPrompt.length} chars`);

  return await callAIAndParse(systemPrompt, userPrompt, candidateName, 'gigantic', retryCount);
}

/**
 * Build data context for prompts
 */
function buildDataContext(scoreData, historicalFeedback, december2025Feedback, candidateName, periodicEvaluationData) {
  let context = '';

  // Historical feedback summary
  Object.entries(historicalFeedback || {}).forEach(([schemaId, data]) => {
    if (data.type === 'numeric' && data.categoryScores) {
      context += `\n[${schemaId}] Score: ${data.overallScore}/100, Reviewers: ${data.reviewerCount}\n`;
    } else if (data.type === 'qualitative' && data.data) {
      context += `\n[${schemaId}] Themes: ${JSON.stringify(data.data).substring(0, 200)}\n`;
    }
  });

  // December 2025 feedback
  if (december2025Feedback) {
    context += `\n[December 2025] Strengths: ${december2025Feedback.strengths?.slice(0, 3).join(', ') || 'N/A'}`;
    context += `\nDevelopment Areas: ${december2025Feedback.developmentAreas?.slice(0, 3).join(', ') || 'N/A'}\n`;
  }

  // Periodic evaluation
  if (periodicEvaluationData && Object.keys(periodicEvaluationData).length > 0) {
    context += `\n[Periodic Evaluation] ${Object.entries(periodicEvaluationData).map(([k, v]) => `${k}: ${v}`).join(', ')}\n`;
  }

  return context || 'No additional feedback data available.';
}

/**
 * Build development plan template for prompts
 */
function buildDevelopmentPlanTemplate() {
  return `
    {"categoryTitle": "بناء الثقة", "resources": [
      {"id": "speed-of-trust", "title": "سرعة الثقة"},
      {"id": "dare-to-lead", "title": "تجرأ على القيادة"},
      {"id": "fearless-organization", "title": "المؤسسة التي لا تهاب"},
      {"id": "frei-trust", "title": "كيف تبني الثقة"},
      {"id": "five-dysfunctions", "title": "خلل العمل الجماعي"}
    ]},
    {"categoryTitle": "التواصل الفعال", "resources": [
      {"id": "crucial-conversations", "title": "محادثات حاسمة"},
      {"id": "radical-candor", "title": "الصراحة المطلقة"},
      {"id": "nonviolent-communication", "title": "التواصل غير العنيف"},
      {"id": "difficult-conversations", "title": "محادثات صعبة"},
      {"id": "treasure-speak", "title": "كيف تتحدث"}
    ]},
    {"categoryTitle": "التفويض والتمكين", "resources": [
      {"id": "turn-ship-around", "title": "اقلب السفينة"},
      {"id": "multipliers", "title": "المضاعفون"},
      {"id": "one-minute-manager", "title": "مدير الدقيقة"},
      {"id": "coaching-habit", "title": "عادة التدريب"},
      {"id": "pink-motivation", "title": "لغز التحفيز"}
    ]},
    {"categoryTitle": "الذكاء العاطفي", "resources": [
      {"id": "emotional-intelligence", "title": "الذكاء العاطفي"},
      {"id": "primal-leadership", "title": "القيادة البدائية"},
      {"id": "brown-vulnerability", "title": "قوة الضعف"},
      {"id": "eq-edge", "title": "حافة الذكاء"},
      {"id": "mindset", "title": "طريقة التفكير"}
    ]}`;
}

/**
 * Call AI API and parse response with validation
 * @param {string} isExtended - 'gigantic' for 24000 tokens, true for 16000, false for 8192
 */
async function callAIAndParse(systemPrompt, userPrompt, candidateName, isExtended, retryCount) {
  // Determine max tokens based on report type
  let maxTokens;
  let reportType;
  if (isExtended === 'gigantic') {
    maxTokens = 24000;
    reportType = 'GIGANTIC';
  } else if (isExtended) {
    maxTokens = 16000;
    reportType = 'EXTENDED';
  } else {
    maxTokens = 8192;
    reportType = 'STANDARD';
  }

  console.log(`[API CALL] Model: ${MODEL}, Max tokens: ${maxTokens}, Report type: ${reportType}`);

  const response = await fetchWithTimeout(OPENROUTER_API_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000',
      'X-Title': 'Leadership Feedback Analyzer'
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      response_format: { type: 'json_object' },
      temperature: 0.5, // Lower temperature for more consistent output
      max_tokens: maxTokens
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    if (response.status === 429 && retryCount < BATCH_CONFIG.maxRetries) {
      const delay = BATCH_CONFIG.retryDelays[retryCount] || 4000;
      console.log(`[RATE LIMITED] Retrying in ${delay}ms...`);
      await sleep(delay);
      return callAIAndParse(systemPrompt, userPrompt, candidateName, isExtended, retryCount + 1);
    }
    throw new Error(errorData.error?.message || `API Error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;

  if (!content) {
    throw new Error('Empty response from AI service');
  }

  console.log(`[AI RESPONSE] Length: ${content.length} chars`);

  const report = safeJSONParse(content, 'report generation');

  // Validate and log the structure
  console.log(`\n[VALIDATION] Checking ${reportType} report structure...`);

  const validation = {
    hasExecutiveSummary: !!report.header?.executiveSummary,
    hasExecutiveSummary2: !!report.header?.executiveSummary2,
    hasExecutiveSummary3: !!report.header?.executiveSummary3,
    strengthsCount: Array.isArray(report.strengths) ? report.strengths.length : 0,
    weaknessesCount: Array.isArray(report.weaknesses) ? report.weaknesses.length : 0,
    teamVoiceCount: Array.isArray(report.teamVoice) ? report.teamVoice.length : 0,
    hasOverview2: !!report.personalityAnalysis?.overview2,
    hasOverview3: !!report.personalityAnalysis?.overview3,
    developmentCompassCount: Array.isArray(report.developmentCompass) ? report.developmentCompass.length : 0,
    bulletPointCounts: Array.isArray(report.coreMetrics) ? report.coreMetrics.map(m => Array.isArray(m.bulletPoints) ? m.bulletPoints.length : 0) : [],
    roadmapStepCounts: Array.isArray(report.roadmap) ? report.roadmap.map(r => Array.isArray(r.steps) ? r.steps.length : 0) : []
  };

  console.log(`[VALIDATION RESULT]`, validation);

  if (isExtended === 'gigantic') {
    // GIGANTIC report validation
    const issues = [];
    if (!validation.hasExecutiveSummary2) issues.push('Missing executiveSummary2');
    if (!validation.hasExecutiveSummary3) issues.push('Missing executiveSummary3');
    if (!validation.hasOverview2) issues.push('Missing overview2');
    if (!validation.hasOverview3) issues.push('Missing overview3');
    if (validation.strengthsCount < 9) issues.push(`Strengths: ${validation.strengthsCount}/9`);
    if (validation.weaknessesCount < 9) issues.push(`Weaknesses: ${validation.weaknessesCount}/9`);
    if (validation.teamVoiceCount < 12) issues.push(`TeamVoice: ${validation.teamVoiceCount}/12`);
    if (validation.developmentCompassCount < 9) issues.push(`DevCompass: ${validation.developmentCompassCount}/9`);
    if (validation.bulletPointCounts.some(c => c < 7)) issues.push(`BulletPoints: ${validation.bulletPointCounts.join(',')}/7`);
    if (validation.roadmapStepCounts.some(c => c < 10)) issues.push(`RoadmapSteps: ${validation.roadmapStepCounts.join(',')}/10`);

    if (issues.length > 0) {
      console.error(`[GIGANTIC VALIDATION FAILED] Issues:`, issues);
    } else {
      console.log(`[GIGANTIC VALIDATION PASSED] ✓ All gigantic fields present`);
    }
  } else if (isExtended) {
    // EXTENDED report validation
    const issues = [];
    if (!validation.hasExecutiveSummary2) issues.push('Missing executiveSummary2');
    if (!validation.hasOverview2) issues.push('Missing overview2');
    if (validation.strengthsCount < 6) issues.push(`Strengths: ${validation.strengthsCount}/6`);
    if (validation.weaknessesCount < 6) issues.push(`Weaknesses: ${validation.weaknessesCount}/6`);
    if (validation.teamVoiceCount < 5) issues.push(`TeamVoice: ${validation.teamVoiceCount}/5`);
    if (validation.bulletPointCounts.some(c => c < 5)) issues.push(`BulletPoints: ${validation.bulletPointCounts.join(',')}/5`);
    if (validation.roadmapStepCounts.some(c => c < 5)) issues.push(`RoadmapSteps: ${validation.roadmapStepCounts.join(',')}/5`);

    if (issues.length > 0) {
      console.error(`[EXTENDED VALIDATION FAILED] Issues:`, issues);
    } else {
      console.log(`[EXTENDED VALIDATION PASSED] ✓ All extended fields present`);
    }
  } else {
    // STANDARD report validation
    console.log(`[STANDARD VALIDATION] Strengths: ${validation.strengthsCount}/3, Weaknesses: ${validation.weaknessesCount}/3`);
  }

  return { success: true, report };
}

/**
 * Normalize Arabic name for matching (handles diacritics, alef variations, etc.)
 */
function normalizeArabicName(name) {
  if (!name) return '';
  return name
    .replace(/[\u064B-\u065F]/g, '') // Remove Arabic diacritics
    .replace(/[أإآا]/g, 'ا')          // Normalize alef variations
    .replace(/ة/g, 'ه')              // Normalize taa marbuta
    .replace(/ى/g, 'ي')              // Normalize alef maksura
    .replace(/\s+/g, ' ')            // Normalize whitespace
    .trim()
    .toLowerCase();
}

/**
 * Calculate fuzzy match score between two names
 */
function fuzzyMatchScore(name1, name2) {
  const n1 = normalizeArabicName(name1);
  const n2 = normalizeArabicName(name2);

  if (n1 === n2) return 100;
  if (n1.includes(n2) || n2.includes(n1)) return 90;

  // Simple Levenshtein-based similarity
  const maxLen = Math.max(n1.length, n2.length);
  if (maxLen === 0) return 0;

  let matches = 0;
  const minLen = Math.min(n1.length, n2.length);
  for (let i = 0; i < minLen; i++) {
    if (n1[i] === n2[i]) matches++;
  }

  return Math.round((matches / maxLen) * 100);
}

/**
 * Extract specific candidate's data from periodic evaluation (transposed format)
 * @param {Object} periodicData - Raw periodic evaluation data with employeeNames and rawData
 * @param {string} candidateName - Name of the candidate to extract
 * @returns {Object|null} Candidate's periodic data or null if not found
 */
function extractCandidatePeriodicData(periodicData, candidateName) {
  if (!periodicData || !periodicData.rawData || !candidateName) return null;

  const normalizedTarget = normalizeArabicName(candidateName);

  // Find the candidate's column
  let candidateColumn = null;
  let bestMatchScore = 0;
  for (const emp of periodicData.employeeNames || []) {
    const normalizedEmp = normalizeArabicName(emp.name);
    const matchScore = fuzzyMatchScore(normalizedTarget, normalizedEmp);
    // Require 85% match minimum to avoid false positives
    if (matchScore >= 85 && matchScore > bestMatchScore) {
      candidateColumn = emp;
      bestMatchScore = matchScore;
      // Log non-exact matches for debugging
      if (matchScore < 100) {
        serviceLogger.debug('Periodic data fuzzy matched', {
          candidateName,
          matchedTo: emp.name,
          matchScore
        });
      }
    }
  }

  if (!candidateColumn) {
    serviceLogger.debug('Candidate not found in periodic evaluation', { candidateName });
    return null;
  }

  // Extract all row data for this candidate
  const candidateData = {};
  const rawData = periodicData.rawData;

  for (let rowIdx = 1; rowIdx < rawData.length; rowIdx++) {
    const row = rawData[rowIdx];
    const rowLabel = row[0];
    const value = row[candidateColumn.index];

    if (rowLabel && value !== undefined && value !== null && value !== '') {
      candidateData[rowLabel] = value;
    }
  }

  serviceLogger.debug('Extracted periodic evaluation data', {
    candidateName,
    matchedName: candidateColumn.name,
    fieldsExtracted: Object.keys(candidateData).length
  });

  return {
    matchedName: candidateColumn.name,
    data: candidateData
  };
}

/**
 * Process a single candidate with retry logic
 * @param {Object} candidate - Candidate data {name, jobTitle, fileData}
 * @param {Function} onLog - Log callback
 * @param {Object|null} periodicEvaluationData - Optional periodic evaluation data for this candidate
 * @returns {Promise<Object>} Processing result
 */
async function processWithRetry(candidate, onLog, periodicEvaluationData = null) {
  let lastError = null;

  for (let attempt = 0; attempt <= BATCH_CONFIG.maxRetries; attempt++) {
    try {
      // Log sending (only on first attempt or retry)
      if (attempt === 0) {
        onLog(`جاري إرسال بيانات "${candidate.name}" للذكاء الاصطناعي...`, 'sending', candidate.name);
      } else {
        const delay = BATCH_CONFIG.retryDelays[attempt - 1] / 1000;
        onLog(`إعادة المحاولة ${attempt} لـ "${candidate.name}" بعد ${delay} ثانية...`, 'info', candidate.name);
      }

      const result = await generateWeightedReport(
        candidate.name,
        candidate.jobTitle,
        candidate.fileData,
        0, // retryCount
        periodicEvaluationData // Pass periodic evaluation data
      );

      // Log received
      onLog(`تم استلام الرد من الذكاء الاصطناعي لـ "${candidate.name}"`, 'received', candidate.name);

      if (result.success) {
        return { success: true, result, candidate };
      } else {
        // API returned error, might be retryable
        lastError = result.error || 'خطأ غير معروف';

        // If we have retries left, wait and retry
        if (attempt < BATCH_CONFIG.maxRetries) {
          const delay = BATCH_CONFIG.retryDelays[attempt];
          onLog(`فشل "${candidate.name}": ${lastError}، جاري الانتظار...`, 'error', candidate.name);
          await sleep(delay);
          continue;
        }

        return { success: false, error: lastError, candidate, result };
      }
    } catch (error) {
      lastError = error.message;

      // If we have retries left, wait and retry
      if (attempt < BATCH_CONFIG.maxRetries) {
        const delay = BATCH_CONFIG.retryDelays[attempt];
        onLog(`خطأ في "${candidate.name}": ${lastError}، إعادة المحاولة بعد ${delay/1000} ثانية...`, 'error', candidate.name);
        await sleep(delay);
        continue;
      }

      // All retries exhausted
      return {
        success: false,
        error: `فشل بعد ${BATCH_CONFIG.maxRetries + 1} محاولات: ${lastError}`,
        candidate
      };
    }
  }

  // Should not reach here, but just in case
  return { success: false, error: lastError, candidate };
}

/**
 * Process multiple candidates in batch with parallel processing
 * Runs up to 3 candidates simultaneously with retry and error handling
 * @param {Array<Object>} candidates - Array of {name, jobTitle, fileData}
 * @param {Function} onProgress - Progress callback (current, total, candidateName, status)
 * @param {Function} onLog - Log callback (message, type, candidateName)
 * @param {Object|null} periodicEvaluationData - Optional periodic evaluation data (transposed format)
 * @returns {Promise<Object>} Batch processing results
 */
export async function processBatchCandidates(candidates, onProgress = () => {}, onLog = () => {}, periodicEvaluationData = null) {
  logger.info('Starting parallel batch processing', {
    totalCandidates: candidates.length,
    maxConcurrent: BATCH_CONFIG.maxConcurrent,
    hasPeriodicEvaluation: !!periodicEvaluationData
  });

  // Log start with parallel info
  const periodicInfo = periodicEvaluationData ? ' (مع التقييم الدوري)' : '';
  onLog(`بدء معالجة ${candidates.length} مرشح (${BATCH_CONFIG.maxConcurrent} بالتوازي)${periodicInfo}`, 'info');

  const results = {
    successful: [],
    failed: [],
    total: candidates.length,
    startTime: new Date().toISOString(),
    endTime: null
  };

  let completed = 0;
  let currentIndex = 0;
  const activePromises = new Map(); // Track active processing promises

  // Process candidates in parallel batches
  while (currentIndex < candidates.length || activePromises.size > 0) {
    // Start new parallel tasks up to the limit
    while (activePromises.size < BATCH_CONFIG.maxConcurrent && currentIndex < candidates.length) {
      const candidate = candidates[currentIndex];
      const candidateIndex = currentIndex;
      currentIndex++;

      // Report processing status
      onProgress(completed, results.total, candidate.name, 'processing');

      // Extract candidate-specific periodic evaluation data if available
      let candidatePeriodicData = null;
      if (periodicEvaluationData) {
        const match = extractCandidatePeriodicData(periodicEvaluationData, candidate.name);
        if (match) {
          candidatePeriodicData = match.data;
          serviceLogger.debug('Found periodic data for candidate', {
            candidateName: candidate.name,
            matchedName: match.matchedName,
            fields: Object.keys(match.data).length
          });
        }
      }

      // Create promise for this candidate
      const promise = processWithRetry(candidate, onLog, candidatePeriodicData)
        .then(processingResult => {
          completed++;

          if (processingResult.success) {
            results.successful.push(processingResult.result);
            onProgress(completed, results.total, candidate.name, 'success');
            onLog(`تم إنشاء تقرير "${candidate.name}" بنجاح ✓`, 'success', candidate.name);
          } else {
            const failedResult = processingResult.result || {
              success: false,
              error: processingResult.error,
              candidateName: candidate.name,
              jobTitle: candidate.jobTitle
            };
            results.failed.push(failedResult);
            onProgress(completed, results.total, candidate.name, 'failed');
            onLog(`فشل إنشاء تقرير "${candidate.name}" نهائياً: ${processingResult.error}`, 'error', candidate.name);
          }

          // Remove from active promises
          activePromises.delete(candidateIndex);
        })
        .catch(error => {
          // This shouldn't happen as processWithRetry handles errors, but just in case
          completed++;
          results.failed.push({
            success: false,
            error: error.message,
            candidateName: candidate.name,
            jobTitle: candidate.jobTitle
          });
          onProgress(completed, results.total, candidate.name, 'error');
          onLog(`خطأ غير متوقع في "${candidate.name}": ${error.message}`, 'error', candidate.name);
          activePromises.delete(candidateIndex);
        });

      activePromises.set(candidateIndex, promise);

      // Small delay before starting next parallel task to avoid burst
      if (activePromises.size < BATCH_CONFIG.maxConcurrent && currentIndex < candidates.length) {
        await sleep(BATCH_CONFIG.rateLimitDelayMs);
      }
    }

    // Wait for at least one promise to complete before continuing
    if (activePromises.size > 0) {
      await Promise.race(activePromises.values());
    }
  }

  results.endTime = new Date().toISOString();
  results.duration = new Date(results.endTime) - new Date(results.startTime);

  // Log completion with time saved estimate
  const durationSecs = Math.round(results.duration / 1000);
  const estimatedSeqTime = candidates.length * 15; // Assume ~15s per candidate sequentially
  const timeSaved = Math.max(0, estimatedSeqTime - durationSecs);

  onLog(`اكتملت المعالجة: ${results.successful.length} ناجح، ${results.failed.length} فاشل (${durationSecs} ثانية)`, 'complete');

  if (timeSaved > 30) {
    onLog(`تم توفير ~${Math.round(timeSaved / 60)} دقائق بفضل المعالجة المتوازية`, 'info');
  }

  logger.info('Parallel batch processing complete', {
    successful: results.successful.length,
    failed: results.failed.length,
    duration: results.duration,
    avgTimePerCandidate: Math.round(results.duration / candidates.length)
  });

  return results;
}

/**
 * Extract unique candidates from uploaded file data
 * @param {Object} allFilesData - Data from all uploaded files, keyed by schema ID
 * @returns {Array<Object>} Array of unique candidates with their data
 */
export function extractUniqueCandidates(allFilesData) {
  serviceLogger.info('Extracting unique candidates from uploaded files', {
    inputSchemas: allFilesData ? Object.keys(allFilesData) : 'undefined'
  });

  // Validate input
  if (!allFilesData || typeof allFilesData !== 'object') {
    serviceLogger.error('Invalid allFilesData input', {
      type: typeof allFilesData,
      value: allFilesData
    });
    return [];
  }

  // Validate FILE_SCHEMAS
  if (!FILE_SCHEMAS || typeof FILE_SCHEMAS !== 'object') {
    serviceLogger.error('FILE_SCHEMAS is undefined or invalid', {
      type: typeof FILE_SCHEMAS
    });
    return [];
  }

  const candidateMap = new Map();

  // Helper to normalize names for matching
  const normalizeName = (name) => {
    if (!name) return null;
    return String(name).trim()
      .replace(/\s+/g, ' ')
      .toLowerCase();
  };

  // Process each file type
  Object.entries(allFilesData).forEach(([schemaId, fileData]) => {
    serviceLogger.debug(`Processing schema: ${schemaId}`, {
      hasData: !!fileData,
      isArray: Array.isArray(fileData),
      length: Array.isArray(fileData) ? fileData.length : 0
    });

    if (!fileData || !Array.isArray(fileData) || fileData.length === 0) {
      serviceLogger.debug(`Skipping schema ${schemaId} - no valid data`);
      return;
    }

    const schema = FILE_SCHEMAS[schemaId];
    if (!schema) {
      serviceLogger.warn(`Schema ${schemaId} not found in FILE_SCHEMAS`);
      return;
    }

    // Handle transposed format (File 6)
    if (schema.isTransposed) {
      serviceLogger.debug(`Processing transposed schema: ${schemaId}`);
      // For transposed, candidates are in columns
      if (schema.knownLeaders) {
        schema.knownLeaders.forEach(leaderName => {
          const normalizedName = normalizeName(leaderName);
          if (!candidateMap.has(normalizedName)) {
            candidateMap.set(normalizedName, {
              name: leaderName,
              jobTitle: 'قائد', // Default title
              fileData: {}
            });
          }
          // Add transposed data for this leader
          const candidate = candidateMap.get(normalizedName);
          candidate.fileData[schemaId] = fileData;
        });
      }
      return;
    }

    // Handle normal row-based formats
    const personColumn = schema.personIdentifierColumn;
    if (!personColumn) {
      serviceLogger.warn(`No personIdentifierColumn defined for schema ${schemaId}`);
      return;
    }

    serviceLogger.debug(`Using personIdentifierColumn: ${personColumn}`);

    let candidatesFoundInFile = 0;
    fileData.forEach(row => {
      const candidateName = row[personColumn];
      if (!candidateName) return;

      const normalizedName = normalizeName(candidateName);
      if (!normalizedName) return;

      if (!candidateMap.has(normalizedName)) {
        candidateMap.set(normalizedName, {
          name: candidateName,
          jobTitle: row['المسمى الوظيفي'] || row['المسمى'] || row['jobTitle'] || 'غير محدد',
          fileData: {}
        });
        candidatesFoundInFile++;
      }

      const candidate = candidateMap.get(normalizedName);

      // Add row to this schema's data for the candidate
      if (!candidate.fileData[schemaId]) {
        candidate.fileData[schemaId] = [];
      }
      candidate.fileData[schemaId].push(row);
    });

    serviceLogger.debug(`Found ${candidatesFoundInFile} new candidates in ${schemaId}`);
  });

  const candidates = Array.from(candidateMap.values());

  serviceLogger.info('Candidate extraction complete', {
    totalCandidates: candidates.length,
    candidateNames: candidates.slice(0, 10).map(c => c.name)
  });

  return candidates;
}

/**
 * Convert batch results to Excel-compatible format with flattened arrays
 * English column names optimized for Figma template mapping
 * Supports both standard and extended report formats
 * @param {Object} batchResults - Results from processBatchCandidates
 * @returns {Array<Object>} Flat array of rows for Excel export
 */
export function convertToExcelFormat(batchResults) {
  const rows = [];

  // Ensure successful is an array
  const successful = Array.isArray(batchResults?.successful) ? batchResults.successful : [];

  // Helper function to ensure no undefined values (XLSX skips undefined)
  const safeValue = (val, defaultVal = '') => val !== undefined && val !== null ? val : defaultVal;

  // Helper function to safely extract string from potentially nested objects
  const safeString = (value) => {
    if (value === null || value === undefined) return '';
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (typeof value === 'object') {
      if (value.text) return String(value.text);
      if (value.value) return String(value.value);
      if (value.content) return String(value.content);
      if (value.title) return String(value.title);
      if (value.name) return String(value.name);
      if (value.description) return String(value.description);
      if (Array.isArray(value)) return value.map(item => safeString(item)).filter(Boolean).join(' | ');
      return '';
    }
    return String(value);
  };

  successful.forEach(result => {
    const { report, scoreData } = result;

    // Get reviewer count from multiple possible sources
    const reviewerCount = scoreData?.totalReviewerCount
      || report?._metadata?.scoreData?.totalReviewerCount
      || report?.header?.reviewerCount
      || 0;

    const isGigantic = report?._metadata?.isGigantic || (reviewerCount >= 21);
    const isExtended = report?._metadata?.isExtended || (!isGigantic && reviewerCount >= 7);
    const personalityUrls = getPersonalityUrls(report?.personalityAnalysis);

    const row = {
      // ===== METADATA (4 columns) =====
      'is_extended_report': isExtended ? 'نعم' : 'لا',
      'is_gigantic_report': isGigantic ? 'نعم' : 'لا',
      'total_reviewer_count': reviewerCount ?? 0,
      'number_of_reviews_analyzed': reviewerCount ?? 0,

      // ===== HEADER (10 columns - includes extended executiveSummary2 with title + 5 bullets) =====
      'employee_name_for_header_greeting': safeString(report?.header?.employeeName || result.candidateName),
      'leadership_path_status_badge_text': safeString(report?.leadershipPath?.statusLabelAr),
      'executive_summary_intro_paragraph': safeString(report?.header?.executiveSummary),
      'executive_summary_2_title': safeString(report?.header?.executiveSummary2?.title),
      'executive_summary_2_bullet_1': safeString(report?.header?.executiveSummary2?.bulletPoints?.[0]),
      'executive_summary_2_bullet_2': safeString(report?.header?.executiveSummary2?.bulletPoints?.[1]),
      'executive_summary_2_bullet_3': safeString(report?.header?.executiveSummary2?.bulletPoints?.[2]),
      'executive_summary_2_bullet_4': safeString(report?.header?.executiveSummary2?.bulletPoints?.[3]),
      'executive_summary_2_bullet_5': safeString(report?.header?.executiveSummary2?.bulletPoints?.[4]),

      // ===== CORE METRICS (25 columns - includes extended bullet point 5) =====
      'clarity_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.score, 0),
      'clarity_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[0]),
      'clarity_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[1]),
      'clarity_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[2]),
      'clarity_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[3]),
      'clarity_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'clarity')?.bulletPoints?.[4]),
      'efficiency_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.score, 0),
      'efficiency_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[0]),
      'efficiency_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[1]),
      'efficiency_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[2]),
      'efficiency_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[3]),
      'efficiency_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'efficiency')?.bulletPoints?.[4]),
      'psychological_safety_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.score, 0),
      'psychological_safety_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[0]),
      'psychological_safety_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[1]),
      'psychological_safety_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[2]),
      'psychological_safety_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[3]),
      'psychological_safety_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'safety')?.bulletPoints?.[4]),
      'empowerment_metric_percentage_score': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.score, 0),
      'empowerment_metric_bullet_point_1': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[0]),
      'empowerment_metric_bullet_point_2': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[1]),
      'empowerment_metric_bullet_point_3': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[2]),
      'empowerment_metric_bullet_point_4': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[3]),
      'empowerment_metric_bullet_point_5_extended': safeString(report?.coreMetrics?.find(m => m.id === 'empowerment')?.bulletPoints?.[4]),

      // ===== STRENGTHS (12 columns - standard 1-3, extended 4-6) =====
      'strength_1_title_in_assessment_section': safeString(report?.strengths?.[0]?.title),
      'strength_1_description_in_assessment_section': safeString(report?.strengths?.[0]?.description),
      'strength_2_title_in_assessment_section': safeString(report?.strengths?.[1]?.title),
      'strength_2_description_in_assessment_section': safeString(report?.strengths?.[1]?.description),
      'strength_3_title_in_assessment_section': safeString(report?.strengths?.[2]?.title),
      'strength_3_description_in_assessment_section': safeString(report?.strengths?.[2]?.description),
      'strength_4_title_extended': safeString(report?.strengths?.[3]?.title),
      'strength_4_description_extended': safeString(report?.strengths?.[3]?.description),
      'strength_5_title_extended': safeString(report?.strengths?.[4]?.title),
      'strength_5_description_extended': safeString(report?.strengths?.[4]?.description),
      'strength_6_title_extended': safeString(report?.strengths?.[5]?.title),
      'strength_6_description_extended': safeString(report?.strengths?.[5]?.description),

      // ===== WEAKNESSES (12 columns - standard 1-3, extended 4-6) =====
      'weakness_1_title_in_improvement_section': safeString(report?.weaknesses?.[0]?.title),
      'weakness_1_description_in_improvement_section': safeString(report?.weaknesses?.[0]?.description),
      'weakness_2_title_in_improvement_section': safeString(report?.weaknesses?.[1]?.title),
      'weakness_2_description_in_improvement_section': safeString(report?.weaknesses?.[1]?.description),
      'weakness_3_title_in_improvement_section': safeString(report?.weaknesses?.[2]?.title),
      'weakness_3_description_in_improvement_section': safeString(report?.weaknesses?.[2]?.description),
      'weakness_4_title_extended': safeString(report?.weaknesses?.[3]?.title),
      'weakness_4_description_extended': safeString(report?.weaknesses?.[3]?.description),
      'weakness_5_title_extended': safeString(report?.weaknesses?.[4]?.title),
      'weakness_5_description_extended': safeString(report?.weaknesses?.[4]?.description),
      'weakness_6_title_extended': safeString(report?.weaknesses?.[5]?.title),
      'weakness_6_description_extended': safeString(report?.weaknesses?.[5]?.description),

      // ===== PERSONALITY ANALYSIS (22 columns - includes extended overview2 with title + 5 bullets) =====
      'personality_analysis_overview_paragraph': safeString(report?.personalityAnalysis?.overview),
      'personality_overview_2_title': safeString(report?.personalityAnalysis?.overview2?.title),
      'personality_overview_2_bullet_1': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[0]),
      'personality_overview_2_bullet_2': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[1]),
      'personality_overview_2_bullet_3': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[2]),
      'personality_overview_2_bullet_4': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[3]),
      'personality_overview_2_bullet_5': safeString(report?.personalityAnalysis?.overview2?.bulletPoints?.[4]),
      'mbti_personality_type_badge_code': safeString(report?.personalityAnalysis?.mbpiType),
      'enneagram_personality_type_badge_code': safeString(report?.personalityAnalysis?.enneagramType),
      'disc_behavioral_style_badge_code': safeString(report?.personalityAnalysis?.discType),
      'big_five_trait_badge_code': safeString(report?.personalityAnalysis?.bigFiveType),
      'personality_strength_bullet_1': safeString(report?.personalityAnalysis?.strengths?.[0]),
      'personality_strength_bullet_2': safeString(report?.personalityAnalysis?.strengths?.[1]),
      'personality_strength_bullet_3': safeString(report?.personalityAnalysis?.strengths?.[2]),
      'personality_strength_bullet_4': safeString(report?.personalityAnalysis?.strengths?.[3]),
      'personality_strength_bullet_5': safeString(report?.personalityAnalysis?.strengths?.[4]),
      'personality_weakness_bullet_1': safeString(report?.personalityAnalysis?.weaknesses?.[0]),
      'personality_weakness_bullet_2': safeString(report?.personalityAnalysis?.weaknesses?.[1]),
      'personality_weakness_bullet_3': safeString(report?.personalityAnalysis?.weaknesses?.[2]),
      'personality_weakness_bullet_4': safeString(report?.personalityAnalysis?.weaknesses?.[3]),
      'personality_weakness_bullet_5': safeString(report?.personalityAnalysis?.weaknesses?.[4]),

      // ===== PERSONALITY ASSESSMENT URLS (4 columns) =====
      'mbti_assessment_url': safeString(personalityUrls.mbtiUrl),
      'enneagram_assessment_url': safeString(personalityUrls.enneagramUrl),
      'disc_assessment_url': safeString(personalityUrls.discUrl),
      'big_five_assessment_url': safeString(personalityUrls.bigFiveUrl),

      // ===== TEAM VOICE (10 columns - standard 1-4, extended 5) =====
      'team_voice_feedback_box_1_title': safeString(report?.teamVoice?.[0]?.title),
      'team_voice_feedback_box_1_content': safeString(report?.teamVoice?.[0]?.content),
      'team_voice_feedback_box_2_title': safeString(report?.teamVoice?.[1]?.title),
      'team_voice_feedback_box_2_content': safeString(report?.teamVoice?.[1]?.content),
      'team_voice_feedback_box_3_title': safeString(report?.teamVoice?.[2]?.title),
      'team_voice_feedback_box_3_content': safeString(report?.teamVoice?.[2]?.content),
      'team_voice_feedback_box_4_title': safeString(report?.teamVoice?.[3]?.title),
      'team_voice_feedback_box_4_content': safeString(report?.teamVoice?.[3]?.content),
      'team_voice_feedback_box_5_title_extended': safeString(report?.teamVoice?.[4]?.title),
      'team_voice_feedback_box_5_content_extended': safeString(report?.teamVoice?.[4]?.content),

      // ===== DEVELOPMENT COMPASS / بوصلة التطوير (5 columns) =====
      'development_compass_1': safeString(report?.developmentCompass?.[0]),
      'development_compass_2': safeString(report?.developmentCompass?.[1]),
      'development_compass_3': safeString(report?.developmentCompass?.[2]),
      'development_compass_4': safeString(report?.developmentCompass?.[3]),
      'development_compass_5': safeString(report?.developmentCompass?.[4]),

      // ===== ROADMAP (21 columns - includes extended step 5 for each priority) =====
      'roadmap_priority_1_highest_action_title': safeString(report?.roadmap?.[0]?.title),
      'roadmap_priority_1_highest_badge_label': safeString(report?.roadmap?.[0]?.priorityAr),
      'roadmap_priority_1_highest_step_1': safeString(report?.roadmap?.[0]?.steps?.[0]),
      'roadmap_priority_1_highest_step_2': safeString(report?.roadmap?.[0]?.steps?.[1]),
      'roadmap_priority_1_highest_step_3': safeString(report?.roadmap?.[0]?.steps?.[2]),
      'roadmap_priority_1_highest_step_4': safeString(report?.roadmap?.[0]?.steps?.[3]),
      'roadmap_priority_1_highest_step_5_extended': safeString(report?.roadmap?.[0]?.steps?.[4]),
      'roadmap_priority_2_urgent_action_title': safeString(report?.roadmap?.[1]?.title),
      'roadmap_priority_2_urgent_badge_label': safeString(report?.roadmap?.[1]?.priorityAr),
      'roadmap_priority_2_urgent_step_1': safeString(report?.roadmap?.[1]?.steps?.[0]),
      'roadmap_priority_2_urgent_step_2': safeString(report?.roadmap?.[1]?.steps?.[1]),
      'roadmap_priority_2_urgent_step_3': safeString(report?.roadmap?.[1]?.steps?.[2]),
      'roadmap_priority_2_urgent_step_4': safeString(report?.roadmap?.[1]?.steps?.[3]),
      'roadmap_priority_2_urgent_step_5_extended': safeString(report?.roadmap?.[1]?.steps?.[4]),
      'roadmap_priority_3_ongoing_action_title': safeString(report?.roadmap?.[2]?.title),
      'roadmap_priority_3_ongoing_badge_label': safeString(report?.roadmap?.[2]?.priorityAr),
      'roadmap_priority_3_ongoing_step_1': safeString(report?.roadmap?.[2]?.steps?.[0]),
      'roadmap_priority_3_ongoing_step_2': safeString(report?.roadmap?.[2]?.steps?.[1]),
      'roadmap_priority_3_ongoing_step_3': safeString(report?.roadmap?.[2]?.steps?.[2]),
      'roadmap_priority_3_ongoing_step_4': safeString(report?.roadmap?.[2]?.steps?.[3]),
      'roadmap_priority_3_ongoing_step_5_extended': safeString(report?.roadmap?.[2]?.steps?.[4]),

      // ===== DEVELOPMENT PLAN (44 columns) =====
      'dev_plan_track_1_category_title': safeString(report?.developmentPlan?.[0]?.categoryTitle),
      'dev_plan_track_1_resource_1_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[0]?.title),
      'dev_plan_track_1_resource_1_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[0]?.link),
      'dev_plan_track_1_resource_2_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[1]?.title),
      'dev_plan_track_1_resource_2_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[1]?.link),
      'dev_plan_track_1_resource_3_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[2]?.title),
      'dev_plan_track_1_resource_3_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[2]?.link),
      'dev_plan_track_1_resource_4_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[3]?.title),
      'dev_plan_track_1_resource_4_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[3]?.link),
      'dev_plan_track_1_resource_5_short_title': safeString(report?.developmentPlan?.[0]?.resources?.[4]?.title),
      'dev_plan_track_1_resource_5_url_link': safeString(report?.developmentPlan?.[0]?.resources?.[4]?.link),
      'dev_plan_track_2_category_title': safeString(report?.developmentPlan?.[1]?.categoryTitle),
      'dev_plan_track_2_resource_1_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[0]?.title),
      'dev_plan_track_2_resource_1_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[0]?.link),
      'dev_plan_track_2_resource_2_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[1]?.title),
      'dev_plan_track_2_resource_2_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[1]?.link),
      'dev_plan_track_2_resource_3_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[2]?.title),
      'dev_plan_track_2_resource_3_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[2]?.link),
      'dev_plan_track_2_resource_4_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[3]?.title),
      'dev_plan_track_2_resource_4_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[3]?.link),
      'dev_plan_track_2_resource_5_short_title': safeString(report?.developmentPlan?.[1]?.resources?.[4]?.title),
      'dev_plan_track_2_resource_5_url_link': safeString(report?.developmentPlan?.[1]?.resources?.[4]?.link),
      'dev_plan_track_3_category_title': safeString(report?.developmentPlan?.[2]?.categoryTitle),
      'dev_plan_track_3_resource_1_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[0]?.title),
      'dev_plan_track_3_resource_1_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[0]?.link),
      'dev_plan_track_3_resource_2_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[1]?.title),
      'dev_plan_track_3_resource_2_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[1]?.link),
      'dev_plan_track_3_resource_3_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[2]?.title),
      'dev_plan_track_3_resource_3_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[2]?.link),
      'dev_plan_track_3_resource_4_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[3]?.title),
      'dev_plan_track_3_resource_4_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[3]?.link),
      'dev_plan_track_3_resource_5_short_title': safeString(report?.developmentPlan?.[2]?.resources?.[4]?.title),
      'dev_plan_track_3_resource_5_url_link': safeString(report?.developmentPlan?.[2]?.resources?.[4]?.link),
      'dev_plan_track_4_category_title': safeString(report?.developmentPlan?.[3]?.categoryTitle),
      'dev_plan_track_4_resource_1_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[0]?.title),
      'dev_plan_track_4_resource_1_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[0]?.link),
      'dev_plan_track_4_resource_2_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[1]?.title),
      'dev_plan_track_4_resource_2_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[1]?.link),
      'dev_plan_track_4_resource_3_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[2]?.title),
      'dev_plan_track_4_resource_3_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[2]?.link),
      'dev_plan_track_4_resource_4_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[3]?.title),
      'dev_plan_track_4_resource_4_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[3]?.link),
      'dev_plan_track_4_resource_5_short_title': safeString(report?.developmentPlan?.[3]?.resources?.[4]?.title),
      'dev_plan_track_4_resource_5_url_link': safeString(report?.developmentPlan?.[3]?.resources?.[4]?.link),
    };

    rows.push(row);
  });

  // Add failed candidates
  const failed = Array.isArray(batchResults?.failed) ? batchResults.failed : [];
  failed.forEach(result => {
    rows.push({
      'employee_name_for_header_greeting': safeString(result.candidateName),
      'report_generation_status': 'Failed',
      'report_generation_error': safeString(result.error)
    });
  });

  return rows;
}

export default {
  generateReportFromFeedback,
  editReportSection,
  generateWeightedReport,
  processBatchCandidates,
  extractUniqueCandidates,
  convertToExcelFormat,
  BATCH_CONFIG
};
