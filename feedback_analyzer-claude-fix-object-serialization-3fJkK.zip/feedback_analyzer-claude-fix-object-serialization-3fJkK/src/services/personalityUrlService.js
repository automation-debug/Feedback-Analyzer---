/**
 * Personality Test URL Service
 * Provides verified URLs for personality type assessments
 * Sources: 16personalities.com, crystalknows.com
 */

// MBTI/16 Personalities URLs (Source: 16personalities.com)
const MBTI_URLS = {
  // Analysts
  'INTJ': 'https://www.16personalities.com/intj-personality',
  'INTP': 'https://www.16personalities.com/intp-personality',
  'ENTJ': 'https://www.16personalities.com/entj-personality',
  'ENTP': 'https://www.16personalities.com/entp-personality',
  // Diplomats
  'INFJ': 'https://www.16personalities.com/infj-personality',
  'INFP': 'https://www.16personalities.com/infp-personality',
  'ENFJ': 'https://www.16personalities.com/enfj-personality',
  'ENFP': 'https://www.16personalities.com/enfp-personality',
  // Sentinels
  'ISTJ': 'https://www.16personalities.com/istj-personality',
  'ISFJ': 'https://www.16personalities.com/isfj-personality',
  'ESTJ': 'https://www.16personalities.com/estj-personality',
  'ESFJ': 'https://www.16personalities.com/esfj-personality',
  // Explorers
  'ISTP': 'https://www.16personalities.com/istp-personality',
  'ISFP': 'https://www.16personalities.com/isfp-personality',
  'ESTP': 'https://www.16personalities.com/estp-personality',
  'ESFP': 'https://www.16personalities.com/esfp-personality',
};

// Enneagram URLs (Source: crystalknows.com)
const ENNEAGRAM_URLS = {
  // Base types
  'Type 1': 'https://www.crystalknows.com/enneagram/type-1',
  'Type 2': 'https://www.crystalknows.com/enneagram/type-2',
  'Type 3': 'https://www.crystalknows.com/enneagram/type-3',
  'Type 4': 'https://www.crystalknows.com/enneagram/type-4',
  'Type 5': 'https://www.crystalknows.com/enneagram/type-5',
  'Type 6': 'https://www.crystalknows.com/enneagram/type-6',
  'Type 7': 'https://www.crystalknows.com/enneagram/type-7',
  'Type 8': 'https://www.crystalknows.com/enneagram/type-8',
  'Type 9': 'https://www.crystalknows.com/enneagram/type-9',
  // Number-only format
  '1': 'https://www.crystalknows.com/enneagram/type-1',
  '2': 'https://www.crystalknows.com/enneagram/type-2',
  '3': 'https://www.crystalknows.com/enneagram/type-3',
  '4': 'https://www.crystalknows.com/enneagram/type-4',
  '5': 'https://www.crystalknows.com/enneagram/type-5',
  '6': 'https://www.crystalknows.com/enneagram/type-6',
  '7': 'https://www.crystalknows.com/enneagram/type-7',
  '8': 'https://www.crystalknows.com/enneagram/type-8',
  '9': 'https://www.crystalknows.com/enneagram/type-9',
  // Wing variants - Type 1
  'Type 1w9': 'https://www.crystalknows.com/enneagram/type-1-wing-9',
  'Type 1w2': 'https://www.crystalknows.com/enneagram/type-1-wing-2',
  '1w9': 'https://www.crystalknows.com/enneagram/type-1-wing-9',
  '1w2': 'https://www.crystalknows.com/enneagram/type-1-wing-2',
  // Wing variants - Type 2
  'Type 2w1': 'https://www.crystalknows.com/enneagram/type-2-wing-1',
  'Type 2w3': 'https://www.crystalknows.com/enneagram/type-2-wing-3',
  '2w1': 'https://www.crystalknows.com/enneagram/type-2-wing-1',
  '2w3': 'https://www.crystalknows.com/enneagram/type-2-wing-3',
  // Wing variants - Type 3
  'Type 3w2': 'https://www.crystalknows.com/enneagram/type-3-wing-2',
  'Type 3w4': 'https://www.crystalknows.com/enneagram/type-3-wing-4',
  '3w2': 'https://www.crystalknows.com/enneagram/type-3-wing-2',
  '3w4': 'https://www.crystalknows.com/enneagram/type-3-wing-4',
  // Wing variants - Type 4
  'Type 4w3': 'https://www.crystalknows.com/enneagram/type-4-wing-3',
  'Type 4w5': 'https://www.crystalknows.com/enneagram/type-4-wing-5',
  '4w3': 'https://www.crystalknows.com/enneagram/type-4-wing-3',
  '4w5': 'https://www.crystalknows.com/enneagram/type-4-wing-5',
  // Wing variants - Type 5
  'Type 5w4': 'https://www.crystalknows.com/enneagram/type-5-wing-4',
  'Type 5w6': 'https://www.crystalknows.com/enneagram/type-5-wing-6',
  '5w4': 'https://www.crystalknows.com/enneagram/type-5-wing-4',
  '5w6': 'https://www.crystalknows.com/enneagram/type-5-wing-6',
  // Wing variants - Type 6
  'Type 6w5': 'https://www.crystalknows.com/enneagram/type-6-wing-5',
  'Type 6w7': 'https://www.crystalknows.com/enneagram/type-6-wing-7',
  '6w5': 'https://www.crystalknows.com/enneagram/type-6-wing-5',
  '6w7': 'https://www.crystalknows.com/enneagram/type-6-wing-7',
  // Wing variants - Type 7
  'Type 7w6': 'https://www.crystalknows.com/enneagram/type-7-wing-6',
  'Type 7w8': 'https://www.crystalknows.com/enneagram/type-7-wing-8',
  '7w6': 'https://www.crystalknows.com/enneagram/type-7-wing-6',
  '7w8': 'https://www.crystalknows.com/enneagram/type-7-wing-8',
  // Wing variants - Type 8
  'Type 8w7': 'https://www.crystalknows.com/enneagram/type-8-wing-7',
  'Type 8w9': 'https://www.crystalknows.com/enneagram/type-8-wing-9',
  '8w7': 'https://www.crystalknows.com/enneagram/type-8-wing-7',
  '8w9': 'https://www.crystalknows.com/enneagram/type-8-wing-9',
  // Wing variants - Type 9
  'Type 9w8': 'https://www.crystalknows.com/enneagram/type-9-wing-8',
  'Type 9w1': 'https://www.crystalknows.com/enneagram/type-9-wing-1',
  '9w8': 'https://www.crystalknows.com/enneagram/type-9-wing-8',
  '9w1': 'https://www.crystalknows.com/enneagram/type-9-wing-1',
};

// DISC Profile URLs (Source: crystalknows.com)
const DISC_URLS = {
  // D (Dominance) Types
  'D': 'https://www.crystalknows.com/disc/d-personality-type/',
  'High D': 'https://www.crystalknows.com/disc/d-personality-type/',
  'Type D': 'https://www.crystalknows.com/disc/d-personality-type/',
  'Di': 'https://www.crystalknows.com/disc/di-personality-type/',
  'DI': 'https://www.crystalknows.com/disc/d-i-personality-type/',
  'D/I': 'https://www.crystalknows.com/disc/d-i-personality-type/',
  'Dc': 'https://www.crystalknows.com/disc/dc-personality-type/',
  'DC': 'https://www.crystalknows.com/disc/dc-personality-type/',
  'D/C': 'https://www.crystalknows.com/disc/dc-personality-type/',
  // I (Influence) Types
  'I': 'https://www.crystalknows.com/disc/i-personality-type/',
  'High I': 'https://www.crystalknows.com/disc/i-personality-type/',
  'Type I': 'https://www.crystalknows.com/disc/i-personality-type/',
  'Id': 'https://www.crystalknows.com/disc/id-personality-type/',
  'ID': 'https://www.crystalknows.com/disc/id-personality-type/',
  'I/D': 'https://www.crystalknows.com/disc/id-personality-type/',
  'Is': 'https://www.crystalknows.com/disc/is-personality-type/',
  'IS': 'https://www.crystalknows.com/disc/i-s-personality-type/',
  'I/S': 'https://www.crystalknows.com/disc/i-s-personality-type/',
  // S (Steadiness) Types
  'S': 'https://www.crystalknows.com/disc/s-personality-type/',
  'High S': 'https://www.crystalknows.com/disc/s-personality-type/',
  'Type S': 'https://www.crystalknows.com/disc/s-personality-type/',
  'Si': 'https://www.crystalknows.com/disc/si-personality-type/',
  'SI': 'https://www.crystalknows.com/disc/si-personality-type/',
  'S/I': 'https://www.crystalknows.com/disc/si-personality-type/',
  'Sc': 'https://www.crystalknows.com/disc/sc-personality-type/',
  'SC': 'https://www.crystalknows.com/disc/s-c-personality-type/',
  'S/C': 'https://www.crystalknows.com/disc/s-c-personality-type/',
  // C (Conscientiousness) Types
  'C': 'https://www.crystalknows.com/disc/c-personality-type/',
  'High C': 'https://www.crystalknows.com/disc/c-personality-type/',
  'Type C': 'https://www.crystalknows.com/disc/c-personality-type/',
  'Cs': 'https://www.crystalknows.com/disc/cs-personality-type/',
  'CS': 'https://www.crystalknows.com/disc/cs-personality-type/',
  'C/S': 'https://www.crystalknows.com/disc/cs-personality-type/',
  'Cd': 'https://www.crystalknows.com/disc/cd-personality-type/',
  'CD': 'https://www.crystalknows.com/disc/c-d-personality-type/',
  'C/D': 'https://www.crystalknows.com/disc/c-d-personality-type/',
  // Full names
  'Dominance': 'https://www.crystalknows.com/disc/d-personality-type/',
  'Influence': 'https://www.crystalknows.com/disc/i-personality-type/',
  'Steadiness': 'https://www.crystalknows.com/disc/s-personality-type/',
  'Conscientiousness': 'https://www.crystalknows.com/disc/c-personality-type/',
};

// Big Five (OCEAN) URL (Source: crystalknows.com)
const BIG_FIVE_URL = 'https://www.crystalknows.com/big-five';

// Default/fallback URLs for each framework
const DEFAULT_URLS = {
  mbti: 'https://www.16personalities.com/personality-types',
  enneagram: 'https://www.crystalknows.com/enneagram',
  disc: 'https://www.crystalknows.com/disc',
  bigFive: 'https://www.crystalknows.com/big-five',
};

/**
 * Normalize personality type string for matching
 * @param {string} type - Raw type string
 * @returns {string} - Normalized string
 */
function normalizeType(type) {
  if (!type || typeof type !== 'string') return '';
  return type.trim().toUpperCase();
}

/**
 * Extract MBTI type from various formats
 * @param {string} type - Raw MBTI type
 * @returns {string|null} - Normalized 4-letter code or null
 */
function extractMbtiType(type) {
  if (!type) return null;
  const normalized = normalizeType(type);

  // Try to extract 4-letter code
  const match = normalized.match(/[IE][NS][TF][JP]/);
  if (match) return match[0];

  return null;
}

/**
 * Extract Enneagram type (with optional wing)
 * @param {string} type - Raw enneagram type
 * @returns {string|null} - "Type X" or "Type XwY" format or null
 */
function extractEnneagramType(type) {
  if (!type) return null;
  const normalized = type.toString().trim();

  // Match wing format first: "Type 8w7", "8w7", "Type 8 wing 7"
  const wingMatch = normalized.match(/(?:type\s*)?(\d)(?:w|wing\s*)(\d)/i);
  if (wingMatch && wingMatch[1] >= '1' && wingMatch[1] <= '9') {
    return `Type ${wingMatch[1]}w${wingMatch[2]}`;
  }

  // Match base type: "Type X", "X"
  const baseMatch = normalized.match(/(?:type\s*)?(\d)/i);
  if (baseMatch && baseMatch[1] >= '1' && baseMatch[1] <= '9') {
    return `Type ${baseMatch[1]}`;
  }

  return null;
}

/**
 * Extract DISC type
 * @param {string} type - Raw DISC type
 * @returns {string|null} - Type code or null
 */
function extractDiscType(type) {
  if (!type) return null;
  const normalized = type.trim();

  // Check for combination types (Di, DI, D/I, etc.)
  const comboMatch = normalized.match(/^([DISC])[\s\/]?([disc])$/i);
  if (comboMatch) {
    const primary = comboMatch[1].toUpperCase();
    const secondary = comboMatch[2].toLowerCase();
    // Try exact match first
    const exactKey = `${primary}${secondary}`;
    if (DISC_URLS[exactKey]) return exactKey;
    // Try uppercase variant
    const upperKey = `${primary}${secondary.toUpperCase()}`;
    if (DISC_URLS[upperKey]) return upperKey;
    // Try slash variant
    const slashKey = `${primary}/${secondary.toUpperCase()}`;
    if (DISC_URLS[slashKey]) return slashKey;
  }

  // Check for "High X" format
  const highMatch = normalized.match(/high\s*([disc])/i);
  if (highMatch) {
    return `High ${highMatch[1].toUpperCase()}`;
  }

  // Check for "Type X" format
  const typeMatch = normalized.match(/type\s*([disc])/i);
  if (typeMatch) {
    return `Type ${typeMatch[1].toUpperCase()}`;
  }

  // Check for single letter
  const letterMatch = normalized.match(/^([disc])$/i);
  if (letterMatch) {
    return letterMatch[1].toUpperCase();
  }

  return normalized;
}

/**
 * Get MBTI personality type URL
 * @param {string} type - MBTI type (e.g., "INTJ", "INTJ-A")
 * @returns {string} - URL for the type
 */
export function getMbtiUrl(type) {
  const extracted = extractMbtiType(type);
  if (extracted && MBTI_URLS[extracted]) {
    return MBTI_URLS[extracted];
  }
  return DEFAULT_URLS.mbti;
}

/**
 * Get Enneagram personality type URL
 * @param {string} type - Enneagram type (e.g., "Type 8", "8", "Type 8w7")
 * @returns {string} - URL for the type
 */
export function getEnneagramUrl(type) {
  const extracted = extractEnneagramType(type);
  if (extracted && ENNEAGRAM_URLS[extracted]) {
    return ENNEAGRAM_URLS[extracted];
  }

  // Try direct lookup
  if (ENNEAGRAM_URLS[type]) {
    return ENNEAGRAM_URLS[type];
  }

  return DEFAULT_URLS.enneagram;
}

/**
 * Get DISC profile type URL
 * @param {string} type - DISC type (e.g., "High D", "Di", "D/I")
 * @returns {string} - URL for the type
 */
export function getDiscUrl(type) {
  const extracted = extractDiscType(type);
  if (extracted && DISC_URLS[extracted]) {
    return DISC_URLS[extracted];
  }

  // Try direct lookup
  if (DISC_URLS[type]) {
    return DISC_URLS[type];
  }

  return DEFAULT_URLS.disc;
}

/**
 * Get Big Five personality trait URL
 * @param {string} type - Big Five type (e.g., "High Conscientiousness")
 * @returns {string} - URL for Big Five overview
 */
export function getBigFiveUrl(type) {
  // All Big Five types point to the same overview page
  return BIG_FIVE_URL;
}

/**
 * Get all personality URLs from a report's personality analysis
 * @param {Object} personalityAnalysis - The personalityAnalysis object from the report
 * @returns {Object} - Object with all 4 URLs
 */
export function getPersonalityUrls(personalityAnalysis) {
  if (!personalityAnalysis) {
    return {
      mbtiUrl: DEFAULT_URLS.mbti,
      enneagramUrl: DEFAULT_URLS.enneagram,
      discUrl: DEFAULT_URLS.disc,
      bigFiveUrl: DEFAULT_URLS.bigFive,
    };
  }

  return {
    mbtiUrl: getMbtiUrl(personalityAnalysis.mbpiType),
    enneagramUrl: getEnneagramUrl(personalityAnalysis.enneagramType),
    discUrl: getDiscUrl(personalityAnalysis.discType),
    bigFiveUrl: getBigFiveUrl(personalityAnalysis.bigFiveType),
  };
}

/**
 * Add personality URLs to a report export row
 * @param {Object} row - Export row object
 * @param {Object} personalityAnalysis - The personalityAnalysis object
 * @returns {Object} - Row with added URL columns
 */
export function addPersonalityUrlsToRow(row, personalityAnalysis) {
  const urls = getPersonalityUrls(personalityAnalysis);

  return {
    ...row,
    'mbti_assessment_url': urls.mbtiUrl,
    'enneagram_assessment_url': urls.enneagramUrl,
    'disc_assessment_url': urls.discUrl,
    'big_five_assessment_url': urls.bigFiveUrl,
  };
}

export default {
  getMbtiUrl,
  getEnneagramUrl,
  getDiscUrl,
  getBigFiveUrl,
  getPersonalityUrls,
  addPersonalityUrlsToRow,
  DEFAULT_URLS,
};
