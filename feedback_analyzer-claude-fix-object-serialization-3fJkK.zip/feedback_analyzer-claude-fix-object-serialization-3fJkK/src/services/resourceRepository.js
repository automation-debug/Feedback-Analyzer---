/**
 * Resource Repository
 * Curated collection of verified leadership development resources
 * AI picks from this repository instead of generating URLs
 */

export const BOOKS = [
  {
    id: "speed-of-trust",
    titleEn: "The Speed of Trust",
    titleAr: "سرعة الثقة",
    author: "Stephen M.R. Covey",
    url: "https://www.amazon.com/dp/1416549005",
    categories: ["trust", "leadership", "safety"]
  },
  {
    id: "dare-to-lead",
    titleEn: "Dare to Lead",
    titleAr: "تجرأ على القيادة",
    author: "Brené Brown",
    url: "https://www.amazon.com/dp/0399592520",
    categories: ["trust", "vulnerability", "leadership"]
  },
  {
    id: "daring-greatly",
    titleEn: "Daring Greatly",
    titleAr: "بجرأة شديدة",
    author: "Brené Brown",
    url: "https://www.amazon.com/dp/1592408419",
    categories: ["vulnerability", "courage", "safety"]
  },
  {
    id: "fearless-organization",
    titleEn: "The Fearless Organization",
    titleAr: "المؤسسة التي لا تهاب",
    author: "Amy Edmondson",
    url: "https://www.amazon.com/dp/1119477247",
    categories: ["trust", "safety", "teams"]
  },
  {
    id: "thin-book-of-trust",
    titleEn: "The Thin Book of Trust",
    titleAr: "كتاب الثقة الصغير",
    author: "Charles Feltman",
    url: "https://www.amazon.com/dp/0966537341",
    categories: ["trust", "care", "relationships"]
  },
  {
    id: "trust-and-inspire",
    titleEn: "Trust and Inspire",
    titleAr: "الثقة والإلهام",
    author: "Stephen M.R. Covey",
    url: "https://www.amazon.com/dp/1982143098",
    categories: ["leadership", "inspiration", "empowerment"]
  },
  {
    id: "leaders-eat-last",
    titleEn: "Leaders Eat Last",
    titleAr: "القادة يأكلون أخيراً",
    author: "Simon Sinek",
    url: "https://www.amazon.com/dp/1591845327",
    categories: ["leadership", "safety", "trust"]
  },
  {
    id: "start-with-why",
    titleEn: "Start With Why",
    titleAr: "ابدأ بـ لماذا",
    author: "Simon Sinek",
    url: "https://www.amazon.com/dp/1591846447",
    categories: ["purpose", "influence", "clarity"]
  },
  {
    id: "infinite-game",
    titleEn: "The Infinite Game",
    titleAr: "اللعبة اللانهائية",
    author: "Simon Sinek",
    url: "https://www.amazon.com/dp/0735213560",
    categories: ["strategy", "leadership", "vision"]
  },
  {
    id: "good-to-great",
    titleEn: "Good to Great",
    titleAr: "من جيد إلى عظيم",
    author: "Jim Collins",
    url: "https://www.amazon.com/dp/0066620996",
    categories: ["leadership", "performance", "excellence"]
  },
  {
    id: "21-laws-leadership",
    titleEn: "The 21 Irrefutable Laws of Leadership",
    titleAr: "21 قانوناً في القيادة",
    author: "John Maxwell",
    url: "https://www.amazon.com/dp/0785288376",
    categories: ["leadership", "laws", "influence"]
  },
  {
    id: "servant-leadership",
    titleEn: "Servant Leadership",
    titleAr: "القيادة الخادمة",
    author: "Robert Greenleaf",
    url: "https://www.amazon.com/dp/0809105543",
    categories: ["leadership", "service", "empowerment"]
  },
  {
    id: "multipliers",
    titleEn: "Multipliers",
    titleAr: "المضاعفون",
    author: "Liz Wiseman",
    url: "https://www.amazon.com/dp/0062657569",
    categories: ["leadership", "intelligence", "empowerment"]
  },
  {
    id: "turn-ship-around",
    titleEn: "Turn the Ship Around",
    titleAr: "اقلب السفينة",
    author: "L. David Marquet",
    url: "https://www.amazon.com/dp/1591846404",
    categories: ["leadership", "empowerment", "delegation"]
  },
  {
    id: "extreme-ownership",
    titleEn: "Extreme Ownership",
    titleAr: "الملكية المطلقة",
    author: "Jocko Willink",
    url: "https://www.amazon.com/dp/1250067057",
    categories: ["leadership", "accountability", "responsibility"]
  },
  {
    id: "primal-leadership",
    titleEn: "Primal Leadership",
    titleAr: "القيادة البدائية",
    author: "Daniel Goleman",
    url: "https://www.amazon.com/dp/1422168034",
    categories: ["leadership", "emotional-intelligence", "resonance"]
  },
  {
    id: "crucial-conversations",
    titleEn: "Crucial Conversations",
    titleAr: "محادثات حاسمة",
    author: "Patterson, Grenny, McMillan",
    url: "https://www.amazon.com/dp/1260474186",
    categories: ["communication", "conflict", "clarity"]
  },
  {
    id: "radical-candor",
    titleEn: "Radical Candor",
    titleAr: "الصراحة المطلقة",
    author: "Kim Scott",
    url: "https://www.amazon.com/dp/1250235375",
    categories: ["feedback", "leadership", "communication"]
  },
  {
    id: "nonviolent-communication",
    titleEn: "Nonviolent Communication",
    titleAr: "التواصل غير العنيف",
    author: "Marshall Rosenberg",
    url: "https://www.amazon.com/dp/189200528X",
    categories: ["communication", "empathy", "safety"]
  },
  {
    id: "difficult-conversations",
    titleEn: "Difficult Conversations",
    titleAr: "محادثات صعبة",
    author: "Stone, Patton, Heen",
    url: "https://www.amazon.com/dp/0143118447",
    categories: ["communication", "feedback", "conflict"]
  },
  {
    id: "thanks-for-feedback",
    titleEn: "Thanks for the Feedback",
    titleAr: "شكراً على الملاحظات",
    author: "Stone & Heen",
    url: "https://www.amazon.com/dp/0143127136",
    categories: ["feedback", "learning", "growth"]
  },
  {
    id: "coaching-habit",
    titleEn: "The Coaching Habit",
    titleAr: "عادة التدريب",
    author: "Michael Bungay Stanier",
    url: "https://www.amazon.com/dp/0994995300",
    categories: ["coaching", "empowerment", "development"]
  },
  {
    id: "emotional-intelligence",
    titleEn: "Emotional Intelligence",
    titleAr: "الذكاء العاطفي",
    author: "Daniel Goleman",
    url: "https://www.amazon.com/dp/055338371X",
    categories: ["emotional-intelligence", "psychology", "self-awareness"]
  },
  {
    id: "emotional-intelligence-2",
    titleEn: "Emotional Intelligence 2.0",
    titleAr: "الذكاء العاطفي 2.0",
    author: "Travis Bradberry",
    url: "https://www.amazon.com/dp/0974320625",
    categories: ["emotional-intelligence", "skills", "development"]
  },
  {
    id: "eq-edge",
    titleEn: "The EQ Edge",
    titleAr: "حافة الذكاء العاطفي",
    author: "Steven Stein",
    url: "https://www.amazon.com/dp/0470681613",
    categories: ["emotional-intelligence", "success", "assessment"]
  },
  {
    id: "working-emotional-intelligence",
    titleEn: "Working with Emotional Intelligence",
    titleAr: "العمل مع الذكاء العاطفي",
    author: "Daniel Goleman",
    url: "https://www.amazon.com/dp/0553378589",
    categories: ["emotional-intelligence", "professional", "workplace"]
  },
  {
    id: "five-dysfunctions",
    titleEn: "The Five Dysfunctions of a Team",
    titleAr: "خلل العمل الجماعي الخمسة",
    author: "Patrick Lencioni",
    url: "https://www.amazon.com/dp/0787960756",
    categories: ["teams", "trust", "collaboration"]
  },
  {
    id: "culture-code",
    titleEn: "The Culture Code",
    titleAr: "شفرة الثقافة",
    author: "Daniel Coyle",
    url: "https://www.amazon.com/dp/0525492461",
    categories: ["culture", "teams", "safety"]
  },
  {
    id: "team-of-teams",
    titleEn: "Team of Teams",
    titleAr: "فريق الفرق",
    author: "General Stanley McChrystal",
    url: "https://www.amazon.com/dp/1591847486",
    categories: ["teams", "adaptability", "leadership"]
  },
  {
    id: "ideal-team-player",
    titleEn: "The Ideal Team Player",
    titleAr: "اللاعب المثالي في الفريق",
    author: "Patrick Lencioni",
    url: "https://www.amazon.com/dp/1119209595",
    categories: ["teams", "hiring", "culture"]
  },
  {
    id: "collaborative-intelligence",
    titleEn: "Collaborative Intelligence",
    titleAr: "الذكاء التعاوني",
    author: "Dawna Markova",
    url: "https://www.amazon.com/dp/0812994906",
    categories: ["teams", "collaboration", "thinking"]
  },
  {
    id: "one-minute-manager",
    titleEn: "The One Minute Manager",
    titleAr: "مدير الدقيقة الواحدة",
    author: "Ken Blanchard",
    url: "https://www.amazon.com/dp/0062367544",
    categories: ["management", "delegation", "efficiency"]
  },
  {
    id: "one-minute-manager-monkey",
    titleEn: "The One Minute Manager Meets the Monkey",
    titleAr: "مدير الدقيقة الواحدة يقابل القرد",
    author: "Ken Blanchard",
    url: "https://www.amazon.com/dp/0688089671",
    categories: ["delegation", "empowerment", "time-management"]
  },
  {
    id: "done-right-yourself",
    titleEn: "If You Want It Done Right, You Don't Have to Do It Yourself",
    titleAr: "إذا أردت إنجازه بشكل صحيح",
    author: "Donna Genett",
    url: "https://www.amazon.com/dp/1402203037",
    categories: ["delegation", "management", "empowerment"]
  },
  {
    id: "leadership-self-deception",
    titleEn: "Leadership and Self-Deception",
    titleAr: "القيادة وخداع الذات",
    author: "Arbinger Institute",
    url: "https://www.amazon.com/dp/1576759776",
    categories: ["mindset", "leadership", "self-awareness"]
  },
  {
    id: "7-habits",
    titleEn: "The 7 Habits of Highly Effective People",
    titleAr: "العادات السبع للأشخاص الأكثر فعالية",
    author: "Stephen Covey",
    url: "https://www.amazon.com/dp/1982137276",
    categories: ["productivity", "growth", "effectiveness"]
  },
  {
    id: "deep-work",
    titleEn: "Deep Work",
    titleAr: "العمل العميق",
    author: "Cal Newport",
    url: "https://www.amazon.com/dp/1455586692",
    categories: ["productivity", "focus", "efficiency"]
  },
  {
    id: "getting-things-done",
    titleEn: "Getting Things Done",
    titleAr: "إنجاز المهام",
    author: "David Allen",
    url: "https://www.amazon.com/dp/0143126563",
    categories: ["productivity", "efficiency", "organization"]
  },
  {
    id: "essentialism",
    titleEn: "Essentialism",
    titleAr: "الجوهرية",
    author: "Greg McKeown",
    url: "https://www.amazon.com/dp/0804137382",
    categories: ["productivity", "strategy", "focus"]
  },
  {
    id: "effective-executive",
    titleEn: "The Effective Executive",
    titleAr: "المدير الفعال",
    author: "Peter Drucker",
    url: "https://www.amazon.com/dp/0060833459",
    categories: ["leadership", "effectiveness", "management"]
  },
  {
    id: "atomic-habits",
    titleEn: "Atomic Habits",
    titleAr: "العادات الذرية",
    author: "James Clear",
    url: "https://www.amazon.com/dp/0735211299",
    categories: ["habits", "productivity", "growth"]
  },
  {
    id: "thinking-fast-slow",
    titleEn: "Thinking, Fast and Slow",
    titleAr: "التفكير بسرعة وببطء",
    author: "Daniel Kahneman",
    url: "https://www.amazon.com/dp/0374533555",
    categories: ["decision-making", "psychology", "clarity"]
  },
  {
    id: "decisive",
    titleEn: "Decisive",
    titleAr: "حاسم",
    author: "Chip & Dan Heath",
    url: "https://www.amazon.com/dp/030795639X",
    categories: ["decision-making", "strategy", "clarity"]
  },
  {
    id: "first-90-days",
    titleEn: "The First 90 Days",
    titleAr: "أول 90 يوماً",
    author: "Michael Watkins",
    url: "https://www.amazon.com/dp/1422188612",
    categories: ["leadership", "transition", "strategy"]
  },
  {
    id: "hbr-leadership",
    titleEn: "HBR's 10 Must Reads on Leadership",
    titleAr: "أهم 10 مقالات في القيادة",
    author: "Harvard Business Review",
    url: "https://www.amazon.com/dp/1422157970",
    categories: ["leadership", "strategy", "management"]
  },
  {
    id: "win-friends",
    titleEn: "How to Win Friends and Influence People",
    titleAr: "كيف تكسب الأصدقاء وتؤثر في الناس",
    author: "Dale Carnegie",
    url: "https://www.amazon.com/dp/0671027034",
    categories: ["influence", "persuasion", "communication"]
  },
  {
    id: "influence",
    titleEn: "Influence",
    titleAr: "التأثير",
    author: "Robert Cialdini",
    url: "https://www.amazon.com/dp/006124189X",
    categories: ["influence", "psychology", "persuasion"]
  },
  {
    id: "pre-suasion",
    titleEn: "Pre-Suasion",
    titleAr: "ما قبل الإقناع",
    author: "Robert Cialdini",
    url: "https://www.amazon.com/dp/1501109790",
    categories: ["persuasion", "psychology", "influence"]
  },
  {
    id: "drive",
    titleEn: "Drive",
    titleAr: "الحافز",
    author: "Daniel Pink",
    url: "https://www.amazon.com/dp/1594484805",
    categories: ["motivation", "leadership", "empowerment"]
  },
  {
    id: "mindset",
    titleEn: "Mindset",
    titleAr: "طريقة التفكير",
    author: "Carol Dweck",
    url: "https://www.amazon.com/dp/0345472322",
    categories: ["mindset", "growth", "psychology"]
  },
  {
    id: "grit",
    titleEn: "Grit",
    titleAr: "المثابرة",
    author: "Angela Duckworth",
    url: "https://www.amazon.com/dp/1501111116",
    categories: ["success", "persistence", "growth"]
  },
  {
    id: "power-of-habit",
    titleEn: "The Power of Habit",
    titleAr: "قوة العادة",
    author: "Charles Duhigg",
    url: "https://www.amazon.com/dp/081298160X",
    categories: ["habits", "psychology", "change"]
  }
];

export const TED_TALKS = [
  {
    id: "sinek-why",
    titleEn: "How great leaders inspire action",
    titleAr: "كيف يلهم القادة العظماء الآخرين",
    speaker: "Simon Sinek",
    url: "https://www.youtube.com/watch?v=qp0HIF3SfI4",
    categories: ["leadership", "inspiration", "purpose"]
  },
  {
    id: "brown-vulnerability",
    titleEn: "The power of vulnerability",
    titleAr: "قوة الضعف",
    speaker: "Brené Brown",
    url: "https://www.youtube.com/watch?v=iCvmsMzlF7o",
    categories: ["courage", "leadership", "authenticity"]
  },
  {
    id: "sinek-safety",
    titleEn: "Why good leaders make you feel safe",
    titleAr: "لماذا يجعلك القادة الجيدون تشعر بالأمان",
    speaker: "Simon Sinek",
    url: "https://www.youtube.com/watch?v=lmyZMtPVodo",
    categories: ["leadership", "safety", "trust"]
  },
  {
    id: "dudley-everyday",
    titleEn: "Everyday leadership",
    titleAr: "القيادة اليومية",
    speaker: "Drew Dudley",
    url: "https://www.youtube.com/watch?v=uAy6EawKKME",
    categories: ["leadership", "impact", "influence"]
  },
  {
    id: "frei-trust",
    titleEn: "How to build (and rebuild) trust",
    titleAr: "كيف تبني الثقة وتستعيدها",
    speaker: "Frances Frei",
    url: "https://www.youtube.com/watch?v=pv8Z13_rVlY",
    categories: ["trust", "authenticity", "leadership"]
  },
  {
    id: "torres-great-leader",
    titleEn: "What it takes to be a great leader",
    titleAr: "ما يتطلبه الأمر لتكون قائداً عظيماً",
    speaker: "Roselinde Torres",
    url: "https://www.youtube.com/watch?v=aUfK7Y8m_9Y",
    categories: ["leadership", "strategy", "growth"]
  },
  {
    id: "pink-motivation",
    titleEn: "The puzzle of motivation",
    titleAr: "لغز التحفيز",
    speaker: "Daniel Pink",
    url: "https://www.youtube.com/watch?v=rrkrvAUbU9Y",
    categories: ["motivation", "psychology", "empowerment"]
  },
  {
    id: "duckworth-grit",
    titleEn: "Grit: The power of passion and perseverance",
    titleAr: "المثابرة: قوة الشغف والمواظبة",
    speaker: "Angela Duckworth",
    url: "https://www.youtube.com/watch?v=H14bBuluwB8",
    categories: ["grit", "success", "persistence"]
  },
  {
    id: "achor-happy",
    titleEn: "The happy secret to better work",
    titleAr: "السر السعيد للعمل بشكل أفضل",
    speaker: "Shawn Achor",
    url: "https://www.youtube.com/watch?v=fLJsdqxnZb0",
    categories: ["happiness", "productivity", "mindset"]
  },
  {
    id: "treasure-speak",
    titleEn: "How to speak so that people want to listen",
    titleAr: "كيف تتحدث لكي يرغب الناس في الاستماع إليك",
    speaker: "Julian Treasure",
    url: "https://www.youtube.com/watch?v=eIho2S0ZahI",
    categories: ["communication", "voice", "influence"]
  }
];

// Category mappings to core metrics
export const CATEGORY_TO_METRIC = {
  // Clarity-related
  'clarity': 'clarity',
  'communication': 'clarity',
  'decision-making': 'clarity',
  'strategy': 'clarity',
  'purpose': 'clarity',
  'vision': 'clarity',

  // Efficiency-related
  'efficiency': 'efficiency',
  'productivity': 'efficiency',
  'time-management': 'efficiency',
  'focus': 'efficiency',
  'organization': 'efficiency',
  'effectiveness': 'efficiency',
  'habits': 'efficiency',

  // Safety-related
  'safety': 'safety',
  'trust': 'safety',
  'vulnerability': 'safety',
  'emotional-intelligence': 'safety',
  'empathy': 'safety',
  'culture': 'safety',
  'authenticity': 'safety',

  // Empowerment-related
  'empowerment': 'empowerment',
  'delegation': 'empowerment',
  'coaching': 'empowerment',
  'development': 'empowerment',
  'motivation': 'empowerment',
  'growth': 'empowerment',
  'teams': 'empowerment',

  // General leadership (can apply to any)
  'leadership': 'all',
  'influence': 'all',
  'management': 'all'
};

/**
 * Get resources by category
 * @param {string} category - Category to filter by
 * @param {number} limit - Maximum number of resources to return
 * @returns {Array} Array of resources
 */
export function getResourcesByCategory(category, limit = 5) {
  const normalizedCategory = category.toLowerCase().replace(/\s+/g, '-');

  const matchingBooks = BOOKS.filter(book =>
    book.categories.some(cat => cat.includes(normalizedCategory) || normalizedCategory.includes(cat))
  );

  const matchingTalks = TED_TALKS.filter(talk =>
    talk.categories.some(cat => cat.includes(normalizedCategory) || normalizedCategory.includes(cat))
  );

  // Mix books and talks, prioritizing books
  const result = [];
  const bookCount = Math.min(Math.ceil(limit * 0.8), matchingBooks.length);
  const talkCount = Math.min(limit - bookCount, matchingTalks.length);

  // Shuffle and pick
  const shuffledBooks = matchingBooks.sort(() => Math.random() - 0.5);
  const shuffledTalks = matchingTalks.sort(() => Math.random() - 0.5);

  result.push(...shuffledBooks.slice(0, bookCount));
  result.push(...shuffledTalks.slice(0, talkCount));

  return result.slice(0, limit);
}

/**
 * Get resources for a specific core metric
 * @param {string} metric - Core metric: clarity, efficiency, safety, empowerment
 * @param {number} limit - Maximum number of resources
 * @returns {Array} Array of resources
 */
export function getResourcesForMetric(metric, limit = 5) {
  const relevantCategories = Object.entries(CATEGORY_TO_METRIC)
    .filter(([_, m]) => m === metric || m === 'all')
    .map(([cat, _]) => cat);

  const matchingBooks = BOOKS.filter(book =>
    book.categories.some(cat => relevantCategories.includes(cat))
  );

  const matchingTalks = TED_TALKS.filter(talk =>
    talk.categories.some(cat => relevantCategories.includes(cat))
  );

  const allResources = [...matchingBooks, ...matchingTalks];
  const shuffled = allResources.sort(() => Math.random() - 0.5);

  return shuffled.slice(0, limit);
}

/**
 * Get a development plan with resources for 4 tracks
 * @param {Object} weakMetrics - Object with metric scores to identify weak areas
 * @returns {Array} Array of 4 development tracks with resources
 */
export function generateDevelopmentPlan(weakMetrics = {}) {
  // Sort metrics by score (lowest first) to prioritize weak areas
  const sortedMetrics = Object.entries(weakMetrics)
    .sort((a, b) => a[1] - b[1])
    .map(([metric]) => metric);

  // Default order if no metrics provided
  const metricsOrder = sortedMetrics.length >= 4
    ? sortedMetrics
    : ['clarity', 'efficiency', 'safety', 'empowerment'];

  const trackTitles = {
    clarity: 'تطوير الوضوح والتواصل',
    efficiency: 'تحسين الكفاءة والإنتاجية',
    safety: 'بناء الأمان النفسي والثقة',
    empowerment: 'تعزيز التمكين والتفويض'
  };

  const tracks = metricsOrder.slice(0, 4).map(metric => {
    const resources = getResourcesForMetric(metric, 5);
    return {
      categoryTitle: trackTitles[metric] || `تطوير ${metric}`,
      resources: resources.map(r => ({
        title: r.titleAr,
        link: r.url
      }))
    };
  });

  return tracks;
}

/**
 * Find a resource by its Arabic or English title
 * @param {string} title - Title to search for
 * @returns {Object|null} Resource object or null
 */
export function findResourceByTitle(title) {
  if (!title) return null;
  const normalizedTitle = title.toLowerCase().trim();

  const book = BOOKS.find(b =>
    b.titleAr === title ||
    b.titleAr.includes(title) ||
    title.includes(b.titleAr) ||
    b.titleEn.toLowerCase() === normalizedTitle ||
    b.titleEn.toLowerCase().includes(normalizedTitle)
  );

  if (book) return book;

  const talk = TED_TALKS.find(t =>
    t.titleAr === title ||
    t.titleAr.includes(title) ||
    title.includes(t.titleAr) ||
    t.titleEn.toLowerCase() === normalizedTitle ||
    t.titleEn.toLowerCase().includes(normalizedTitle)
  );

  return talk || null;
}

/**
 * Find a resource by its ID
 * @param {string} id - Resource ID
 * @returns {Object|null} Resource object or null
 */
export function findResourceById(id) {
  if (!id) return null;
  const normalizedId = id.toLowerCase().trim();

  const book = BOOKS.find(b => b.id === normalizedId);
  if (book) return book;

  const talk = TED_TALKS.find(t => t.id === normalizedId);
  return talk || null;
}

/**
 * Get formatted resource list for AI prompt
 * Returns a compact list with IDs for AI to select from
 * @returns {string} Formatted list
 */
export function getResourceListForPrompt() {
  const booksList = BOOKS.map(b =>
    `  - ID: "${b.id}" | "${b.titleAr}" (${b.titleEn}) - ${b.author}`
  ).join('\n');

  const talksList = TED_TALKS.map(t =>
    `  - ID: "${t.id}" | "${t.titleAr}" (${t.titleEn}) - ${t.speaker}`
  ).join('\n');

  return `
=== AVAILABLE RESOURCES (USE ONLY THESE) ===

BOOKS:
${booksList}

TED TALKS:
${talksList}
`;
}

/**
 * Map AI-selected resource IDs/titles to full resources with URLs
 * @param {Array} developmentPlan - AI-generated development plan with resource IDs or titles
 * @returns {Array} Development plan with verified URLs
 */
export function mapDevelopmentPlanToUrls(developmentPlan) {
  if (!developmentPlan || !Array.isArray(developmentPlan)) {
    return generateDevelopmentPlan({});
  }

  return developmentPlan.map(track => {
    const mappedResources = (track.resources || []).map(resource => {
      // Try to find by ID first, then by title
      let found = findResourceById(resource.id) || findResourceByTitle(resource.title);

      if (found) {
        return {
          title: found.titleAr,
          link: found.url
        };
      }

      // Fallback: keep original but mark as not found
      console.warn(`Resource not found: ${resource.id || resource.title}`);
      return {
        title: resource.title || 'مورد غير متوفر',
        link: resource.link || 'https://www.amazon.com'
      };
    });

    return {
      categoryTitle: track.categoryTitle,
      resources: mappedResources
    };
  });
}

/**
 * Get all available resource titles for AI prompt
 * @returns {string} Formatted list of available resources
 */
export function getAvailableResourcesList() {
  const booksList = BOOKS.map(b => `- "${b.titleAr}" (${b.titleEn})`).join('\n');
  const talksList = TED_TALKS.map(t => `- "${t.titleAr}" (${t.titleEn})`).join('\n');

  return `
كتب متاحة:
${booksList}

محادثات TED متاحة:
${talksList}
`;
}

export default {
  BOOKS,
  TED_TALKS,
  CATEGORY_TO_METRIC,
  getResourcesByCategory,
  getResourcesForMetric,
  generateDevelopmentPlan,
  findResourceByTitle,
  findResourceById,
  getResourceListForPrompt,
  mapDevelopmentPlanToUrls,
  getAvailableResourcesList
};
