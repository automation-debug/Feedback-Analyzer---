/**
 * ===================================================================
 * BASE REPORT SCHEMA
 * ===================================================================
 *
 * Common schema definitions shared across all report types
 * (Standard, Extended, Gigantic)
 *
 * @module services/report/schemas/baseSchema
 */

import { FIELD_LIMITS } from '../../../config/constants/index.js';

// ===================================================================
// SHARED PROPERTY DEFINITIONS
// ===================================================================

/**
 * Header property schema (base)
 */
export const headerProps = {
  employeeName: {
    type: 'string',
    maxLength: FIELD_LIMITS.header.employeeName.max,
    description: 'Name of the employee (max 30 chars)'
  },
  executiveSummary: {
    type: 'string',
    maxLength: FIELD_LIMITS.header.executiveSummary.max,
    description: 'Executive summary in Arabic (max 445 chars)'
  }
};

/**
 * Executive Summary 2/3 bullet point structure
 */
export const executiveSummaryBullets = {
  type: 'object',
  properties: {
    title: {
      type: 'string',
      maxLength: FIELD_LIMITS.header.executiveSummary2Title.max,
      description: `Unique title (${FIELD_LIMITS.header.executiveSummary2Title.min}-${FIELD_LIMITS.header.executiveSummary2Title.max} chars)`
    },
    bulletPoints: {
      type: 'array',
      items: {
        type: 'string',
        maxLength: FIELD_LIMITS.header.executiveSummary2Bullet.max
      },
      minItems: 5,
      maxItems: 5,
      description: `5 bullet points (${FIELD_LIMITS.header.executiveSummary2Bullet.min}-${FIELD_LIMITS.header.executiveSummary2Bullet.max} chars each)`
    }
  },
  required: ['title', 'bulletPoints'],
  additionalProperties: false
};

/**
 * Leadership Path schema (same for all report types)
 */
export const leadershipPathSchema = {
  type: 'object',
  description: 'Overall leadership status',
  properties: {
    score: {
      type: 'number',
      description: 'Overall leadership score from 0 to 100'
    },
    statusLabelAr: {
      type: 'string',
      maxLength: 15,
      description: 'Arabic status label: فخر, خضر, صفر, حمر, or خطر'
    }
  },
  required: ['score', 'statusLabelAr'],
  additionalProperties: false
};

/**
 * Core Metric item schema
 * @param {number} bulletCount - Number of bullet points
 */
export function getCoreMetricItemSchema(bulletCount) {
  return {
    type: 'object',
    properties: {
      id: {
        type: 'string',
        enum: ['clarity', 'efficiency', 'safety', 'empowerment'],
        description: 'Metric identifier'
      },
      score: {
        type: 'number',
        description: 'Score from 0 to 100'
      },
      bulletPoints: {
        type: 'array',
        items: {
          type: 'string',
          maxLength: FIELD_LIMITS.coreMetrics.bulletPoint.max
        },
        minItems: bulletCount,
        maxItems: bulletCount,
        description: `${bulletCount} bullet points (${FIELD_LIMITS.coreMetrics.bulletPoint.min}-${FIELD_LIMITS.coreMetrics.bulletPoint.max} chars each)`
      }
    },
    required: ['id', 'score', 'bulletPoints'],
    additionalProperties: false
  };
}

/**
 * Strength/Weakness item schema
 */
export const strengthWeaknessItemSchema = {
  type: 'object',
  properties: {
    title: {
      type: 'string',
      maxLength: FIELD_LIMITS.strengths.title.max,
      description: `Title (${FIELD_LIMITS.strengths.title.min}-${FIELD_LIMITS.strengths.title.max} chars)`
    },
    description: {
      type: 'string',
      maxLength: FIELD_LIMITS.strengths.description.max,
      description: `Description (${FIELD_LIMITS.strengths.description.min}-${FIELD_LIMITS.strengths.description.max} chars)`
    }
  },
  required: ['title', 'description'],
  additionalProperties: false
};

/**
 * Base personality analysis properties (shared across all types)
 */
export const personalityBaseProps = {
  overview: {
    type: 'string',
    maxLength: FIELD_LIMITS.personalityAnalysis.overview.max,
    description: 'Personality overview paragraph in Arabic'
  },
  mbpiType: {
    type: 'string',
    maxLength: 10,
    description: 'MBTI type code (e.g., INTJ)'
  },
  enneagramType: {
    type: 'string',
    maxLength: 15,
    description: 'Enneagram type (e.g., Type 8)'
  },
  discType: {
    type: 'string',
    maxLength: 15,
    description: 'DISC style (e.g., High D)'
  },
  bigFiveType: {
    type: 'string',
    maxLength: 30,
    description: 'Big Five trait (e.g., High Conscientiousness)'
  },
  strengths: {
    type: 'array',
    items: { type: 'string', maxLength: 175 },
    minItems: 5,
    maxItems: 5,
    description: '5 personality-based strengths in Arabic'
  },
  weaknesses: {
    type: 'array',
    items: { type: 'string', maxLength: 175 },
    minItems: 5,
    maxItems: 5,
    description: '5 personality-based weaknesses in Arabic'
  }
};

/**
 * Team Voice item schema
 */
export const teamVoiceItemSchema = {
  type: 'object',
  properties: {
    title: {
      type: 'string',
      maxLength: 20,
      description: 'Feedback topic (1-2 words)'
    },
    content: {
      type: 'string',
      maxLength: 150,
      description: `Content (${FIELD_LIMITS.teamVoice.content.words.min}-${FIELD_LIMITS.teamVoice.content.words.max} words)`
    }
  },
  required: ['title', 'content'],
  additionalProperties: false
};

/**
 * Development Compass item schema
 */
export const developmentCompassItemSchema = {
  type: 'string',
  maxLength: FIELD_LIMITS.developmentCompass.item.max,
  description: `Soft skill (${FIELD_LIMITS.developmentCompass.item.min}-${FIELD_LIMITS.developmentCompass.item.max} chars)`
};

/**
 * Roadmap item schema
 * @param {number} stepCount - Number of steps per roadmap item
 * @param {Object} stepLimits - Character limits for steps
 */
export function getRoadmapItemSchema(stepCount, stepLimits) {
  return {
    type: 'object',
    properties: {
      title: {
        type: 'string',
        maxLength: FIELD_LIMITS.roadmap.title.max,
        description: 'Action title in Arabic'
      },
      priorityAr: {
        type: 'string',
        description: 'Arabic priority: الأولوية القصوى, عاجل, or مستمر'
      },
      steps: {
        type: 'array',
        items: { type: 'string', maxLength: stepLimits.max },
        minItems: stepCount,
        maxItems: stepCount,
        description: `${stepCount} action steps (${stepLimits.min}-${stepLimits.max} chars each)`
      }
    },
    required: ['title', 'priorityAr', 'steps'],
    additionalProperties: false
  };
}

/**
 * Development Plan resource item schema
 */
export const resourceItemSchema = {
  type: 'object',
  properties: {
    id: {
      type: 'string',
      description: 'Resource ID from the provided list'
    },
    title: {
      type: 'string',
      maxLength: FIELD_LIMITS.developmentPlan.resourceTitle.max,
      description: 'Resource Arabic title'
    }
  },
  required: ['id', 'title'],
  additionalProperties: false
};

/**
 * Development Plan category schema
 */
export const developmentPlanCategorySchema = {
  type: 'object',
  properties: {
    categoryTitle: {
      type: 'string',
      maxLength: FIELD_LIMITS.developmentPlan.categoryTitle.max,
      description: 'Category title in Arabic'
    },
    resources: {
      type: 'array',
      items: resourceItemSchema,
      minItems: 5,
      maxItems: 5,
      description: '5 resources selected from provided list'
    }
  },
  required: ['categoryTitle', 'resources'],
  additionalProperties: false
};

export default {
  headerProps,
  executiveSummaryBullets,
  leadershipPathSchema,
  getCoreMetricItemSchema,
  strengthWeaknessItemSchema,
  personalityBaseProps,
  teamVoiceItemSchema,
  developmentCompassItemSchema,
  getRoadmapItemSchema,
  resourceItemSchema,
  developmentPlanCategorySchema
};
