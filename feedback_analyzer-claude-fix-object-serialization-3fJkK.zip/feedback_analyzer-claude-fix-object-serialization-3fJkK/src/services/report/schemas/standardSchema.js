/**
 * ===================================================================
 * STANDARD REPORT SCHEMA
 * ===================================================================
 *
 * JSON Schema for Standard reports (< 7 reviewers)
 * - 3 strengths, 3 weaknesses
 * - 4 teamVoice items
 * - 3 bullet points per core metric
 * - 4 roadmap steps
 *
 * @module services/report/schemas/standardSchema
 */

import { ITEM_COUNTS, FIELD_LIMITS } from '../../../config/constants/index.js';
import {
  headerProps,
  executiveSummaryBullets,
  leadershipPathSchema,
  getCoreMetricItemSchema,
  strengthWeaknessItemSchema,
  personalityBaseProps,
  teamVoiceItemSchema,
  developmentCompassItemSchema,
  getRoadmapItemSchema,
  developmentPlanCategorySchema
} from './baseSchema.js';

const counts = ITEM_COUNTS.STANDARD;

/**
 * Standard Report JSON Schema
 */
export const STANDARD_REPORT_SCHEMA = {
  type: 'object',
  properties: {
    // HEADER
    header: {
      type: 'object',
      description: 'Header information for the report',
      properties: {
        ...headerProps,
        executiveSummary2: {
          ...executiveSummaryBullets,
          description: 'Second executive summary with unique angle'
        }
      },
      required: ['employeeName', 'executiveSummary', 'executiveSummary2'],
      additionalProperties: false
    },

    // LEADERSHIP PATH
    leadershipPath: leadershipPathSchema,

    // CORE METRICS (4 items, 3 bullets each)
    coreMetrics: {
      type: 'array',
      items: getCoreMetricItemSchema(counts.coreMetricBullets),
      minItems: 4,
      maxItems: 4,
      description: `4 core metrics with ${counts.coreMetricBullets} bullet points each`
    },

    // STRENGTHS (3 items)
    strengths: {
      type: 'array',
      items: strengthWeaknessItemSchema,
      minItems: counts.strengths,
      maxItems: counts.strengths,
      description: `Exactly ${counts.strengths} key strengths`
    },

    // WEAKNESSES (3 items)
    weaknesses: {
      type: 'array',
      items: strengthWeaknessItemSchema,
      minItems: counts.weaknesses,
      maxItems: counts.weaknesses,
      description: `Exactly ${counts.weaknesses} key weaknesses`
    },

    // PERSONALITY ANALYSIS
    personalityAnalysis: {
      type: 'object',
      description: 'Consolidated personality analysis',
      properties: {
        ...personalityBaseProps,
        overview2: {
          ...executiveSummaryBullets,
          description: 'Second personality overview with unique angle'
        }
      },
      required: [
        'overview', 'overview2', 'mbpiType', 'enneagramType',
        'discType', 'bigFiveType', 'strengths', 'weaknesses'
      ],
      additionalProperties: false
    },

    // TEAM VOICE (4 items)
    teamVoice: {
      type: 'array',
      items: teamVoiceItemSchema,
      minItems: counts.teamVoice,
      maxItems: counts.teamVoice,
      description: `${counts.teamVoice} team voice feedback items`
    },

    // DEVELOPMENT COMPASS (5 items)
    developmentCompass: {
      type: 'array',
      items: developmentCompassItemSchema,
      minItems: counts.developmentCompass,
      maxItems: counts.developmentCompass,
      description: `${counts.developmentCompass} unique soft skills to develop`
    },

    // ROADMAP (3 items, 4 steps each)
    roadmap: {
      type: 'array',
      items: getRoadmapItemSchema(counts.roadmapSteps, FIELD_LIMITS.roadmap.step.STANDARD),
      minItems: 3,
      maxItems: 3,
      description: `3 roadmap priorities with ${counts.roadmapSteps} steps each`
    },

    // DEVELOPMENT PLAN (4 tracks, 5 resources each)
    developmentPlan: {
      type: 'array',
      items: developmentPlanCategorySchema,
      minItems: 4,
      maxItems: 4,
      description: '4 development tracks with resources'
    }
  },
  required: [
    'header', 'leadershipPath', 'coreMetrics', 'strengths', 'weaknesses',
    'personalityAnalysis', 'teamVoice', 'developmentCompass', 'roadmap', 'developmentPlan'
  ],
  additionalProperties: false
};

export default STANDARD_REPORT_SCHEMA;
