/**
 * ===================================================================
 * GIGANTIC REPORT SCHEMA
 * ===================================================================
 *
 * JSON Schema for Gigantic reports (21+ reviewers)
 * - 9 strengths, 9 weaknesses
 * - 12 teamVoice items
 * - 7 bullet points per core metric
 * - 10 roadmap steps
 * - Additional executiveSummary3 and overview3
 *
 * @module services/report/schemas/giganticSchema
 */

import { ITEM_COUNTS, FIELD_LIMITS } from '../../../config/constants/index.js';
import {
  headerProps,
  executiveSummaryBullets,
  leadershipPathSchema,
  getCoreMetricItemSchema,
  strengthWeaknessItemSchema,
  personalityBaseProps,
  teamVoiceItemSchema,
  developmentCompassItemSchema,
  getRoadmapItemSchema,
  developmentPlanCategorySchema
} from './baseSchema.js';

const counts = ITEM_COUNTS.GIGANTIC;

/**
 * Gigantic Report JSON Schema
 */
export const GIGANTIC_REPORT_SCHEMA = {
  type: 'object',
  properties: {
    // HEADER (includes executiveSummary3)
    header: {
      type: 'object',
      description: 'Gigantic header information (21+ reviews)',
      properties: {
        ...headerProps,
        executiveSummary2: {
          ...executiveSummaryBullets,
          description: 'Second executive summary with unique angle'
        },
        executiveSummary3: {
          ...executiveSummaryBullets,
          description: 'Third executive summary with unique strategic perspective'
        }
      },
      required: ['employeeName', 'executiveSummary', 'executiveSummary2', 'executiveSummary3'],
      additionalProperties: false
    },

    // LEADERSHIP PATH
    leadershipPath: leadershipPathSchema,

    // CORE METRICS (4 items, 7 bullets each)
    coreMetrics: {
      type: 'array',
      items: getCoreMetricItemSchema(counts.coreMetricBullets),
      minItems: 4,
      maxItems: 4,
      description: `4 core metrics with ${counts.coreMetricBullets} bullet points each for gigantic reports`
    },

    // STRENGTHS (9 items)
    strengths: {
      type: 'array',
      items: strengthWeaknessItemSchema,
      minItems: counts.strengths,
      maxItems: counts.strengths,
      description: `Exactly ${counts.strengths} key strengths for gigantic reports`
    },

    // WEAKNESSES (9 items)
    weaknesses: {
      type: 'array',
      items: strengthWeaknessItemSchema,
      minItems: counts.weaknesses,
      maxItems: counts.weaknesses,
      description: `Exactly ${counts.weaknesses} key weaknesses for gigantic reports`
    },

    // PERSONALITY ANALYSIS (includes overview3)
    personalityAnalysis: {
      type: 'object',
      description: 'Gigantic consolidated personality analysis',
      properties: {
        ...personalityBaseProps,
        overview2: {
          ...executiveSummaryBullets,
          description: 'Second personality overview with unique angle'
        },
        overview3: {
          ...executiveSummaryBullets,
          description: 'Third personality overview with deeper behavioral insights'
        }
      },
      required: [
        'overview', 'overview2', 'overview3', 'mbpiType', 'enneagramType',
        'discType', 'bigFiveType', 'strengths', 'weaknesses'
      ],
      additionalProperties: false
    },

    // TEAM VOICE (12 items)
    teamVoice: {
      type: 'array',
      items: teamVoiceItemSchema,
      minItems: counts.teamVoice,
      maxItems: counts.teamVoice,
      description: `${counts.teamVoice} team voice feedback items for gigantic reports`
    },

    // DEVELOPMENT COMPASS (9 items)
    developmentCompass: {
      type: 'array',
      items: developmentCompassItemSchema,
      minItems: counts.developmentCompass,
      maxItems: counts.developmentCompass,
      description: `${counts.developmentCompass} unique soft skills to develop for gigantic reports`
    },

    // ROADMAP (3 items, 10 steps each)
    roadmap: {
      type: 'array',
      items: getRoadmapItemSchema(counts.roadmapSteps, FIELD_LIMITS.roadmap.step.GIGANTIC),
      minItems: 3,
      maxItems: 3,
      description: `3 roadmap priorities with ${counts.roadmapSteps} steps each for gigantic reports`
    },

    // DEVELOPMENT PLAN (4 tracks, 5 resources each)
    developmentPlan: {
      type: 'array',
      items: developmentPlanCategorySchema,
      minItems: 4,
      maxItems: 4,
      description: '4 development tracks with resources'
    }
  },
  required: [
    'header', 'leadershipPath', 'coreMetrics', 'strengths', 'weaknesses',
    'personalityAnalysis', 'teamVoice', 'developmentCompass', 'roadmap', 'developmentPlan'
  ],
  additionalProperties: false
};

export default GIGANTIC_REPORT_SCHEMA;
