/**
 * ===================================================================
 * REPORT SCHEMAS INDEX
 * ===================================================================
 *
 * Central export for all report JSON schemas.
 * These schemas define the structure of AI-generated leadership reports.
 *
 * @module services/report/schemas
 *
 * USAGE:
 * ```javascript
 * import { getSchemaByReviewerCount } from './report/schemas';
 *
 * const { schema, reportType } = getSchemaByReviewerCount(15);
 * // Returns: { schema: EXTENDED_REPORT_SCHEMA, reportType: 'EXTENDED' }
 * ```
 *
 * REPORT TYPES (by reviewer count):
 * ┌─────────────┬───────────┬───────────┬────────────┬───────────┐
 * │ Type        │ Reviewers │ Strengths │ Weaknesses │ TeamVoice │
 * ├─────────────┼───────────┼───────────┼────────────┼───────────┤
 * │ STANDARD    │ < 7       │ 3         │ 3          │ 4         │
 * │ EXTENDED    │ 7-20      │ 6         │ 6          │ 5         │
 * │ GIGANTIC    │ 21+       │ 9         │ 9          │ 12        │
 * └─────────────┴───────────┴───────────┴────────────┴───────────┘
 *
 * FILES:
 * - baseSchema.js: Shared property definitions
 * - standardSchema.js: STANDARD_REPORT_SCHEMA
 * - extendedSchema.js: EXTENDED_REPORT_SCHEMA
 * - giganticSchema.js: GIGANTIC_REPORT_SCHEMA
 */

import { REPORT_THRESHOLDS, getReportType } from '../../../config/constants/index.js';
import STANDARD_REPORT_SCHEMA from './standardSchema.js';
import EXTENDED_REPORT_SCHEMA from './extendedSchema.js';
import GIGANTIC_REPORT_SCHEMA from './giganticSchema.js';

// Re-export individual schemas
export { STANDARD_REPORT_SCHEMA } from './standardSchema.js';
export { EXTENDED_REPORT_SCHEMA } from './extendedSchema.js';
export { GIGANTIC_REPORT_SCHEMA } from './giganticSchema.js';

// Re-export base schema utilities
export * from './baseSchema.js';

/**
 * Schema map for quick lookup by report type
 */
export const REPORT_SCHEMAS = {
  STANDARD: STANDARD_REPORT_SCHEMA,
  EXTENDED: EXTENDED_REPORT_SCHEMA,
  GIGANTIC: GIGANTIC_REPORT_SCHEMA
};

/**
 * Get the appropriate schema based on report type
 *
 * @param {'STANDARD' | 'EXTENDED' | 'GIGANTIC'} reportType - Report type
 * @returns {Object} JSON Schema for the report type
 *
 * @example
 * const schema = getSchemaForReportType('EXTENDED');
 */
export function getSchemaForReportType(reportType) {
  const schema = REPORT_SCHEMAS[reportType];
  if (!schema) {
    throw new Error(`Invalid report type: ${reportType}. Valid types: ${Object.keys(REPORT_SCHEMAS).join(', ')}`);
  }
  return schema;
}

/**
 * Get the appropriate schema based on reviewer count
 *
 * @param {number} reviewerCount - Number of reviewers
 * @returns {Object} Object containing schema and report type
 *
 * @example
 * const { schema, reportType } = getSchemaByReviewerCount(15);
 * // Returns { schema: EXTENDED_REPORT_SCHEMA, reportType: 'EXTENDED' }
 */
export function getSchemaByReviewerCount(reviewerCount) {
  const reportType = getReportType(reviewerCount);
  return {
    schema: getSchemaForReportType(reportType),
    reportType,
    thresholds: REPORT_THRESHOLDS
  };
}

/**
 * Validate that a report object matches the expected schema structure
 * (Basic validation - checks required fields exist)
 *
 * @param {Object} report - Report object to validate
 * @param {'STANDARD' | 'EXTENDED' | 'GIGANTIC'} reportType - Expected report type
 * @returns {Object} Validation result { valid: boolean, errors: string[] }
 *
 * @example
 * const result = validateReportStructure(report, 'EXTENDED');
 * if (!result.valid) {
 *   console.error('Validation errors:', result.errors);
 * }
 */
export function validateReportStructure(report, reportType) {
  const errors = [];
  const schema = getSchemaForReportType(reportType);

  // Check required top-level fields
  schema.required.forEach(field => {
    if (!report[field]) {
      errors.push(`Missing required field: ${field}`);
    }
  });

  // Check array lengths match schema
  if (report.strengths) {
    const expected = schema.properties.strengths.minItems;
    if (report.strengths.length < expected) {
      errors.push(`strengths has ${report.strengths.length} items, expected ${expected}`);
    }
  }

  if (report.weaknesses) {
    const expected = schema.properties.weaknesses.minItems;
    if (report.weaknesses.length < expected) {
      errors.push(`weaknesses has ${report.weaknesses.length} items, expected ${expected}`);
    }
  }

  if (report.teamVoice) {
    const expected = schema.properties.teamVoice.minItems;
    if (report.teamVoice.length < expected) {
      errors.push(`teamVoice has ${report.teamVoice.length} items, expected ${expected}`);
    }
  }

  if (report.coreMetrics) {
    const expectedBullets = schema.properties.coreMetrics.items.properties.bulletPoints.minItems;
    report.coreMetrics.forEach((metric, i) => {
      if (metric.bulletPoints && metric.bulletPoints.length < expectedBullets) {
        errors.push(`coreMetrics[${i}].bulletPoints has ${metric.bulletPoints.length} items, expected ${expectedBullets}`);
      }
    });
  }

  // Check for gigantic-specific fields
  if (reportType === 'GIGANTIC') {
    if (!report.header?.executiveSummary3) {
      errors.push('Missing executiveSummary3 for gigantic report');
    }
    if (!report.personalityAnalysis?.overview3) {
      errors.push('Missing overview3 for gigantic report');
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

export default {
  REPORT_SCHEMAS,
  STANDARD_REPORT_SCHEMA,
  EXTENDED_REPORT_SCHEMA,
  GIGANTIC_REPORT_SCHEMA,
  getSchemaForReportType,
  getSchemaByReviewerCount,
  validateReportStructure
};
