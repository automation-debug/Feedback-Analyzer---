/**
 * ===================================================================
 * ENHANCED LOGGING UTILITY
 * ===================================================================
 *
 * Provides structured logging with:
 * - Multiple log levels (DEBUG, INFO, WARN, ERROR)
 * - Context tracking for easy filtering
 * - Operation timing and tracking
 * - Real-time log subscriptions
 * - Log history with circular buffer
 * - Export functionality
 *
 * @module utils/logger
 *
 * USAGE:
 *   import { createLogger } from './utils/logger.js';
 *
 *   const logger = createLogger('MyService');
 *   logger.info('Processing started', { count: 10 });
 *
 *   // Track operations
 *   const op = logger.startOperation('fetchData');
 *   try {
 *     const result = await fetchData();
 *     op.end({ recordCount: result.length });
 *   } catch (err) {
 *     op.fail(err);
 *   }
 */

import { LOG_CONFIG } from '../config/constants/index.js';

// ===================================================================
// CONFIGURATION
// ===================================================================
const { LEVELS: LOG_LEVELS, MAX_HISTORY: MAX_LOG_HISTORY, DEFAULT_LEVEL } = LOG_CONFIG;

/** Current active log level */
let currentLogLevel = LOG_LEVELS[DEFAULT_LEVEL] ?? LOG_LEVELS.DEBUG;

/** Log history buffer */
const logHistory = [];

/** Subscribers for real-time log updates */
const subscribers = new Set();

// ===================================================================
// FORMATTING UTILITIES
// ===================================================================

/**
 * Format timestamp for logs
 * @returns {string} ISO timestamp
 */
function formatTimestamp() {
  return new Date().toISOString();
}

/**
 * Format duration in human-readable form
 * @param {number} ms - Duration in milliseconds
 * @returns {string} Formatted duration (e.g., "1.23s", "456ms")
 */
function formatDuration(ms) {
  if (ms >= 1000) {
    return `${(ms / 1000).toFixed(2)}s`;
  }
  return `${Math.round(ms)}ms`;
}

/**
 * Get emoji indicator for log level
 * @param {string} level - Log level
 * @returns {string} Emoji indicator
 */
function getLevelEmoji(level) {
  const emojis = {
    DEBUG: '🔍',
    INFO: '📘',
    WARN: '⚠️',
    ERROR: '❌'
  };
  return emojis[level] || '📋';
}

/**
 * Format log entry for console output
 * @param {Object} entry - Log entry
 * @returns {string} Formatted log string
 */
function formatForConsole(entry) {
  const emoji = getLevelEmoji(entry.level);
  const timestamp = entry.timestamp.split('T')[1].split('.')[0]; // HH:MM:SS
  const context = entry.context.padEnd(20);
  const duration = entry.duration ? ` (${formatDuration(entry.duration)})` : '';

  return `${emoji} [${timestamp}] [${entry.level.padEnd(5)}] [${context}] ${entry.message}${duration}`;
}

/**
 * Create a log entry object
 * @param {string} level - Log level
 * @param {string} context - Logger context
 * @param {string} message - Log message
 * @param {Object} data - Additional data
 * @param {Object} options - Additional options
 * @returns {Object} Log entry
 */
function createLogEntry(level, context, message, data, options = {}) {
  return {
    id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    timestamp: formatTimestamp(),
    level,
    context,
    message,
    data: data ? JSON.parse(JSON.stringify(data)) : undefined,
    duration: options.duration,
    operationId: options.operationId,
    status: options.status
  };
}

// ===================================================================
// HISTORY MANAGEMENT
// ===================================================================

/**
 * Add log entry to history and notify subscribers
 * @param {Object} entry - Log entry
 */
function addToHistory(entry) {
  logHistory.push(entry);

  // Maintain circular buffer
  if (logHistory.length > MAX_LOG_HISTORY) {
    logHistory.shift();
  }

  // Notify all subscribers
  subscribers.forEach(callback => {
    try {
      callback(entry, [...logHistory]);
    } catch (e) {
      console.error('Log subscriber error:', e);
    }
  });
}

// ===================================================================
// CORE LOGGING FUNCTION
// ===================================================================

/**
 * Core logging function
 * @param {string} level - Log level
 * @param {string} context - Logger context
 * @param {string} message - Log message
 * @param {Object} data - Additional data
 * @param {Object} options - Additional options
 * @returns {Object} Log entry
 */
function log(level, context, message, data, options = {}) {
  // Check log level threshold
  if (LOG_LEVELS[level] < currentLogLevel) return null;

  const entry = createLogEntry(level, context, message, data, options);
  addToHistory(entry);

  // Console output
  const formattedMessage = formatForConsole(entry);
  const consoleMethod = level === 'ERROR' ? 'error' : level === 'WARN' ? 'warn' : 'log';

  if (data && Object.keys(data).length > 0) {
    console[consoleMethod](formattedMessage, data);
  } else {
    console[consoleMethod](formattedMessage);
  }

  return entry;
}

// ===================================================================
// LOGGER FACTORY
// ===================================================================

/**
 * Create a contextualized logger instance
 *
 * @param {string} context - Context name (e.g., 'GeminiService', 'ExportService')
 * @returns {Object} Logger instance with debug, info, warn, error, and operation tracking methods
 *
 * @example
 * const logger = createLogger('MyService');
 * logger.info('Process started', { items: 10 });
 * logger.debug('Details', { data: someData });
 * logger.warn('Something might be wrong');
 * logger.error('Something failed', { error: err.message });
 *
 * // Operation tracking
 * const op = logger.startOperation('fetchData');
 * // ... do work ...
 * op.end({ recordCount: 100 }); // or op.fail(error);
 */
export function createLogger(context) {
  return {
    /**
     * Log debug message (lowest level, for development)
     * @param {string} message - Log message
     * @param {Object} [data] - Additional data
     */
    debug: (message, data) => log('DEBUG', context, message, data),

    /**
     * Log info message (general information)
     * @param {string} message - Log message
     * @param {Object} [data] - Additional data
     */
    info: (message, data) => log('INFO', context, message, data),

    /**
     * Log warning message (potential issues)
     * @param {string} message - Log message
     * @param {Object} [data] - Additional data
     */
    warn: (message, data) => log('WARN', context, message, data),

    /**
     * Log error message (failures)
     * @param {string} message - Log message
     * @param {Object} [data] - Additional data
     */
    error: (message, data) => log('ERROR', context, message, data),

    /**
     * Start tracking an operation
     * Returns an object with end() and fail() methods
     *
     * @param {string} operationName - Name of the operation
     * @param {Object} [data] - Initial data
     * @returns {Object} Operation tracker with end() and fail() methods
     *
     * @example
     * const op = logger.startOperation('processCandidate', { name: 'John' });
     * try {
     *   const result = await processCandidate('John');
     *   op.end({ score: result.score });
     * } catch (err) {
     *   op.fail(err);
     * }
     */
    startOperation: (operationName, data) => {
      const operationId = `${operationName}-${Date.now()}`;
      const startTime = Date.now();

      log('INFO', context, `▶ Starting: ${operationName}`, { operationId, ...data }, {
        operationId,
        status: 'started'
      });

      return {
        operationId,

        /**
         * Mark operation as successfully completed
         * @param {Object} [result] - Result data
         */
        end: (result) => {
          const duration = Date.now() - startTime;
          log('INFO', context, `✓ Completed: ${operationName}`, { operationId, result }, {
            operationId,
            status: 'completed',
            duration
          });
        },

        /**
         * Mark operation as failed
         * @param {Error|string} error - Error that caused failure
         */
        fail: (error) => {
          const duration = Date.now() - startTime;
          const errorMessage = error?.message || String(error);
          log('ERROR', context, `✗ Failed: ${operationName}`, { operationId, error: errorMessage }, {
            operationId,
            status: 'failed',
            duration
          });
        }
      };
    },

    /**
     * Log a table of data (useful for debugging arrays)
     * @param {string} title - Table title
     * @param {Array} data - Array of objects to display
     */
    table: (title, data) => {
      log('DEBUG', context, `📊 ${title}`, { rowCount: data?.length || 0 });
      if (Array.isArray(data) && data.length > 0) {
        console.table(data);
      }
    },

    /**
     * Log a separator line (useful for visual grouping)
     * @param {string} [label] - Optional label
     */
    separator: (label) => {
      const line = '═'.repeat(60);
      if (label) {
        console.log(`\n${line}\n${label}\n${line}`);
      } else {
        console.log(`\n${line}`);
      }
    }
  };
}

// ===================================================================
// SUBSCRIPTION MANAGEMENT
// ===================================================================

/**
 * Subscribe to log updates (for UI display)
 *
 * @param {Function} callback - Function called with (newEntry, allHistory)
 * @returns {Function} Unsubscribe function
 *
 * @example
 * const unsubscribe = subscribeToLogs((entry, history) => {
 *   console.log('New log:', entry);
 *   setLogs(history);
 * });
 *
 * // Later: unsubscribe();
 */
export function subscribeToLogs(callback) {
  subscribers.add(callback);
  return () => subscribers.delete(callback);
}

// ===================================================================
// HISTORY ACCESS
// ===================================================================

/**
 * Get full log history
 * @returns {Array} Copy of log history
 */
export function getLogHistory() {
  return [...logHistory];
}

/**
 * Get filtered log history
 * @param {Object} filters - Filter options
 * @param {string} [filters.level] - Filter by log level
 * @param {string} [filters.context] - Filter by context
 * @param {string} [filters.search] - Search in message
 * @returns {Array} Filtered log entries
 */
export function getFilteredLogs(filters = {}) {
  return logHistory.filter(entry => {
    if (filters.level && entry.level !== filters.level) return false;
    if (filters.context && entry.context !== filters.context) return false;
    if (filters.search && !entry.message.toLowerCase().includes(filters.search.toLowerCase())) return false;
    return true;
  });
}

/**
 * Clear log history
 */
export function clearLogHistory() {
  logHistory.length = 0;
}

// ===================================================================
// LOG LEVEL MANAGEMENT
// ===================================================================

/**
 * Set current log level
 * @param {'DEBUG' | 'INFO' | 'WARN' | 'ERROR'} level - New log level
 */
export function setLogLevel(level) {
  if (LOG_LEVELS[level] !== undefined) {
    currentLogLevel = LOG_LEVELS[level];
    console.log(`📋 Log level set to: ${level}`);
  } else {
    console.warn(`Invalid log level: ${level}. Valid levels: ${Object.keys(LOG_LEVELS).join(', ')}`);
  }
}

/**
 * Get current log level
 * @returns {string} Current log level name
 */
export function getLogLevel() {
  return Object.entries(LOG_LEVELS).find(([, value]) => value === currentLogLevel)?.[0] || 'DEBUG';
}

// ===================================================================
// EXPORT FUNCTIONALITY
// ===================================================================

/**
 * Export logs as JSON string
 * @param {Object} [options] - Export options
 * @param {boolean} [options.pretty=true] - Pretty print JSON
 * @returns {string} JSON string of logs
 */
export function exportLogs(options = { pretty: true }) {
  return JSON.stringify(logHistory, null, options.pretty ? 2 : 0);
}

/**
 * Export logs as downloadable file
 * @param {string} [filename='logs'] - Filename without extension
 */
export function downloadLogs(filename = 'logs') {
  const blob = new Blob([exportLogs()], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ===================================================================
// DEFAULT LOGGER INSTANCE
// ===================================================================

/**
 * Default logger instance for general app logging
 */
export const logger = createLogger('App');

// ===================================================================
// DEFAULT EXPORT
// ===================================================================

export default {
  createLogger,
  subscribeToLogs,
  getLogHistory,
  getFilteredLogs,
  clearLogHistory,
  setLogLevel,
  getLogLevel,
  exportLogs,
  downloadLogs,
  logger
};
