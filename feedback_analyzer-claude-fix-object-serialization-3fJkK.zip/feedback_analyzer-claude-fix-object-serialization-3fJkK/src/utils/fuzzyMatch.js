/**
 * Fuzzy Matching Utility
 * For finding feedback about a specific person across all data sources
 */

/**
 * Calculate Levenshtein distance between two strings
 * Lower distance = more similar
 */
const levenshteinDistance = (str1, str2) => {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();

  if (s1 === s2) return 0;
  if (s1.length === 0) return s2.length;
  if (s2.length === 0) return s1.length;

  const matrix = [];

  // Initialize matrix
  for (let i = 0; i <= s2.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= s1.length; j++) {
    matrix[0][j] = j;
  }

  // Fill matrix
  for (let i = 1; i <= s2.length; i++) {
    for (let j = 1; j <= s1.length; j++) {
      if (s2.charAt(i - 1) === s1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }

  return matrix[s2.length][s1.length];
};

/**
 * Calculate similarity score between two strings (0-100)
 * Higher score = more similar
 */
export const calculateSimilarity = (str1, str2) => {
  if (!str1 || !str2) return 0;

  const s1 = String(str1).toLowerCase().trim();
  const s2 = String(str2).toLowerCase().trim();

  if (s1 === s2) return 100;

  const maxLen = Math.max(s1.length, s2.length);
  if (maxLen === 0) return 100;

  const distance = levenshteinDistance(s1, s2);
  return Math.round((1 - distance / maxLen) * 100);
};

/**
 * Normalize Arabic name variations
 * Handles common Arabic character variations
 */
export const normalizeArabicName = (name) => {
  if (!name) return '';

  let normalized = String(name).trim();

  // Remove extra spaces
  normalized = normalized.replace(/\s+/g, ' ');

  // Normalize Arabic characters
  // أ، إ، آ -> ا
  normalized = normalized.replace(/[أإآ]/g, 'ا');

  // ة -> ه
  normalized = normalized.replace(/ة/g, 'ه');

  // ى -> ي
  normalized = normalized.replace(/ى/g, 'ي');

  // Remove tashkeel (diacritics)
  normalized = normalized.replace(/[\u064B-\u065F]/g, '');

  // Remove tatweel
  normalized = normalized.replace(/\u0640/g, '');

  return normalized.toLowerCase();
};

/**
 * Check if two names match (with fuzzy tolerance)
 * @param {string} name1 - First name
 * @param {string} name2 - Second name
 * @param {number} threshold - Minimum similarity threshold (0-100), default 75
 * @returns {boolean} - Whether names match
 */
export const namesMatch = (name1, name2, threshold = 75) => {
  const n1 = normalizeArabicName(name1);
  const n2 = normalizeArabicName(name2);

  // Exact match after normalization
  if (n1 === n2) return true;

  // One contains the other
  if (n1.includes(n2) || n2.includes(n1)) return true;

  // Fuzzy match
  return calculateSimilarity(n1, n2) >= threshold;
};

/**
 * Extract unique person names from data
 * @param {Array} data - Array of data rows
 * @param {string} personColumn - Column name containing person identifiers
 * @returns {Array} - Array of unique person names with their variations
 */
export const extractUniquePersons = (data, personColumn) => {
  if (!data || !personColumn) return [];

  const personsMap = new Map();

  data.forEach(row => {
    const name = row[personColumn];
    if (!name || String(name).trim() === '') return;

    const normalizedName = normalizeArabicName(name);
    const originalName = String(name).trim();

    // Find if this name matches an existing person
    let found = false;
    for (const [key, person] of personsMap.entries()) {
      if (namesMatch(normalizedName, key, 85)) {
        // Add as variation if different
        if (!person.variations.includes(originalName)) {
          person.variations.push(originalName);
        }
        person.count++;
        found = true;
        break;
      }
    }

    if (!found) {
      personsMap.set(normalizedName, {
        primaryName: originalName,
        normalizedName,
        variations: [originalName],
        count: 1
      });
    }
  });

  // Convert to array and sort by count
  return Array.from(personsMap.values())
    .sort((a, b) => b.count - a.count);
};

/**
 * Find all feedback rows for a specific person
 * @param {Array} data - Array of data rows
 * @param {string} personColumn - Column name containing person identifiers
 * @param {string} targetPerson - The person to find feedback for
 * @param {number} threshold - Fuzzy match threshold (0-100)
 * @returns {Array} - Filtered rows that match the person
 */
export const findFeedbackForPerson = (data, personColumn, targetPerson, threshold = 75) => {
  if (!data || !personColumn || !targetPerson) return [];

  const normalizedTarget = normalizeArabicName(targetPerson);

  return data.filter(row => {
    const name = row[personColumn];
    if (!name) return false;
    return namesMatch(name, normalizedTarget, threshold);
  });
};

/**
 * Group feedback data by source (file/sheet)
 * @param {Array} data - Array of data rows with _sourceFile and _sourceSheet
 * @returns {Object} - Grouped data by source
 */
export const groupFeedbackBySource = (data) => {
  const grouped = {};

  data.forEach(row => {
    const file = row._sourceFile || 'unknown';
    const sheet = row._sourceSheet || 'default';
    const key = `${file}::${sheet}`;

    if (!grouped[key]) {
      grouped[key] = {
        fileName: file,
        sheetName: sheet,
        rows: []
      };
    }
    grouped[key].rows.push(row);
  });

  return grouped;
};

/**
 * Calculate weighted scores for a person based on file/sheet weights
 * @param {Array} feedbackData - Feedback rows for a person
 * @param {Object} weights - Weight configuration { 'filename::sheetname': weight }
 * @param {Array} numericColumns - Column names containing numeric scores
 * @returns {Object} - Calculated weighted scores
 */
export const calculateWeightedScores = (feedbackData, weights, numericColumns) => {
  const grouped = groupFeedbackBySource(feedbackData);
  const categoryScores = {};
  let totalWeight = 0;

  Object.entries(grouped).forEach(([sourceKey, source]) => {
    const weight = weights[sourceKey] || 0;
    if (weight === 0) return;

    totalWeight += weight;

    // Calculate average scores for this source
    numericColumns.forEach(col => {
      const values = source.rows
        .map(row => parseFloat(row[col]))
        .filter(v => !isNaN(v));

      if (values.length > 0) {
        const avg = values.reduce((sum, v) => sum + v, 0) / values.length;

        if (!categoryScores[col]) {
          categoryScores[col] = { weightedSum: 0, totalWeight: 0 };
        }
        categoryScores[col].weightedSum += avg * weight;
        categoryScores[col].totalWeight += weight;
      }
    });
  });

  // Calculate final weighted averages
  const finalScores = {};
  Object.entries(categoryScores).forEach(([col, data]) => {
    if (data.totalWeight > 0) {
      finalScores[col] = data.weightedSum / data.totalWeight;
    }
  });

  return {
    scores: finalScores,
    totalWeight,
    sourceCount: Object.keys(grouped).length
  };
};

export default {
  calculateSimilarity,
  normalizeArabicName,
  namesMatch,
  extractUniquePersons,
  findFeedbackForPerson,
  groupFeedbackBySource,
  calculateWeightedScores
};
