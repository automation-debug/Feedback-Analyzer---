/**
 * Vercel Serverless Function: URL Validator
 * Validates URLs server-side to avoid CORS issues
 *
 * POST /api/validate-url
 * Body: { url: string }
 * Returns: { isValid: boolean, status: number, error: string|null, details: object }
 */

// Patterns that indicate error pages (soft 404s)
const ERROR_INDICATORS = [
  'page not found',
  'not found',
  '404',
  'error',
  'unavailable',
  'doesn\'t exist',
  'does not exist',
  'no longer available',
  'has been removed',
  'we couldn\'t find',
  'sorry, we couldn',
  'this video is unavailable',
  'this video is private',
  'video unavailable',
  'product not found',
  'item not found',
  'sorry, this product',
  'looking for something',
  'page you requested',
  'الصفحة غير موجودة',
  'غير متوفر',
];

// Domain-specific validation rules
const DOMAIN_RULES = {
  'amazon.com': {
    // Amazon returns 200 for non-existent products but shows error message
    errorPatterns: ['sorry, we couldn\'t find', 'looking for something', 'product not found'],
    successPatterns: ['add to cart', 'buy now', 'price'],
  },
  'youtube.com': {
    errorPatterns: ['video unavailable', 'this video is private', 'this video is unavailable'],
    successPatterns: ['subscribe', 'views'],
  },
  'coursera.org': {
    errorPatterns: ['page not found', 'course not found'],
    successPatterns: ['enroll', 'syllabus'],
  },
  'linkedin.com': {
    errorPatterns: ['page not found', 'content unavailable'],
    successPatterns: ['start learning', 'course'],
  },
  'goodreads.com': {
    errorPatterns: ['page not found', 'book not found'],
    successPatterns: ['rating', 'reviews'],
  },
};

/**
 * Extract domain from URL
 */
function getDomain(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace('www.', '');
  } catch {
    return null;
  }
}

/**
 * Check if content indicates an error page
 */
function isErrorPage(content, domain) {
  const lowerContent = content.toLowerCase();

  // Check domain-specific error patterns first
  const domainRules = DOMAIN_RULES[domain];
  if (domainRules) {
    for (const pattern of domainRules.errorPatterns) {
      if (lowerContent.includes(pattern.toLowerCase())) {
        return { isError: true, reason: `Domain-specific error: ${pattern}` };
      }
    }
    // Check for success patterns - if found, it's likely valid
    for (const pattern of domainRules.successPatterns) {
      if (lowerContent.includes(pattern.toLowerCase())) {
        return { isError: false, reason: 'Success pattern found' };
      }
    }
  }

  // Check generic error indicators
  for (const indicator of ERROR_INDICATORS) {
    if (lowerContent.includes(indicator.toLowerCase())) {
      return { isError: true, reason: `Error indicator found: ${indicator}` };
    }
  }

  return { isError: false, reason: 'No error indicators found' };
}

/**
 * Validate URL by fetching it
 */
async function validateUrl(url) {
  const startTime = Date.now();
  const domain = getDomain(url);

  if (!domain) {
    return {
      isValid: false,
      status: 0,
      error: 'Invalid URL format',
      details: { domain: null, duration: Date.now() - startTime },
    };
  }

  try {
    // Use AbortController for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5,ar;q=0.3',
        'Cache-Control': 'no-cache',
      },
      redirect: 'follow',
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const duration = Date.now() - startTime;

    // Check HTTP status
    if (!response.ok) {
      return {
        isValid: false,
        status: response.status,
        error: `HTTP ${response.status}: ${response.statusText}`,
        details: {
          domain,
          duration,
          finalUrl: response.url,
          redirected: response.redirected,
        },
      };
    }

    // Check for redirect to error page
    const finalUrl = response.url;
    if (response.redirected) {
      const finalDomain = getDomain(finalUrl);
      // If redirected to a completely different domain or contains error in path
      if (finalUrl.includes('/error') || finalUrl.includes('/404') || finalUrl.includes('/not-found')) {
        return {
          isValid: false,
          status: response.status,
          error: 'Redirected to error page',
          details: {
            domain,
            duration,
            finalUrl,
            redirected: true,
          },
        };
      }
    }

    // For certain domains, check content for soft 404s
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('text/html')) {
      // Only read a portion of the content to check for errors
      const text = await response.text();
      const contentPreview = text.substring(0, 10000).toLowerCase();

      const errorCheck = isErrorPage(contentPreview, domain);
      if (errorCheck.isError) {
        return {
          isValid: false,
          status: response.status,
          error: errorCheck.reason,
          details: {
            domain,
            duration,
            finalUrl,
            contentLength: text.length,
            isSoft404: true,
          },
        };
      }

      // Check if page has minimal content (might be empty/error page)
      if (text.length < 1000) {
        return {
          isValid: false,
          status: response.status,
          error: 'Page has minimal content',
          details: {
            domain,
            duration,
            finalUrl,
            contentLength: text.length,
          },
        };
      }
    }

    // URL is valid
    return {
      isValid: true,
      status: response.status,
      error: null,
      details: {
        domain,
        duration,
        finalUrl,
        redirected: response.redirected,
        contentType,
      },
    };

  } catch (error) {
    const duration = Date.now() - startTime;

    if (error.name === 'AbortError') {
      return {
        isValid: false,
        status: 0,
        error: 'Request timeout (8s)',
        details: { domain, duration, timeout: true },
      };
    }

    // Network errors
    return {
      isValid: false,
      status: 0,
      error: error.message || 'Network error',
      details: { domain, duration, networkError: true },
    };
  }
}

/**
 * Main handler
 */
export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Get URL from body
  const { url } = req.body || {};

  if (!url || typeof url !== 'string') {
    return res.status(400).json({
      isValid: false,
      status: 0,
      error: 'URL is required',
      details: null,
    });
  }

  // Validate URL format
  try {
    new URL(url);
  } catch {
    return res.status(400).json({
      isValid: false,
      status: 0,
      error: 'Invalid URL format',
      details: null,
    });
  }

  // Perform validation
  try {
    const result = await validateUrl(url);

    // Log for debugging (will show in Vercel logs)
    console.log(`URL Validation: ${url} -> ${result.isValid ? 'VALID' : 'INVALID'} (${result.error || 'OK'})`);

    return res.status(200).json(result);
  } catch (error) {
    console.error(`URL Validation Error: ${url}`, error);
    return res.status(500).json({
      isValid: false,
      status: 0,
      error: 'Internal server error',
      details: { serverError: error.message },
    });
  }
}
