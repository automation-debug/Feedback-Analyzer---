# Feedback Analyzer - Developer Guide

Welcome to the Feedback Analyzer codebase! This guide will help you understand the project structure, make changes, and run tests.

## Table of Contents

1. [Quick Start](#quick-start)
2. [Project Structure](#project-structure)
3. [Architecture Overview](#architecture-overview)
4. [Configuration](#configuration)
5. [Services](#services)
6. [Testing](#testing)
7. [Common Tasks](#common-tasks)
8. [Troubleshooting](#troubleshooting)

---

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

---

## Project Structure

```
feedback_analyzer/
├── src/
│   ├── components/          # React UI components
│   │   ├── FeedbackAnalyzer.jsx    # Main workflow orchestrator
│   │   ├── LeadershipReport.jsx    # Report display
│   │   ├── BatchProgress.jsx       # Batch processing UI
│   │   └── ...
│   │
│   ├── config/              # Configuration files
│   │   ├── constants/       # Centralized configuration
│   │   │   └── index.js     # ⭐ ALL configurable values
│   │   └── fileSchemas.js   # Assessment file format definitions
│   │
│   ├── services/            # Business logic
│   │   ├── geminiService.js        # AI report generation
│   │   ├── weightedScoreService.js # Score calculations
│   │   ├── exportService.js        # Excel/CSV/JSON export
│   │   ├── personalityUrlService.js # Personality type URLs
│   │   ├── resourceRepository.js   # Development resources
│   │   └── report/
│   │       └── schemas/     # Report JSON schemas
│   │           ├── baseSchema.js
│   │           ├── standardSchema.js
│   │           ├── extendedSchema.js
│   │           ├── giganticSchema.js
│   │           └── index.js
│   │
│   ├── utils/               # Utility functions
│   │   ├── logger.js        # Logging utility
│   │   └── fuzzyMatch.js    # Arabic name matching
│   │
│   ├── tests/               # Test files
│   │   ├── setup.js         # Test configuration
│   │   ├── constants.test.js
│   │   ├── fuzzyMatch.test.js
│   │   ├── weightedScoreService.test.js
│   │   ├── personalityUrlService.test.js
│   │   └── reportSchemas.test.js
│   │
│   └── types/               # Type definitions
│       └── reportSchema.js  # JSDoc type annotations
│
├── api/                     # Vercel serverless functions
│   └── validate-url.js      # URL validation endpoint
│
├── vitest.config.js         # Test configuration
├── vite.config.js           # Build configuration
└── package.json
```

---

## Architecture Overview

### Data Flow

```
Upload Files (CSV/Excel)
    ↓
Parse Schemas (auto-detect format)
    ↓
Extract Candidates (fuzzy match names)
    ↓
Calculate Scores (weighted multi-source)
    ↓
Generate Reports (AI via OpenRouter)
    ↓
Export/Display Results
```

### Report Types

The system generates three types of reports based on reviewer count:

| Type | Reviewers | Strengths | Weaknesses | TeamVoice |
|------|-----------|-----------|------------|-----------|
| **STANDARD** | 1-6 | 3 | 3 | 4 |
| **EXTENDED** | 7-20 | 6 | 6 | 5 |
| **GIGANTIC** | 21+ | 9 | 9 | 12 |

---

## Configuration

All configurable values are centralized in `src/config/constants/index.js`.

### Key Configuration Sections

#### Report Thresholds
```javascript
import { REPORT_THRESHOLDS, getReportType } from './config/constants';

// Thresholds
REPORT_THRESHOLDS.EXTENDED  // 7 (7-20 reviewers)
REPORT_THRESHOLDS.GIGANTIC  // 21 (21+ reviewers)

// Helper function
getReportType(15)  // Returns 'EXTENDED'
```

#### File Weights
```javascript
import { FILE_WEIGHTS } from './config/constants';

// Assessment source weights (must sum to 100)
FILE_WEIGHTS['leadership_assessment_dec_2025']  // 60% (primary)
FILE_WEIGHTS['360_leadership_feedback']         // 10%
// ... etc
```

#### Score Thresholds (5-tier color system)
```javascript
import { SCORE_THRESHOLDS, getScoreStatus } from './config/constants';

// Score ranges
SCORE_THRESHOLDS.PRIDE   // 92-100 (فخر)
SCORE_THRESHOLDS.GREEN   // 83-91  (خضر)
SCORE_THRESHOLDS.YELLOW  // 74-82  (صفر)
SCORE_THRESHOLDS.RED     // 64-73  (حمر)
SCORE_THRESHOLDS.DANGER  // 0-63   (خطر)

// Helper function
getScoreStatus(85)  // Returns GREEN threshold object
```

#### Character Limits
```javascript
import { FIELD_LIMITS, ITEM_COUNTS } from './config/constants';

// Field character limits
FIELD_LIMITS.strengths.description.min  // 120
FIELD_LIMITS.strengths.description.max  // 175

// Item counts by report type
ITEM_COUNTS.STANDARD.strengths  // 3
ITEM_COUNTS.EXTENDED.strengths  // 6
ITEM_COUNTS.GIGANTIC.strengths  // 9
```

---

## Services

### geminiService.js
Handles AI-powered report generation via OpenRouter API.

```javascript
import { generateReportFromFeedback } from './services/geminiService';

const report = await generateReportFromFeedback(
  feedbackData,    // Parsed CSV/Excel data
  'محمد أحمد',     // Employee name
  'مدير',          // Job title
  null,            // Leader assessment (optional)
  null,            // Periodic evaluation (optional)
  'standard'       // Writing style: 'standard' or 'direct'
);
```

### weightedScoreService.js
Calculates deterministic scores from multiple assessment sources.

```javascript
import { calculateCandidateScores } from './services/weightedScoreService';

const scores = calculateCandidateScores(
  'محمد أحمد',     // Candidate name
  allFileData      // Data from all uploaded files
);

// Returns:
// {
//   overallScore: 85,
//   statusLabelAr: 'خضر',
//   coreMetricScores: { clarity: 80, efficiency: 85, safety: 90, empowerment: 75 },
//   totalReviewerCount: 15,
//   ...
// }
```

### Logger Utility
```javascript
import { createLogger } from './utils/logger';

const logger = createLogger('MyService');

logger.info('Processing started', { count: 10 });
logger.debug('Details', { data: someData });
logger.warn('Potential issue');
logger.error('Something failed', { error: err.message });

// Track operations with timing
const op = logger.startOperation('fetchData');
try {
  const result = await fetchData();
  op.end({ recordCount: result.length });  // Logs duration
} catch (err) {
  op.fail(err);
}
```

---

## Testing

### Running Tests

```bash
# Run all tests
npm test

# Run tests once (CI mode)
npm run test:run

# Run with coverage
npm run test:coverage

# Run specific test file
npm test -- fuzzyMatch
```

### Test Structure

Each service has a corresponding test file in `src/tests/`:

```
constants.test.js          # Configuration tests
fuzzyMatch.test.js         # Arabic name matching tests
weightedScoreService.test.js # Score calculation tests
personalityUrlService.test.js # URL generation tests
reportSchemas.test.js      # Schema validation tests
```

### Writing Tests

```javascript
import { describe, it, expect } from 'vitest';
import { myFunction } from '../services/myService';

describe('myFunction', () => {
  it('should handle valid input', () => {
    const result = myFunction('input');
    expect(result).toBe('expected');
  });

  it('should handle edge cases', () => {
    expect(myFunction(null)).toBe(null);
    expect(myFunction('')).toBe('');
  });
});
```

---

## Common Tasks

### Changing Report Thresholds

Edit `src/config/constants/index.js`:

```javascript
export const REPORT_THRESHOLDS = {
  EXTENDED: 7,   // Change to adjust Extended threshold
  GIGANTIC: 21   // Change to adjust Gigantic threshold
};
```

### Adding a New Assessment Source

1. Add schema in `src/config/fileSchemas.js`
2. Add weight in `src/config/constants/index.js`:
   ```javascript
   export const FILE_WEIGHTS = {
     // ... existing
     'new_source': 5  // Must sum to 100 with others
   };
   ```
3. Add extraction function in `weightedScoreService.js`

### Modifying Report Content Length

Edit `src/config/constants/index.js`:

```javascript
export const FIELD_LIMITS = {
  strengths: {
    title: { min: 37, max: 39 },
    description: { min: 120, max: 175 }  // Adjust these
  },
  // ...
};
```

### Adding a New Personality Type URL

Edit `src/services/personalityUrlService.js`:

```javascript
const MBTI_URLS = {
  // Add new type
  'XXXX': 'https://example.com/xxxx',
  // ...
};
```

---

## Troubleshooting

### Common Issues

#### "Module not found" errors
```bash
# Clear node_modules and reinstall
rm -rf node_modules
npm install
```

#### Tests failing after changes
```bash
# Run tests in watch mode to see failures
npm test
```

#### API errors
- Check that `VITE_OPENROUTER_API_KEY` is set
- Verify API key is valid
- Check rate limits (max 3 concurrent requests)

### Debug Logging

```javascript
import { setLogLevel } from './utils/logger';

// Enable debug logging
setLogLevel('DEBUG');

// View logs
import { getLogHistory, exportLogs } from './utils/logger';
console.log(getLogHistory());
console.log(exportLogs());
```

---

## Key Files Reference

| File | Purpose | When to Edit |
|------|---------|--------------|
| `config/constants/index.js` | All configuration | Change thresholds, limits, weights |
| `services/geminiService.js` | AI prompts | Modify report content style |
| `services/weightedScoreService.js` | Score calculation | Change scoring logic |
| `services/exportService.js` | Export formats | Modify Excel/CSV output |
| `config/fileSchemas.js` | File format parsing | Support new file formats |
| `utils/logger.js` | Logging | Modify log format |
| `utils/fuzzyMatch.js` | Name matching | Improve Arabic matching |

---

## Contact

For questions or issues, open a GitHub issue or contact the development team.
