# Feedback Analyzer - Codebase Map

> **Quick Reference**: Direct access to every part of the codebase.
> For detailed usage, see [DEVELOPER.md](./DEVELOPER.md)

---

## At a Glance

```
┌─────────────────────────────────────────────────────────────────────┐
│                    FEEDBACK ANALYZER CODEBASE                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  [CONFIG]              [SERVICES]              [UTILS]              │
│  ─────────            ───────────             ───────               │
│  constants/           geminiService.js        logger.js             │
│  └─ index.js ◀────┐   weightedScoreService    fuzzyMatch.js         │
│  fileSchemas.js   │   exportService.js                              │
│                   │   personalityUrlService   [TESTS]               │
│  [SCHEMAS]        │   resourceRepository      ───────               │
│  ─────────        │                           160 tests             │
│  baseSchema.js    └── report/schemas/         5 test files          │
│  standardSchema       └─ index.js                                   │
│  extendedSchema                                                     │
│  giganticSchema                                                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 1. Configuration (`src/config/`)

### `constants/index.js` ⭐ MAIN CONFIG FILE
**Location**: `src/config/constants/index.js`

Everything configurable lives here. Edit this file to change app behavior.

| Export | What It Does | Example Values |
|--------|--------------|----------------|
| `REPORT_THRESHOLDS` | When to use EXTENDED/GIGANTIC reports | `{ EXTENDED: 7, GIGANTIC: 21 }` |
| `FILE_WEIGHTS` | How much each data source affects scores | `leadership_assessment: 60%` |
| `SCORE_THRESHOLDS` | 5-tier color system (فخر/خضر/صفر/حمر/خطر) | `PRIDE: 92-100, GREEN: 83-91` |
| `FIELD_LIMITS` | Character limits for report fields | `strengths.title: 37-39 chars` |
| `ITEM_COUNTS` | How many items per report type | `STANDARD.strengths: 3` |
| `API_CONFIG` | OpenRouter API settings | `timeout: 120000ms` |
| `BATCH_CONFIG` | Parallel processing settings | `maxConcurrent: 3` |
| `getReportType(n)` | Get report type from reviewer count | `getReportType(15) → 'EXTENDED'` |
| `getScoreStatus(n)` | Get color tier from score | `getScoreStatus(85) → GREEN` |

### `fileSchemas.js`
**Location**: `src/config/fileSchemas.js`

Defines how to parse different assessment file formats (CSV/Excel column mappings).

---

## 2. Services (`src/services/`)

### `geminiService.js` - AI Report Generation
**Location**: `src/services/geminiService.js`

Generates leadership reports using OpenRouter API (GPT-4o-mini).

| Function | Purpose |
|----------|---------|
| `generateReportFromFeedback()` | Generate report for one person |
| `processBatch()` | Process multiple candidates in parallel |
| `buildStandardOutputRequirements()` | Build prompt for <7 reviewers |
| `buildExtendedOutputRequirements()` | Build prompt for 7-20 reviewers |
| `buildGiganticOutputRequirements()` | Build prompt for 21+ reviewers |

**Imports schemas from**: `./report/schemas/index.js`
**Imports constants from**: `../config/constants/index.js`

---

### `weightedScoreService.js` - Score Calculations
**Location**: `src/services/weightedScoreService.js`

All score calculations are deterministic (no AI randomness).

| Function | Purpose |
|----------|---------|
| `calculateCandidateScores()` | Full score calculation for a candidate |
| `normalizeScore(score, min, max)` | Convert any scale to 0-100 |
| `calculateAdjustedWeights()` | Rebalance when sources missing |
| `calculateWeightedScore()` | Compute weighted average |
| `calculateCoreMetricScores()` | Scores per metric (clarity, efficiency, safety, empowerment) |
| `aggregateHistoricalFeedback()` | Combine feedback from all sources |
| `getDecember2025Feedback()` | Extract File 7 (primary source) data |

**Exports**: `FILE_WEIGHTS` (re-exported from constants)

---

### `exportService.js` - Export to Files
**Location**: `src/services/exportService.js`

Export reports to Excel, CSV, or JSON formats.

---

### `personalityUrlService.js` - Personality Type URLs
**Location**: `src/services/personalityUrlService.js`

Generates URLs for personality type descriptions.

| Function | Purpose |
|----------|---------|
| `getMbtiUrl(type)` | URL for MBTI type (e.g., INTJ) |
| `getEnneagramUrl(type)` | URL for Enneagram type |
| `getDiscUrl(type)` | URL for DISC profile |
| `getBigFiveUrl(type)` | URL for Big Five trait |
| `getPersonalityUrls(analysis)` | Get all URLs for a personality analysis |
| `addPersonalityUrlsToRow(row, analysis)` | Add URL columns to export row |

---

### `resourceRepository.js` - Development Resources
**Location**: `src/services/resourceRepository.js`

Catalog of books/resources for development plans.

| Function | Purpose |
|----------|---------|
| `getResourceListForPrompt()` | Format resources for AI prompt |
| `mapDevelopmentPlanToUrls()` | Add URLs to development plan |

---

## 3. Report Schemas (`src/services/report/schemas/`)

JSON schemas defining report structure for AI generation.

### `index.js` - Schema Entry Point
**Location**: `src/services/report/schemas/index.js`

| Export | Purpose |
|--------|---------|
| `STANDARD_REPORT_SCHEMA` | Schema for <7 reviewers |
| `EXTENDED_REPORT_SCHEMA` | Schema for 7-20 reviewers |
| `GIGANTIC_REPORT_SCHEMA` | Schema for 21+ reviewers |
| `REPORT_SCHEMAS` | Map of all schemas |
| `getSchemaForReportType(type)` | Get schema by type name |
| `getSchemaByReviewerCount(n)` | Get schema by reviewer count |
| `validateReportStructure()` | Validate report matches schema |

### Schema Files
| File | Report Type | Strengths | Weaknesses | TeamVoice |
|------|-------------|-----------|------------|-----------|
| `standardSchema.js` | STANDARD (<7) | 3 | 3 | 4 |
| `extendedSchema.js` | EXTENDED (7-20) | 6 | 6 | 5 |
| `giganticSchema.js` | GIGANTIC (21+) | 9 | 9 | 12 |

### `baseSchema.js` - Shared Components
Common schema pieces reused across all report types.

---

## 4. Utilities (`src/utils/`)

### `logger.js` - Logging System
**Location**: `src/utils/logger.js`

| Function | Purpose |
|----------|---------|
| `createLogger(name)` | Create a named logger instance |
| `logger.info/debug/warn/error()` | Log at different levels |
| `logger.startOperation(name)` | Start timing an operation |
| `setLogLevel(level)` | Change log verbosity |
| `getLogHistory()` | Get recent log entries |
| `exportLogs()` | Export logs for debugging |

### `fuzzyMatch.js` - Arabic Name Matching
**Location**: `src/utils/fuzzyMatch.js`

Handles Arabic name normalization and fuzzy matching.

| Function | Purpose |
|----------|---------|
| `normalizeArabicName(name)` | Normalize Arabic characters |
| `fuzzyMatchName(name, candidates)` | Find best match in list |

---

## 5. Tests (`src/tests/`)

**160 tests** across 5 files. Run with `npm test`.

| Test File | Tests | What It Tests |
|-----------|-------|---------------|
| `constants.test.js` | 39 | All configuration values |
| `fuzzyMatch.test.js` | 35 | Arabic name matching |
| `weightedScoreService.test.js` | 32 | Score calculations |
| `personalityUrlService.test.js` | 24 | URL generation |
| `reportSchemas.test.js` | 30 | Schema structure |

---

## 6. Components (`src/components/`)

React UI components.

| Component | Purpose |
|-----------|---------|
| `FeedbackAnalyzer.jsx` | Main workflow orchestrator |
| `LeadershipReport.jsx` | Report display |
| `BatchProgress.jsx` | Batch processing UI |

---

## 7. API (`api/`)

Vercel serverless functions.

| File | Purpose |
|------|---------|
| `validate-url.js` | URL validation endpoint |

---

## Quick Find

### "I want to change..."

| Change This | Edit This File |
|-------------|----------------|
| Report thresholds (7/21) | `config/constants/index.js` → `REPORT_THRESHOLDS` |
| Assessment weights | `config/constants/index.js` → `FILE_WEIGHTS` |
| Score color ranges | `config/constants/index.js` → `SCORE_THRESHOLDS` |
| Field character limits | `config/constants/index.js` → `FIELD_LIMITS` |
| AI prompt wording | `services/geminiService.js` → `build*OutputRequirements()` |
| Score calculation logic | `services/weightedScoreService.js` |
| Export format | `services/exportService.js` |
| File parsing | `config/fileSchemas.js` |
| Personality URLs | `services/personalityUrlService.js` |

### "I want to understand..."

| Topic | Look Here |
|-------|-----------|
| How scores are calculated | `weightedScoreService.js` |
| How reports are generated | `geminiService.js` |
| What schemas look like | `services/report/schemas/` |
| How names are matched | `utils/fuzzyMatch.js` |
| Configuration options | `config/constants/index.js` |
| Test examples | `src/tests/` |

---

## Data Flow Diagram

```
┌─────────────────┐
│  Upload Files   │  CSV/Excel assessment files
└────────┬────────┘
         ▼
┌─────────────────┐
│  fileSchemas.js │  Parse & detect file format
└────────┬────────┘
         ▼
┌─────────────────┐
│  fuzzyMatch.js  │  Match candidate names across files
└────────┬────────┘
         ▼
┌─────────────────────────┐
│  weightedScoreService   │  Calculate deterministic scores
│  - normalizeScore()     │  (client-side, no AI)
│  - calculateWeighted()  │
└────────┬────────────────┘
         ▼
┌─────────────────────────┐
│  geminiService.js       │  Generate AI report
│  - Choose schema        │  STANDARD/EXTENDED/GIGANTIC
│  - Build prompt         │  based on reviewer count
│  - Call OpenRouter API  │
└────────┬────────────────┘
         ▼
┌─────────────────┐
│  exportService  │  Export to Excel/CSV/JSON
└─────────────────┘
```

---

## File Size Reference

After recent refactoring:
- **geminiService.js**: ~2,400 lines (down from ~3,100)
- **weightedScoreService.js**: ~800 lines
- **constants/index.js**: ~380 lines
- **Total tests**: 160 tests, 5 files

---

## Arabic Text Notes

- All reports are in Arabic (العربية)
- Name matching handles Arabic normalization
- Gender detection defaults to MASCULINE
- 5-tier status labels: فخر، خضر، صفر، حمر، خطر

---

*Last updated: After duplication removal refactoring*
