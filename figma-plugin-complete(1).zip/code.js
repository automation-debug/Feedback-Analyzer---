console.log('🚀 Plugin starting...');

figma.showUI(__html__, { width: 500, height: 700, themeColors: true });

let isProcessing = false;
const originalFormatting = new Map();

// RESOURCE URL LOOKUP DATABASE - Using Goodreads URLs
const LEADERSHIP_RESOURCES = {
  "books": {
    "تجرأ على القيادة": "https://www.goodreads.com/book/show/40109367-dare-to-lead",
    "Dare to Lead": "https://www.goodreads.com/book/show/40109367-dare-to-lead",
    "بجرأة شديدة": "https://www.goodreads.com/book/show/13588356-daring-greatly",
    "Daring Greatly": "https://www.goodreads.com/book/show/13588356-daring-greatly",
    "المؤسسة التي لا تهاب": "https://www.goodreads.com/book/show/40275161-the-fearless-organization",
    "The Fearless Organization": "https://www.goodreads.com/book/show/40275161-the-fearless-organization",
    "كتاب الثقة الصغير": "https://www.goodreads.com/book/show/7013813-the-thin-book-of-trust-an-essential-primer-for-building-trust-at-work",
    "The Thin Book of Trust": "https://www.goodreads.com/book/show/7013813-the-thin-book-of-trust-an-essential-primer-for-building-trust-at-work",
    "الثقة والإلهام": "https://www.goodreads.com/book/show/58438525-trust-and-inspire",
    "Trust and Inspire": "https://www.goodreads.com/book/show/58438525-trust-and-inspire",
    "القادة يأكلون أخيراً": "https://www.goodreads.com/book/show/16144853-leaders-eat-last",
    "Leaders Eat Last": "https://www.goodreads.com/book/show/16144853-leaders-eat-last",
    "ابدأ بـ لماذا": "https://www.goodreads.com/book/show/7108725-start-with-why",
    "Start With Why": "https://www.goodreads.com/book/show/7108725-start-with-why",
    "اللعبة اللانهائية": "https://www.goodreads.com/book/show/38390751-the-infinite-game",
    "The Infinite Game": "https://www.goodreads.com/book/show/38390751-the-infinite-game",
    "من جيد إلى عظيم": "https://www.goodreads.com/book/show/76865",
    "Good to Great": "https://www.goodreads.com/book/show/76865",
    "21 قانوناً في القيادة": "https://www.goodreads.com/book/show/815716.The_21_Irrefutable_Laws_of_Leadership",
    "The 21 Irrefutable Laws of Leadership": "https://www.goodreads.com/book/show/815716.The_21_Irrefutable_Laws_of_Leadership",
    "القيادة الخادمة": "https://www.goodreads.com/book/show/181737.Servant_Leadership",
    "Servant Leadership": "https://www.goodreads.com/book/show/181737.Servant_Leadership",
    "المضاعفون": "https://www.goodreads.com/book/show/8310410-multipliers",
    "Multipliers": "https://www.goodreads.com/book/show/8310410-multipliers",
    "اقلب السفينة": "https://www.goodreads.com/book/show/16158601-turn-the-ship-around",
    "Turn the Ship Around": "https://www.goodreads.com/book/show/16158601-turn-the-ship-around",
    "الملكية المطلقة": "https://www.goodreads.com/book/show/23848190-extreme-ownership",
    "Extreme Ownership": "https://www.goodreads.com/book/show/23848190-extreme-ownership",
    "القيادة البدائية": "https://www.goodreads.com/book/show/163106.Primal_Leadership",
    "Primal Leadership": "https://www.goodreads.com/book/show/163106.Primal_Leadership",
    "محادثات حاسمة": "https://www.goodreads.com/book/show/15014.Crucial_Conversations",
    "Crucial Conversations": "https://www.goodreads.com/book/show/15014.Crucial_Conversations",
    "الصراحة المطلقة": "https://www.goodreads.com/book/show/29939161-radical-candor",
    "Radical Candor": "https://www.goodreads.com/book/show/29939161-radical-candor",
    "التواصل غير العنيف": "https://www.goodreads.com/book/show/71730.Nonviolent_Communication",
    "Nonviolent Communication": "https://www.goodreads.com/book/show/71730.Nonviolent_Communication",
    "محادثات صعبة": "https://www.goodreads.com/book/show/774088",
    "Difficult Conversations": "https://www.goodreads.com/book/show/774088",
    "شكراً على الملاحظات": "https://www.goodreads.com/book/show/18114668",
    "Thanks for the Feedback": "https://www.goodreads.com/book/show/18114668",
    "عادة التدريب": "https://www.goodreads.com/book/show/29342515",
    "The Coaching Habit": "https://www.goodreads.com/book/show/29342515",
    "الذكاء العاطفي": "https://www.goodreads.com/book/show/26329.Emotional_Intelligence",
    "Emotional Intelligence": "https://www.goodreads.com/book/show/26329.Emotional_Intelligence",
    "الذكاء العاطفي 2.0": "https://www.goodreads.com/book/show/6486483-emotional-intelligence-2-0",
    "Emotional Intelligence 2.0": "https://www.goodreads.com/book/show/6486483-emotional-intelligence-2-0",
    "حافة الذكاء العاطفي": "https://www.goodreads.com/book/show/603804.The_EQ_Edge",
    "The EQ Edge": "https://www.goodreads.com/book/show/603804.The_EQ_Edge",
    "العمل مع الذكاء العاطفي": "https://www.goodreads.com/book/show/27537",
    "Working with Emotional Intelligence": "https://www.goodreads.com/book/show/27537",
    "خلل العمل الجماعي الخمسة": "https://www.goodreads.com/book/show/21323",
    "The Five Dysfunctions of a Team": "https://www.goodreads.com/book/show/21323",
    "شفرة الثقافة": "https://www.goodreads.com/book/show/33512613",
    "The Culture Code": "https://www.goodreads.com/book/show/33512613",
    "فريق الفرق": "https://www.goodreads.com/book/show/22245331",
    "Team of Teams": "https://www.goodreads.com/book/show/22245331",
    "اللاعب المثالي في الفريق": "https://www.goodreads.com/book/show/27214150",
    "The Ideal Team Player": "https://www.goodreads.com/book/show/27214150",
    "الذكاء التعاوني": "https://www.goodreads.com/book/show/24453535",
    "Collaborative Intelligence": "https://www.goodreads.com/book/show/24453535",
    "مدير الدقيقة الواحدة": "https://www.goodreads.com/book/show/763362",
    "The One Minute Manager": "https://www.goodreads.com/book/show/763362",
    "مدير الدقيقة الواحدة يقابل القرد": "https://www.goodreads.com/book/show/15950",
    "The One Minute Manager Meets the Monkey": "https://www.goodreads.com/book/show/15950",
    "إذا أردت إنجازه بشكل صحيح": "https://www.goodreads.com/book/show/440590",
    "If You Want It Done Right, You Don't Have to Do It Yourself": "https://www.goodreads.com/book/show/440590",
    "القيادة وخداع الذات": "https://www.goodreads.com/book/show/180436.Leadership_and_Self_Deception",
    "Leadership and Self-Deception": "https://www.goodreads.com/book/show/180436.Leadership_and_Self_Deception",
    "العادات السبع": "https://www.goodreads.com/book/show/36072",
    "The 7 Habits of Highly Effective People": "https://www.goodreads.com/book/show/36072",
    "العمل العميق": "https://www.goodreads.com/book/show/25744928",
    "Deep Work": "https://www.goodreads.com/book/show/25744928",
    "إنجاز المهام": "https://www.goodreads.com/book/show/1633",
    "Getting Things Done": "https://www.goodreads.com/book/show/1633",
    "الجوهرية": "https://www.goodreads.com/book/show/18077875-essentialism",
    "Essentialism": "https://www.goodreads.com/book/show/18077875-essentialism",
    "المدير الفعال": "https://www.goodreads.com/book/show/48015.The_Effective_Executive",
    "The Effective Executive": "https://www.goodreads.com/book/show/48015.The_Effective_Executive",
    "العادات الذرية": "https://www.goodreads.com/book/show/40121378-atomic-habits",
    "Atomic Habits": "https://www.goodreads.com/book/show/40121378-atomic-habits",
    "التفكير بسرعة وببطء": "https://www.goodreads.com/book/show/11468377-thinking-fast-and-slow",
    "Thinking, Fast and Slow": "https://www.goodreads.com/book/show/11468377-thinking-fast-and-slow",
    "حاسم": "https://www.goodreads.com/book/show/15798078-decisive",
    "Decisive": "https://www.goodreads.com/book/show/15798078-decisive",
    "أول 90 يوماً": "https://www.goodreads.com/book/show/15824358",
    "The First 90 Days": "https://www.goodreads.com/book/show/15824358",
    "أهم 10 مقالات في القيادة": "https://www.goodreads.com/book/show/8499092",
    "HBR's 10 Must Reads on Leadership": "https://www.goodreads.com/book/show/8499092",
    "كيف تكسب الأصدقاء": "https://www.goodreads.com/book/show/4865",
    "How to Win Friends and Influence People": "https://www.goodreads.com/book/show/4865",
    "التأثير": "https://www.goodreads.com/book/show/28815",
    "Influence": "https://www.goodreads.com/book/show/28815",
    "ما قبل الإقناع": "https://www.goodreads.com/book/show/28814414",
    "Pre-Suasion": "https://www.goodreads.com/book/show/28814414",
    "الحافز": "https://www.goodreads.com/book/show/6452796",
    "Drive": "https://www.goodreads.com/book/show/6452796",
    "طريقة التفكير": "https://www.goodreads.com/book/show/40495",
    "Mindset": "https://www.goodreads.com/book/show/40495",
    "المثابرة": "https://www.goodreads.com/book/show/27213329",
    "Grit": "https://www.goodreads.com/book/show/27213329",
    "قوة العادة": "https://www.goodreads.com/book/show/12609433",
    "The Power of Habit": "https://www.goodreads.com/book/show/12609433"
  },
  "videos": {
    "قوة الضعف": "https://www.youtube.com/watch?v=iCvmsMzlF7o",
    "The power of vulnerability": "https://www.youtube.com/watch?v=iCvmsMzlF7o",
    "لماذا يجعلك القادة الجيدون تشعر بالأمان": "https://www.youtube.com/watch?v=lmyZMtPVodo",
    "Why good leaders make you feel safe": "https://www.youtube.com/watch?v=lmyZMtPVodo",
    "القيادة اليومية": "https://www.youtube.com/watch?v=HR2UnsOuKxo",
    "Everyday leadership": "https://www.youtube.com/watch?v=HR2UnsOuKxo",
    "كيف تبني الثقة وتستعيدها": "https://www.youtube.com/watch?v=pVeq-0dIqpk",
    "How to build (and rebuild) trust": "https://www.youtube.com/watch?v=pVeq-0dIqpk",
    "ما يتطلبه الأمر لتكون قائداً عظيماً": "https://www.youtube.com/watch?v=aUfK7Y8m_9Y",
    "What it takes to be a great leader": "https://www.youtube.com/watch?v=aUfK7Y8m_9Y",
    "لغز التحفيز": "https://www.youtube.com/watch?v=rrkrvAUbU9Y",
    "The puzzle of motivation": "https://www.youtube.com/watch?v=rrkrvAUbU9Y",
    "المثابرة: قوة الشغف والمواظبة": "https://www.youtube.com/watch?v=H14bBuluwB8",
    "Grit: The power of passion and perseverance": "https://www.youtube.com/watch?v=H14bBuluwB8",
    "السر السعيد للعمل بشكل أفضل": "https://www.youtube.com/watch?v=fLJsdqxnZb0",
    "The happy secret to better work": "https://www.youtube.com/watch?v=fLJsdqxnZb0",
    "كيف تتحدث لكي يرغب الناس في الاستماع إليك": "https://www.youtube.com/watch?v=eIho2S0ZahI",
    "How to speak so that people want to listen": "https://www.youtube.com/watch?v=eIho2S0ZahI"
  }
};

// Helper function to lookup URL by title (with fallback)
// Used ONLY for development plan resources - ignores CSV URLs
function lookupResourceUrl(title, csvUrl) {
  console.log(`    🔍 Lookup: title="${title}", csvUrl="${csvUrl}"`);
  
  // ALWAYS use database for development resources (ignore CSV URL)
  // CSV URLs for development plan are unreliable, so we force lookup
  
  if (!title || !title.trim()) {
    console.log(`    ⚠️ No title provided, skipping lookup`);
    return '';
  }
  
  const cleanTitle = title.trim();
  console.log(`    🔍 Searching for: "${cleanTitle}"`);
  
  // Check books
  if (LEADERSHIP_RESOURCES.books[cleanTitle]) {
    console.log(`    ✅ Found in books: ${LEADERSHIP_RESOURCES.books[cleanTitle]}`);
    return LEADERSHIP_RESOURCES.books[cleanTitle];
  }
  
  // Check videos
  if (LEADERSHIP_RESOURCES.videos[cleanTitle]) {
    console.log(`    ✅ Found in videos: ${LEADERSHIP_RESOURCES.videos[cleanTitle]}`);
    return LEADERSHIP_RESOURCES.videos[cleanTitle];
  }
  
  console.log(`    ❌ Not found in database`);
  return '';
}

// Helper function to add emoji based on resource type
function addResourceEmoji(title) {
  if (!title || !title.trim()) return '';
  
  const cleanTitle = title.trim();
  
  // Check if it's a book (exact match)
  if (LEADERSHIP_RESOURCES.books[cleanTitle]) {
    console.log(`    📚 Book emoji added: "${cleanTitle}"`);
    return `📚 ${cleanTitle}`;
  }
  
  // Check if it's a video (exact match)
  if (LEADERSHIP_RESOURCES.videos[cleanTitle]) {
    console.log(`    🎥 Video emoji added: "${cleanTitle}"`);
    return `🎥 ${cleanTitle}`;
  }
  
  // Unknown resource - add link emoji as default
  console.log(`    🔗 Default link emoji added (not in database): "${cleanTitle}"`);
  return `🔗 ${cleanTitle}`;
}

// Helper function for personality badge URLs - USES CSV URLs!
function getPersonalityUrl(title, csvUrl) {
  console.log(`    🔗 Personality URL: title="${title}", csvUrl="${csvUrl}"`);
  
  // For personality badges, ALWAYS use CSV URL
  if (csvUrl && csvUrl.trim() && csvUrl.startsWith('http')) {
    console.log(`    ✅ Using CSV URL: ${csvUrl}`);
    return csvUrl;
  }
  
  if (!csvUrl || !csvUrl.trim()) {
    console.log(`    ⚠️ CSV URL is empty or missing!`);
  } else if (!csvUrl.startsWith('http')) {
    console.log(`    ⚠️ CSV URL doesn't start with http: "${csvUrl}"`);
  }
  
  return '';
}

// TEMPLATE DETECTION: SHORT vs EXTENDED
function getTemplateMappings(isExtended) {
  return isExtended ? EXTENDED_MAPPINGS_V2 : SHORT_MAPPINGS_V2;
}

function getFieldDefinitions(isExtended) {
  return isExtended ? EXTENDED_FIELDS_V2 : SHORT_FIELDS_V2;
}

// SHORT TEMPLATE MAPPINGS (Old 5-page template - nodes 19029:xxx)
const SHORT_MAPPINGS_V2 = {
  // Page "1 - old" - Cover
  '19029:19': 'employee_name_cover',
  
  // Page "2 - old" - Overview  
  '19029:40': 'employee_name',
  '19029:49': 'status_badge',
  '19029:97': 'executive_summary',
  
  // Page "2 - old" - Metrics (4 boxes with 3 bullets)
  '19029:64': 'empowerment_score',
  '19029:65': 'empowerment_text',
  '19029:60': 'safety_score',
  '19029:66': 'safety_text',
  '19029:61': 'efficiency_score',
  '19029:67': 'efficiency_text',
  '19029:62': 'clarity_score',
  '19029:68': 'clarity_text',
  
  // Page "2 - old" - Strength/Weakness boxes (6 boxes total, 3×2)
  '19029:85': 'strength_1_title',
  '19029:88': 'strength_1_desc',
  '19029:86': 'strength_2_title',
  '19029:89': 'strength_2_desc',
  '19029:87': 'strength_3_title',
  '19029:90': 'strength_3_desc',
  
  '19029:91': 'weakness_1_title',
  '19029:94': 'weakness_1_desc',
  '19029:92': 'weakness_2_title',
  '19029:95': 'weakness_2_desc',
  '19029:93': 'weakness_3_title',
  '19029:96': 'weakness_3_desc',
  
  // Page "3 - old" - Personality
  '19029:150': 'personality_overview',
  '19029:131': 'big5_badge',
  '19029:136': 'mbti_badge',
  '19029:139': 'disc_badge',
  '19029:142': 'enneagram_badge',
  '19029:144': 'personality_strengths',
  '19029:145': 'personality_weaknesses',
  
  // Page "3 - old" - Team Voice (4 boxes)
  '19029:108': 'team_voice_1_title',
  '19029:111': 'team_voice_1_content',
  '19029:109': 'team_voice_2_title',
  '19029:110': 'team_voice_2_content',
  '19029:116': 'team_voice_3_title',
  '19029:118': 'team_voice_3_content',
  '19029:117': 'team_voice_4_title',
  '19029:119': 'team_voice_4_content',
  
  // Page "4 - old" - Roadmap (3 items)
  '19029:173': 'roadmap_1_title',
  '19029:192': 'roadmap_1_steps',
  '19029:182': 'roadmap_2_title',
  '19029:193': 'roadmap_2_steps',
  '19029:191': 'roadmap_3_title',
  '19029:194': 'roadmap_3_steps',
  
  // Page "4 - old" - Development Plan Track 1
  '19029:199': 'dev_track_1_title',
  '19029:204': 'dev_track_1_res_1',
  '19029:206': 'dev_track_1_res_2',
  '19029:208': 'dev_track_1_res_3',
  '19029:210': 'dev_track_1_res_4',
  '19029:212': 'dev_track_1_res_5',
  
  // Page "4 - old" - Development Plan Track 2
  '19029:200': 'dev_track_2_title',
  '19029:228': 'dev_track_2_res_1',
  '19029:230': 'dev_track_2_res_2',
  '19029:232': 'dev_track_2_res_3',
  '19029:234': 'dev_track_2_res_4',
  '19029:236': 'dev_track_2_res_5',
  
  // Page "4 - old" - Development Plan Track 3
  '19029:201': 'dev_track_3_title',
  '19029:238': 'dev_track_3_res_1',
  '19029:240': 'dev_track_3_res_2',
  '19029:242': 'dev_track_3_res_3',
  '19029:244': 'dev_track_3_res_4',
  '19029:246': 'dev_track_3_res_5',
  
  // Page "4 - old" - Development Plan Track 4
  '19029:202': 'dev_track_4_title',
  '19029:214': 'dev_track_4_res_1',
  '19029:216': 'dev_track_4_res_2',
  '19029:218': 'dev_track_4_res_3',
  '19029:220': 'dev_track_4_res_4',
  '19029:222': 'dev_track_4_res_5'
};

// EXTENDED TEMPLATE MAPPINGS (New 6-page template - nodes 1:xxx, 6001:xxx, etc.)
// EXTENDED TEMPLATE MAPPINGS (New 6-page template - nodes 1:xxx, 6001:xxx, etc.)
const EXTENDED_MAPPINGS_V2 = {
  // Page 1 - Cover
  '1:19': 'employee_name_cover',
  
  // Page 2 - Overview
  '1:72': 'employee_name',
  '1:93': 'status_badge',
  '6001:181': 'executive_summary',
  
  // Page 2 - Extended Analysis Boxes (two red boxes with 5 bullets each)
  // Page 2 - Extended Analysis Boxes (NEW - title + 5 bullets each)
  '19081:66': 'executive_summary_2_title',       // Right box title
  '17007:303': 'executive_summary_2_bullets',    // Right box bullets
  '19081:49': 'personality_overview_2_title',    // Left box title
  '19081:51': 'personality_overview_2_bullets',  // Left box bullets
  
  // Page 2 - Metrics (4 boxes with 5 bullets each)
  '17007:315': 'empowerment_score',
  '17007:316': 'empowerment_text',
  '17007:311': 'safety_score',
  '17007:317': 'safety_text',
  '17007:312': 'efficiency_score',
  '17007:318': 'efficiency_text',
  '17007:313': 'clarity_score',
  '17007:319': 'clarity_text',
  
  // Page 3 - Strength Boxes ROW 1 (top 3 boxes - use columns 1-3)
  '17007:347': 'strength_1_title',
  '17007:353': 'strength_1_desc',
  '17007:349': 'strength_2_title',
  '17007:355': 'strength_2_desc',
  '17007:351': 'strength_3_title',
  '17007:357': 'strength_3_desc',
  
  // Page 3 - Strength Boxes ROW 2 (bottom 3 boxes - use columns 4-6)
  '17007:348': 'strength_4_title',
  '17007:354': 'strength_4_desc',
  '17007:350': 'strength_5_title',
  '17007:356': 'strength_5_desc',
  '17007:352': 'strength_6_title',
  '17007:358': 'strength_6_desc',
  
  // Page 3 - Improvement Boxes ROW 1 (top 3 boxes - use columns 1-3)
  '15002:483': 'weakness_1_title',
  '15002:486': 'weakness_1_desc',
  '15002:484': 'weakness_2_title',
  '15002:487': 'weakness_2_desc',
  '15002:485': 'weakness_3_title',
  '15002:488': 'weakness_3_desc',
  
  // Page 3 - Improvement Boxes ROW 2 (bottom 3 boxes - use columns 4-6)
  '17007:335': 'weakness_4_title',
  '17007:338': 'weakness_4_desc',
  '17007:336': 'weakness_5_title',
  '17007:339': 'weakness_5_desc',
  '17007:337': 'weakness_6_title',
  '17007:340': 'weakness_6_desc',
  
  // Page 3 - Bottom assessment boxes - NOT FILLED (no separate columns for these)
  // '15002:472': 'assessment_strengths',
  // '15002:473': 'assessment_weaknesses',
  
  // Page 4 - Personality
  '8029:29': 'personality_overview',
  '8027:95': 'big5_badge',
  '12027:14': 'mbti_badge',
  '12110:14': 'disc_badge',
  '12110:10': 'enneagram_badge',
  '15002:443': 'personality_strengths',
  '17003:47': 'personality_weaknesses',
  
  // Page 4 - Team Voice (5 boxes)
  '15002:595': 'team_voice_1_title',
  '15002:596': 'team_voice_1_content',
  '17010:368': 'team_voice_2_title',
  '17010:369': 'team_voice_2_content',
  '17010:365': 'team_voice_3_title',
  '17010:366': 'team_voice_3_content',
  '17010:371': 'team_voice_4_title',
  '17010:372': 'team_voice_4_content',
  '17010:374': 'team_voice_5_title',
  '17010:375': 'team_voice_5_content',
  
  // Page 4 - Development Compass (بوصلة التطوير) - 5 bullets
  '19083:81': 'development_compass',
  
  // Page 5 - Roadmap (3 items)
  '15001:151': 'roadmap_1_title',
  '15002:617': 'roadmap_1_steps',
  '15001:156': 'roadmap_2_title',
  '15002:616': 'roadmap_2_steps',
  '15001:161': 'roadmap_3_title',
  '15001:164': 'roadmap_3_steps',
  
  // Page 5 - Development Plan Track 1
  '17004:235': 'dev_track_1_title',
  '17004:240': 'dev_track_1_res_1',
  '17004:242': 'dev_track_1_res_2',
  '17004:244': 'dev_track_1_res_3',
  '17004:248': 'dev_track_1_res_4',
  '17004:246': 'dev_track_1_res_5',
  
  // Page 5 - Development Plan Track 2
  '17004:236': 'dev_track_2_title',
  '17004:264': 'dev_track_2_res_1',
  '17004:266': 'dev_track_2_res_2',
  '17004:268': 'dev_track_2_res_3',
  '17004:272': 'dev_track_2_res_4',
  '17004:270': 'dev_track_2_res_5',
  
  // Page 5 - Development Plan Track 3
  '17004:237': 'dev_track_3_title',
  '17004:250': 'dev_track_3_res_1',
  '17004:252': 'dev_track_3_res_2',
  '17004:254': 'dev_track_3_res_3',
  '17004:258': 'dev_track_3_res_4',
  '17004:256': 'dev_track_3_res_5',
  
  // Page 5 - Development Plan Track 4
  '17004:238': 'dev_track_4_title',
  '17004:274': 'dev_track_4_res_1',
  '17004:276': 'dev_track_4_res_2',
  '17004:278': 'dev_track_4_res_3',
  '17004:282': 'dev_track_4_res_4',
  '17004:280': 'dev_track_4_res_5'
};

// CSV column definitions for SHORT template (3 bullets, single paragraphs)
const SHORT_FIELDS_V2 = {
  'employee_name_cover': { type: 'single', column: 'employee_name_for_header_greeting' },
  'employee_name': { type: 'single', column: 'employee_name_for_header_greeting' },
  'status_badge': { type: 'single', column: 'leadership_path_status_badge_text' },
  'executive_summary': { type: 'single', column: 'executive_summary_intro_paragraph' },
  
  'clarity_score': { type: 'percentage', column: 'clarity_metric_percentage_score' },
  'clarity_text': { type: 'bullets', columns: ['clarity_metric_bullet_point_1', 'clarity_metric_bullet_point_2', 'clarity_metric_bullet_point_3'] },
  'efficiency_score': { type: 'percentage', column: 'efficiency_metric_percentage_score' },
  'efficiency_text': { type: 'bullets', columns: ['efficiency_metric_bullet_point_1', 'efficiency_metric_bullet_point_2', 'efficiency_metric_bullet_point_3'] },
  'safety_score': { type: 'percentage', column: 'psychological_safety_metric_percentage_score' },
  'safety_text': { type: 'bullets', columns: ['psychological_safety_metric_bullet_point_1', 'psychological_safety_metric_bullet_point_2', 'psychological_safety_metric_bullet_point_3'] },
  'empowerment_score': { type: 'percentage', column: 'empowerment_metric_percentage_score' },
  'empowerment_text': { type: 'bullets', columns: ['empowerment_metric_bullet_point_1', 'empowerment_metric_bullet_point_2', 'empowerment_metric_bullet_point_3'] },
  
  'strength_1_title': { type: 'single', column: 'strength_1_title_in_assessment_section' },
  'strength_1_desc': { type: 'single', column: 'strength_1_description_in_assessment_section' },
  'strength_2_title': { type: 'single', column: 'strength_2_title_in_assessment_section' },
  'strength_2_desc': { type: 'single', column: 'strength_2_description_in_assessment_section' },
  'strength_3_title': { type: 'single', column: 'strength_3_title_in_assessment_section' },
  'strength_3_desc': { type: 'single', column: 'strength_3_description_in_assessment_section' },
  
  'weakness_1_title': { type: 'single', column: 'weakness_1_title_in_improvement_section' },
  'weakness_1_desc': { type: 'single', column: 'weakness_1_description_in_improvement_section' },
  'weakness_2_title': { type: 'single', column: 'weakness_2_title_in_improvement_section' },
  'weakness_2_desc': { type: 'single', column: 'weakness_2_description_in_improvement_section' },
  'weakness_3_title': { type: 'single', column: 'weakness_3_title_in_improvement_section' },
  'weakness_3_desc': { type: 'single', column: 'weakness_3_description_in_improvement_section' },
  
  'personality_overview': { type: 'single', column: 'personality_analysis_overview_paragraph' },
  'mbti_badge': { type: 'link', columns: ['mbti_personality_type_badge_code', 'mbti_assessment_url'] },
  'big5_badge': { type: 'link', columns: ['big_five_trait_badge_code', 'big_five_assessment_url'] },
  'disc_badge': { type: 'link', columns: ['disc_behavioral_style_badge_code', 'disc_assessment_url'] },
  'enneagram_badge': { type: 'link', columns: ['enneagram_personality_type_badge_code', 'enneagram_assessment_url'] },
  'personality_strengths': { type: 'bullets', columns: ['personality_strength_bullet_1', 'personality_strength_bullet_2', 'personality_strength_bullet_3', 'personality_strength_bullet_4', 'personality_strength_bullet_5'] },
  'personality_weaknesses': { type: 'bullets', columns: ['personality_weakness_bullet_1', 'personality_weakness_bullet_2', 'personality_weakness_bullet_3', 'personality_weakness_bullet_4', 'personality_weakness_bullet_5'] },
  
  'team_voice_1_title': { type: 'single', column: 'team_voice_feedback_box_1_title' },
  'team_voice_1_content': { type: 'single', column: 'team_voice_feedback_box_1_content' },
  'team_voice_2_title': { type: 'single', column: 'team_voice_feedback_box_2_title' },
  'team_voice_2_content': { type: 'single', column: 'team_voice_feedback_box_2_content' },
  'team_voice_3_title': { type: 'single', column: 'team_voice_feedback_box_3_title' },
  'team_voice_3_content': { type: 'single', column: 'team_voice_feedback_box_3_content' },
  'team_voice_4_title': { type: 'single', column: 'team_voice_feedback_box_4_title' },
  'team_voice_4_content': { type: 'single', column: 'team_voice_feedback_box_4_content' },
  
  'roadmap_1_title': { type: 'single', column: 'roadmap_priority_1_highest_action_title' },
  'roadmap_1_steps': { type: 'roadmap_bullets', columns: ['roadmap_priority_1_highest_step_1', 'roadmap_priority_1_highest_step_2', 'roadmap_priority_1_highest_step_3', 'roadmap_priority_1_highest_step_4'] },
  'roadmap_2_title': { type: 'single', column: 'roadmap_priority_2_urgent_action_title' },
  'roadmap_2_steps': { type: 'roadmap_bullets', columns: ['roadmap_priority_2_urgent_step_1', 'roadmap_priority_2_urgent_step_2', 'roadmap_priority_2_urgent_step_3', 'roadmap_priority_2_urgent_step_4'] },
  'roadmap_3_title': { type: 'single', column: 'roadmap_priority_3_ongoing_action_title' },
  'roadmap_3_steps': { type: 'roadmap_bullets', columns: ['roadmap_priority_3_ongoing_step_1', 'roadmap_priority_3_ongoing_step_2', 'roadmap_priority_3_ongoing_step_3', 'roadmap_priority_3_ongoing_step_4'] },
  
  'dev_track_1_title': { type: 'single', column: 'dev_plan_track_1_category_title' },
  'dev_track_1_res_1': { type: 'link', columns: ['dev_plan_track_1_resource_1_short_title', 'dev_plan_track_1_resource_1_url_link'] },
  'dev_track_1_res_2': { type: 'link', columns: ['dev_plan_track_1_resource_2_short_title', 'dev_plan_track_1_resource_2_url_link'] },
  'dev_track_1_res_3': { type: 'link', columns: ['dev_plan_track_1_resource_3_short_title', 'dev_plan_track_1_resource_3_url_link'] },
  'dev_track_1_res_4': { type: 'link', columns: ['dev_plan_track_1_resource_4_short_title', 'dev_plan_track_1_resource_4_url_link'] },
  'dev_track_1_res_5': { type: 'link', columns: ['dev_plan_track_1_resource_5_short_title', 'dev_plan_track_1_resource_5_url_link'] },
  
  'dev_track_2_title': { type: 'single', column: 'dev_plan_track_2_category_title' },
  'dev_track_2_res_1': { type: 'link', columns: ['dev_plan_track_2_resource_1_short_title', 'dev_plan_track_2_resource_1_url_link'] },
  'dev_track_2_res_2': { type: 'link', columns: ['dev_plan_track_2_resource_2_short_title', 'dev_plan_track_2_resource_2_url_link'] },
  'dev_track_2_res_3': { type: 'link', columns: ['dev_plan_track_2_resource_3_short_title', 'dev_plan_track_2_resource_3_url_link'] },
  'dev_track_2_res_4': { type: 'link', columns: ['dev_plan_track_2_resource_4_short_title', 'dev_plan_track_2_resource_4_url_link'] },
  'dev_track_2_res_5': { type: 'link', columns: ['dev_plan_track_2_resource_5_short_title', 'dev_plan_track_2_resource_5_url_link'] },
  
  'dev_track_3_title': { type: 'single', column: 'dev_plan_track_3_category_title' },
  'dev_track_3_res_1': { type: 'link', columns: ['dev_plan_track_3_resource_1_short_title', 'dev_plan_track_3_resource_1_url_link'] },
  'dev_track_3_res_2': { type: 'link', columns: ['dev_plan_track_3_resource_2_short_title', 'dev_plan_track_3_resource_2_url_link'] },
  'dev_track_3_res_3': { type: 'link', columns: ['dev_plan_track_3_resource_3_short_title', 'dev_plan_track_3_resource_3_url_link'] },
  'dev_track_3_res_4': { type: 'link', columns: ['dev_plan_track_3_resource_4_short_title', 'dev_plan_track_3_resource_4_url_link'] },
  'dev_track_3_res_5': { type: 'link', columns: ['dev_plan_track_3_resource_5_short_title', 'dev_plan_track_3_resource_5_url_link'] },
  
  'dev_track_4_title': { type: 'single', column: 'dev_plan_track_4_category_title' },
  'dev_track_4_res_1': { type: 'link', columns: ['dev_plan_track_4_resource_1_short_title', 'dev_plan_track_4_resource_1_url_link'] },
  'dev_track_4_res_2': { type: 'link', columns: ['dev_plan_track_4_resource_2_short_title', 'dev_plan_track_4_resource_2_url_link'] },
  'dev_track_4_res_3': { type: 'link', columns: ['dev_plan_track_4_resource_3_short_title', 'dev_plan_track_4_resource_3_url_link'] },
  'dev_track_4_res_4': { type: 'link', columns: ['dev_plan_track_4_resource_4_short_title', 'dev_plan_track_4_resource_4_url_link'] },
  'dev_track_4_res_5': { type: 'link', columns: ['dev_plan_track_4_resource_5_short_title', 'dev_plan_track_4_resource_5_url_link'] }
};

// CSV column definitions for EXTENDED template (uses 5 bullets + extended columns)
const EXTENDED_FIELDS_V2 = {
  'employee_name_cover': { type: 'single', column: 'employee_name_for_header_greeting' },
  'employee_name': { type: 'single', column: 'employee_name_for_header_greeting' },
  'status_badge': { type: 'single', column: 'leadership_path_status_badge_text' },
  'executive_summary': { type: 'single', column: 'executive_summary_intro_paragraph' },
  
  // Page 2 - New Analysis Boxes (title + 5 bullets each)
  'executive_summary_2_title': { type: 'single', column: 'executive_summary_2_title' },
  'executive_summary_2_bullets': { type: 'bullets', columns: ['executive_summary_2_bullet_1', 'executive_summary_2_bullet_2', 'executive_summary_2_bullet_3', 'executive_summary_2_bullet_4', 'executive_summary_2_bullet_5'] },
  'personality_overview_2_title': { type: 'single', column: 'personality_overview_2_title' },
  'personality_overview_2_bullets': { type: 'bullets', columns: ['personality_overview_2_bullet_1', 'personality_overview_2_bullet_2', 'personality_overview_2_bullet_3', 'personality_overview_2_bullet_4', 'personality_overview_2_bullet_5'] },
  
  'clarity_score': { type: 'percentage', column: 'clarity_metric_percentage_score' },
  'clarity_text': { type: 'bullets', columns: ['clarity_metric_bullet_point_1', 'clarity_metric_bullet_point_2', 'clarity_metric_bullet_point_3', 'clarity_metric_bullet_point_4', 'clarity_metric_bullet_point_5_extended'] },
  'efficiency_score': { type: 'percentage', column: 'efficiency_metric_percentage_score' },
  'efficiency_text': { type: 'bullets', columns: ['efficiency_metric_bullet_point_1', 'efficiency_metric_bullet_point_2', 'efficiency_metric_bullet_point_3', 'efficiency_metric_bullet_point_4', 'efficiency_metric_bullet_point_5_extended'] },
  'safety_score': { type: 'percentage', column: 'psychological_safety_metric_percentage_score' },
  'safety_text': { type: 'bullets', columns: ['psychological_safety_metric_bullet_point_1', 'psychological_safety_metric_bullet_point_2', 'psychological_safety_metric_bullet_point_3', 'psychological_safety_metric_bullet_point_4', 'psychological_safety_metric_bullet_point_5_extended'] },
  'empowerment_score': { type: 'percentage', column: 'empowerment_metric_percentage_score' },
  'empowerment_text': { type: 'bullets', columns: ['empowerment_metric_bullet_point_1', 'empowerment_metric_bullet_point_2', 'empowerment_metric_bullet_point_3', 'empowerment_metric_bullet_point_4', 'empowerment_metric_bullet_point_5_extended'] },
  
  // Strengths 1-3 (row 1)
  'strength_1_title': { type: 'single', column: 'strength_1_title_in_assessment_section' },
  'strength_1_desc': { type: 'single', column: 'strength_1_description_in_assessment_section' },
  'strength_2_title': { type: 'single', column: 'strength_2_title_in_assessment_section' },
  'strength_2_desc': { type: 'single', column: 'strength_2_description_in_assessment_section' },
  'strength_3_title': { type: 'single', column: 'strength_3_title_in_assessment_section' },
  'strength_3_desc': { type: 'single', column: 'strength_3_description_in_assessment_section' },
  
  // Strengths 4-6 (row 2)
  'strength_4_title': { type: 'single', column: 'strength_4_title_extended' },
  'strength_4_desc': { type: 'single', column: 'strength_4_description_extended' },
  'strength_5_title': { type: 'single', column: 'strength_5_title_extended' },
  'strength_5_desc': { type: 'single', column: 'strength_5_description_extended' },
  'strength_6_title': { type: 'single', column: 'strength_6_title_extended' },
  'strength_6_desc': { type: 'single', column: 'strength_6_description_extended' },
  
  // Weaknesses 1-3 (row 1)
  'weakness_1_title': { type: 'single', column: 'weakness_1_title_in_improvement_section' },
  'weakness_1_desc': { type: 'single', column: 'weakness_1_description_in_improvement_section' },
  'weakness_2_title': { type: 'single', column: 'weakness_2_title_in_improvement_section' },
  'weakness_2_desc': { type: 'single', column: 'weakness_2_description_in_improvement_section' },
  'weakness_3_title': { type: 'single', column: 'weakness_3_title_in_improvement_section' },
  'weakness_3_desc': { type: 'single', column: 'weakness_3_description_in_improvement_section' },
  
  // Weaknesses 4-6 (row 2)
  'weakness_4_title': { type: 'single', column: 'weakness_4_title_extended' },
  'weakness_4_desc': { type: 'single', column: 'weakness_4_description_extended' },
  'weakness_5_title': { type: 'single', column: 'weakness_5_title_extended' },
  'weakness_5_desc': { type: 'single', column: 'weakness_5_description_extended' },
  'weakness_6_title': { type: 'single', column: 'weakness_6_title_extended' },
  'weakness_6_desc': { type: 'single', column: 'weakness_6_description_extended' },
  
  'assessment_strengths': { type: 'bullets', columns: ['personality_strength_bullet_1', 'personality_strength_bullet_2', 'personality_strength_bullet_3', 'personality_strength_bullet_4', 'personality_strength_bullet_5'] },
  'assessment_weaknesses': { type: 'bullets', columns: ['personality_weakness_bullet_1', 'personality_weakness_bullet_2', 'personality_weakness_bullet_3', 'personality_weakness_bullet_4', 'personality_weakness_bullet_5'] },
  
  'personality_overview': { type: 'single', column: 'personality_analysis_overview_paragraph' },
  'mbti_badge': { type: 'link', columns: ['mbti_personality_type_badge_code', 'mbti_assessment_url'] },
  'big5_badge': { type: 'link', columns: ['big_five_trait_badge_code', 'big_five_assessment_url'] },
  'disc_badge': { type: 'link', columns: ['disc_behavioral_style_badge_code', 'disc_assessment_url'] },
  'enneagram_badge': { type: 'link', columns: ['enneagram_personality_type_badge_code', 'enneagram_assessment_url'] },
  'personality_strengths': { type: 'bullets', columns: ['personality_strength_bullet_1', 'personality_strength_bullet_2', 'personality_strength_bullet_3', 'personality_strength_bullet_4', 'personality_strength_bullet_5'] },
  'personality_weaknesses': { type: 'bullets', columns: ['personality_weakness_bullet_1', 'personality_weakness_bullet_2', 'personality_weakness_bullet_3', 'personality_weakness_bullet_4', 'personality_weakness_bullet_5'] },
  
  'team_voice_1_title': { type: 'single', column: 'team_voice_feedback_box_1_title' },
  'team_voice_1_content': { type: 'single', column: 'team_voice_feedback_box_1_content' },
  'team_voice_2_title': { type: 'single', column: 'team_voice_feedback_box_2_title' },
  'team_voice_2_content': { type: 'single', column: 'team_voice_feedback_box_2_content' },
  'team_voice_3_title': { type: 'single', column: 'team_voice_feedback_box_3_title' },
  'team_voice_3_content': { type: 'single', column: 'team_voice_feedback_box_3_content' },
  'team_voice_4_title': { type: 'single', column: 'team_voice_feedback_box_4_title' },
  'team_voice_4_content': { type: 'single', column: 'team_voice_feedback_box_4_content' },
  'team_voice_5_title': { type: 'single', column: 'team_voice_feedback_box_5_title_extended' },
  'team_voice_5_content': { type: 'single', column: 'team_voice_feedback_box_5_content_extended' },
  
  'development_compass': { type: 'bullets', columns: ['development_compass_1', 'development_compass_2', 'development_compass_3', 'development_compass_4', 'development_compass_5'] },
  
  'roadmap_1_title': { type: 'single', column: 'roadmap_priority_1_highest_action_title' },
  'roadmap_1_steps': { type: 'roadmap_bullets', columns: ['roadmap_priority_1_highest_step_1', 'roadmap_priority_1_highest_step_2', 'roadmap_priority_1_highest_step_3', 'roadmap_priority_1_highest_step_4', 'roadmap_priority_1_highest_step_5_extended'] },
  'roadmap_2_title': { type: 'single', column: 'roadmap_priority_2_urgent_action_title' },
  'roadmap_2_steps': { type: 'roadmap_bullets', columns: ['roadmap_priority_2_urgent_step_1', 'roadmap_priority_2_urgent_step_2', 'roadmap_priority_2_urgent_step_3', 'roadmap_priority_2_urgent_step_4', 'roadmap_priority_2_urgent_step_5_extended'] },
  'roadmap_3_title': { type: 'single', column: 'roadmap_priority_3_ongoing_action_title' },
  'roadmap_3_steps': { type: 'roadmap_bullets', columns: ['roadmap_priority_3_ongoing_step_1', 'roadmap_priority_3_ongoing_step_2', 'roadmap_priority_3_ongoing_step_3', 'roadmap_priority_3_ongoing_step_4', 'roadmap_priority_3_ongoing_step_5_extended'] },
  
  'dev_track_1_title': { type: 'single', column: 'dev_plan_track_1_category_title' },
  'dev_track_1_res_1': { type: 'link', columns: ['dev_plan_track_1_resource_1_short_title', 'dev_plan_track_1_resource_1_url_link'] },
  'dev_track_1_res_2': { type: 'link', columns: ['dev_plan_track_1_resource_2_short_title', 'dev_plan_track_1_resource_2_url_link'] },
  'dev_track_1_res_3': { type: 'link', columns: ['dev_plan_track_1_resource_3_short_title', 'dev_plan_track_1_resource_3_url_link'] },
  'dev_track_1_res_4': { type: 'link', columns: ['dev_plan_track_1_resource_4_short_title', 'dev_plan_track_1_resource_4_url_link'] },
  'dev_track_1_res_5': { type: 'link', columns: ['dev_plan_track_1_resource_5_short_title', 'dev_plan_track_1_resource_5_url_link'] },
  
  'dev_track_2_title': { type: 'single', column: 'dev_plan_track_2_category_title' },
  'dev_track_2_res_1': { type: 'link', columns: ['dev_plan_track_2_resource_1_short_title', 'dev_plan_track_2_resource_1_url_link'] },
  'dev_track_2_res_2': { type: 'link', columns: ['dev_plan_track_2_resource_2_short_title', 'dev_plan_track_2_resource_2_url_link'] },
  'dev_track_2_res_3': { type: 'link', columns: ['dev_plan_track_2_resource_3_short_title', 'dev_plan_track_2_resource_3_url_link'] },
  'dev_track_2_res_4': { type: 'link', columns: ['dev_plan_track_2_resource_4_short_title', 'dev_plan_track_2_resource_4_url_link'] },
  'dev_track_2_res_5': { type: 'link', columns: ['dev_plan_track_2_resource_5_short_title', 'dev_plan_track_2_resource_5_url_link'] },
  
  'dev_track_3_title': { type: 'single', column: 'dev_plan_track_3_category_title' },
  'dev_track_3_res_1': { type: 'link', columns: ['dev_plan_track_3_resource_1_short_title', 'dev_plan_track_3_resource_1_url_link'] },
  'dev_track_3_res_2': { type: 'link', columns: ['dev_plan_track_3_resource_2_short_title', 'dev_plan_track_3_resource_2_url_link'] },
  'dev_track_3_res_3': { type: 'link', columns: ['dev_plan_track_3_resource_3_short_title', 'dev_plan_track_3_resource_3_url_link'] },
  'dev_track_3_res_4': { type: 'link', columns: ['dev_plan_track_3_resource_4_short_title', 'dev_plan_track_3_resource_4_url_link'] },
  'dev_track_3_res_5': { type: 'link', columns: ['dev_plan_track_3_resource_5_short_title', 'dev_plan_track_3_resource_5_url_link'] },
  
  'dev_track_4_title': { type: 'single', column: 'dev_plan_track_4_category_title' },
  'dev_track_4_res_1': { type: 'link', columns: ['dev_plan_track_4_resource_1_short_title', 'dev_plan_track_4_resource_1_url_link'] },
  'dev_track_4_res_2': { type: 'link', columns: ['dev_plan_track_4_resource_2_short_title', 'dev_plan_track_4_resource_2_url_link'] },
  'dev_track_4_res_3': { type: 'link', columns: ['dev_plan_track_4_resource_3_short_title', 'dev_plan_track_4_resource_3_url_link'] },
  'dev_track_4_res_4': { type: 'link', columns: ['dev_plan_track_4_resource_4_short_title', 'dev_plan_track_4_resource_4_url_link'] },
  'dev_track_4_res_5': { type: 'link', columns: ['dev_plan_track_4_resource_5_short_title', 'dev_plan_track_4_resource_5_url_link'] }
};

console.log('✅ Loaded SHORT template:', Object.keys(SHORT_MAPPINGS_V2).length, 'mappings');
console.log('✅ Loaded EXTENDED template:', Object.keys(EXTENDED_MAPPINGS_V2).length, 'mappings');

figma.ui.onmessage = async (msg) => {
  console.log('✅ Received message:', msg.type);

  if (msg.type === 'detect-template') {
    try {
      // Check if this is the leadership template
      const hasRoadmap = figma.currentPage.findOne(n => n.name && n.name.includes('خارطـة التحسيـن'));
      const hasDevPlan = figma.currentPage.findOne(n => n.name && n.name.includes('خطـة التطويـر'));
      
      if (hasRoadmap && hasDevPlan) {
        console.log('✅ Leadership template detected!');
        figma.ui.postMessage({ 
          type: 'template-detected', 
          template: 'leadership',
          name: 'قالب تقارير القيادة'
        });
      } else {
        console.log('❌ Template not recognized');
        figma.ui.postMessage({ 
          type: 'template-not-found'
        });
      }
    } catch (err) {
      console.error('❌ Template detection error:', err);
      figma.ui.postMessage({ type: 'error', message: err.message });
    }
  }

  if (msg.type === 'process-reports') {
    console.log('🎯🎯🎯 RECEIVED PROCESS-REPORTS MESSAGE');
    console.log('isProcessing:', isProcessing);
    console.log('csvData length:', msg.csvData ? msg.csvData.length : 'NO DATA');
    
    if (isProcessing) {
      console.log('⚠️ Already processing');
      return;
    }

    isProcessing = true;
    const { csvData } = msg;
    
    console.log('\n🚀 ========== PROCESSING REPORTS ==========');
    console.log('📊 Total reports:', csvData.length);
    console.log('🔗 SHORT mappings:', Object.keys(SHORT_MAPPINGS_V2).length);
    console.log('🔗 EXTENDED mappings:', Object.keys(EXTENDED_MAPPINGS_V2).length);
    console.log('First row keys:', csvData[0] ? Object.keys(csvData[0]).slice(0, 10) : 'NO FIRST ROW');

    (async () => {
      console.log('✅✅✅ ASYNC FUNCTION STARTED');
      try {
        console.log('✅ Entered try block');
        // Store original formatting for BOTH templates
        console.log('💾 Storing original formatting...');
        const allMappings = Object.assign({}, SHORT_MAPPINGS_V2, EXTENDED_MAPPINGS_V2);
        for (const [nodeId] of Object.entries(allMappings)) {
          const node = figma.getNodeById(nodeId);
          if (node && node.type === 'TEXT') {
            originalFormatting.set(nodeId, {
              fontSize: node.fontSize,
              fontName: node.fontName,
              textAlignHorizontal: node.textAlignHorizontal,
              textAlignVertical: node.textAlignVertical,
              letterSpacing: node.letterSpacing,
              lineHeight: node.lineHeight,
              paragraphSpacing: node.paragraphSpacing,
              fills: JSON.parse(JSON.stringify(node.fills))
            });
          }
        }
        console.log('✅ Stored formatting for', originalFormatting.size, 'nodes');

        // Load fonts for BOTH templates
        console.log('🔤 Loading fonts...');
        const uniqueFonts = new Set();
        for (const [nodeId] of Object.entries(allMappings)) {
          const node = figma.getNodeById(nodeId);
          if (node && node.type === 'TEXT') {
            const fontKey = `${node.fontName.family}-${node.fontName.style}`;
            uniqueFonts.add(fontKey);
            try {
              await figma.loadFontAsync(node.fontName);
            } catch (err) {
              console.warn(`⚠️ Font load warning: ${fontKey}`);
            }
          }
        }
        console.log('✅ Loaded', uniqueFonts.size, 'unique fonts');

        // Process each row
        for (let i = 0; i < csvData.length; i++) {
          const row = csvData[i];
          const reportName = row['employee_name_for_header_greeting'] || `Report_${i + 1}`;
          
          // 🎯 DETECT TEMPLATE TYPE FROM CSV
          // Default to SHORT if column is missing or empty
          const isExtendedValue = row['is_extended_report'];
          const isExtended = isExtendedValue === 'نعم' || isExtendedValue === 'yes' || isExtendedValue === 'YES';
          const templateType = isExtended ? 'EXTENDED' : 'SHORT';
          
          console.log(`\n📄 ========== ROW ${i + 1}/${csvData.length}: ${reportName} ==========`);
          console.log(`📋 Template: ${templateType} (is_extended_report = "${isExtendedValue || 'NOT SET - defaulting to SHORT'}")`);
          
          // Select appropriate mappings based on template type
          const TEMPLATE_MAPPINGS = getTemplateMappings(isExtended);
          const FIELD_DEFS = getFieldDefinitions(isExtended);
          
          console.log(`✅ Using ${Object.keys(TEMPLATE_MAPPINGS).length} node mappings for ${templateType} template`);
          
          // DEBUG: Show first few column values
          console.log('🔍 DEBUG - Sample data:');
          console.log('  employee_name_for_header_greeting:', row['employee_name_for_header_greeting']);
          console.log('  leadership_path_status_badge_text:', row['leadership_path_status_badge_text']);
          console.log('  clarity_metric_percentage_score:', row['clarity_metric_percentage_score']);
          console.log('  Total keys in row:', Object.keys(row).length);
          console.log('  First 5 keys:', Object.keys(row).slice(0, 5));
          
          figma.ui.postMessage({
            type: 'progress',
            current: i + 1,
            total: csvData.length,
            name: reportName
          });

          let filled = 0;
          let skipped = 0;

          // Fill each field
          for (const [nodeId, fieldKey] of Object.entries(TEMPLATE_MAPPINGS)) {
            const node = figma.getNodeById(nodeId);
            
            if (!node || node.type !== 'TEXT') {
              console.log(`  ⏭️ Skip ${fieldKey} - not TEXT`);
              skipped++;
              continue;
            }

            const definition = FIELD_DEFS[fieldKey];
            if (!definition) {
              console.log(`  ⚠️ No definition for ${fieldKey}`);
              skipped++;
              continue;
            }

            try {
              let value = null;
              let linkUrl = null;

              // Get value based on type
              if (definition.type === 'single') {
                value = row[definition.column] || '';
                
                // Special handling: Extract first name only for page 2 greeting
                // Works for BOTH SHORT (19029:40) and EXTENDED (1:72) templates
                if ((nodeId === '1:72' || nodeId === '19029:40') && value) {
                  const fullName = value.trim();
                  const firstName = fullName.split(/\s+/)[0];  // Get first word only
                  value = firstName;
                  console.log(`  🔤 Extracted first name: "${firstName}" from "${fullName}"`);
                }
              } else if (definition.type === 'truncated') {
                // Special type for Page 3 Extended strength/weakness boxes
                // Limits to ~4 bullet points by splitting on bullet markers
                const fullText = row[definition.column] || '';
                if (fullText) {
                  // Split on common bullet markers: •, *, -, or numbers
                  const bullets = fullText.split(/[•\*\-]|\d+\./g)
                    .map(b => b.trim())
                    .filter(b => b.length > 0)
                    .slice(0, 4);  // Take only first 4
                  
                  // Rejoin with bullet markers
                  value = bullets.map(b => '• ' + b).join('\n');
                  console.log(`  ✂️ Truncated to 4 bullets (was ${fullText.split(/[•\*\-]/).length - 1} bullets)`);
                } else {
                  value = '';
                }
              } else if (definition.type === 'percentage') {
                const score = row[definition.column] || '';
                value = score ? `%${score}` : '';
              } else if (definition.type === 'bullets') {
                const bullets = definition.columns
                  .map(col => row[col] || '')
                  .filter(x => x.trim());
                value = bullets.join('\n');
              } else if (definition.type === 'roadmap_bullets') {
                // Special type for Page 4 roadmap - adds bullet symbols
                const bullets = definition.columns
                  .map(col => row[col] || '')
                  .filter(x => x.trim())
                  .map(bullet => '• ' + bullet);
                value = bullets.join('\n');
              } else if (definition.type === 'paragraph') {
                const steps = definition.columns
                  .map(col => row[col] || '')
                  .filter(x => x.trim());
                value = steps.join(' ');
              } else if (definition.type === 'link') {
                const [titleCol, urlCol] = definition.columns;
                value = row[titleCol] || '';
                const csvUrl = row[urlCol] || '';
                
                // Personality badges use CSV URLs directly
                // Development resources use database lookup
                const isPersonalityBadge = ['mbti_badge', 'big5_badge', 'disc_badge', 'enneagram_badge'].includes(fieldKey);
                
                if (isPersonalityBadge) {
                  console.log(`  🎯 PERSONALITY BADGE: ${fieldKey}`);
                  linkUrl = getPersonalityUrl(value, csvUrl);
                } else {
                  console.log(`  📚 DEVELOPMENT RESOURCE: ${fieldKey}`);
                  linkUrl = lookupResourceUrl(value, csvUrl);
                  // Add emoji to development resources
                  value = addResourceEmoji(value);
                }
              }

              if (!value || !value.trim()) {
                console.log(`  ⏭️ Skip ${fieldKey} - empty`);
                skipped++;
                continue;
              }

              // Fill the field
              await figma.loadFontAsync(node.fontName);
              node.characters = value;

              // Add hyperlink if applicable
              if (linkUrl) {
                node.setRangeHyperlink(0, value.length, {
                  type: 'URL',
                  value: linkUrl
                });
                console.log(`  🔗 ${fieldKey}: "${value}" → ${linkUrl.substring(0, 30)}...`);
              } else {
                console.log(`  ✅ ${fieldKey}: "${value.substring(0, 40)}..."`);
              }

              // Restore formatting
              const fmt = originalFormatting.get(nodeId);
              if (fmt) {
                if (typeof fmt.fontSize === 'number') node.fontSize = fmt.fontSize;
                if (fmt.textAlignHorizontal) node.textAlignHorizontal = fmt.textAlignHorizontal;
                if (fmt.textAlignVertical) node.textAlignVertical = fmt.textAlignVertical;
                if (fmt.letterSpacing) node.letterSpacing = fmt.letterSpacing;
                if (fmt.lineHeight) node.lineHeight = fmt.lineHeight;
                if (fmt.paragraphSpacing !== undefined) node.paragraphSpacing = fmt.paragraphSpacing;
                if (fmt.fills) node.fills = fmt.fills;
              }

              filled++;
            } catch (err) {
              console.error(`  ❌ Error on ${fieldKey}:`, err.message);
              skipped++;
            }
          }

          console.log(`📊 Summary: ${filled} filled, ${skipped} skipped`);

          // CALCULATE AVERAGE METRIC & DETERMINE COLOR/TEXT
          console.log('🎨 Calculating metrics for color/badge...');
          
          // Read raw scores from CSV
          let empowermentScore = parseFloat(row['empowerment_metric_percentage_score']) || 0;
          let safetyScore = parseFloat(row['psychological_safety_metric_percentage_score']) || 0;
          let efficiencyScore = parseFloat(row['efficiency_metric_percentage_score']) || 0;
          let clarityScore = parseFloat(row['clarity_metric_percentage_score']) || 0;
          
          console.log(`  📊 Original scores: Emp=${empowermentScore}, Saf=${safetyScore}, Eff=${efficiencyScore}, Cla=${clarityScore}`);
          
          // RULE 1: Cap any score > 95 by reducing 5 points
          if (empowermentScore > 95) {
            empowermentScore -= 5;
            console.log(`  ⚠️ Empowerment capped: ${empowermentScore + 5} → ${empowermentScore}`);
          }
          if (safetyScore > 95) {
            safetyScore -= 5;
            console.log(`  ⚠️ Safety capped: ${safetyScore + 5} → ${safetyScore}`);
          }
          if (efficiencyScore > 95) {
            efficiencyScore -= 5;
            console.log(`  ⚠️ Efficiency capped: ${efficiencyScore + 5} → ${efficiencyScore}`);
          }
          if (clarityScore > 95) {
            clarityScore -= 5;
            console.log(`  ⚠️ Clarity capped: ${clarityScore + 5} → ${clarityScore}`);
          }
          
          // RULE 2: If all scores identical AND >= 90, randomize ±1-2 points
          const allIdentical = (empowermentScore === safetyScore && 
                               safetyScore === efficiencyScore && 
                               efficiencyScore === clarityScore);
          
          if (allIdentical && empowermentScore >= 90) {
            console.log(`  🎲 All scores identical (${empowermentScore}) and ≥90. Randomizing...`);
            
            // Create randomized adjustments: [-2, -1, +1, +2] shuffled
            const adjustments = [-2, -1, +1, +2];
            // Fisher-Yates shuffle
            for (let i = adjustments.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              [adjustments[i], adjustments[j]] = [adjustments[j], adjustments[i]];
            }
            
            empowermentScore += adjustments[0];
            safetyScore += adjustments[1];
            efficiencyScore += adjustments[2];
            clarityScore += adjustments[3];
            
            console.log(`  🎲 Randomized: Emp=${empowermentScore}, Saf=${safetyScore}, Eff=${efficiencyScore}, Cla=${clarityScore}`);
          }
          
          // Final adjusted scores
          const metrics = [empowermentScore, safetyScore, efficiencyScore, clarityScore];
          
          let avgMetric = metrics.reduce((a, b) => a + b, 0) / metrics.length;
          console.log(`  ✅ Final scores: ${metrics.join(', ')}`);
          console.log(`  ✅ Average: ${avgMetric.toFixed(1)}%`);
          
          // FIXED SCORE OVERRIDES FOR SPECIFIC PEOPLE (main badge only)
          const FIXED_BADGE_SCORES = {
            'إبراهيم القرعاوي': 69.4,
            'البراء العوهلي': 92.5,
            'شهاب سمير': 94.1,
            'عبدالقدوس': 90.4,
            'وهاب محمد': 73.9,
            'معاذ الحربي': 74.4,
            'علي بوصالح': 90.7,
            'مشاري الحمود': 81.4,
            'محمد عطاالله': 86.9,
            'أنس الأهدل': 82.3,
            'عبدالرحمن أبومالح': 78.8,
            'أسيل باعبدالله - إنتاج': 76.7,
            'فيصل الغامدي': 80.9,
            'محمد هاني': 77.2,
            'أسيل باعبدالله - كامل': 72.9,
            'أسيل باعبدالله - تسويق': 63.5,
            'ميسم المنيع': 85.0
          };
          
          const employeeName = row['employee_name_for_header_greeting'] || '';
          const fixedScore = FIXED_BADGE_SCORES[employeeName];
          
          if (fixedScore !== undefined) {
            console.log(`  🔒 FIXED SCORE OVERRIDE for "${employeeName}": ${avgMetric.toFixed(1)}% → ${fixedScore}%`);
            avgMetric = fixedScore;
          }
          
          let bgColor = null;
          let badgeText = '';
          
          if (avgMetric >= 92) {
            bgColor = { r: 220/255, g: 235/255, b: 194/255 };  // #DCEBC2 - Light green
            badgeText = 'فخر';
            console.log('  🟢 LIGHT GREEN (100-92%): فخر');
          } else if (avgMetric >= 83) {
            bgColor = { r: 215/255, g: 237/255, b: 191/255 };  // #D7EDBF - Pale green
            badgeText = 'خضر';
            console.log('  🟩 PALE GREEN (92-83%): خضر');
          } else if (avgMetric >= 74) {
            bgColor = { r: 240/255, g: 217/255, b: 156/255 };  // #F0D99C - Beige
            badgeText = 'صفر';
            console.log('  🟡 BEIGE (83-74%): صفر');
          } else if (avgMetric >= 64) {
            bgColor = { r: 234/255, g: 169/255, b: 164/255 };  // #EAA9A4 - Light pink
            badgeText = 'حمر';
            console.log('  🟠 LIGHT PINK (74-64%): حمر');
          } else {
            bgColor = { r: 182/255, g: 34/255, b: 43/255 };   // #B6222B - Dark red
            badgeText = 'خطر';
            console.log('  🔴 DARK RED (64-0%): خطر');
          }
          
          // APPLY RECTANGLE COLORS FIRST (BEFORE ANY ASYNC OPERATIONS)
          // This prevents race conditions from font loading interfering with color application
          console.log('🎨 Updating rectangle colors...');
          
          // Helper function to get color for a score
          function getColorForScore(score) {
            if (score >= 92) {
              return { r: 220/255, g: 235/255, b: 194/255 };  // #DCEBC2 - Light green bg (فخر)
            } else if (score >= 83) {
              return { r: 215/255, g: 237/255, b: 191/255 };  // #D7EDBF - Pale green bg (خضر)
            } else if (score >= 74) {
              return { r: 240/255, g: 217/255, b: 156/255 };  // #F0D99C - Beige bg (صفر)
            } else if (score >= 64) {
              return { r: 234/255, g: 169/255, b: 164/255 };  // #EAA9A4 - Light pink bg (حمر)
            } else {
              return { r: 182/255, g: 34/255, b: 43/255 };   // #B6222B - Dark red bg (خطر)
            }
          }
          
          // Helper function to get TEXT color for a score
          function getTextColorForScore(score) {
            if (score >= 92) {
              return { r: 16/255, g: 108/255, b: 62/255 };   // #106C3E - Dark green text
            } else if (score >= 83) {
              return { r: 16/255, g: 108/255, b: 62/255 };   // #106C3E - Dark green text
            } else if (score >= 74) {
              return { r: 74/255, g: 59/255, b: 4/255 };     // #4A3B04 - Dark brown text
            } else if (score >= 64) {
              return { r: 182/255, g: 34/255, b: 43/255 };   // #B6222B - Dark red text
            } else {
              return { r: 234/255, g: 169/255, b: 164/255 }; // #EAA9A4 - Light pink text (reversed)
            }
          }
          
          // TEMPLATE-AWARE RECTANGLE IDs
          const RECT_IDS = isExtended ? {
            badge: '1:92',           // Badge remains same
            empowerment: '17007:304',
            safety: '17007:305',
            efficiency: '17007:306',
            clarity: '17007:307'
          } : {
            badge: '1:92',
            empowerment: '1:112',
            safety: '1:113',
            efficiency: '1:114',
            clarity: '1:115'
          };
          
          console.log(`  📦 Using ${templateType} rectangle IDs`);
          
          // Rectangle 13 (1:92) - Badge box - uses AVERAGE (same for both templates)
          const badgeRect = figma.getNodeById(RECT_IDS.badge);
          if (badgeRect && 'fills' in badgeRect && badgeRect.fills !== figma.mixed) {
            badgeRect.fills = [{ type: 'SOLID', color: bgColor }];
            console.log(`    ✅ Badge (${RECT_IDS.badge}) - Average: ${avgMetric.toFixed(1)}%`);
          }
          
          // Empowerment rectangle
          const empowermentRect = figma.getNodeById(RECT_IDS.empowerment);
          if (empowermentRect && 'fills' in empowermentRect && empowermentRect.fills !== figma.mixed) {
            const empowermentColor = getColorForScore(empowermentScore);
            empowermentRect.fills = [{ type: 'SOLID', color: empowermentColor }];
            console.log(`    ✅ Empowerment (${RECT_IDS.empowerment}) - ${empowermentScore}%`);
          }
          
          // Safety rectangle
          const safetyRect = figma.getNodeById(RECT_IDS.safety);
          if (safetyRect && 'fills' in safetyRect && safetyRect.fills !== figma.mixed) {
            const safetyColor = getColorForScore(safetyScore);
            safetyRect.fills = [{ type: 'SOLID', color: safetyColor }];
            console.log(`    ✅ Safety (${RECT_IDS.safety}) - ${safetyScore}%`);
          }
          
          // Efficiency rectangle
          const efficiencyRect = figma.getNodeById(RECT_IDS.efficiency);
          if (efficiencyRect && 'fills' in efficiencyRect && efficiencyRect.fills !== figma.mixed) {
            const efficiencyColor = getColorForScore(efficiencyScore);
            efficiencyRect.fills = [{ type: 'SOLID', color: efficiencyColor }];
            console.log(`    ✅ Efficiency (${RECT_IDS.efficiency}) - ${efficiencyScore}%`);
          }
          
          // Clarity rectangle
          const clarityRect = figma.getNodeById(RECT_IDS.clarity);
          if (clarityRect && 'fills' in clarityRect && clarityRect.fills !== figma.mixed) {
            const clarityColor = getColorForScore(clarityScore);
            clarityRect.fills = [{ type: 'SOLID', color: clarityColor }];
            console.log(`    ✅ Clarity (${RECT_IDS.clarity}) - ${clarityScore}%`);
          }
          
          // UPDATE TEXT COLORS FOR PERCENTAGE NUMBERS
          console.log('🎨 Updating percentage text colors...');
          
          // TEMPLATE-AWARE TEXT NODE IDs
          const TEXT_IDS = isExtended ? {
            empowerment_pct: '17007:315',
            safety_pct: '17007:311',
            efficiency_pct: '17007:312',
            clarity_pct: '17007:313',
            empowerment_desc: '17007:316',
            safety_desc: '17007:317',
            efficiency_desc: '17007:318',
            clarity_desc: '17007:319'
          } : {
            empowerment_pct: '1:123',
            safety_pct: '1:119',
            efficiency_pct: '1:120',
            clarity_pct: '1:121',
            empowerment_desc: '1:124',
            safety_desc: '1:125',
            efficiency_desc: '1:126',
            clarity_desc: '1:127'
          };
          
          // Empowerment percentage text
          const empowermentText = figma.getNodeById(TEXT_IDS.empowerment_pct);
          if (empowermentText && empowermentText.type === 'TEXT') {
            const empowermentTextColor = getTextColorForScore(empowermentScore);
            await figma.loadFontAsync(empowermentText.fontName);
            empowermentText.characters = `%${Math.round(empowermentScore)}`;
            empowermentText.fills = [{ type: 'SOLID', color: empowermentTextColor }];
            console.log(`    ✅ Empowerment % (${TEXT_IDS.empowerment_pct}): ${empowermentScore}%`);
          }
          
          // Safety percentage text
          const safetyText = figma.getNodeById(TEXT_IDS.safety_pct);
          if (safetyText && safetyText.type === 'TEXT') {
            const safetyTextColor = getTextColorForScore(safetyScore);
            await figma.loadFontAsync(safetyText.fontName);
            safetyText.characters = `%${Math.round(safetyScore)}`;
            safetyText.fills = [{ type: 'SOLID', color: safetyTextColor }];
            console.log(`    ✅ Safety % (${TEXT_IDS.safety_pct}): ${safetyScore}%`);
          }
          
          // Efficiency percentage text
          const efficiencyText = figma.getNodeById(TEXT_IDS.efficiency_pct);
          if (efficiencyText && efficiencyText.type === 'TEXT') {
            const efficiencyTextColor = getTextColorForScore(efficiencyScore);
            await figma.loadFontAsync(efficiencyText.fontName);
            efficiencyText.characters = `%${Math.round(efficiencyScore)}`;
            efficiencyText.fills = [{ type: 'SOLID', color: efficiencyTextColor }];
            console.log(`    ✅ Efficiency % (${TEXT_IDS.efficiency_pct}): ${efficiencyScore}%`);
          }
          
          // Clarity percentage text
          const clarityText = figma.getNodeById(TEXT_IDS.clarity_pct);
          if (clarityText && clarityText.type === 'TEXT') {
            const clarityTextColor = getTextColorForScore(clarityScore);
            await figma.loadFontAsync(clarityText.fontName);
            clarityText.characters = `%${Math.round(clarityScore)}`;
            clarityText.fills = [{ type: 'SOLID', color: clarityTextColor }];
            console.log(`    ✅ Clarity % (${TEXT_IDS.clarity_pct}): ${clarityScore}%`);
          }
          
          // UPDATE DESCRIPTION TEXT COLORS (the long text inside boxes)
          console.log('🎨 Updating description text colors...');
          
          // Empowerment description text
          const empowermentDescText = figma.getNodeById(TEXT_IDS.empowerment_desc);
          if (empowermentDescText && empowermentDescText.type === 'TEXT') {
            const empowermentDescColor = getTextColorForScore(empowermentScore);
            await figma.loadFontAsync(empowermentDescText.fontName);
            empowermentDescText.fills = [{ type: 'SOLID', color: empowermentDescColor }];
            console.log(`    ✅ Empowerment desc (${TEXT_IDS.empowerment_desc})`);
          }
          
          // Safety description text
          const safetyDescText = figma.getNodeById(TEXT_IDS.safety_desc);
          if (safetyDescText && safetyDescText.type === 'TEXT') {
            const safetyDescColor = getTextColorForScore(safetyScore);
            await figma.loadFontAsync(safetyDescText.fontName);
            safetyDescText.fills = [{ type: 'SOLID', color: safetyDescColor }];
            console.log(`    ✅ Safety desc (${TEXT_IDS.safety_desc})`);
          }
          
          // Efficiency description text
          const efficiencyDescText = figma.getNodeById(TEXT_IDS.efficiency_desc);
          if (efficiencyDescText && efficiencyDescText.type === 'TEXT') {
            const efficiencyDescColor = getTextColorForScore(efficiencyScore);
            await figma.loadFontAsync(efficiencyDescText.fontName);
            efficiencyDescText.fills = [{ type: 'SOLID', color: efficiencyDescColor }];
            console.log(`    ✅ Efficiency desc (${TEXT_IDS.efficiency_desc})`);
          }
          
          // Clarity description text
          const clarityDescText = figma.getNodeById(TEXT_IDS.clarity_desc);
          if (clarityDescText && clarityDescText.type === 'TEXT') {
            const clarityDescColor = getTextColorForScore(clarityScore);
            await figma.loadFontAsync(clarityDescText.fontName);
            clarityDescText.fills = [{ type: 'SOLID', color: clarityDescColor }];
            console.log(`    ✅ Clarity desc (${TEXT_IDS.clarity_desc})`);
          }
          
          // UPDATE TITLE TEXT COLORS (metric names at top of boxes)
          console.log('🎨 Updating title text colors...');
          
          // TEMPLATE-AWARE TITLE NODE IDs
          const TITLE_IDS = isExtended ? {
            empowerment: '17007:314',
            safety: '17007:308',
            efficiency: '17007:309',
            clarity: '17007:310'
          } : {
            empowerment: '1:122',
            safety: '1:116',
            efficiency: '1:117',
            clarity: '1:118'
          };
          
          // Empowerment title
          const empowermentTitle = figma.getNodeById(TITLE_IDS.empowerment);
          if (empowermentTitle && empowermentTitle.type === 'TEXT') {
            const empowermentTitleColor = getTextColorForScore(empowermentScore);
            await figma.loadFontAsync(empowermentTitle.fontName);
            empowermentTitle.fills = [{ type: 'SOLID', color: empowermentTitleColor }];
            console.log(`    ✅ Empowerment title (${TITLE_IDS.empowerment})`);
          }
          
          // Safety title
          const safetyTitle = figma.getNodeById(TITLE_IDS.safety);
          if (safetyTitle && safetyTitle.type === 'TEXT') {
            const safetyTitleColor = getTextColorForScore(safetyScore);
            await figma.loadFontAsync(safetyTitle.fontName);
            safetyTitle.fills = [{ type: 'SOLID', color: safetyTitleColor }];
            console.log(`    ✅ Safety title (${TITLE_IDS.safety})`);
          }
          
          // Efficiency title
          const efficiencyTitle = figma.getNodeById(TITLE_IDS.efficiency);
          if (efficiencyTitle && efficiencyTitle.type === 'TEXT') {
            const efficiencyTitleColor = getTextColorForScore(efficiencyScore);
            await figma.loadFontAsync(efficiencyTitle.fontName);
            efficiencyTitle.fills = [{ type: 'SOLID', color: efficiencyTitleColor }];
            console.log(`    ✅ Efficiency title (${TITLE_IDS.efficiency})`);
          }
          
          // Clarity title
          const clarityTitle = figma.getNodeById(TITLE_IDS.clarity);
          if (clarityTitle && clarityTitle.type === 'TEXT') {
            const clarityTitleColor = getTextColorForScore(clarityScore);
            await figma.loadFontAsync(clarityTitle.fontName);
            clarityTitle.fills = [{ type: 'SOLID', color: clarityTitleColor }];
            console.log(`    ✅ Clarity title (${TITLE_IDS.clarity})`);
          }
          
          // NOW UPDATE BADGE TEXT (after colors are locked in)
          console.log('🎨 Updating badge text...');
          const badgeNode = figma.getNodeById('1:93');
          if (badgeNode && badgeNode.type === 'TEXT') {
            await figma.loadFontAsync(badgeNode.fontName);
            badgeNode.characters = badgeText;
            // Set badge text color based on score
            const badgeTextColor = getTextColorForScore(avgMetric);
            badgeNode.fills = [{ type: 'SOLID', color: badgeTextColor }];
            console.log(`  ✅ Badge text updated: "${badgeText}"`);
          }
          
          // UPDATE TOP BADGE TEXT (node 1:94 - "دربك")
          const topBadgeNode = figma.getNodeById('1:94');
          if (topBadgeNode && topBadgeNode.type === 'TEXT') {
            await figma.loadFontAsync(topBadgeNode.fontName);
            topBadgeNode.characters = 'دربك';
            // Set top badge text color based on score
            const topBadgeTextColor = getTextColorForScore(avgMetric);
            topBadgeNode.fills = [{ type: 'SOLID', color: topBadgeTextColor }];
            console.log(`  ✅ Top badge text: "دربك"`);
          }

          // SKIP PAGE REARRANGEMENT - Keep pages in original positions
          console.log('📐 Skipping page rearrangement (keeping original positions)');
          
          // Find only the pages for THIS template to export as PDF
          const currentTemplatePages = figma.currentPage.findAll(n => 
            n.type === 'FRAME' && 
            n.parent === figma.currentPage &&
            n.width === 595 && 
            n.height === 842
          );
          
          // Filter to only pages for this specific template based on node IDs
          const relevantPageIds = new Set();
          for (const nodeId of Object.keys(TEMPLATE_MAPPINGS)) {
            const node = figma.getNodeById(nodeId);
            if (node) {
              let parent = node.parent;
              while (parent && parent.type !== 'FRAME') {
                parent = parent.parent;
              }
              if (parent && parent.type === 'FRAME') {
                relevantPageIds.add(parent.id);
              }
            }
          }
          
          const allFrames = currentTemplatePages.filter(f => relevantPageIds.has(f.id));
          
          console.log(`  Found ${allFrames.length} pages for ${templateType} template`);
          
          // Sort by existing Y position (no movement)
          allFrames.sort((a, b) => a.y - b.y);

          // Export each frame as separate PDF page
          console.log('📄 Exporting multi-page PDF...');
          const pdfPages = [];
          
          for (let i = 0; i < allFrames.length; i++) {
            const frame = allFrames[i];
            console.log(`  📄 Exporting page ${i + 1}/${allFrames.length}: ${frame.name}`);
            const pageBytes = await frame.exportAsync({ format: 'PDF' });
            pdfPages.push(Array.from(pageBytes));
          }
          
          console.log(`✅ Exported ${pdfPages.length} pages`);

          figma.ui.postMessage({
            type: 'pdf-ready',
            pdfPages: pdfPages,  // Array of PDF byte arrays
            fileName: `${reportName.replace(/[^a-zA-Z0-9\u0600-\u06FF\s]/g, '_')}.pdf`
          });
        }

        console.log('\n🎉 ========== ALL COMPLETE ==========');
        figma.ui.postMessage({
          type: 'process-complete',
          message: `تمت معالجة ${csvData.length} تقرير بنجاح!`
        });

      } catch (err) {
        console.error('❌❌❌ FATAL ERROR IN MAIN PROCESSING:', err);
        console.error('Error message:', err.message);
        console.error('Error stack:', err.stack);
        console.error('Error name:', err.name);
        figma.ui.postMessage({ 
          type: 'error', 
          message: `خطأ فادح: ${err.message}\n\nتحقق من وحدة التحكم للحصول على التفاصيل`
        });
        alert(`ERROR: ${err.message}`);
      } finally {
        console.log('🔚 Finally block - setting isProcessing = false');
        isProcessing = false;
      }
    })();
  }
};

console.log('✅ Plugin ready');
